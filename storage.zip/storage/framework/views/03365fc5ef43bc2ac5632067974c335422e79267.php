<?php  use App\component\Content;?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php echo $__env->make('admin.report.headerReport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>		
	<a href="javascript:void(0)" class="pull-right" onclick="window.print();"><span class="btn btn-primary btn-xs"><i class="fa fa-print"></i></span></a>&nbsp;&nbsp;&nbsp;&nbsp;
	<table class="table table-bordered" id="roomrate" style="font-size: 16px;">
		<?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<tr>
					<td colspan="2">
						<address>
							<p><b>Hotel Name :</b> <?php echo e($supplier->supplier_name); ?><br>
							<b>P/H :</b> <?php echo e($supplier->supplier_phone); ?>/<?php echo e($supplier->supplier_phone2); ?><br>
							<b>Email :</b> <?php echo e($supplier->supplier_email); ?><br>
							<b>Address :</b> <?php echo e($supplier->supplier_address); ?><br>
							<b>Website :</b> <?php echo e($supplier->supplier_website); ?></p>
						</address>
						<?php echo $supplier->supplier_intro; ?></td>
				</tr>
				<td style="width: 50%; vertical-align:top;">
					<strong>Hotel Facilities</strong>
					<ul>
						<?php if($supplier->hotel_facility ): ?>
							<?php $__currentLoopData = $supplier->hotel_facility; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $hf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($hf->name); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</ul>
				</td> 
				<td style="width: 50%; vertical-align:top;">
					<strong>Hotel Info</strong>
					<ul>
						<?php if($supplier->hotel_category ): ?>
							<?php $__currentLoopData = $supplier->hotel_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $hf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($hf->name); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</ul>
				</td>	
				<?php if($supplier->supplier_pgroup): ?>
				<tr>
					<td colspan="2">
						<strong>Group Policy</strong>
						<?php echo $supplier->supplier_pgroup; ?></td>
				</tr>
				<?php endif; ?>
				<?php if($supplier->supplier_pchild): ?>
				<tr>
					<td colspan="2">
						<strong>Child Policy</strong>
						<?php echo $supplier->supplier_pchild; ?></td>
				</tr>
				<?php endif; ?>
				<?php if($supplier->supplier_pcancelation): ?>
				<tr>
					<td colspan="2">
						<strong>Canceltion Policy</strong>
						<?php echo $supplier->supplier_pcancelation; ?></td>
				</tr>
				<?php endif; ?>
				<?php if($supplier->supplier_ppayment): ?>
				<tr>
					<td colspan="2">
						<strong>Payment Policy</strong>
						<?php echo $supplier->supplier_ppayment; ?></td>
				</tr>
				<?php endif; ?>
				

				<tr>
					<td colspan="2"> <strong>Remarks:</strong><?php echo $supplier->remak; ?> </td>
				</tr>
			</tr>
		
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>