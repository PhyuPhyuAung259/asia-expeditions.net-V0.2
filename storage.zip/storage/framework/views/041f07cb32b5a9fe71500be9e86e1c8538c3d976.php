<?php $__env->startSection('title', 'Booked Cruise List'); ?>
<?php $active = 'booked/project'; 
$subactive ='booked/cruiserate';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <form method="POST" action="<?php echo e(route('searchProject', ['project'=> 'cruiserate'])); ?>">
            <?php echo e(csrf_field()); ?>

            <section class="col-lg-12 connectedSortable">
                <h3 class="border">Booked Cruise Rate List</h3>
                <?php echo $__env->make('admin.project.Search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <table class="datatable table table-hover table-striped">
                  <thead>
                    <tr>                       
                      <th width="75">Project No.</th>
                      <th>Check-In</th>
                      <th>Check-Out</th>
                      <th>Cruise Name</th>
                      <th>Cabin Type</th>
                      <?php $__currentLoopData = App\RoomCategory::take(5)->orderBy('id', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e($cat->name); ?></th>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <th class="text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crRate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr> 
                      <td class="studentId" width="75"><?php echo e($crRate->project_number); ?></td>
                      <td><?php echo e(Content::dateformat($crRate->checkin)); ?></td>
                      <td><?php echo e(Content::dateformat($crRate->checkout)); ?></td>
                      <td><?php echo e(isset($crRate->cruise->supplier_name) ? $crRate->cruise->supplier_name : ''); ?></td>
                      <td><?php echo e(isset($crRate->room->name) ? $crRate->room->name : ''); ?></td>
                      <td class="text-right"><?php echo e(number_format($crRate->ssingle, 2)); ?></td>
                      <td class="text-right"><?php echo e(number_format($crRate->stwin, 2)); ?></td>
                      <td class="text-right"><?php echo e(number_format($crRate->sdouble, 2)); ?></td>
                      <td class="text-right"><?php echo e(number_format($crRate->sextra, 2)); ?></td>
                      <td class="text-right"><?php echo e(number_format($crRate->schextra, 2)); ?></td>
                      <td class="text-right">
                        <?php if(isset($crRate->book->id)): ?>
                          <a target="_blank" href="<?php echo e(route('hVoucher', ['project'=>$crRate->project_number, 'bcruise'=> $crRate->id, 'bookid'=>$crRate->book->id, 'type'=>'cruise-voucher'])); ?>" title="Cruise Voucher">
                        <?php else: ?>
                          <a href="javascript:void(0)" title="No Cabin Rate">
                        <?php endif; ?>
                          <label class="icon-list ic_inclusion"></label>
                        </a> &nbsp;
                        &nbsp;
<!--                         <a href="javascript:void(0)" class="RemoveHotelRate" data-type="book_cruiserate" data-id="<?php echo e($crRate->id); ?>" title="Delete this Cruise Rate">
                          <label class="icon-list ic_remove"></label>
                        </a>      -->                
                        <?php echo Content::DelUserRole("Delete this Cruise Rate ?", "book_cruiserate", $crRate->id, $crRate->user_id ); ?>        
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <!-- <div class="pull-left">Check All</div> -->
            </section>
          </form>
        </div>
    </section>
  </div>
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>