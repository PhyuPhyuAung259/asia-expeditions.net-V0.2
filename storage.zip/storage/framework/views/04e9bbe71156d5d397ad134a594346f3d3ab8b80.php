<?php $__env->startSection('title', 'Booked Tour List'); ?>
<?php $active = 'booked/project'; 
  $subactive ='booked/tour';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <form method="POST" action="<?php echo e(route('searchProject', ['project'=> 'tour'])); ?>">
            <?php echo e(csrf_field()); ?>

            <section class="col-lg-12 connectedSortable">
                <h3 class="border">Booked Tours List</h3>
                <div class="col-sm-8 col-xs-12 pull-right">
                  <div class="col-md-3">
                    <input type="hidden" svalue="<?php echo e(isset($projectNum) ? $projectNum : ''); ?>" id="projectNum">
                    <input class="form-control input-sm" type="text" id="from_date" name="start_date" placeholder="From Date" value="<?php echo e(isset($startDate) ? $startDate : ''); ?>"> 
                  </div>
                  <div class="col-md-3">
                    <input class="form-control input-sm" type="text" id="to_date" name="end_date" placeholder="To Date" value="<?php echo e(isset($endDate) ? $endDate : ''); ?>"> 
                  </div>
                   <div class="col-md-2" style="padding: 0px;">
                    <button class="btn btn-default btn-sm" type="submit">Search</button>
                  </div>
                </div>
                <table class="datatable table table-hover table-striped">
                  <thead>
                    <tr>                       
                      <th width="65">Project No.</th>
                      <th>Date</th>
                      <th>Location</th>
                      <th>Tour</th>
                      <th>User</th>
                      <th>Pax</th>
                      <th>Price</th>
                      <th>Amount</th>
                      <th class="text-center">Booking Type</th>
                      <th class="text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php 
                        $tourb= \App\Tour::find($tour->tour_id);
                        $conb = \App\Country::find($tour->country_id);
                        $prob = \App\Province::find($tour->province_id);
                        $user = \App\User::find($tour->book_userId);
                      ?>
                    <tr>
                      <td><?php echo e($tour->book_project); ?></td>
                      <td><?php echo e(Content::dateformat($tour->book_checkin)); ?></td>
                      <td style="color: #605ca8;"><i class="fa fa-map-marker" ></i> <?php echo e(isset($conb->country_name) ? $conb->country_name : ''); ?> <?php echo e(isset($conb->country_name) ? $conb->country_name : ''); ?>,  <?php echo e(isset($prob->province_name) ? $prob->province_name : ''); ?></td>
                      <td><a target="_blank" href="<?php echo e(route('getTourReport', ['tour_id'=> $tourb->id, 'type'=> 'selling'])); ?>"><?php echo e(isset($tourb->tour_name) ? $tourb->tour_name : ''); ?></a></td>
                      <td><?php echo e($user['fullname']); ?></td>
                      <td><?php echo e($tour->book_pax); ?></td>
                      <td><?php echo e(Content::money($tour->book_price)); ?></td>
                      <td><?php echo e(Content::money($tour->book_amount)); ?></td>
                      <td class="text-center">
                        <?php if($tour->book_option == 1): ?>
                        <span class="text-danger">Quotation</span>
                        <?php else: ?>
                          <span class="text-success">Booking</span>
                        <?php endif; ?>
                      </td>
                      <td class="text-right">
                        <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$tour->book_project, 'type'=>'details'])); ?>" title="Program Details">
                          <label class="icon-list ic_ops_program"></label>
                        </a>
                        <a target="_blank" href="<?php echo e(route('bookingEdit', ['type'=>'tour', 'bookid'=>$tour->book_id])); ?>" title="Edit booked tour">
                          <label class="icon-list ic_edit"></label>
                        </a> 
                       <?php echo Content::DelUserRole("Delete this Tour Booked ?", "book_tour", $tour->book_id, $tour->user_id ); ?>              
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
            </section>
          </form>
        </div>
    </section>
  </div>
 <script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>