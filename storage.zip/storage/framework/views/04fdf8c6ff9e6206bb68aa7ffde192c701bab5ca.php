<?php use App\component\Content; ?>
<table class="table table-hover table-bordered excel-sheed">
	<?php if(isset($bookeds) && $bookeds != Null): ?>
	    <thead>
            <tr><td colspan="8" align="left"><font color="#1991d6"><?php echo e($supp['supplier_name']); ?></font> From <?php echo e(Content::dateformat($start_date)); ?> -> <?php echo e(Content::dateformat($end_date)); ?></td></tr>
	        <tr style="background-color: #ddd">
	          	<td width="86">File No.</td>
	          	<td>Client Name</td>
	          	<td>Start Date</td>
                <td>Service Name</td>
                <td>Vehicle</td>
	          	<td>Driver</td>
                <td class="text-right">Price <?php echo e(Content::currency()); ?></td>
                <td class="text-right">Amount <?php echo e(Content::currency()); ?></td>
	        </tr>
	    </thead>
        <tbody>
        	<?php $__currentLoopData = $bookeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $project = App\Project::where('project_number',$sub->project_number)->first(); ?>
                <tr>
                    <td><?php echo e($project['project_prefix']); ?>-<?php echo e($project['project_fileno']); ?></td>
                    <td><?php echo e($project['project_client']); ?> <small><b>x</b></small> <i>[ <?php echo e($project['project_pax']); ?> ]</i></td>
                    <td><?php echo e(Content::dateformat($sub->book['book_checkin'])); ?></td>
                    <td><?php echo e($sub->service['title']); ?></td>
                    <td><?php echo e($sub->vehicle['name']); ?></td>
                    <td><?php echo e($sub->driver['driver_name']); ?></td>
                    <td class="text-right"><?php echo e(Content::money($sub->price)); ?></td>
                    <td class="text-right"><?php echo e(Content::money($sub->kprice)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
        </tbody>
        <tfoot>
        	<tr style="border: solid 1px #ddd;">
        		<td bgcolor="#ddd" colspan="7" align="right" >
                    <font color="#1991d6">
                        <?php if($bookeds->sum('price')): ?>
                            Grand Total : <?php echo e(Content::money($bookeds->sum('price'))); ?> <?php echo e(Content::currency()); ?>

                        <?php endif; ?>
                    </font>
                </td>
                <td bgcolor="#ddd" colspan="2" align="right">
                    <font color="#1991d6">
                        <?php if($bookeds->sum('kprice')): ?>
                            Grand Total : <?php echo e(Content::money($bookeds->sum('kprice'))); ?> <?php echo e(Content::currency(1)); ?>

                        <?php endif; ?>
                    </font>
                </td>
        	</tr>
        </tfoot>
    <?php else: ?>
    	<tfoot>
        	<tr>
        		<td bgcolor="#ddd" colspan="12" class="text-center">Record Not found...</td>
        	</tr>
        </tfoot>	
    <?php endif; ?>
</table>