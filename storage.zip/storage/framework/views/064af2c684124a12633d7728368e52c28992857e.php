<?php $__env->startSection('title', 'Golf Service '); ?>
<?php
  $active = 'restaurant/menu'; 
  $subactive = 'golf/service';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <div class="row">
        <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <section class="col-lg-12 connectedSortable">
          <h3 class="border">Golf Services <span class="fa fa-angle-double-right"></span> <a href="#" class="btn btn-default btn-sm" id="addMiscService" data-toggle="modal" data-target="#myModal">Add Service</a></h3>
            <table class="datatable table table-hover table-striped">
              <thead>
                <tr>
                  <th>Golf Service</th>
                  <th>Golf Names</th>
                  <th>Price <?php echo e(Content::currency()); ?></th>
                  <th>Price Net <?php echo e(Content::currency()); ?></th>
                  <th>Price <?php echo e(Content::currency(1)); ?></th>
                  <th>Price Net <?php echo e(Content::currency(1)); ?></th>
                  <th class="text-center">Status</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $gservice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($rest->name); ?></td>
                  <td><?php echo e(isset($rest->supplier->supplier_name) ? $rest->supplier->supplier_name : ''); ?></td>                   
                  <td class="text-right"><?php echo e(number_format($rest->price,2)); ?></td>
                  <td class="text-right"><?php echo e(number_format($rest->nprice,2)); ?></td>
                  <td class="text-right"><?php echo e(number_format($rest->kprice,2)); ?></td>
                  <td class="text-right"><?php echo e(number_format($rest->nkprice,2)); ?></td>
                  <td class="text-right">                      
                    <button style="padding:0px; border:none; top: -5px; position: relative;" class="miscEdit" data-province="<?php echo e(isset($rest->supplier->id) ? $rest->supplier->id : ''); ?>" data-id="<?php echo e($rest->id); ?>"  data-title="<?php echo e($rest->name); ?>" data-price="<?php echo e($rest->price); ?>" data-nprice="<?php echo e($rest->nprice); ?>" data-kprice="<?php echo e($rest->kprice); ?>" data-nkprice="<?php echo e($rest->nkprice); ?>" data-toggle="modal" data-target="#myModal">
                      <i style="padding:1px 2px;" class="btn btn-info btn-xs fa fa-pencil-square-o"></i>
                    </button>
                    <a href="javascript:void(0)" class="RemoveHotelRate" data-type="golf_service" data-id="<?php echo e($rest->id); ?>" title="Remove this?">
                      <label src="#" class="icon-list ic-trash"></label>
                    </a>
                  </td>                     
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        </section>
      </div>
    </section>
  </div>
</div>

<div class="modal fade" id="myModal" role="dialog"  data-backdrop="static" data-keyboard="true">
  <div class="modal-dialog modal-lg">    
    <form method="POST" action="<?php echo e(route('addGolfService')); ?>">
      <div class="modal-content">        
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><strong>Add Golf Service</strong></h4>
        </div>
        <div class="modal-body">
          <?php echo e(csrf_field()); ?>    
          <input type="hidden" name="eid" id="eid">
          <div class="row">
            <div class="col-md-16 col-xs-12">
              <div class="form-group">
                <label>Golf Name</label>
                <select class="form-control province" name="golf_name">
                  <option>---Select Golf---</option>
                  <?php $__currentLoopData = App\Supplier::where(['business_id'=>29, 'supplier_status'=>1])->orderBy('supplier_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($gs->id); ?>"><?php echo e($gs->supplier_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <div class="col-md-16 col-xs-12">
              <div class="form-group">
                <label>Service Name</label>
                <input type="text" name="title" id="title" class="form-control" placeholder="Service Name" required="">
              </div>
            </div>
            <div class="col-md-3 col-xs-6">
              <div class="form-group">
                <label>Price <?php echo e(Content::currency()); ?></label>
                <input type="text" name="price" id="price" class="form-control number_only" placeholder="00.0">
              </div>
            </div>
            <div class="col-md-3 col-xs-6">
              <div class="form-group">
                <label>Price Net <?php echo e(Content::currency()); ?> </label>
                <input type="text" name="nprice" id="nprice" class="form-control number_only" placeholder="00.0">
              </div>
            </div>
            <div class="col-md-3 col-xs-6">
              <div class="form-group">
                <label>Price <?php echo e(Content::currency(1)); ?></label>
                <input type="text" name="kprice" id="kprice" class="form-control number_only" placeholder="00.0">
              </div>
            </div>
            <div class="col-md-3 col-xs-6">
              <div class="form-group">
                <label>Price Net <?php echo e(Content::currency(1)); ?></label>
                <input type="text" name="nkprice" id="nkprice" class="form-control number_only" placeholder="00.0">
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success btn-flat btn-sm" id="btnEntrance">Confirm</button>
          <a href="#" class="btn btn-danger btn-flat btn-sm" data-dismiss="modal">Cancel</a>
        </div>
      </div>      
    </form>
  </div>
</div>
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>