<?php $__env->startSection('title', 'Guide Service'); ?>
<?php
  $active = 'restaurant/menu'; 
  $subactive ='guide/service';
  use App\component\Content;
?>  
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <div class="row">
        <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <section class="col-lg-12 connectedSortable">
          <h3 class="border">Guide Services List <span class="fa fa-angle-double-right"></span> <a href="#" data-toggle="modal" data-target="#myModal" class="btn btn-primary" id="btnCreateTransport">Add Service</a></h3>
          <?php if(Auth::user()->role_id == 2): ?>
          <?php $guideLocation = App\Country::where(['country_status'=>1])->whereHas('guideservice', function($query) {
              $query->where(['status'=>1, 'company_id'=>Auth::user()->company_id]);
            })->orderBy('country_name')->get(); ?>
            <form action="" method="">
                <div class="col-sm-2 col-xs-6 pull-right" style="text-align: right; position: relative; z-index: 2;">
                  <label class="location">
                    <select class="form-control input-sm locationchange" name="loc">
                      <?php $__currentLoopData = $guideLocation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($loc->id); ?>" <?php echo e($locat == $loc->id ? 'selected':''); ?>><?php echo e($loc->country_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </label>
                </div>
            </form>
            <?php endif; ?>
            <table class="datatable table table-hover table-striped">
              <thead>
                <tr>
                  <th>Title</th> 
                  <th>Code</th> 
                  <th class="text-center">Status</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $guide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($tran->title); ?></td>
                  <td><?php echo e($tran->code); ?></td>
                  <td class="text-right">
                    <a data-toggle="modal" data-target="#myModalLanguage" href="#" class="ViewLang" data-con="<?php echo e($tran->country_id); ?>"  data-title="<?php echo e($tran->title); ?>" data-id="<?php echo e($tran->id); ?>" title="<?php echo e($tran->language->count()); ?> Language click to privew details">
                      <i style="padding:1px 2px;" class="btn btn-primary btn-xs a fa fa-list-alt"></i>
                    </a>&nbsp;
                    <button class="btnEditService" data-code="<?php echo e($tran->code); ?>" data-title="<?php echo e($tran->title); ?>" style="padding:0px; border:none;position: relative;" data-id="<?php echo e($tran->id); ?>" data-country="<?php echo e($tran->country_id); ?>" 
                      data-province="<?php echo e($tran->province_id); ?>", data-supplier="<?php echo e($tran->supplier_id); ?>" data-toggle="modal" data-target="#myModal" title="click to Update">
                      <i style="padding:1px 2px;" class="btn btn-info btn-xs fa fa-pencil-square-o"></i>
                    </button>&nbsp;


                    <a href="javascript:void(0)" class="RemoveHotelRate" data-type="guide_service" data-id="<?php echo e($tran->id); ?>" title="Remove this item?">
                      <i style="padding:1px 2px;" class="fa fa-minus-circle btn btn-danger btn-xs"></i>
                    </a>
                  </td>                     
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        </section>
      </div>
    </section>
  </div>
</div>
<div class="modal" id="myModal" role="dialog"  data-backdrop="static" data-keyboard="true">
  <div class="modal-dialog modal-lg">    
    <form id="" method="POST" action="<?php echo e(route('addGuideService')); ?>">
      <div class="modal-content">        
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><strong>Guide Service</strong></h4>
        </div>
        <div class="modal-body">
          <?php echo e(csrf_field()); ?>    
          <input type="hidden" name="eid" id="eid">
          <div class="row">
            <div class="col-md-6 col-xs-6">
              <div class="form-group">
                <label>Country <span style="color:#b12f1f;">*</span></label> 
                <select class="form-control country" id="country" name="country" data-type="country-guide" data-locat="data" required>
                    <option value="0">--select--</option>
                    <?php $__currentLoopData = \App\Country::countryBySupplier([6]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($con->id); ?>"><?php echo e($con->country_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div> 
            </div>
            <div class="col-md-6 col-xs-6">
              <div class="form-group">
                <label>City Name <span style="color:#b12f1f;">*</span></label> 
                <select class="form-control province" name="city" data-type="guide_service" id="dropdown-country-guide"  required>
                </select>
              </div> 
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label>Guide Name</label>
                <select class="form-control supplier" name="guide_language"  id="dropdown-guide_service" data-type="driver">
                </select>           
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label>Service Name</label>
                <input type="text" name="service_name" id="service_name" class="form-control" placeholder="Service Name">
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label>Service Code</label>
                <input type="text" name="service_code" id="service_code" class="form-control" placeholder="Service Code">
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer" style="text-align: center;">
          <button type="submit" class="btn btn-success btn-flat btn-sm" id="btnaddTransport">Publish</button>
          <a href="#" class="btn btn-danger btn-flat btn-sm" data-dismiss="modal">Cancel</a>
        </div>
      </div>      
    </form>
  </div>
</div>

<!-- list all language -->
<div class="modal fade" id="myModalLanguage" role="dialog"  data-backdrop="static" data-keyboard="true">
  <div class="modal-dialog modal-lg">
    <form id="form_submitGlanguage" method="POST" action="<?php echo e(route('addLanguage')); ?>">
      <?php echo e(csrf_field()); ?>

      <div class="modal-content"> 
        <div class="modal-header" >
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><strong id="form_lan_title">Add Language</strong></h4>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-12">
              <div class="row">
                <div class="col-md-3 col-xs-4">
                  <div class="form-group">
                    <label>Country<span style="color:#b12f1f;">*</span></label> 
                    <select class="form-control country input-sm" id="country-guide" name="country" data-type="guide_by_country" required>
                        <option value="">--country--</option>
                      <?php $__currentLoopData = App\Booking::countryByBooking(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($con->id); ?>"><?php echo e($con->country_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-3 col-xs-4">
                  <div class="form-group">
                    <label>Choose Supplier<span style="color:#b12f1f;">*</span></label>
                    <div class="btn-group" style="display: block;">
                      <button type="button" class="form-control input-sm" data-toggle="dropdown" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="false">
                       <span class="pull-left">Choose Supplier</span><span class="pull-right"><i class="caret"></i></span>
                      </button>  
                      <div class="obs-wrapper-search" style="padding: 0px;">
                        <div class="">
                          <input type="text" data-type="guide_by_country" data-url="<?php echo e(route('getFilter')); ?>" id="data_filter" class="form-control" autofocus>
                        </div>
                        <ul class="dropdown-data" style="width: 100%; padding: 0px 4px;" id="dropdown-guide_by_country">
                          <div class="clearfix"></div>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-md-3 col-xs-4">
                  <div class="form-group">
                    <label>Language <span style="color:#b12f1f;">*</span></label> 
                    <input type="text" name="title" id="title" class="form-control input-sm" required placeholder="Language">
                  </div> 
                  <input type="hidden" name="languid" id="languid" class="clearValue">
                  <input type="hidden" name="service" id="service">
                </div>
                <div class="col-md-2 col-xs-4">
                  <div class="form-group">
                    <label>Price <?php echo e(Content::currency()); ?></label> 
                    <input type="text" name="price" id="price" class="form-control input-sm number_only" placeholder="00.0">
                  </div> 
                </div>
              
                <div class="col-md-1 col-xs-4">
                  <div class="row">        
                    <button style="position: relative;top: 22px;right: 6px;" type="submit" class="btn btn-primary btn-sm" id="btnSaveLange"  data-url="<?php echo e(route('addLanguage')); ?>" value="Add">
                      <i class="fa fa-plus-circle"></i>&nbsp;&nbsp;
                      <span id="btnAddLanguage">Add</span>
                    </button>
                  </div>
                </div>
               </div>
            </div>
          </div>
          <table class="table table-hover table-striped" id="tableLanuage">
            <thead>
              <tr>
                <th>Langauge</th>
                <th>No. Of Supplier</th>
                <th width="130px">Price <?php echo e(Content::currency()); ?></th>             
                <th width="100px" class="text-center">Status</th>
              </tr>
            </thead>
            <tbody>
              
            </tbody>
          </table>          
        </div>
      </div>      
    </form>
  </div>
</div>
<script type="text/javascript">
  $(document).ready(function(){
    $(".datatable").DataTable();
  });
</script>

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>