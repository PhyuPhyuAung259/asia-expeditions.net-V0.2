<?php $__env->startSection('title', 'Flight Booking'); ?>
<?php $active = 'booked/project';
$subactive ='booked/flight';
  use App\component\Content;
  $countryId = $book->country_id != null ? $book->country_id : Auth::user()->country_id;
  $proId = $book->province_id != null ? $book->province_id : Auth::user()->province_id;
  $amount = number_format(($book->book_price * $book->book_pax), 2);
?>
<?php $__env->startSection('content'); ?>
  <div class="wrapper">
    <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content"> 
        <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="col-lg-12"><h3 class="border">Flight Booking</h3></div>
        <form action="<?php echo e(route('updateBooked', 'flight')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="bookId" value="<?php echo e($book->id); ?>">
            <section class="col-lg-12">                              
              <div class="row">
                  <div class="col-md-3 col-xs-12">
                    <div class="form-group">
                      <label>Flight Date <span style="color:#b12f1f;">*</span></label> 
                      <input type="text" class="form-control book_date" name="book_start" value="<?php echo e($book->book_checkin); ?>"  placeholder="Tour Date" required >
                    </div> 
                  </div>
                  <div class="col-md-3 col-xs-6">
                    <div class="form-group">
                      <label>Country <span style="color:#b12f1f;">*</span></label> 
                      <select class="form-control input-sm country_book" name="country" data-type="booking_flight" data-pro_of_bus="4" data-formtype="booking" required>
                        <?php $__currentLoopData = App\Country::countryBySupplier([4]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($con->id); ?>" <?php echo e($book->country_id == $con->id ? 'selected':''); ?>><?php echo e($con->country_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div> 
                  </div>

                  <div class="col-md-6 col-xs-6">
                    <div class="form-group">
                      <label class="pull-left" style="width: 50%;text-align: center;">Flight From<span style="color:#b12f1f;">*</span></label> 
                      <label class="pull-right" style="width: 50%;text-align: center;">Flight To<span style="color:#b12f1f;">*</span></label> <div class="clearfix"></div>
                      <div class="input-group">
                        <select class="form-control province" name="flightfrom" id="dropdown-booking_flight" data-type="pro_flight" aria-describedby="basic-addon3">
                          <?php $flighFrom=App\FlightSchedule::where(['flight_status'=>1,'country_id'=>$book->country_id, 'company_id'=>\Auth::user()->company_id])->groupBy('flight_from')->orderBy('flight_from')->get(); ?>
                            <?php $__currentLoopData = $flighFrom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $from): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                              
                                <option value="<?php echo e($from->flight_from); ?>" <?php echo e($from->flight_from == $book->flight_from ? 'selected' : ''); ?>><?php echo e($from->flight_from); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <span class="input-group-addon" id="basic-addon3"><i class="fa fa-fighter-jet" style="color: #4f4ab8;"></i></span>                        
                        <select class="form-control city_destination"​​​ id="dropdown-pro_flight" name="flight_to" data-type="single_city_destination" aria-describedby="basic-addon3">
                            <?php $flightTo = App\FlightSchedule::where(['flight_status'=>1, 'flight_to'=>$book->city_destination, 'company_id'=>Auth::user()->company_id])->groupBy("flight_to")->orderBy('flight_to')->get(); ?>
                              <?php $__currentLoopData = $flightTo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $fto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($fto->flight_to); ?>" <?php echo e($fto->flight_to ==  $book->city_destination ? 'selected' : ''); ?>><?php echo e($fto->flight_to); ?> </option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </select>
                        
                      </div>
                    </div>
                  </div>                
                  <div class="col-md-3 col-xs-6">
                    <div class="form-group">
                      <label>Flight Number<span style="color:#b12f1f;">*</span></label> 
                      <select class="form-control Book_FlightNo" data-type="flightno" name="flight_name" id="dropdown-FlightNo" style="font-size: 12px;">
                        <?php $getFightNo = App\FlightSchedule::where(['flight_status'=>1,
                                                  'id' => $book->flight_id,
                                                 'company_id' => Auth::user()->company_id])
                                                  ->orderBy('flightno')->get();
                                        ?>
                        <?php $__currentLoopData = $getFightNo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($fno->id); ?>" <?php echo e($fno->id == $book->flight_id ? 'selected':''); ?>>
                            <?php echo e($fno->flightno); ?> - D:<?php echo e($fno->dep_time); ?> -> A:<?php echo e($fno->arr_time); ?>

                          </option>                           
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                          
                      </select>
                    </div> 
                  </div>
                  <div class="col-md-3 col-xs-6">
                    <div class="form-group">
                      <label>Ticketing Agent <span style="color:#b12f1f;">*</span></label> 
                      <?php $gatFAgent = App\FlightSchedule::find($book->flight_id); ?>
                      <select class="form-control book_FlightAgent" name="ticketing" id="dropdown-TicketingAgent"  style="font-size: 12px;">
                      <?php if(isset($gatFAgent->flightagent) && $gatFAgent->flightagent->count() > 0): ?>
                        <?php $__currentLoopData = $gatFAgent->flightagent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($sch->id); ?>" data-oneway="<?php echo e($sch->pivot->oneway_price); ?>" 
                              data-return="<?php echo e($sch->pivot->return_price); ?>" 
                              data-noneway="<?php echo e($sch->pivot->oneway_nprice); ?>" 
                              data-nreturn="<?php echo e($sch->pivot->return_nprice); ?>" 
                              data-koneway="<?php echo e($sch->pivot->oneway_kprice); ?>" 
                              data-kreturn="<?php echo e($sch->pivot->return_kprice); ?>" 
                              <?php echo e($sch->id == $book->book_agent?'selected':''); ?>><?php echo e($sch->supplier_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                      </select>
                    </div> 
                  </div>
                  <div class="col-md-3 col-xs-6">
                    <div class="form-group">
                      <label>Pax No.</label> 
                      <select class="form-control book_FlightPax" name="book_pax">
                        <?php for($n=1; $n<=29; $n++): ?>
                          <option value="<?php echo e($n); ?>" <?php echo e($n==$book->book_pax?'selected':''); ?>><?php echo e($n); ?></option>
                        <?php endfor; ?>
                      </select>
                    </div>
                  </div>                    
                  <div class="col-md-3 col-xs-6">
                    <div class="form-group">
                      <div><label>Book Way</label></div>
                      <label style="font-weight:400;"> 
                        <input type="radio" class="bookway" name="book_way" value="Oneway" <?php echo e($book->book_way == 'Oneway'? 'checked':''); ?> /><span style="position: relative;top:-2px;">Oneway</span></label>&nbsp;&nbsp;
                      <label style="font-weight: 400;"> 
                        <input type="radio" class="bookway" name="book_way" value="Return" <?php echo e($book->book_way == 'Return'? 'checked':''); ?> /><span style="position: relative;top:-2px;">Return</span></label>
                    </div>
                  </div><div class="clearfix"></div>
                  <div class="col-md-3 col-xs-6">
                    <div class="form-group">
                      <label>Price <?php echo e(Content::currency()); ?></label> 
                      <input type="text" name="book_price" id="book_price" class="form-control" value="<?php echo e($book->book_price); ?>" placeholder="00.0" readonly>
                      <input type="hidden" name="book_nprice" id="book_nprice" value="<?php echo e($book->book_nprice); ?>">
                      <input type="hidden" name="book_kprice" id="book_kprice" value="<?php echo e($book->book_kprice); ?>">
                    </div>
                  </div>
                  <div class="col-md-3 col-xs-6">
                    <div class="form-group">
                      <label>Amount <?php echo e(Content::currency()); ?></label> 
                      <input type="text" name="book_amount" id="book_amount" class="form-control" value="<?php echo e($book->book_amount); ?>" placeholder="00.0" readonly>
                    </div>
                  </div>
                  <div class="col-md-6 col-xs-12">
                    <div class="form-group">
                      <label>Add Remarks</label>
                      <textarea class="form-control my-editor" name="book_intro" rows="4" placeholder="Enter ..."><?php echo e(old('book_intro', $book->book_intro)); ?></textarea>
                    </div>
                  </div>
              </div>
            </section>
            <section class="col-lg-12 ">
              <div class="panel panel-default">
                <div class="panel-footer text-center">
                  <button type="submit" class="btn btn-success btn-flat btn-sm">Submit</button> &nbsp;                    
                </div>
              </div>
            </section>
        </form>
        <div class="clearfix"></div>
      </section>
    </div>  
  </div>
  <?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>