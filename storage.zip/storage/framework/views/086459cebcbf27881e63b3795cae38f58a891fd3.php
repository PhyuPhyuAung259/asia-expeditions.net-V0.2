<?php $__env->startSection('title', $title); ?>
<?php 
	use App\component\Content;
	$comadd = \App\Company::where('country_id', \Auth::user()->country_id)->first();
?>

<?php $__env->startSection('content'); ?>

<?php if($title == "Booking Records"): ?>
	<br><br>
	<?php 
		$projectNum = ' / '.$project->project_number;
	?>
<?php else: ?>
	<?php 
	$projectNum = '';
	 ?>
	<?php echo $__env->make('admin.report.headerReport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

<div class="container-fluid">
	<div class="col-lg-12">
		<div class="pull-right hidden-print">
			<a href="javascript:void(0)" onclick="window.print();"><span class="fa fa-print btn btn-primary"></span></a>
		</div>		
		<h3 class="text-center"><span style="text-transform:capitalize; text-decoration:underline;"><?php echo e($title); ?> On <?php echo e(Content::dateformat(date("d-M-Y"))); ?></span></h3><br><br>
		<table class="table table-bordered">
			<tr>
				<td style="width:50%;">
					<p><label style="width:100px; margin-bottom:0px;">File/Project No.:</label> <?php echo e($project->project_prefix); ?>-<?php echo e($project->project_fileno ? $project->project_fileno: $project->project_number); ?> <?php echo e($projectNum); ?> </p>
					<p><label style="width:90px; margin-bottom:0px;">Client Name:</label> <?php echo e($project->project_client); ?></p>
					<p><label style="width:90px; margin-bottom:0px;">Tour Date:</label> <?php echo e(Content::dateformat($project->project_start)); ?> - <?php echo e(Content::dateformat($project->project_end)); ?></p>
				</td>
				<td style="width:50%;">
					<p><label style="width:106px; margin-bottom: 0px;">Agent Name:</label> <?php echo e(isset($project->supplier->supplier_name) ? $project->supplier->supplier_name : ''); ?></p>
					<p><label style="width:106px; margin-bottom: 0px;">Reference No.:</label> <?php echo e($project->project_book_ref); ?></p>
					<p><label style="width:106px; margin-bottom: 0px;">
					Flight No./:Arrival</label><?php echo e(isset($project->flightArr->flightno) ? $project->flightArr->flightno : ''); ?> - <?php echo e(isset($project->flightArr->arr_time) ? $project->flightArr->arr_time : ''); ?>, &nbsp;&nbsp;<b> 
					Flight No./Departure:</b><?php echo e(isset($project->flightDep->flightno) ? $project->flightDep->flightno : ''); ?> - <?php echo e(isset($project->flightDep->dep_time) ? $project->flightDep->dep_time : ''); ?></p>
				</td>
			</tr>
		</table>	
		<table class="table operation-sheed table-bordered">
			<?php if($hotelb->get()->count() > 0): ?>
			<tr>
				<th style="text-transform: uppercase;"  colspan="12">Hotel </th>
			</tr>
			
			<tr class="header-row">
				<th width="175px">Checkin - Checkout</th>
				<th>Hotel</th>
				<th>Location</th>
				<th class="text-center">Room</th>
				<th class="text-center">Nights</th>
				<th class="text-center">Single </th>
				<th class="text-center">Twin</th>
				<th class="text-center">Double</th>
				<th class="text-center">EX-Bed</th>
				<th class="text-center">ChEX-Bed</th>
				<th class="text-center">Status</th>
			</tr>
				<?php $__currentLoopData = $hotelb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php 
						$hbook = \App\Booking::find($hb->book_id);
					?>
					<tr>
						<td><?php echo e(Content::dateformat($hb->checkin)); ?> - <?php echo e(Content::dateformat($hb->checkout)); ?></td>
						<td><?php echo e(isset($hb->hotel->supplier_name) ? $hb->hotel->supplier_name : ''); ?></td>
						<td><?php echo e(isset($hbook->province->province_name) ? $hbook->province->province_name : ''); ?></td>
						<td class="text-center"><?php echo e(isset($hb->room->name) ? $hb->room->name : ''); ?></td>
						<td class="text-center"><?php echo e($hb->book_day); ?></td>
						<td class="text-center"><?php echo e($hb->nsingle != 0 ? $hb->no_of_room :''); ?></td>
						<td class="text-center"><?php echo e($hb->ntwin != 0 ? $hb->no_of_room :''); ?></td>
						<td class="text-center"><?php echo e($hb->ndouble != 0 ? $hb->no_of_room :''); ?></td>
						<td class="text-center"><?php echo e($hb->nextra != 0 ? $hb->no_of_room :''); ?></td>
						<td class="text-center"><?php echo e($hb->nchextra != 0 ? $hb->no_of_room :''); ?></td>
						<td class="text-center"><b><?php echo e($hb->confirm !=0? 'OK':'RQ'); ?></b></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>

			<?php if($flightb->get()->count() > 0): ?>
				<tr>
					<th style="padding-top: 20px; text-transform: uppercase;"  colspan="12">Flight </th>
				</tr>
				<tr class="header-row">
					<th>Flight Date</th>
					<th>Flight No.</th>
					<th colspan="5">From - To</th>
					<th class="text-center">Dep Time</th>
					<th class="text-center">Arr Time</th>
					<th class="text-center">Seats</th>
					<th class="text-center">Status</th>
				</tr>
				<?php $__currentLoopData = $flightb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e(Content::dateformat($fb->book_checkin)); ?></td>
					<td><?php echo e(isset($fb->flight->flightno) ? $fb->flight->flightno : ''); ?></td>
					<td colspan="5"><?php echo e(isset($fb->flight->flight_from) ? $fb->flight->flight_from : ''); ?> - <?php echo e(isset($fb->flight->flight_to) ? $fb->flight->flight_to : ''); ?></td>
					<td class="text-center"><?php echo e(isset($fb->flight->dep_time) ? $fb->flight->dep_time : ''); ?></td>
					<td class="text-center"><?php echo e(isset($fb->flight->arr_time) ? $fb->flight->arr_time : ''); ?></td>
					<td class="text-center"><?php echo e($fb->book_pax); ?></td>
					<td class="text-center"><b><?php echo e($fb->book_confirm !=0? 'OK':'RQ'); ?></b></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>

			<?php if($golfb->get()->count() > 0): ?>
				<tr>
					<th style="padding-top: 20px; text-transform: uppercase;"  colspan="12">Golf </th>
				</tr>
				<tr class="header-row">
					<th>Start Date</th>
					<th>Golf Name</th>
					<th colspan="6">Golf Service </th>
					<th class="text-center">Tee Time</th>
					<th class="text-center">No. of Pax</th>
					<th class="text-center">Status</th>
				</tr>
				<?php $__currentLoopData = $golfb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e(Content::dateformat($gb->book_checkin)); ?></td>
					<td><?php echo e(isset($gb->golf->supplier_name) ? $gb->golf->supplier_name : ''); ?></td>
					<td colspan="6"><?php echo e(isset($gb->golf_service->name) ? $gb->golf_service->name : ''); ?></td>
					<td class="text-center"><?php echo e($gb->book_pax); ?></td>
					<td class="text-center"><?php echo e($gb->book_golf_time); ?></td>
					<td class="text-center"><b><?php echo e($gb->book_confirm !=0? 'OK':'RQ'); ?></b></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>

 	
			<?php if($guideb->get()->count() > 0): ?>
				<tr>
					<th  style="padding-top: 20px; text-transform: uppercase;" colspan="12">Guide </th>
				</tr>
				<tr class="header-row">
					<th>Start Date</th>
					<th>Guide Name</th>
					<th colspan="5"> Service </th>
					<th class="text-center">Language</th>
					<th class="text-center">Location</th>
					<th class="text-center">Phone</th>
					<th class="text-center">Status</th>
				</tr>
				<?php $__currentLoopData = $guideb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php 
					$dateb = \App\Booking::find($bg->book_id);
					$sb = \App\GuideService::find($bg->service_id);
					$supb = \App\Supplier::find($bg->sup_id);
					$langb = \App\GuideLanguage::find($bg->language_id);
					$prob = \App\Province::find($bg->province_id);
				?>
				<tr>	
					<td><?php echo e(isset($dateb->book_checkin) ? Content::dateformat($dateb->book_checkin) : ''); ?></td>
					<td><?php echo e(isset($supb->supplier_name) ? $supb->supplier_name : ''); ?> </td>
					<td <th colspan="5"><?php echo e(isset($sb->title) ? $sb->title : ''); ?></td>
					<td class="text-center"><?php echo e(isset($langb->name) ? $langb->name : ''); ?></td>
			        <td class="text-center"><?php echo e(isset($prob->province_name) ? $prob->province_name : ''); ?></td>
					<td class="text-right"><?php echo e($bg->phone); ?></td>
					<td class="text-center">...........</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>

			<?php if($transportb->get()->count() >0): ?>
				<tr>
					<th  style="padding-top: 20px; text-transform: uppercase;" colspan="12">Transportation </th>
				</tr>
				<tr class="header-row">
					<th>Start Date</th>
					<th>Driver Name</th>
					<th colspan="5"> Service </th>
					<th class="text-center">Vehicle</th> 
					<th class="text-center">Location</th>
					<th class="text-center">Phone</th>
					<th class="text-center">Status</th>
				</tr>
				<?php $__currentLoopData = $transportb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php 				
					$dateb = \App\Booking::find($bk->book_id);
					$driver = \App\Driver::find($bk->driver_id);
					$service = \App\TransportService::find($bk->service_id);
					$vehicle = \App\TransportMenu::find($bk->vehicle_id);
					$province = \App\Province::find($bk->province_id);
				?>
				<tr>	
					<td><?php echo e(isset($dateb->book_checkin) ? Content::dateformat($dateb->book_checkin) : ''); ?></td>
					<td><?php echo e(isset($driver->driver_name) ? $driver->driver_name : ''); ?></td>
					<td colspan="5"><?php echo e($service->title); ?></td>
			        <td class="text-center"><?php echo e(isset($vehicle->name) ? $vehicle->name : ''); ?></td>
					<td class="text-center"><?php echo e(isset($province->province_name) ? $province->province_name : ''); ?></td>
					<td class="text-center"><?php echo e(isset($driver->phone) ? $driver->phone : ''); ?></td>		
					<td class="text-center">...........</td>			
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>

			<?php if($cruiseb->get()->count() > 0): ?>
				<tr>
					<th style="padding-top: 20px; text-transform: uppercase;" colspan="12">Cruise </th>
				</tr>
				<tr class="header-row">
					<th>Start Date</th>
					<th>Cruise Name</th>
					<th>Program </th>
					<th class="text-center">Room</th>
					<th class="text-center">Nights</th>
					<th class="text-center">Single</th>
					<th class="text-center">Twin</th>
					<th class="text-center">Double</th>
					<th class="text-center">EX-Bed</th>
					<th class="text-center">CHEX-Bed</th>
					<th class="text-center">Status</th>
				</tr>
				<?php $__currentLoopData = $cruiseb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr> 
					<td><?php echo e(Content::dateformat($cb->checkin)); ?> - <?php echo e(Content::dateformat($cb->checkout)); ?></td>
					<td><?php echo e(isset($cb->cruise->supplier_name) ? $cb->cruise->supplier_name : ''); ?></td>
					<td><?php echo e(isset($cb->program->program_name) ? $cb->program->program_name : ''); ?></td>
					<td><?php echo e($cb->room->name); ?></td>
					<td class="text-center"><?php echo e($cb->book_day); ?></td>
					<td class="text-center"><?php echo e($cb->nsingle != 0 ? $cb->cabin_pax :''); ?></td>
					<td class="text-center"><?php echo e($cb->ntwin != 0 ? $cb->cabin_pax :''); ?></td>
					<td class="text-center"><?php echo e($cb->ndouble != 0 ? $cb->cabin_pax :''); ?></td>
					<td class="text-center"><?php echo e($cb->nextra != 0 ? $cb->cabin_pax :''); ?></td>
					<td class="text-center"><?php echo e($cb->nchextra != 0 ? $cb->cabin_pax :''); ?></td>
					<td class="text-center"><b><?php echo e($cb->confirm !=0? 'OK':'RQ'); ?></b></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
			<tr>
				<td colspan="11">
					<b>Remark</b>
					<p><?php echo e($remark); ?></p>
				</td>
			</tr>
			<tr>
				<td colspan="5" style="border:none; padding-top: 12px;">Date of Open:............................</td>
				<td colspan="6" style="border:none; padding-top: 12px;" class="text-right">Signature:........................................................</td>
			</tr>
		</table>
  	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>