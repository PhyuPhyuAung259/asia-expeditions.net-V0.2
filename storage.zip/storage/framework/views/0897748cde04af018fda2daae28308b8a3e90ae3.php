<?php $__env->startSection('title', 'Golf Assignment'); ?>
<?php
  $active = 'restaurant/menu'; 
  $subactive = 'transport/service';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="content-wrapper">
	    <section class="content"> 
		    <div class="row">
		      	<?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		        <section class="col-lg-12 connectedSortable">
		          <h3 class="border" style="text-transform:capitalize;">Booking Golf for Project No. <b><?php echo e($project->project_number); ?> </b></h3>
		            <table class="datatable table table-hover table-striped">
		              <thead>
		                <tr>
		                 	<th width="100px">Date</th>
							<th>Golf</th>
							<th>Tee Time</th>
							<th>Golf Service</th>
							<th class="text-center">Pax</th>
							<th class="text-right">Price <?php echo e(Content::currency()); ?></th>
							<th class="text-right">Amount <?php echo e(Content::currency()); ?></th>
							
							<th class="text-right">Price <?php echo e(Content::currency(1)); ?></th>
							<th class="text-right">Amount <?php echo e(Content::currency(1)); ?></th>
							<th class="text-center">Status</th>
		                </tr>
		              </thead>
		              <tbody>
		              <?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>			
						<?php 
						$gsv = App\GolfMenu::find($gf->program_id);
						?>	
							<tr>
								<td><?php echo e(Content::dateformat($gf->book_checkin)); ?></td>
								<td><?php echo e($gf->supplier_name); ?></td>
								<td><?php echo e($gf->book_golf_time); ?></td>
								<td><?php echo e(isset($gsv->name) ? $gsv->name : ''); ?></td>
								<td class="text-center"><?php echo e($gf->book_pax); ?></td>			
								<td class="text-right"><?php echo e($gf->book_nprice); ?></td>
								<td class="text-right"><?php echo e($gf->book_namount); ?></td>
								<td class="text-right"><?php echo e($gf->book_nkprice); ?></td>
								<td class="text-right"><?php echo e($gf->book_nkamount); ?></td>
								<td class="text-center"><button class="btnEditTran" style="padding:0px;border:none;" data-id="<?php echo e($gf->id); ?>" data-toggle="modal" data-target="#myModal">
		                      	<i style="padding:1px 2px;" class="btn btn-info btn-xs fa fa-pencil-square-o"></i>
		                    </button> </td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		              </tbody>
		            </table>
		        </section>
		    </div>
	    </section>
	</div>
</div>

<div class="modal fade" id="myModal" role="dialog" data-backdrop="static" data-keyboard="true">
	<div class="modal-dialog modal-md">
	    <form method="POST" action="<?php echo e(route('updateTeetime')); ?>">
		    <div class="modal-content">        
		        <div class="modal-header" style="padding: 5px 13px;">
		          <button type="button" class="close" data-dismiss="modal">&times;</button>
		          <h4 class="modal-title"><strong id="form_title">What time you want to play</strong></h4>
		        </div>
		        <div class="modal-body">
		          	<?php echo e(csrf_field()); ?>    
		          	<input type="hidden" name="bookid" id="tour_id">
			        <div class="row">
			            <div class="col-md-4 col-xs-6">
				            <div class="form-group">
				                <label>Hours</label>
				               	<select class="form-control" name="hour">
				               		<?php for($i=12; $i>= 1; $i--): ?>
					               	<option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
					               	<?php endfor; ?>
				               	</select>
				            </div>
			            </div>
			            <div class="col-md-4 col-xs-3">
				            <div class="form-group">
				                <label>Minute</label>
				               	<select class="form-control" name="minute">
					               	<?php for($i=59; $i>= 1; $i--): ?>
					               	<option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
					               	<?php endfor; ?>
				               </select>
				            </div>
			            </div>	
			            <div class="col-md-4 col-xs-3">
			              <div class="form-group">
			                <label>Start</label>
			               	<select class="form-control" name="start">
			               		<option value="AM">AM</option>
			               		<option value="PM">PM</option>
			               	</select>
			              </div>
			            </div>
			        </div>
		        </div>
		        <div class="modal-footer">
		          <button type="submit" class="btn btn-success btn-flat btn-sm" >Confirm</button>
		          <a href="#" class="btn btn-danger btn-flat btn-sm" data-dismiss="modal">Cancel</a>
		        </div>
		    </div>      
	    </form>
	</div>
</div>
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>