<?php $__env->startSection('title', 'All Country'); ?>
<?php $active = 'country'; 
  $subactive ='country';
use App\component\Content;

?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <form action="POST">
            <section class="col-lg-12 connectedSortable">
                <h3 class="border">Countries List <span class="fa fa-angle-double-right"></span> <a href="<?php echo e(route('getCountry')); ?>" class="btn btn-default btn-sm">New Country</a></h3>
                <table class="datatable table table-hover table-striped">
                  <thead>
                    <tr>
                      <th width="12px">Flag</th>
                      <th>Country</th>
                      <th>Published On</th>
                      <th width="30">Status</th>
                      <th width="100" class="text-center">Options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><img src="<?php echo e(Content::urlthumbnail($country->country_photo)); ?>" style="width: 100%"></td>
                      <td><?php echo e($country->country_name); ?></td>
                      <td><?php echo e(Content::dateformat($country->updated_at)); ?></td>                      
                      <td><?php echo $country->country_status == 1 ? "<label class='label label-success'>Active</label>" : "<label class='label label-warning'>Inactive</label>"; ?></label></td>
                      <td class="text-right">            
                        <a href="<?php echo e(route('getCountryEdit', ['con' => $country->id])); ?>" title="Edit County">
                          <label class="icon-list ic_book_project"></label>
                        </a>
                        <a href="javascript:void(0)" class="RemoveHotelRate" data-type="country" data-id="<?php echo e($country->id); ?>" title="Disable this country ?">
                          <label class="icon-list ic-trash"></label>
                        </a>
                      </td>                     
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
            </section>
          </form>
        </div>
    </section>
  </div>  
</div>
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>