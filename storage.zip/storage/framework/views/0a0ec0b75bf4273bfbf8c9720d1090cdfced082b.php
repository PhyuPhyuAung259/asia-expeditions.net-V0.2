<?php $__env->startSection('title', 'Profit & Loss For '); ?>
<?php 
	use App\component\Content;
	$comadd = \App\Company::find(1);
	$amount = "Amount";
	$invoice = "Invoice";
?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<?php echo $__env->make('admin.report.headerReport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>		
	<span><a href="<?php echo e(URL::previous()); ?>"><i class="fa fa-arrow-circle-o-left"></i>  Go Back</a></span>  
	<h3 class="text-left"><strong style="font-size: 18px; text-transform:capitalize;">Profit & Loss For <b><?php echo e(isset($supplier->supplier_name) ? $supplier->supplier_name : ''); ?></b></strong></h3>
	<div class="pull-left">
		<div><p>Contact Name: <b><?php echo e($supplier->supplier_contact_name); ?></b></p></div>
		<div><p>Phone: <b><?php echo e($supplier->supplier_phone); ?></b>, &nbsp; Email: <b><?php echo e($supplier->supplier_email); ?></b></p></div>
	</div>
	<div class="pull-right ">
	    <form method="GET" action="" class="hidden-print">      
	     
		        <div class="form-group">
		        	<div class="col-md-5">
		        		<input type="hidden" name="office_supplier_report" class="form-control input-sm text-center" value="<?php echo e(isset($_GET['office_supplier_report']) ? $_GET['office_supplier_report'] : ''); ?>" placeholder="Ex-Rate 0.0">
			            <input type="text" name="exrate" class="form-control input-sm text-center number_only" value="<?php echo e(isset($_GET['exrate']) ? $_GET['exrate'] : ''); ?>" placeholder="Ex-Rate 0.0">
		            </div>		           
		            <div class="col-md-2" style="padding-left: 0px;">
		              <button type="submit" class="btn btn-primary btn-sm btn-flat">Make Change</button>
		            </div>
		        </div>
	       
	    </form>
	</div><div class="clearfix"></div>
	<table class="table">
		<tr>
			<th width="120px" style="border-top: none;border-bottom: 1px solid #ddd;">Date</th>
			<th width="230px" style="border-top: none;border-bottom: 1px solid #ddd;"><b>Suppliers Entry</b></th>
			<th width="130px" class="text-left" style="border-top: none;border-bottom: 1px solid #ddd;"><?php echo e($invoice); ?> Date</th>
			<th class="text-left" width="400px" style="border-top: none;border-bottom: 1px solid #ddd;">Descriptions</th>
			
			<!-- <th class="text-right" width="180px" style="border-top: none;border-bottom: 1px solid #ddd;">Balance </th> -->
			<th class="text-right" width="190px" style="border-top: none;border-bottom: 1px solid #ddd;">Paid <?php echo e($amount); ?> </th>

			<!-- <th class="text-right" width="180px" style="border-top: none;border-bottom: 1px solid #ddd;">Balance <?php echo e(Content::currency(1)); ?></th> -->
			<th class="text-right" width="210px" style="border-top: none;border-bottom: 1px solid #ddd;">Paid <?php echo e($amount); ?> <?php echo e(Content::currency(1)); ?></th>
		</tr>

		<tbody>
			<?php 
				$usdBalance = 0;
				$kyatBalance = 0;
			?>
			<?php $__currentLoopData = $OfficeSupList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php 
					// $accAmount = AccountTransaction::where(['status'=>1, 'supplier_id' => $acc->supplier_id, 'journal_id'=> $acc->journal_id])->whereNull('project_number')->orderBy("project_number", "DESC")->get();
				$usdBalance = $usdBalance + $acc->credit;
				$kyatBalance = $kyatBalance + $acc->kcredit;
				?>
				<tr>
					<td><?php echo e(Content::dateformat($acc->pay_date)); ?></td>
					<td><?php echo e(isset($acc->supplier->supplier_name) ? $acc->supplier->supplier_name : ''); ?></td>
					<td><?php echo e(Content::dateformat($acc->invoice_pay_date)); ?></td>
					<td><?php echo e($acc->remark); ?></td>						
					<td class="text-right"><?php echo e(Content::money($acc->credit)); ?></td>
					<td class="text-right"><?php echo e(Content::money($acc->kcredit)); ?></td>
				</tr> 
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php if($OfficeSupList->count() > 0): ?>
				<tr>
					<th colspan="4"></th>
					<th class="text-right"> Sub Total: <?php echo e(Content::currency(0)); ?> <?php echo e(Content::money($usdBalance)); ?> </th>
					<th class="text-right"> Sub Total: <?php echo e(Content::currency(1)); ?> <?php echo e(Content::money($kyatBalance)); ?> </th>
					<?php 
						if (isset($_GET['exrate']) && !empty($_GET['exrate'])) {
							$exrate = $_GET['exrate'];
						}else{
							$exrate = 1;
						}

						$exBalance = $kyatBalance / $exrate;
					?>
				</tr>
				<tr>
					<th colspan="6" class="text-right">Grand Total <?php echo e(Content::money($exBalance + $usdBalance)); ?></th>				
				</tr>
			<?php endif; ?>
		</tbody>

	</table>
</div>
<br><br><br> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>