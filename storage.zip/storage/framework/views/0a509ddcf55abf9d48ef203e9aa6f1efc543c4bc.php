<?php $__env->startSection('title', 'Client Arrival Report'); ?>
<?php
  $active = 'reports'; 
  $subactive = 'project/operation-daily-chart';
  use App\component\Content;
  $agent_id = isset($agentid) ? $agentid:0;
  $locat = isset($location) ? $location:0;
  $main = isset($sort_main) ? $sort_main:0;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <div class="row">
        <section class="col-lg-12 connectedSortable">
          <h3 class="border">Operation Daily Chart</h3>
          <form method="POST" action="<?php echo e(route('searchPOSDailyChart')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="col-sm-8 pull-right">
              <div class="col-md-2">
                <input type="hidden" name="" value="<?php echo e(isset($projectNo) ? $projectNo : ''); ?>" id="projectNum">
                <input readonly class="form-control input-sm" type="text" id="from_date" name="start_date" placeholder="From Date" value="<?php echo e(isset($startDate) ? $startDate : ''); ?>"> 
              </div>
              <div class="col-md-2" style="padding-right: 0px;">
                <input readonly class="form-control input-sm" type="text" id="to_date" name="end_date" placeholder="To Date" value="<?php echo e(isset($endDate) ? $endDate : ''); ?>"> 
              </div>
              <div class="col-md-2">
                <select class="form-control input-sm" name="sort_location">
                  <?php $__currentLoopData = \App\Country::countryByProject(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($con->id); ?>" <?php echo e(isset($country) && $con->id == $country ? 'selected' : ''); ?>><?php echo e($con->country_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="col-md-2" style="padding: 0px;">
                <button class="btn btn-primary btn-sm" type="submit">Search</button>
              </div>   
              <div class="col-md-4 text-right" >
                 <!-- <button class="btn btn-primary btn-sm" type="submit">Search</button> -->
                <span class="btn btn-primary btn-sm myConvert"> <i class="fa fa-download"></i>Download</span>
              </div>
            </div>
          <table class="datatable table table-hover table-striped">
            <thead>
              <tr>
                <th style="width:50px;">Date</th>
                <th style="width: 18px;">FileNo.</th>
                <th style="width: 250px;">Client Name</th>
                <th >City / Tour Name</th>
                <th width="170px">Tour Start->End Date</th>
                <th>Guide Name / Phone</th>
                <th>Driver Name/ Phone</th>
                <th>City/Hotel</th>
                <th>City/Golf</th>
                <th>Restaurant</th>
                <!-- <th style="width: 60px;">Status</th> -->
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $bookingTour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php  
                  $project = App\Project::where('project_number', $pro->project_number)->first();
                  $province = App\Province::find($pro->province_id);
                  $guide  = App\BookGuide::where(['project_number'=>$pro->project_number, 'book_id'=> $pro->book_id])->orderBy("created_at")->first();  
                  $transport = App\BookTransport::where(['project_number'=>$pro->project_number, 'book_id'=>$pro->book_id])->first();

                  $hotel= \App\HotelBooked::where(['project_number'=>$pro->project_number])
                          ->whereDate('checkin', $pro->book_checkin)
                          ->orderBy("checkin", "ASC")->groupBy('hotel_id')->first();
                  $golfSupplier = App\Booking::golfBook($pro->project_number)->whereDate('book_checkin', $pro->book_checkin)->first();

                  $restaurant = \App\BookRestaurant::where('project_number', $pro->project_number)
                    ->whereDate('start_date', $pro->book_checkin)
                    ->orderBy("start_date")->first();
                ?>
              <tr>
                <td><?php echo e(Content::dateformat($pro->book_checkin)); ?></td>
                <td><b><?php echo e(isset($project->project_prefix) ? $project->project_prefix : ''); ?>-<?php echo e(isset($project->project_fileno) ? $project->project_fileno : ''); ?></b></td>
                <td><?php echo e($project->project_client); ?> 
                  <?php if($project): ?>
                  <span style="color: #034ea2;"> x <?php echo e($project->project_pax); ?> Pax</span>
                  <?php endif; ?>
                </td>
                
                <td> <?php echo e($pro->tour_name); ?>, <span style="color: #034ea2;"><?php echo e(isset($province->province_name) ? $province->province_name : ''); ?></span></td>
                <td>
                  <?php if($project): ?>
                    <?php echo e(Content::dateformat($project->project_start)); ?> -> <?php echo e(Content::dateformat($project->project_end)); ?> 
                  <?php endif; ?>
                </td>
                <td>
                  <?php if($guide): ?>
                    <div><?php echo e(isset($guide->supplier->supplier_name) ? $guide->supplier->supplier_name : ''); ?></div> 
                    <?php if(isset($guide->supplier->supplier_phone)): ?>
                       <?php echo e($guide->supplier->supplier_phone); ?>

                    <?php endif; ?>
                    <?php if(isset($guide->supplier->supplier_phone)): ?>
                       <?php echo e($guide->supplier->supplier_phone2); ?>

                    <?php endif; ?>
                  <?php endif; ?>
                </td>
                <td>
                    <div><?php echo e(isset($transport->vehicle->name) ? $transport->vehicle->name : ''); ?></div>
                    <?php if(isset($transport->driver->driver_name)): ?>
                    / <?php echo e(isset($transport->driver->driver_name) ? $transport->driver->driver_name : ''); ?>

                    <?php endif; ?>
                    <?php if(isset($transport->driver->phone2)): ?>
                    / <?php echo e(isset($transport->driver->phone2) ? $transport->driver->phone2 : ''); ?>

                    <?php endif; ?>
                 </td>
                <td>
                  <?php if(isset($hotel)): ?>
                    <?php $hotelSupplier = App\Supplier::find($hotel->hotel_id); ?>
                    <div>
                     
                      <?php echo e(isset($hotel->hotel->supplier_name) ? $hotel->hotel->supplier_name : ''); ?>

                    </div>
                    <?php if($hotel): ?> 
                      <div><span style="color: #034ea2;">CIN</span>:
                      <strong><?php echo e(Content::dateformat($hotel->checkin)); ?>-><?php echo e(Content::dateformat($hotel->checkout)); ?></strong>
                     <?php if(isset($hotelSupplier)): ?>
                        ,<span style="color: #034ea2;"><?php echo e($hotelSupplier->province->province_name); ?></span>
                      <?php endif; ?></div>
                    <?php endif; ?>
                  <?php endif; ?>
                  
                </td>
                <td>
                  <?php if(isset($golfSupplier)): ?>
                    <?php $Golfprovince = App\Province::find($golfSupplier->province_id); ?>
                  <?php echo e(isset($golfSupplier->supplier_name) ? $golfSupplier->supplier_name : ''); ?>

                    <?php if($Golfprovince): ?>, 
                    ,<span style="color: #034ea2;">Tee Time:<?php echo e($golfSupplier->book_golf_time); ?></span>
                      ,<span style="color: #034ea2;"><?php echo e($Golfprovince->province_name); ?></span>
                    <?php endif; ?>
                  <?php endif; ?>
                </td>
                <td>
                  <?php if(isset($restaurant->supplier)): ?>
                     <?php $RestProvince = App\Province::find($restaurant->province_id); ?>
                      <?php echo e(isset($RestProvince->supplier_name) ? $RestProvince->supplier_name : ''); ?>

                    <?php echo e(isset($restaurant->supplier->supplier_name) ? $restaurant->supplier->supplier_name : ''); ?>

                    <?php if($RestProvince): ?>
                      ,<span style="color: #034ea2;"><?php echo e($RestProvince->province_name); ?></span>
                    <?php endif; ?>
                  <?php endif; ?>
                </td>
               <!--  <td>
                    <div class="btn-group">
                      <span style="cursor: pointer;-webkit-box-shadow:none;box-shadow:none;" class=" dropdown-toggle" data-toggle="dropdown"> 
                        <i class="fa fa-circle" style="color: <?php echo e($pro->active == 1 ? '#21ef91': '#FF5722'); ?>; font-size:12px;"></i> <?php echo e($pro->active == 1 ? 'Active': 'Inactive'); ?>

                      <i  class="fa fa-angle-down"></i>
                      </span>
                      <ul class="dropdown-menu" style="min-width: 100%; padding: 0px;">
                        <li><a href="#" style="padding: 10px;"><i class="fa fa-circle" style="color: #21ef91;"></i>Active <?php echo $pro->active==1?'<i class="fa fa-check" style="color: #009688;font-style: italic;"></i>' : ''; ?></a></li>
                        <li><a href="#" style="padding: 10px;"><i class="fa fa-circle" style="color: #FF5722;"></i>Inactive 
                        <?php echo $pro->active==0?'<i class="fa fa-check" style="color: #009688;font-style: italic;"></i>' : ''; ?> </a> </li>
                      </ul>
                    </div>
                </td> -->
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </form>
        </section>
      </div>
    </section>
  </div>
</div>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.table2excel.min.js')); ?>"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $(".datatable").DataTable({
      // language: {
      //   searchPlaceholder: "Number No., File No.",
      // }
      columnDefs: [
        {  type : "datetime-moment", targets:  "sort-date" },
     ]
    });

    $(".myConvert").click(function(){
        if(confirm('Do you to export in excel?')){
          $(".datatable").table2excel({
            exclude: ".noExl",
            name: "Daily Operation Chart <?php echo e(isset($startDate) ? $startDate : ''); ?> - <?php echo e(isset($endDate) ? $endDate : ''); ?>",
            filename: "Daily Operation Chart <?php echo e(isset($startDate) ? $startDate : ''); ?> - <?php echo e(isset($endDate) ? $endDate : ''); ?>",
            fileext: ".xls",
            exclude_img: true,
            exclude_links: true,
            exclude_inputs: true
            
          });
          return false;
        }else{
          return false;
        }
      });
  });
</script>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>