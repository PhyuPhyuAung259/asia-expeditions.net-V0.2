<?php $__env->startSection('title', 'Preview Of '); ?>
<?php 
  use App\component\Content;
  $comadd = \App\Company::find(1);
?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <?php echo $__env->make('admin.report.headerReport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
</div>
<div class="col-md-12">
    <div class=" text-right">
      <form method="GET" action="" class="hidden-print">
          <div class="col-md-3 col-xs-6 <?php echo e(\Auth::user()->role_id == 2 ? '': 'hidden'); ?>">
              <div class="form-group">
                <select class="form-control location " name="country" data-type="sup_by_bus">
                  <option value="">Choose Location</option>
                  <?php $__currentLoopData = App\Country::LocalPayment(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($con->id); ?>" <?php echo e(\Auth::user()->country_id == $con->id ? 'selected' : ''); ?>><?php echo e($con->country_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
          </div>          
          <div class="col-md-3 col-xs-6">
            <div class="form-group">
              <select class="form-control business_type_receive" name="business" data-type="sup_by_bus">
                <option value="">Choose Business</option>
                  <?php $__currentLoopData = App\Business::PaymentBusiness(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($bn->id); ?>" <?php echo e(isset($_GET['business']) && $_GET['business'] == $bn->id ? 'selected' : ''); ?>><?php echo e($bn->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
          <div class="col-md-3 col-xs-6" id="supplier_Name">
            <select class="form-control supplier-receivable" name="supplier" id="dropdown_receive_supplier" >
              <option value="">--supplier--</option>
                <?php $bus_id = isset($_GET['business']) ? $_GET["business"]:''; ?>
                <?php $__currentLoopData = App\Supplier::SupByAccount($bus_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($sup->id); ?>" <?php echo e(isset($_GET['supplier']) && $_GET['supplier'] == $sup->id ? 'selected' : ''); ?>><?php echo e($sup->supplier_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="col-md-2 col-xs-6 text-left">
            <div class="form-group">
              <input type="submit"  value="Search" class="btn btn-default btn-acc">
            </div>               
          </div>          
      </form>
    </cener>    
    <form target="_blank" action="<?php echo e(route('getOutstanding', ['outstanding' => 'print'])); ?>">
      <input type="submit" name="outstanding_print" value="Query" class="btn btn-default btn-acc">
      <input type="hidden" name="supplier" value="<?php echo e(isset($_GET['supplier']) ? $_GET['supplier'] : ''); ?>">
      <table class="table">
        <thead>
          <tr>
            <th width="10px" style="border-top: none;border-bottom: 1px solid #ddd;"><input type="checkbox" id="check_all"></th>
            <th width="70" style="border-top: none;border-bottom: 1px solid #ddd;">FileNo.</th>  
            <th width="200" style="border-top: none;border-bottom: 1px solid #ddd;">Client Name</th>
            <th width="200" style="border-top: none;border-bottom: 1px solid #ddd;">Suplier Name</th>
            <th width="225" style="border-top: none;border-bottom: 1px solid #ddd;">Travelling Date</th>
            <th class="text-right" width="130" style="border-top: none;border-bottom: 1px solid #ddd;">Invoice <?php echo e(Content::currency()); ?></th>  
            <th class="text-right" width="130" style="border-top: none;border-bottom: 1px solid #ddd;">Paid <?php echo e(Content::currency()); ?></th> 
            <th class="text-right" width="130" style="border-top: none;border-bottom: 1px solid #ddd;"><?php echo e(Content::currency()); ?> ToPay</th>
            <th class="text-right" width="180" style="border-top: none;border-bottom: 1px solid #ddd;">Paid Date</th>
            <th class="text-right" width="130" style="border-top: none;border-bottom: 1px solid #ddd;">Invoice <?php echo e(Content::currency(1)); ?></th> 
            <th class="text-right" width="130" style="border-top: none;border-bottom: 1px solid #ddd;">Paid <?php echo e(Content::currency(1)); ?></th>
            <th class="text-right" width="130" style="border-top: none;border-bottom: 1px solid #ddd;"><?php echo e(Content::currency(1)); ?> ToPay </th> 
            <th class="text-right" width="130" style="border-top: none;border-bottom: 1px solid #ddd;">SUP-INV Date</th> 
          </tr>
        </thead>
          <?php if($outstanding->count() > 0 ): ?>
          <tbody>
            <?php $__currentLoopData = $outstanding; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php 
                $project = App\Project::where(["project_number"=> $sup->project_number, "project_status"=>1])->first();
                $accTranc = App\AccountTransaction::where(["journal_id"=> $sup->id]);
              ?>
              <?php 
                $project=App\Project::where("project_number", $sup->project_number)->first();
                $supplier = App\Supplier::find($sup->supplier_id);
                $supName=isset($supplier->supplier_name)? $supplier->supplier_name: '';
                if ($sup->business_id == 55) {
                  $supName=isset($sup->ent_service->name)? $sup->ent_service->name :'';
                }
                if ($sup->business_id == 54) {
                  $supName=isset($sup->misc_service->name)?$sup->misc_service->name :'';
                }
              ?>
              <tr>
                <td><input type="checkbox" class="checkall" name="checkOurstanding[]" value="<?php echo e($sup->id); ?>"></td>
                <td><?php echo e(isset($project->project_prefix) ? $project->project_prefix : ''); ?>-<?php echo e(isset($project->project_fileno) ? $project->project_fileno : ''); ?></td>
                <td class="text-left"><?php echo e(isset($project->project_client) ? $project->project_client : ''); ?></td>
                <td class="text-left"><?php echo e($supName); ?></td>
                <td class="text-left"><?php echo e(isset($project->project_start) ? Content::dateformat($project->project_start) :''); ?> - <?php echo e(isset($project->project_end) ? Content::dateformat($project->project_end) :''); ?></td>
                <td class="text-right"><?php echo e(Content::money($sup->debit)); ?></td>
                <td class="text-right"><?php echo e(Content::money($accTranc->sum('credit'))); ?></td>
                <td class="text-right"><?php echo e(Content::money( $sup->debit - $accTranc->sum('credit'))); ?></td>
                <td class="text-right"><?php echo e(isset($accTranc->first()->invoice_pay_date) ? Content::dateformat($accTranc->first()->invoice_pay_date):''); ?></td>
                <td class="text-right"><?php echo e(Content::money($sup->kdebit)); ?></td>
                <td class="text-right"><?php echo e(Content::money($accTranc->sum('kcredit'))); ?></td>
                <td class="text-right"><?php echo e(Content::money( $sup->kdebit - $accTranc->sum('kcredit'))); ?></td>
                <td class="text-right"><?php echo e(isset($accTranc->first()->invoice_rc_date_from_sup) ? Content::dateformat($accTranc->first()->invoice_rc_date_from_sup):''); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <?php endif; ?>
      </table>  
    </form>
    <br>
</div>
<script type="text/javascript">
    $("#check_all").click(function () {
        if($("#check_all").is(':checked')){
           // Code in the case checkbox is checked.
            $(".checkall").prop('checked', true);
        } else {
             // Code in the case checkbox is NOT checked.
            $(".checkall").prop('checked', false);
        }
      });
</script>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make("admin.account.accountant", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>