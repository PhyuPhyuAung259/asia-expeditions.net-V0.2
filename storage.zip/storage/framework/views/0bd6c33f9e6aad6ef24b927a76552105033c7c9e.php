<?php use App\component\Content; ?>
<table class="table table-hover table-bordered excel-sheed">
    <!-- <?php echo e($bookeds); ?> -->
	<?php if(isset($bookeds) && $bookeds->count() > 0 ): ?>
	    <thead>
            <tr><th colspan="8" align="left"><font color="#1991d6"><?php echo e($supp['supplier_name']); ?></font> From <?php echo e(Content::dateformat($start_date)); ?> -> <?php echo e(Content::dateformat($end_date)); ?></th></tr>
	        <tr style="background-color: #ddd">
	          	<td width="86">File No.</td>
	          	<td>Client Name</td>
	          	<td>Date</td>
	          	<td>Flight No.</td>
                <td>Departure -> Arrival Time</td>
	          	<td>Destination</td>
	          	<td class="text-center">Seats</td>
	          	<td class="text-right">Price</td>
	            <td class="text-right">Amount</td>
	        </tr>
	    </thead>
        <tbody>
        	<?php $__currentLoopData = $bookeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        		
                <tr>
        			<td><?php echo e($sub->project['project_prefix']); ?>-<?php echo e($sub->project['project_fileno']); ?></td>
        			<td><?php echo e($sub->project['project_client']); ?> <small><b>x</b></small> <i>[ <?php echo e($sub->project['project_pax']); ?> ]</i></td>
        			<td><?php echo e(Content::dateformat($sub->book_checkin)); ?></td>
        			<td><?php echo e(isset($sub->flight['flightno']) ? $sub->flight['flightno'] : ''); ?></td>
                    <td><?php echo e(isset($sub->flight['dep_time']) ? $sub->flight['dep_time'] : ''); ?> -> <?php echo e(isset($sub->flight['arr_time']) ? $sub->flight['arr_time'] : ''); ?></td>
                    <td><?php echo e(isset($sub->flight['flight_from']) ? $sub->flight['flight_from'] : ''); ?> <i class="fa fa-long-arrow-right" style="color: #72afd2"></i> <?php echo e(isset($sub->flight['flight_to']) ? $sub->flight['flight_to'] : ''); ?> </td>
        			<td class="text-center"><?php echo e($sub->book_pax); ?></td>
                    <td class="text-right"><?php echo e(Content::money($sub->book_price)); ?></td>
                    <td class="text-right"><?php echo e(Content::money($sub->book_amount)); ?></td>
                </tr>
        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
        </tbody>
        <tfoot>
        	<tr>
        		<th colspan="11" bgcolor="#ddd" align="right" style="border: solid 1px #ddd;">
                    <font color="#1991d6">
                        Grand Total : <?php echo e(Content::money($bookeds->sum('book_amount'))); ?>  <?php echo e(Content::currency()); ?>

                    </font>
                </th>
        	</tr>
        </tfoot>
    <?php else: ?>
    	<tfoot>
        	<tr>
        		<th bgcolor="#ddd" colspan="12" align="center">Record Not found...</th>
        	</tr>
        </tfoot>	
    <?php endif; ?>
</table>