<?php 
	use App\component\Content;
	$hotelReport=\App\HotelBooked::where(['project_number'=>$book->book_project, 'company_id'=> Auth::user()->company_id])->groupBy('hotel_id')->orderBy('checkin', 'ASC')->get();
?>

<?php if($hotelReport->count() >0): ?>
	<h5 class="text-center"><strong>HOTEL INFORMATION ON YOUR PROGRAM</strong></h5>
	<table class="table">
		<?php $__currentLoopData = $hotelReport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $sup = App\Supplier::find($hotel->hotel_id);?>
			<tr>
				<td width="330px;">
					<img src="<?php echo e(Content::urlthumbnail($sup->supplier_photo, $sup->user_id)); ?>" class="img-responsive">
				</td>
				<td style="vertical-align:top;">
					<h5 style="text-transform: capitalize;"><strong><?php echo e($sup->supplier_name); ?> | <a href="javascript:void(0)"><?php echo e(isset($sup->province->province_name) ? $sup->province->province_name : ''); ?></a>, <a href="javascript:void(0)"><?php echo e(isset($sup->country->country_name) ? $sup->country->country_name : ''); ?></a> </strong></h5>
					<?php echo str_limit($sup->supplier_intro,1350); ?>

				</td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
<?php endif; ?>