<?php  use App\component\Content;?>
<table class="table table-bordered" id="roomrate">
	<?php if($priceType  == "contract" ): ?>
		<tr>
			<tr>
				<td colspan="2">
					<address>
						<p><b>Hotel Name :</b> <?php echo e($supplier->supplier_name); ?><br>
						<b>P/H :</b> <?php echo e($supplier->supplier_phone); ?>/<?php echo e($supplier->supplier_phone2); ?><br>
						<b>Email :</b> <?php echo e($supplier->supplier_email); ?><br>
						<b>Address :</b> <?php echo e($supplier->supplier_address); ?><br>
						<b>Website :</b> <?php echo e($supplier->supplier_website); ?></p>
					</address>
					<?php echo $supplier->supplier_intro; ?></td>
			</tr>
			<td style="width: 50%; vertical-align:top;">
				<strong>Hotel Facilities</strong>
				<ul>
					<?php if($supplier->hotel_facility ): ?>
						<?php $__currentLoopData = $supplier->hotel_facility; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $hf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($hf->name); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</ul>
			</td> 
			<td style="width: 50%; vertical-align:top;">
				<strong>Hotel Info</strong>
				<ul>
					<?php if($supplier->hotel_category ): ?>
						<?php $__currentLoopData = $supplier->hotel_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $hf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($hf->name); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</ul>
			</td>	
			<?php if($supplier->supplier_term_condition): ?>
			<tr>
				<td colspan="2">
					<strong>Terms & Conditions</strong>
					<?php echo $supplier->supplier_term_condition; ?></td>
			</tr>
			<?php endif; ?>
			<?php if($supplier->supplier_pgroup): ?>
			<tr>
				<td colspan="2">
					<strong>Group Policy</strong>
					<?php echo $supplier->supplier_pgroup; ?></td>
			</tr>
			<?php endif; ?>



			<?php if($supplier->supplier_pchild): ?>
			<tr>
				<td colspan="2">
					<strong>Child Policy</strong>
					<?php echo $supplier->supplier_pchild; ?></td>
			</tr>
			<?php endif; ?>
			<?php if($supplier->supplier_pcancelation): ?>
			<tr>
				<td colspan="2">
					<strong>Cancellation Policy</strong>
					<?php echo $supplier->supplier_pcancelation; ?></td>
			</tr>
			<?php endif; ?>
			<?php if($supplier->supplier_ppayment): ?>
			<tr>
				<td colspan="2">
					<strong>Payment Policy</strong>
					<?php echo $supplier->supplier_ppayment; ?></td>
			</tr>
			<?php endif; ?>
			

			<tr>
				<td colspan="2"> <strong>Remarks:</strong><?php echo $supplier->remak; ?> </td>
			</tr>
		</tr>
	<?php else: ?>
		<tr style="background-color: rgb(245, 245, 245);">
			<th style="padding:2px;"><span>RoomType</span></td>
			<th style="padding:2px;"><span>From Date</span>  <span class="fa fa-long-arrow-right" style="top: 1px; position: relative;"></span> <span>To Date</span></th>
			<?php if($priceType != "selling"): ?>
				<?php $__currentLoopData = \App\RoomCategory::where('status',1)->orderBy('id','ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<th title="<?php echo e($cat->name); ?>" style="padding: 2px;" class="text-right"><span><?php echo e($cat->name); ?></span></th>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
				<?php $__currentLoopData = \App\RoomCategory::where('status',1)->take(5)->orderBy('id','ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<th title="<?php echo e($cat->name); ?>" style="padding: 2px;" class="text-right"><span><?php echo e($cat->name); ?></span></th>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</tr>			 
		<?php $__currentLoopData = $supplier->room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if(isset($fmonth) != "" && isset($tmonth) != "" && isset($year) != ""): ?>
				<?php
				$getRate = App\RoomRate::where(['supplier_id'=>$supplier->id, 'room_id'=>$room->id])
									->whereMonth('start_date', '>=', $fmonth)
									->whereMonth('start_date', '<=', $tmonth)
									->whereYear('start_date', $year)
									->orderBy('start_date','ASC')->get();
					// dd($getRate);
				?>
			<?php else: ?>
				<?php
				$getRate = App\RoomRate::where(['supplier_id'=>$supplier->id, 'room_id'=>$room->id])->orderBy('start_date','ASC')->get();
				?>
			<?php endif; ?>
			<tr>
				<td style="vertical-align: middle;" colspan="<?php echo e($getRate->count()== 0? '12':''); ?>" rowspan="<?php echo e($getRate->count() +1); ?>"><b><?php echo e($room->name); ?></b></td>
			</tr>
			<?php $__currentLoopData = $getRate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td style="font-size:12px;" class="date-font"><?php echo e(Content::dateformat($rate->start_date)); ?> <i class="pcolor">-></i> <?php echo e(Content::dateformat($rate->end_date)); ?></td>
				<td class="text-right"><?php echo e(Content::money($rate->ssingle)); ?> <small class="pcolor"><?php echo e($rate->ssingle>0?Content::currency():''); ?></small></td>
				<td class="text-right"><?php echo e(Content::money($rate->stwin)); ?> <small class="pcolor"><?php echo e($rate->stwin>0?Content::currency():''); ?></small></td>
				<td class="text-right"><?php echo e(Content::money($rate->sdbl_price)); ?> <small class="pcolor"><?php echo e($rate->sdbl_price>0?Content::currency():''); ?></small></td>
				<td class="text-right"><?php echo e(Content::money($rate->sextra)); ?> <small class="pcolor"><?php echo e($rate->sextra>0?Content::currency():''); ?></small></td>
				<td class="text-right"><?php echo e(Content::money($rate->schexbed)); ?> <small class="pcolor"><?php echo e($rate->schexbed>0?Content::currency():''); ?></small></td>
				<?php if($priceType != "selling" ): ?>
					<td class="text-right"><?php echo e(Content::money($rate->nsingle)); ?> <small class="pcolor"><?php echo e($rate->nsingle>0?Content::currency():''); ?></small></td>
					<td class="text-right"><?php echo e(Content::money($rate->ntwin)); ?> <small class="pcolor"><?php echo e($rate->ntwin>0?Content::currency():''); ?></small></td>
					<td class="text-right"><?php echo e(Content::money($rate->ndbl_price)); ?> <small class="pcolor"><?php echo e($rate->ndbl_price>0?Content::currency():''); ?></small></td>
					<td class="text-right"><?php echo e(Content::money($rate->nextra)); ?> <small class="pcolor"><?php echo e($rate->nextra>0?Content::currency():''); ?></small></td>
					<td class="text-right"><?php echo e(Content::money($rate->nchexbed)); ?> <small class="pcolor"><?php echo e($rate->nchexbed>0?Content::currency():''); ?></small></td>
				<?php endif; ?>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>				
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php echo $__env->make('admin.report.supplier_info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php endif; ?>	
</table>