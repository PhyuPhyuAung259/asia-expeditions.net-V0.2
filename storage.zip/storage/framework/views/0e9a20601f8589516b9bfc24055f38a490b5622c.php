<?php $__env->startSection('title', 'Driver Service'); ?>
<?php
  $active = 'restaurant/menu'; 
  $subactive ='transport/driver/add';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <div class="row">
        <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <section class="col-lg-12 connectedSortable">
          <h3 class="border">Driver List <span class="fa fa-angle-double-right"></span> <a href="#" data-toggle="modal" data-target="#myModal" class="btn btn-primary" id="btnAddDriver">Add New Driver</a></h3>
           <?php if(Auth::user()->role_id == 2): ?>
             <?php if($country->count() > 0): ?>
                <form action="" method="">
                    <div class="col-sm-2 col-xs-6 pull-right" style="text-align: right; position: relative; z-index: 2;">
                      <label class="location">
                        <select class="form-control input-sm locationchange" name="loc">
                          <?php $__currentLoopData = App\Country::where('country_status',1)->whereHas('driver', 
                            function($query) {
                              $query->where(['status'=>1, 'company_id'=> Auth::user()->company_id]);
                            })->orderBy('country_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option value="<?php echo e($con->id); ?>" <?php echo e($locat == $con->id ? 'selected':''); ?>><?php echo e($con->country_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </label>
                    </div>
                </form>
              <?php endif; ?>
            <?php endif; ?>
            <table class="datatable table table-hover table-striped">
              <thead> 
                <tr>
                  <th>Title</th>
                  <th>Supplier Name</th>
                  <th>Phone</th>
                  <th>Email</th>
                  <th class="text-center">Status</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($dr->driver_name); ?></td>
                  <td><?php echo e(isset($dr->supplier->supplier_name) ? $dr->supplier->supplier_name : ''); ?></td>
                  <td><?php echo e($dr->phone); ?></td>
                  <td><?php echo e($dr->email); ?></td>
                  <td class="text-right"> 
                    <a  href="#" class="tranEditDriver" data-type="assign_driver" data-id="<?php echo e($dr->id); ?>" data-toggle="modal" data-target="#myModal">
                      <i style="padding:1px 2px;" class="btn btn-info btn-xs fa fa-pencil-square-o"></i>
                    </a>
                    <a href="javascript:void(0)" class="RemoveHotelRate" data-type="driver" data-id="<?php echo e($dr->id); ?>" title="Remove this menu ?">
                      <i style="padding:1px 2px;" class="fa fa-minus-circle btn btn-danger btn-xs"></i>
                    </a>
                  </td>                     
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        </section>
      </div>
    </section>
  </div>
</div>
<div class="modal in" id="myModal" role="dialog"  data-backdrop="static" data-keyboard="true">
  <div class="modal-dialog modal-lg">    
    <form method="POST" action="<?php echo e(route('addDriver')); ?>">
      <div class="modal-content">        
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><strong>Add New Driver</strong></h4>
        </div>
        <div class="modal-body">
          <?php echo e(csrf_field()); ?>    
          <input type="hidden" name="eid" id="eid">
          <div class="row">
            <div class="col-md-6 col-xs-6">
              <div class="form-group">
                <label>Country <span style="color:#b12f1f;">*</span></label> 
                <select class="form-control country" id="country" name="country" data-type="country-driver"  data-locat="data" required>
                  <option value="">--Choose--</option>
                  <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($con->id); ?>"><?php echo e($con->country_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div> 
            </div>
            <div class="col-md-6 col-xs-6">
              <div class="form-group">
                <label>City Name <span style="color:#b12f1f;">*</span></label> 
                <select class="form-control province" name="city" data-type="assign_driver" id="dropdown-country-driver" required>
                </select>
              </div> 
            </div>
            <div class="col-md-6 col-xs-6">
              <div class="form-group">
                <label>Transportation</label>
                <select class="form-control supplier" name="transport" id="dropdown-assign_driver" required>         
                </select>
              </div>
            </div>
            <div class="col-md-6 col-xs-6">
              <div class="form-group">
                <label>Driver Name</label>
                <input type="text" name="driver_name" id="driver_name" class="form-control">
              </div>
            </div>
            <div class="col-md-3 col-xs-6">
              <div class="form-group">
                <label>Phone</label>
                <input type="text" name="phone" id="phone" class="form-control" required="">
              </div>
            </div>
            <div class="col-md-3 col-xs-6">
              <div class="form-group">
                <label>Phone 2</label>
                <input type="text" name="phone2" id="phone2" class="form-control" >
              </div>
            </div>
            <div class="col-md-3 col-xs-6">
              <div class="form-group">
                <label>Email <span style="color:#b12f1f;">*</span></label>
                <input type="email" name="email" id="email" class="form-control" required="">
              </div>
            </div>
            <div class="col-md-3 col-xs-6">
              <div class="form-group">
                <label>Email 2</label>
                <input type="email" name="email2" id="email2" class="form-control" >
              </div>
            </div>
            <div class="col-md-6 col-xs-12">
              <div class="form-group">
                <div><label>Address</label></div>
                <textarea rows="3" name="address" id="address" class="form-control" placeholder="Address here.."></textarea>
              </div>
            </div>
            <div class="col-md-6 col-xs-12">
              <div class="form-group">
                <div><label>Introduction</label></div>
                <textarea rows="3" name="intro" id="intro" class="form-control" placeholder="Introduction here.."></textarea>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer" style="text-align: center;">
          <button type="submit" class="btn btn-success btn-flat btn-sm" >Save</button>
          <a href="#" class="btn btn-danger btn-flat btn-sm" data-dismiss="modal">Cancel</a>
        </div>
      </div>      
    </form>
  </div>
</div>
<script type="text/javascript">
  $(document).ready(function(){
    $(".datatable").DataTable();
    $("#btnAddDriver").on("click", function(){
      $("#eid").val("");
    });
  });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>