<?php $__env->startSection('title', 'OutStanding'); ?>
<?php 
  use App\component\Content;
  $comadd = \App\Company::find(1);
?>
<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
      <?php echo $__env->make('admin.report.headerReport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
      <?php if($journals->count() > 0): ?>
      <div class="pull-right">
        <button type="submit" class="btn btn-default btn-acc btn-xs hidden-print" onclick="window.print();"><i class="fa fa-print Print"></i> Print</button>
        <span class="btn btn-default btn-acc btn-xs hidden-print myConvert"><i class="fa fa-print Print"></i> Download</span>
      </div>

      <table class="table tableExcel" border="1">
        <tr style="background-color: #e8f1ff; color: #3c8dbc;">
          <th style="border-top: none;border-bottom: 1px solid #ddd;" width="8px">No.</th>
          <th style="border-top: none;border-bottom: 1px solid #ddd;" width="106px" title="Invoice Paid Date">INV Paid Date</th>
          <th style="border-top: none;border-bottom: 1px solid #ddd;" width="200px">Descriptions</th>
          <th style="border-top: none;border-bottom: 1px solid #ddd;">File/Project</th>
          <th style="border-top: none;border-bottom: 1px solid #ddd;">Client Name</th>            
          <th style="border-top: none;border-bottom: 1px solid #ddd;" class="text-right" title="Amount To Pay/Receive"> Amount To Pay</th> 
          <th style="border-top: none;border-bottom: 1px solid #ddd;" class="text-right">Deposit/Paid </th>
          <th style="border-top: none;border-bottom: 1px solid #ddd;" class="text-right" title="Balance to Pay/Receive">Balance To AP/RP</th>
          
          <th style="border-top: none;border-bottom: 1px solid #ddd;" class="text-right" title="Amount To Pay <?php echo e(Content::currency(1)); ?>">To Pay <?php echo e(Content::currency(1)); ?></th> 
          <th style="border-top: none;border-bottom: 1px solid #ddd;" class="text-right">Deposit/Paid <?php echo e(Content::currency(1)); ?></th>
          <th style="border-top: none;border-bottom: 1px solid #ddd;" class="text-right" title="Balance to Pay/Receive">Balance To AP/RP <?php echo e(Content::currency(1)); ?></th>

          <th style="border-top: none;border-bottom: 1px solid #ddd;" class="text-right">Paid From / To</th>
        </tr>
          <?php
            $totalBalance = 0;
            $totalKBalanceKyat = 0;
            $n=0;
          ?>
        <tbody>
          
            <?php $__currentLoopData = $journals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
              <?php
                // $jnlTransaction = App\AccountTransaction::where(['journal_id'=>$sup->id, 'status'=>1])->whereNotIn('id',$tranCheck)->get();
                $jnlTransaction = App\AccountTransaction::where(['journal_id'=>$jn->id, 'status'=>1, 'supplier_id'=> $jn->supplier_id])->whereIn('id',[$tranCheck])->get();
              ?>

              <?php if($jnlTransaction->count() > 0): ?>
                <?php $__currentLoopData = $jnlTransaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $sub = App\Supplier::find($tran->supplier_book); 
                   $n++;
                   $DepositAmt = ($tran->credit > 0 ? $tran->credit : $tran->debit);
                   $DepositAmtKyat = ($tran->kcredit > 0 ? $tran->kcredit : $tran->kdebit);
                   $totalBalance = $totalBalance + ($tran->total_amount - $DepositAmt);
                   $totalKBalanceKyat = $totalKBalanceKyat + ($tran->total_kamount - $DepositAmtKyat);
                  ?>
                  <tr>
                    <td class="text-center"><?php echo e($n); ?></td>
                    <td class="text-left"><?php echo e(Content::dateformat($tran->invoice_pay_date)); ?></td>
                    <td><?php echo e($tran->remark); ?></td>
                    <td class="text-left">
                      <?php if($tran->project): ?>
                        <a target="_blank" href="<?php echo e(route('getJournalReport', ['journal_entry'=>$tran->project['project_number']])); ?>"><?php echo e($tran->project['project_prefix']); ?>-<?php echo e($tran->project['project_fileno']); ?></a>
                      <?php endif; ?>
                    </td>
                    <td class="text-left"><?php echo e($tran->project['project_client']); ?></td>
                    <td class="text-right"><?php echo e(Content::money($tran->total_amount)); ?></td>                
                    <td class="text-right">
                      <?php if($tran->type == 1): ?>
                        <span style="color:red"><?php echo e($tran->credit < 0 ? number_format($tran->credit,2) :''); ?></span>
                      <?php else: ?> 
                        <span style="color: #10e719;font-weight: 700;"><?php echo e(number_format($tran->debit,2)); ?></span>
                      <?php endif; ?>
                    </td>
                    <td class="text-right"><?php echo e(number_format(($tran->total_amount - $DepositAmt),2)); ?></td>
                    <td class="text-right"><?php echo e(Content::money($tran->total_kamount)); ?></td>                
                    <td class="text-right" style="color:#3c8dbc; font-weight: 700"><?php echo e(Content::money($DepositAmtKyat)); ?></td>
                    <td class="text-right"><?php echo e(number_format(($tran->total_kamount - $DepositAmtKyat), 2)); ?></td>
                    <td class="text-right"><?php echo e($sub['supplier_name']); ?></td> 
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
                <?php $totalBalance = $totalBalance + $jn->book_amount;
                  $n++;
                   ?>
                  <tr>
                    <td><?php echo e($n); ?> </td>
                    <td class="text-left"><?php echo e(Content::dateformat($jn->entry_date)); ?></td>
                    <td><?php echo e($jn->remark); ?></td>
                    <td class="text-left">
                      <?php if($jn->project): ?>
                        <a target="_blank" href="<?php echo e(route('getJournalReport', ['journal_entry'=>$jn->project['project_number']])); ?>"><?php echo e($jn->project['project_prefix']); ?>-<?php echo e($jn->project['project_fileno']); ?></a>
                      <?php endif; ?>
                    </td>
                    <td class="text-left"><?php echo e($jn->project['project_client']); ?></td>
                    <td class="text-right"><?php echo e(Content::money($jn->book_amount)); ?></td>                
                    <td class="text-right" ></td>
                    <td class="text-right" style="color:#3c8dbc; font-weight: 700"><?php echo e(Content::money($jn->book_amount)); ?></td>

                    <td class="text-right"><?php echo e(Content::money($jn->book_kamount)); ?></td>                
                    <td class="text-right" style="color:#3c8dbc;"></td>
                    <td class="text-right"><?php echo e(Content::money($jn->book_kamount)); ?></td>
                    <td class="text-right"></td> 
                  </tr>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
          <tr style="background-color: #e8f1ff; font-weight: 700;">
            <th colspan="7" class="text-right">Sub Total: </th> 
            <th class="text-right"><?php echo e(number_format($totalBalance,2)); ?></th>
            <th class="text-right" colspan="3"><?php echo e(number_format($totalKBalanceKyat,2)); ?></th>
            <th class="text-right"></th>
          </tr>
        </tfoot>
      </table>  
      <?php endif; ?>
  </div>

  <script type="text/javascript" src="<?php echo e(asset('js/jquery.table2excel.min.js')); ?>"></script>
  <script type="text/javascript">
    $(document).ready(function(){
      $(".myConvert").click(function(){
          if(confirm('Do you to export in excel?')){
            $(".tableExcel").table2excel({
              exclude: ".noExl",
              name: "Daily Cash",
              filename: "OutStanding of ",
              fileext: ".xls",
              exclude_img: true,
              exclude_links: true,
              exclude_inputs: true
            });
            return false;
          }else{
            return false;
          }
      });
    });
  </script>

  <?php echo $__env->make("admin.account.accountant", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>