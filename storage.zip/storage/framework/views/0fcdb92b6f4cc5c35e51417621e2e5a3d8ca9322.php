<?php $__env->startSection('title', isset($business) ? $business->name: 'Suppliers'); ?>
<?php 
  $active = isset($business->slug) == "agents" ? 'supplier/'.$business->slug: 'suppliers'; 
  $supply = isset($business) ? $business->slug: 'supplier'; 
  $subactive = isset($business) ? 'supplier/'.$business->slug: 'suppliers';
  use App\component\Content;
  $busIn = $business['id'];
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper"> 
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <section class="col-lg-12 connectedSortable">
        <h3 class="border">Suppliers <?php echo e(isset($business->name) ? $business->name : ''); ?> List <span class="fa fa-angle-double-right"></span> <a href="<?php echo e(route('getSupplierForm', ['type'=> $supply] )); ?>" class="btn btn-primary btn-sm">Add New Supplier</a></h3>
        <?php $getLocation = App\Country::countryBySupplier([$busIn]); ?>
        <?php if($getLocation->count() >0): ?>
          <form action="" method="" style="position: relative; z-index: 2;">
            <div class="col-sm-2 col-xs-6 pull-right" style="text-align: right;">
              <label class="location">
                <select class="form-control input-sm locationchange" name="location">
                  <option value="0">--Choose--</option>
                  <?php $__currentLoopData = $getLocation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($loc->id); ?>" <?php echo e($locationid == $loc->id ? 'selected':''); ?>><?php echo e($loc->country_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>                 
              </label>
            </div>
          </form>
        <?php endif; ?>
        <table class="datatable table table-hover table-striped">
          <thead>
            <tr>
              <th class="hidden-xs" width="20px">Logo</th>
              <th>Name</th>
              <?php if(!isset($supplierName)): ?>
              <th>Type</th>
              <?php endif; ?>
              <th>Phone</th>
              <th>Email</th>
              <th class="hidden-xs">City</th>
              <th class="hidden-xs" width="75">Member On</th>
              <?php if(isset($supplierName)): ?>
                <?php if($supplierName == 'restaurants'): ?>
                  <th>Restaurant</th>
                <?php endif; ?>
              <?php endif; ?>

              <?php if(isset($supplierName)): ?>
                <?php if($supplierName == 'hotels'): ?>
                <th class="text-center">Room</th>
                <?php endif; ?>
              <?php endif; ?>
              <th class="text-center hidden-xs">Status</th>
              <?php if(isset($supplierName)): ?>
                <?php if($supplierName == 'cruises'): ?>
                <th class="text-center">Program</th>
                <?php endif; ?>
              <?php endif; ?>
              <th width="150" class="text-center">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td class="hidden-xs" width="20px">
                <img src="<?php echo e(Content::urlImage($sup->supplier_photo)); ?>" style="width: 100%"></td>
              <td><?php echo e($sup->supplier_name); ?></td>
              <?php if(!isset($supplierName)): ?>
                <td><?php echo e(isset($sup->business->name) ? $sup->business->name : ''); ?></td>
              <?php endif; ?>
              <td><?php echo e($sup->supplier_phone); ?></td>
              <td><?php echo e($sup->supplier_email); ?></td>
             
              <td class="hidden-xs"><?php echo e(isset($sup->province->province_name) ? $sup->province->province_name : ''); ?></td>
              <td class="hidden-xs"><?php echo e(Content::dateformat($sup->updated_at)); ?></td> 
              <?php if(isset($supplierName)): ?>
                <?php if($supplierName == "hotels"): ?>
                <td class="text-center"><label title="Number of Room" class="badge"><?php echo e($sup->room->count()); ?></label></td>
                <?php endif; ?>
              <?php endif; ?>  
              <?php if(isset($supplierName)): ?>
                <?php if($supplierName == 'restaurants'): ?>
                  <td class="text-center"><label class="badge"><?php echo e($sup->res_menu()->where('status',1)->count()); ?></label> <a target="_blank" href="<?php echo e(route('restMenu')); ?>?rest=<?php echo e($sup->id); ?>">View Menu</a></td>
                <?php endif; ?>
              <?php endif; ?> 
              <td class="text-center hidden-xs">
                <?php if($sup->supplier_status == 1): ?>
                  <label class="icon-list ic_active"></label>
                <?php else: ?>
                  <label class="icon-list ic_inactive"></label>
                <?php endif; ?>
              </td>
              <?php if(isset($supplierName)): ?>
                <?php if($supplierName == "cruises"): ?>
                <td class="text-center"><label class="badge"><?php echo e($sup->crprogram->count()); ?></label></td>
                <?php endif; ?>
              <?php endif; ?>                                   
              <td class="text-right">
                <?php if(isset($supplierName)): ?>
                  <?php if($supplierName == "transport"): ?>
                    <a target="_blank" href="<?php echo e(route('getDriver', ['id'=> $sup->id])); ?>" title="Preview Driver">
                      <i style="padding:1px 2px; position: relative;top:-5px;" class="btn btn-primary btn-xs a fa fa-list-alt"></i>
                    </a>
                  <?php endif; ?>
                <?php endif; ?>
                <a href="<?php echo e(route('getEditSupplier', ['url'=> $sup->id])); ?>" title="Edit Supplier">
                  <label  class="icon-list ic_book_project"></label>
                </a>
                <?php if(isset($supplierName)): ?>
                  <?php if($supplierName == "cruises"): ?>
                    <a href="<?php echo e(route('getCruiseProgram',['uri' => $sup->id])); ?>" title="Create River Cruises Program">
                      <label  class="icon-list ic_book_add"></label>
                    </a>
                  <?php endif; ?>
                <?php endif; ?>  
                <?php if(isset($supplierName)): ?>
                  <?php if($supplierName == "hotels"): ?>
                    <a href="<?php echo e(route('getRoomApply',['hotelId' => $sup->id])); ?>" title="Apply Room">
                      <label class="icon-list ic_roomApply"></label>
                    </a>              
                    <a target="_blank" href="<?php echo e(route('supplierReport' ,['reportId' => $sup->id,'type'=> isset($sup->business->slug)? $sup->business->slug :''])); ?>?type=selling" title="View report hotel selling price">
                      <label class="icon-list ic_report"></label>
                    </a> 
                    <a href="<?php echo e(route('getEditHotelInfo', ['url'=> $sup->id])); ?>" title="Edit hotel Infor">
                      <label  class="icon-list ic_book_project"></label>
                    </a>
                    <a target="_blank" href="<?php echo e(route('supplierReport' ,['reportId' => $sup->id,'type'=> isset($sup->business->slug)? $sup->business->slug :''])); ?>?type=contract" title="View report hotel contract">
                      <label  class="icon-list ic_invoice_drop"></label>
                    </a>
                  <?php endif; ?>
                <?php endif; ?> 
                <a target="_blank" href="<?php echo e(route('supplierReport' ,['reportId' => $sup->id,'type'=> isset($sup->business->slug)? $sup->business->slug :''])); ?>" title="View <?php echo e(isset($business->name) ? $business->name : 'supplier'); ?> Report">
                  <label class="icon-list ic_report"></label>
                </a> 
                              
                <a href="javascript:void(0)" class="RemoveHotelRate" data-type="supplier" data-id="<?php echo e($sup->id); ?>" title="Remove this Flight Number ?">
                  <label class="icon-list ic_remove"></label>
                </a>                   
              </td>                     
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>                
      </section>
      <div class="clearfix"></div>
    </section>
  </div>  
</div>
<script type="text/javascript">
  $(document).ready(function(){
    $(".datatable").DataTable({
      language: {
        searchPlaceholder: "<?php echo e(isset($supplierName) ? $supplierName : ''); ?>"
      }
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>