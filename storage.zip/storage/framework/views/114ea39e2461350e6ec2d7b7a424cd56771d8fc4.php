<?php $__env->startSection('title', 'Booked Cruise List'); ?>
<?php $active = 'booked/project'; 
$subactive ='booked/cruise';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <form method="POST" action="<?php echo e(route('searchProject', ['project'=> 'cruise'])); ?>">
           <?php echo e(csrf_field()); ?>

            <section class="col-lg-12 connectedSortable">
                <h3 class="border">Booked Cruise List</h3>
                <div class="col-sm-8 col-xs-12 pull-right">
                  <div class="col-md-3">
                    <input type="hidden" value="<?php echo e(isset($projectNum) ? $projectNum : ''); ?>" id="projectNum">
                    <input class="form-control input-sm" type="text" id="from_date" name="start_date" placeholder="From Date" value="<?php echo e(isset($startDate) ? $startDate : ''); ?>"> 
                  </div>
                  <div class="col-md-3">
                    <input class="form-control input-sm" type="text" id="to_date" name="end_date" placeholder="To Date" value="<?php echo e(isset($endDate) ? $endDate : ''); ?>"> 
                  </div>
                  <div class="col-md-2" style="padding: 0px;">
                    <button class="btn btn-default btn-sm" type="submit">Search</button>
                  </div>
                </div>
                <table class="datatable table table-hover table-striped">
                  <thead>
                    <tr>                       
                      <th width="75">Project No.</th>
                      <th>Date</th>
                      <!-- <th>City</th> -->
                      <th>River Cruise</th>
                      <th>Program</th>
                      <th>User</th>
                      <th>Booking Type</th>
                      <th class="text-center" style="width: 17%;">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php 
                        $supb = \App\Supplier::find($rc->cruise_id);
                        $conb = \App\Country::find($rc->country_id);
                        $prob = \App\Province::find($rc->province_id);
                        $cruisb = \App\CrProgram::find($rc->program_id);
                        $user   = \App\User::find($rc->book_userId);
                        $RCJournal = App\AccountJournal::where(['business_id'=>3,'project_number'=>$rc->book_project, 'status'=>1, 'type'=>1, 'supplier_id'=>$rc->cruise_id,])->first(); 
                      ?>
                      <tr>
                        <td width="75"><?php echo e($rc->book_project); ?></td>
                        <td><?php echo e(Content::dateformat($rc->book_checkin)); ?></td>
                        <td><?php echo e(isset($supb->supplier_name) ? $supb->supplier_name : ''); ?> <span class="badge"><?php echo e(isset($prob->province_name) ? $prob->province_name : ''); ?></span></td>
                        <td><?php echo e(isset($cruisb->program_name) ? $cruisb->program_name : ''); ?></td>
                        <td><?php echo e(isset($user->fullname) ? $user->fullname : ''); ?></td>
                        <td class="text-center">
                          <?php if($rc->book_option == 1): ?>
                            <span class="text-danger">Quotation</span>
                            <?php else: ?>
                              <span class="text-success">Booking</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                          <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$rc->book_project, 'type'=>'details'])); ?>" title="Program Details">
                            <label class="icon-list ic_ops_program"></label>
                          </a>&nbsp;
                          <?php if($RCJournal == Null): ?>
                            <a target="_blank" href="<?php echo e(route('bookingEdit', ['url'=>'cruise', 'id'=>$rc->book_id])); ?>" title="Edit Cruise">
                              <label class="icon-list ic_edit"></label>
                            </a>&nbsp;
                          <?php endif; ?>
                          <a target="_blank" href="<?php echo e(route('bookedCruise', ['pro'=> $rc->book_project,'cruise'=>$rc->cruise_id,'book'=>$rc->book_id])); ?>" title="Book room for this Cruse" style="position: relative;top: -1px;">
                            <i class="fa fa-hotel (alias)" style="font-size: 19px;color: #c38015;"></i>
                          </a>&nbsp;
                          <a target="_blank" href="<?php echo e(route('searchProject', ['project'=> 'cruiserate', 'textSearch'=>$rc->book_project])); ?>" title="View Cruise Booking Rate">
                            <label class="icon-list ic_inclusion"></label>
                          </a>&nbsp;
                          <?php if($RCJournal == Null): ?>
                            <a onclick="return confirm('Are you sure to Remove Cruise Rate ?');" href="<?php echo e(route('RhPrice', ['rc'=> isset($rc->cruise_id)? $rc->cruise_id:0 , 'book'=> $rc->book_id, 'type'=> 'cruise'])); ?>" title="Remove cruise rate all in this project" style="position: relative;top: -2px;">
                              <i class="fa fa-trash" style="font-size: 19px;color: #8e877b;"></i>
                            </a>
                            <?php echo Content::DelUserRole("Delete this Flight Booked ?", "book_cruise", $rc->book_id, $rc->user_id ); ?>            
                          <?php else: ?>
                              <span title="Project have been posted. can't edit" style="border-radius: 50px;border: solid 1px #795548; padding: 0px 6px;  position: relative;top: -4px;">Posted</span>
                          <?php endif; ?>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <!-- <div class="pull-left">Check All</div> -->
            </section>
          </form>
        </div>
    </section>
  </div>
  <script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>