<?php $__env->startSection('title', 'Reportation'); ?>
<?php
  $active = 'restaurant/menu'; 
  $subactive = 'entrance/service';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
	<div class="content-wrapper">
	    <section class="content"> 
		    <div class="row">
		      	<?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		        <section class="col-lg-12 connectedSortable">
		           	<div class="col-md-12">
		           		<h3 style="text-transform:capitalize; color: #3c8dbc;"><i class="fa fa-user-md" style="font-size: 21px;"></i> Suppliers Reportation </h3>
		           	</div>
		            <form method="GET" action="">
		            	<div class="row">
		            		<?php $getBusType = App\Business::where(['status'=>1,'web'=>0])->whereNotIn('id', [4,51,5,10,13,12,9])->whereHas('supplier', function($query){
		            			$query->where('supplier_status',1);
		            		})->orderBy('name')->get(); ?>
	                        <div class="col-md-3"> 
		                        <select class="form-control" name="business">   
		                        	<?php $__currentLoopData = $getBusType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                        		<?php $busid = isset($bus_id) ? $bus_id : 0; ?>
		                        		<option value="<?php echo e($bus->id); ?>" <?php echo e($busid == $bus->id ? 'selected' : ''); ?>><?php echo e($bus->name); ?></option>
		                        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                        </select>
	                        </div>
	                        <div class="col-md-3">
		                        <div class="form-group">
		                            <input type="text" name="supplier" class="form-control" value="<?php echo e($supp['supplier_name']); ?>" placeholder="Supplier Name Search..." >		           	
		                        </div>
	                        </div>
	                        <div class="col-md-2">
		                        <div class="form-group">
		                            <input type="text" name="start_date" class="form-control text-center" id="from_date" value="<?php echo e(isset($start_date) ? $start_date : ''); ?>"  placeholder="Date From" readonly>
		                        </div>
	                        </div>
	                        <div class="col-md-2">
		                        <div class="form-group">
		                            <input type="text" name="end_date" class="form-control text-center" id="to_date" value="<?php echo e(isset($end_date) ? $end_date : ''); ?>" placeholder="Date To" readonly>
		                        </div>
	                        </div>
	                        <div class="col-md-1">
		                        <div class="form-group">
		                            <div class="pull-left">
		                              <button type="submit" class="btn btn-primary " id="btnSearchJournal">Search</button>
		                            </div>
		                        </div>
	                        </div> 
                        </div>
                    </form>
                    <hr style="border: none;border-top: solid #3c8dbc; margin-top: 0px;">
                    <div class="col-md-12">
                    	<?php if(isset($bookeds) && $bookeds != Null): ?>
			    			<span class="pull-right">
			    				<div class="dropup">
								  	<button class="btn btn-primary btn-acc btn-xs dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								    Download <span class="caret"></span>
								  	</button>
									<ul class="dropdown-menu" aria-labelledby="dropdownMenu2">
									    <li><a href="#" class="ok_download" data-type="pdf"><i class="fa fa-file-pdf-o"></i>PDF</a></li>
									    <li><a href="#" class="ok_download" data-type="excel"><i class="fa fa-file-excel-o"></i> Excel</a></li>
									</ul>
								</div>
							</span>
						<?php endif; ?>
		    		
			           	<?php if($bus_id == 1): ?>
			           		<?php echo $__env->make('admin.report.supplier_booked.hotelbooked', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			           	<?php elseif($bus_id == 2): ?>
			           		<?php echo $__env->make('admin.report.supplier_booked.restaurantbooked', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			           	<?php elseif($bus_id == 6): ?>
			           		<?php echo $__env->make('admin.report.supplier_booked.guidebooked', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			           	<?php elseif($bus_id == 7): ?>
			           		<?php echo $__env->make('admin.report.supplier_booked.transportbooked', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			           	<?php elseif($bus_id == 29): ?>
			           		<?php echo $__env->make('admin.report.supplier_booked.golfbooked', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			           	<?php elseif($bus_id == 37): ?>
			           		<?php echo $__env->make('admin.report.supplier_booked.ticketingbooked', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			           	<?php endif; ?>
			        </div>
		        </section>
		    </div>
	    </section>
	</div>
</div>

<script type="text/javascript" src="<?php echo e(asset('js/jquery.table2excel.min.js')); ?>"></script>
<script type="text/javascript">
	$(".ok_download").click(function(){
		var type = $(this).data('type');
		if (type == 'excel') {
			$(".excel-sheed").table2excel({
				exclude: ".noExl",
				name: "Supplier booked report by <?php echo e(Content::dateformat($start_date)); ?> - <?php echo e(Content::dateformat($end_date)); ?>",
				filename: "Supplier booked report by <?php echo e(Content::dateformat($start_date)); ?> - <?php echo e(Content::dateformat($end_date)); ?>",
				fileext: ".xls",
				exclude_img: true,
				exclude_links: true,
				exclude_inputs: true						
			});
			return false;
		}
	});
</script>


<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>