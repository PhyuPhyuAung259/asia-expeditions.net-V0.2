<?php $__env->startSection('title', 'Golf Service '); ?>
<?php
  $active = 'restaurant/menu'; 
  $subactive = 'golf/service';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <div class="row">
        <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <section class="col-lg-12 connectedSortable">
          <h3 class="border">Golf Services <span class="fa fa-angle-double-right"></span> <a href="#" class="btn btn-default btn-sm" id="addMiscService" data-toggle="modal" data-target="#myModal">Add Service</a></h3>
          <?php if(Auth::user()->role_id == 2): ?>
            <form action="" method="">
                <div class="col-sm-2 col-xs-6 pull-right" style="text-align: right; position: relative; z-index: 2;">
                  <label class="location">
                    <select class="form-control input-sm locationchange" name="loc">
                        <option value="">--choose--</option>
                      <?php $__currentLoopData = \App\Country::conByGolfMenu(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($loc->id); ?>" <?php echo e($locationid == $loc->id ? 'selected':''); ?>><?php echo e($loc->country_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </label>
                </div>
            </form>
            <?php endif; ?>
            <table class="datatable table table-hover table-striped">
              <thead>
                <tr>
                  <th>Golf Service</th>
                  <th>Golf Names</th>
                  <th>Price <?php echo e(Content::currency()); ?></th>
                  <th>Price Net <?php echo e(Content::currency()); ?></th>
                  <th>Price <?php echo e(Content::currency(1)); ?></th>
                  <th>Price Net <?php echo e(Content::currency(1)); ?></th>
                  <th class="text-center">Status</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $gservice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($rest->name); ?></td>
                  <td><?php echo e(isset($rest->supplier->supplier_name) ? $rest->supplier->supplier_name : ''); ?></td>                   
                  <td class="text-right"><?php echo e(number_format($rest->price,2)); ?></td>
                  <td class="text-right"><?php echo e(number_format($rest->nprice,2)); ?></td>
                  <td class="text-right"><?php echo e(number_format($rest->kprice,2)); ?></td>
                  <td class="text-right"><?php echo e(number_format($rest->nkprice,2)); ?></td>
                  <td class="text-right">                      
                    <button style="padding:0px; border:none; top: -5px; position: relative;" class="miscEdit" data-country="<?php echo e($locationid); ?>" data-id="<?php echo e($rest->id); ?>"  data-title="<?php echo e($rest->name); ?>" data-price="<?php echo e($rest->price); ?>" data-nprice="<?php echo e($rest->nprice); ?>" data-kprice="<?php echo e($rest->kprice); ?>" data-nkprice="<?php echo e($rest->nkprice); ?>" data-supplier="<?php echo e($rest->supplier_id); ?>" data-toggle="modal" data-target="#myModal">
                      <i style="padding:1px 2px;" class="btn btn-info btn-xs fa fa-pencil-square-o"></i>
                    </button>
                    <a href="javascript:void(0)" class="RemoveHotelRate" data-type="golf_service" data-id="<?php echo e($rest->id); ?>" title="Remove this?">
                      <label src="#" class="icon-list ic-trash"></label>
                    </a>
                  </td>                     
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        </section>
      </div>
    </section>
  </div>
</div>

<div class="modal fade" id="myModal" role="dialog"  data-backdrop="static" data-keyboard="true">
  <div class="modal-dialog modal-lg">    
    <form method="POST" action="<?php echo e(route('addGolfService')); ?>">
      <div class="modal-content">        
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><strong>Add Golf Service</strong></h4>
        </div>
        <div class="modal-body">
          <?php echo e(csrf_field()); ?>    
          <input type="hidden" name="eid" id="eid">
          <div class="row">
           <input type="hidden" name="country" value="<?php echo e($locationid); ?>">
            <div class="col-md-2 text-right">
              <label>Golf Name</label>
            </div>
            <div class="col-md-6 col-xs-12">
              <div class="form-group">               
                <select class="form-control golfName" name="golf_name" id="supplier_golf_dropdown">
                  <option value="">--Choose--</option>
                  <?php $__currentLoopData = App\Supplier::where(['business_id'=>29, 'supplier_status'=>1])->orderBy('supplier_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($gs->id); ?>"><?php echo e($gs->supplier_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <div class="col-md-12">
              <table class="table" id="golf_service_add_row">
                <tr>
                  <th style="border: none;">Service Name</th>
                  <th style="border: none;">Price <?php echo e(Content::currency()); ?></th>
                  <th style="border: none;">Price Net <?php echo e(Content::currency()); ?></th>
                  <th style="border: none;">Price <?php echo e(Content::currency(1)); ?></th>
                  <th style="border: none;">Price Net <?php echo e(Content::currency(1)); ?></th>
                  <th style="border: none;"></th>
                </tr>
                <tbody>
                  <tr >
                    <td width="287px">
                      <input type="text" name="title[]" id="title" class="form-control input-sm" placeholder="Service Name" required="">
                    </td>
                    <td>
                      <input type="text" name="price[]" id="price" class="form-control input-sm number_only" placeholder="00.0">
                    </td>
                    <td>
                      <input type="text" name="nprice[]" id="nprice" class="form-control input-sm number_only" placeholder="00.0">
                    </td>
                    <td>
                      <input type="text" name="kprice[]" id="kprice" class="form-control input-sm number_only" placeholder="00.0">
                    </td>
                    <td>                   
                      <input type="text" name="nkprice[]" id="nkprice" class="form-control input-sm number_only" placeholder="00.0">
                    </td>
                    <td>
                      <i class="fa fa-plus-circle btn btn-flat btn-success addRow"></i>
                    </td>
                  </tr>
              </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="modal-footer" style="text-align: center;">
          <button type="submit" class="btn btn-success btn-flat btn-sm" id="btnEntrance">Save</button>
          <a href="#" class="btn btn-danger btn-flat btn-sm" data-dismiss="modal">Close</a>
        </div>
      </div>      
    </form>
  </div>
</div>
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<script type="text/javascript">
    $(".addRow").on("click", function(){
        $("table#golf_service_add_row tbody tr:last").after('<tr><td width="287px"><input type="text" name="title[]" id="title" class="form-control input-sm" placeholder="Service Name" required=""></td><td><input type="text" name="price[]" id="price" class="form-control input-sm number_only" placeholder="00.0"></td><td><input type="text" name="nprice[]" id="nprice" class="form-control input-sm number_only" placeholder="00.0"></td><td><input type="text" name="kprice[]" id="kprice" class="form-control input-sm number_only" placeholder="00.0"></td><td><input type="text" name="nkprice[]" id="nkprice" class="form-control input-sm number_only" placeholder="00.0"></td><td><i class="fa fa-minus-circle btn btn-danger RemoveRest"></i></td></tr>');
    });
    $(document).on('click','.RemoveRest', function(){
      $(this).closest("tr").remove();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>