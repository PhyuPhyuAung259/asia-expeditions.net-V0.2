<?php $fileno = $project->project_fileno ? $project->project_fileno : $project->project_number ?>
<?php 
	use App\component\Content;
	if ($title == "Query") {
		$title = "Request Cash Advance for Entrance Fee & Expenses";
	}else{
		$title = $title;
	}
?>

<?php $__env->startSection('title', $fileno ."-". $title); ?>
<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="col-lg-12">
			<div class="pull-right hidden-print">
				<a href="javascript:void(0)" onclick="window.print();"><span class="fa fa-print btn btn-primary"></span></a>
			</div>		
			<h3 class="text-center"><span style="text-transform:capitalize; text-decoration:underline; font-weight: 700;"><?php echo e($title); ?></span></h3><br><br>
			<table class="table table-bordered">
				<tr>
					<td style="width:50%;">
						<p><label style="width:120px; margin-bottom:0px;">File No.:</label> <?php echo e($project->project_prefix); ?>-<?php echo e($fileno); ?> </p>
						<p><label style="width:90px; margin-bottom:0px;">Client Name:</label> <?php echo e($project->project_client); ?></p>
						<p><label style="width:90px; margin-bottom:0px;">Tour Date:</label> <?php echo e(Content::dateformat($project->project_start)); ?> - <?php echo e(Content::dateformat($project->project_end)); ?></p>
					</td>
					<td style="width:50%;">
						<p><label style="width:106px; margin-bottom: 0px;">Agent Name:</label> <?php echo e(isset($project->supplier->supplier_name) ? $project->supplier->supplier_name : ''); ?></p>
						<p><label style="width:106px; margin-bottom: 0px;">Reference No.:</label> <?php echo e($project->project_client); ?></p>
						
						<p><label style="width:106px; margin-bottom: 0px;">
						<?php if(isset($project->flightDep->dep_time)): ?>
							Flight No./Arrival:</label> <?php echo e(isset($project->flightDep->flightno) ? $project->flightDep->flightno : ''); ?> - <?php echo e(isset($project->flightDep->dep_time) ? $project->flightDep->dep_time : ''); ?>, &nbsp;&nbsp;  
						<?php endif; ?>
						<?php if(isset($project->flightDep->arr_time)): ?>
							<b>Flight No./Departure:</b> <?php echo e(isset($project->flightArr->flightno) ? $project->flightArr->flightno : ''); ?> - <?php echo e(isset($project->flightDep->arr_time) ? $project->flightDep->arr_time : ''); ?>

						<?php endif; ?>
						</p>

					</td>
				</tr>
			</table>	

			<?php if($title == "B Form WO/P"): ?>
				<table class="table operation-sheed table-bordered">
					<tr class="header-row">
						<th width="10px">No.</th>
						<th>Description</th>
						<th>Service Name</th>
						<th>Date</th>
						<th width="40px" class="text-center">Qty</th>
					</tr>
					<?php 
						$n = 0;
					?>
					<?php if($hotelb->get()->count() > 0): ?>
						<?php $__currentLoopData = $hotelb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td class="text-center"><?php echo e($n++); ?></td>
							<td><?php echo e(isset($hb->hotel->supplier_name) ? $hb->hotel->supplier_name : ''); ?></td>
							<td><?php echo e(isset($hb->room->name) ? $hb->room->name : ''); ?></td>
							<td><?php echo e(Content::dateformat($hb->checkin)); ?> - <?php echo e(Content::dateformat($hb->checkin)); ?></td>
							<td class="text-center"><?php echo e($hb->book_day); ?></td>					
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

					<?php if($flightb->get()->count() > 0): ?>
						<?php $__currentLoopData = $flightb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php 
							$n++;
						?>
						<tr>
							<td class="text-center"><?php echo e($n); ?></td>
							<td><?php echo e(isset($fb->supplier->supplier_name) ? $fb->supplier->supplier_name : ''); ?></td>
							<td><?php echo e(isset($fb->fagent->supplier_name) ? $fb->fagent->supplier_name : ''); ?></td>				
							<td><?php echo e(Content::dateformat($fb->book_checkin)); ?></td>
							<td class="text-center"><?php echo e($fb->book_pax); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

					<?php if($golfb->get()->count() > 0): ?>
						<?php $__currentLoopData = $golfb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php 
							$n++;
						?>
						<tr>
							<td class="text-center"><?php echo e($n); ?></td>
							<td><?php echo e(isset($gb->golf->supplier_name) ? $gb->golf->supplier_name : ''); ?></td>
							<td ><?php echo e(isset($gb->golf_service->name) ? $gb->golf_service->name : ''); ?></td>
							<td><?php echo e(Content::dateformat($gb->book_checkin)); ?></td>
							<td class="text-center"><?php echo e($gb->book_pax); ?></td>					
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

					<?php if($cruiseb->get()->count() > 0): ?>
						<?php $__currentLoopData = $cruiseb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php 
							$n++;
						?>
						<tr>
							<td class="text-center"><?php echo e($n); ?></td>					
							<td><?php echo e(isset($cb->cruise->supplier_name) ? $cb->cruise->supplier_name : ''); ?></td>
							<td><?php echo e(isset($cb->program->program_name) ? $cb->program->program_name : ''); ?></td>
							<td><?php echo e(Content::dateformat($cb->checkin)); ?> - <?php echo e(Content::dateformat($cb->checkout)); ?></td>
							<td class="text-center"><?php echo e($cb->book_day); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

					<?php if($transportb->get()->count() >0): ?>
						<?php $__currentLoopData = $transportb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php 
							$n++; 
							$dateb = \App\Booking::find($bk->book_id);
						?>
						<tr>	
							<td class="text-center"><?php echo e($n); ?></td>
							<td><?php echo e(isset($bk->service->title) ? $bk->service->title : ''); ?></td>
					        <td><?php echo e(isset($bk->vehicle->name) ? $bk->vehicle->name : ''); ?></td>
							<td><?php echo e(Content::dateformat($dateb->book_checkin)); ?></td>
							<td class="text-center"></td>					
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

					<?php if($guideb->get()->count() > 0): ?>
						<?php $__currentLoopData = $guideb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php 
							$n++; 
							$dateb = \App\Booking::find($bg->book_id);
						?>
						<tr>	
							<td class="text-center"><?php echo e($n); ?></td>					
							<td><?php echo e(isset($bg->service->title) ? $bg->service->title : ''); ?></td>
					        <td><?php echo e(isset($bg->language->name) ? $bg->language->name : ''); ?></td>
					        <td><?php echo e(Content::dateformat($dateb->book_checkin)); ?></td>
							<td></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

					<?php if($restaurantb->get()->count() > 0): ?>
						<?php $__currentLoopData = $restaurantb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $n++; ?>
						<tr>	
							<td class="text-center"><?php echo e($n); ?></td>
							<td><?php echo e(isset($rb->supplier->supplier_name) ? $rb->supplier->supplier_name : ''); ?></td>         
						    <td><?php echo e(isset($rb->rest_menu->title) ? $rb->rest_menu->title : ''); ?></td>
						    <td><?php echo e(Content::dateformat($rb->start_date)); ?></td>
						    <td class="text-center"><?php echo e($rb->book_pax); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

					<?php if($entranb->get()->count() > 0): ?>
						<?php $__currentLoopData = $entranb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $n++; ?>
						<tr>	
							<td class="text-center"><?php echo e($n); ?></td>
							<td><?php echo e(isset($rb->entrance->name) ? $rb->entrance->name : ''); ?></td>       
							<td></td>
							<td><?php echo e(Content::dateformat($rb->start_date)); ?></td>
						    <td class="text-center"><?php echo e($rb->book_pax); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

					<?php if($miscb->get()->count() > 0): ?>
						<?php $__currentLoopData = $miscb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $misc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $n++; 
							$dateb = \App\Booking::find($misc->book_id);
						?>
						<tr>	
							<td class="text-center"><?php echo e($n); ?></td>
							<td><?php echo e(isset($misc->servicetype->name) ? $misc->servicetype->name : ''); ?></td>    
							<td></td>   
							<td><?php echo e(Content::dateformat($dateb->book_checkin)); ?></td>
						    <td class="text-center"><?php echo e($misc->book_pax); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
					<tr>
						<td colspan="2" style="border:none;">Request By:............................</td>
						<td colspan="" style="border:none;">Reviewed By:............................</td>
						<td colspan="" style="border:none;">Confirmeds By:............................</td>
					</tr>
					<tr><td style="border: none;"></td></tr>
					<tr>
						<td colspan="5" style="border: none;">
							<b>Remark</b>
							<p><?php echo e($remark); ?></p>
						</td>
					</tr>
				</table>

			<?php else: ?>
				<table class="table operation-sheed table-bordered">
					<tr class="header-row">
						<th width="10px">No.</th>
						<th>Date</th>
						<th>Description</th>
						<th>Service Name</th>
						<th class="text-center">Qty</th>
						<th class="text-center">Price <?php echo e(Content::currency()); ?></th>
						<th class="text-center">Amount</th>
						<th class="text-center">Price <?php echo e(Content::currency(1)); ?></th>
						<th class="text-center">Amount</th>
					</tr>
					<?php 
						$n = 0;
					?>
					<?php if($hotelb->get()->count() > 0): ?>
						<?php $__currentLoopData = $hotelb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php 
							$hbook = \App\Booking::find($hb->book_id);
							$n++;
							if (!empty($hb->nsingle) && $hb->nsingle != 0) {
								$hprice = $hb->nsingle;
							}elseif (!empty($hb->ntwin) && $hb->ntwin != 0) {
								$hprice = $hb->ntwin;
							}elseif(!empty($hb->ndouble) && $hb->ndouble != 0){
								$hprice = $hb->ndouble;
							}elseif (!empty($hb->nextra) && $hb->nextra != 0) {
								$hprice = $hb->nextra;
							}else{
								$hprice = $hb->nchextra;
							}					
						?>
						<tr>
							<td class="text-center"><?php echo e($n); ?></td>
							<td><?php echo e(Content::dateformat($hb->checkin)); ?> - <?php echo e(Content::dateformat($hb->checkin)); ?></td>
							<td><?php echo e(isset($hb->hotel->supplier_name) ? $hb->hotel->supplier_name : ''); ?></td>
							<td><?php echo e(isset($hb->room->name) ? $hb->room->name : ''); ?></td>
							<td class="text-center"><?php echo e($hb->book_day); ?></td>
							<td class="text-right"><?php echo e($hprice); ?></td>
							<td class="text-right"><?php echo e($hb->net_amount); ?></td>
							<td class="text-right"></td>
							<td class="text-right"></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

					<?php if($flightb->get()->count() > 0): ?>
						<?php $__currentLoopData = $flightb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php 
							$n++;
						?>
						<tr>
							<td class="text-center"><?php echo e($n); ?></td>
							<td><?php echo e(Content::dateformat($fb->book_checkin)); ?></td>
							<td><?php echo e(isset($fb->supplier->supplier_name) ? $fb->supplier->supplier_name : ''); ?></td>
							<td><?php echo e(isset($fb->fagent->supplier_name) ? $fb->fagent->supplier_name : ''); ?></td>				
							<td class="text-center"><?php echo e($fb->book_pax); ?></td>
							<td class="text-right"><?php echo e(Content::money($fb->book_price)); ?></td>
							<td class="text-right"><?php echo e(Content::money($fb->book_namount)); ?></td>
							<td class="text-right"><?php echo e(Content::money($fb->book_nkprice)); ?></td>
							<td class="text-right"><?php echo e(Content::money($fb->book_kamount)); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

					<?php if($golfb->get()->count() > 0): ?>
						<?php $__currentLoopData = $golfb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php 
							$n++;
						?>
						<tr>
							<td class="text-center"><?php echo e($n); ?></td>
							<td><?php echo e(Content::dateformat($gb->book_checkin)); ?></td>
							<td><?php echo e(isset($gb->golf->supplier_name) ? $gb->golf->supplier_name : ''); ?></td>
							<td ><?php echo e(isset($gb->golf_service->name) ? $gb->golf_service->name : ''); ?></td>
							<td class="text-center"><?php echo e($gb->book_pax); ?></td>
							<td class="text-right"><?php echo e(Content::money($gb->book_price)); ?></td>
							<td class="text-right"><?php echo e(Content::money($gb->book_namount)); ?></td>
							<td class="text-right"><?php echo e(Content::money($gb->book_kprice)); ?></td>
							<td class="text-right"><?php echo e(Content::money($gb->book_kamount)); ?></td>
							
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

					<?php if($cruiseb->get()->count() > 0): ?>
						<?php $__currentLoopData = $cruiseb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php 
							$n++;
							if (!empty($cb->nsingle) && $cb->nsingle != 0) {
								$hprice = $cb->nsingle;
							}elseif (!empty($cb->ntwin) && $cb->ntwin != 0) {
								$hprice = $cb->ntwin;
							}elseif(!empty($cb->ndouble) && $cb->ndouble != 0){
								$hprice = $cb->ndouble;
							}elseif (!empty($cb->nextra) && $cb->nextra != 0) {
								$hprice = $cb->nextra;
							}else{
								$hprice = $cb->nchextra;
							}		
						?>
						<tr>
							<td class="text-center"><?php echo e($n); ?></td>
							<td><?php echo e(Content::dateformat($cb->checkin)); ?> - <?php echo e(Content::dateformat($cb->checkout)); ?></td>
							<td><?php echo e(isset($cb->cruise->supplier_name) ? $cb->cruise->supplier_name : ''); ?></td>
							<td><?php echo e(isset($cb->program->program_name) ? $cb->program->program_name : ''); ?></td>
							<td class="text-center"><?php echo e($cb->book_day); ?></td>
							<td class="text-right"><?php echo e(Content::money($hprice)); ?></td>
							<td class="text-right"><?php echo e(Content::money($cb->net_amount)); ?></td>
							<td></td>
							<td></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
	 
					<?php if($transportb->get()->count() >0): ?>
						<?php $__currentLoopData = $transportb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php 
							$n++; 
							$dateb = \App\Booking::find($bk->book_id);
							$price = isset($bk->price)? $bk->price:0; 
							$kprice = isset($bk->kprice)? $bk->kprice:0;
							$service = \App\TransportService::find($bk->service_id);
							$vehicle = \App\TransportMenu::find($bk->vehicle_id);
						?>
						<tr>	
							<td class="text-center"><?php echo e($n); ?></td>
							<td><?php echo e(Content::dateformat($dateb->book_checkin)); ?></td>
							<td><?php echo e(isset($service->title) ? $service->title : ''); ?></td>
					        <td><?php echo e(isset($vehicle->name) ? $vehicle->name : ''); ?></td>
							<td class="text-center"></td>
							<td class="text-right"><?php echo e(Content::money($price)); ?></td>
							<td class="text-right"><?php echo e(Content::money($price)); ?></td>
							<td class="text-right"><?php echo e(Content::money($kprice)); ?></td>
							<td class="text-right"><?php echo e(Content::money($kprice)); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

					<?php if($guideb->get()->count() > 0): ?>
						<?php $__currentLoopData = $guideb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php 
							$n++; 
							$dateb = \App\Booking::find($bg->book_id);
							$price = isset($bg->price)?$bg->price :0;
							$kprice = isset($bg->kprice)? $bg->kprice :0;
							$sb = \App\GuideService::find($bg->service_id);
							$supb = \App\Supplier::find($bg->sup_id);
							$langb = \App\GuideLanguage::find($bg->language_id);
						?>
						<tr>	
							<td class="text-center"><?php echo e($n); ?></td>
							<td><?php echo e(Content::dateformat($dateb->book_checkin)); ?></td>
							<td><?php echo e(isset($sb->title) ? $sb->title : ''); ?></td>
					        <td><?php echo e(isset($langb->name) ? $langb->name : ''); ?></td>
							<td></td>
							<td class="text-right"><?php echo e(Content::money($price)); ?></td>
							<td class="text-right"><?php echo e(Content::money($price)); ?></td>
							<td class="text-right"><?php echo e(Content::money($kprice)); ?></td>
							<td class="text-right"><?php echo e(Content::money($kprice)); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

					<?php if($restaurantb->get()->count() > 0): ?>
						<?php $__currentLoopData = $restaurantb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $n++; ?>
						<tr>	
							<td class="text-center"><?php echo e($n); ?></td>
							<td><?php echo e(Content::dateformat($rb->start_date)); ?></td>
							<td><?php echo e(isset($rb->supplier->supplier_name) ? $rb->supplier->supplier_name : ''); ?></td>         
						    <td><?php echo e(isset($rb->rest_menu->title) ? $rb->rest_menu->title : ''); ?></td>
						    <td class="text-center"><?php echo e($rb->book_pax); ?></td>
							<td class="text-right"><?php echo e(Content::money($rb->price)); ?></td>
			                <td class="text-right"><?php echo e(Content::money($rb->amount)); ?></td>
			                <td class="text-right"><?php echo e(Content::money($rb->kprice)); ?></td>
		                  	<td class="text-right"><?php echo e(Content::money($rb->kamount)); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

					<?php if($entranb->get()->count() > 0): ?>
						<?php $__currentLoopData = $entranb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $n++; ?>
						<tr>	
							<td class="text-center"><?php echo e($n); ?></td>
							<td><?php echo e(Content::dateformat($rb->start_date)); ?></td>
							<td><?php echo e(isset($rb->entrance->name) ? $rb->entrance->name : ''); ?></td>       
							<td></td>
						    <td class="text-center"><?php echo e($rb->book_pax); ?></td>
			                <td class="text-right"><?php echo e(Content::money($rb->price)); ?></td>
			                <td class="text-right"><?php echo e(Content::money($rb->amount)); ?></td>
			                <td class="text-right"><?php echo e(Content::money($rb->kprice)); ?></td>
		                  	<td class="text-right"><?php echo e(Content::money($rb->kamount)); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

					<?php if($miscb->get()->count() > 0): ?>
						<?php $__currentLoopData = $miscb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $misc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $n++; 
							$dateb = \App\Booking::find($misc->book_id);
						?>
						<tr>	
							<td class="text-center"><?php echo e($n); ?></td>
							<td><?php echo e(Content::dateformat($dateb->book_checkin)); ?></td>
							<td ><?php echo e(isset($misc->servicetype->name) ? $misc->servicetype->name : ''); ?></td>    
							<td></td>   
						    <td class="text-center"><?php echo e($misc->book_pax); ?></td>
			                <td class="text-right"><?php echo e(Content::money($misc->price)); ?></td>
			                <td class="text-right"><?php echo e(Content::money($misc->amount)); ?></td>
			                <td class="text-right"><?php echo e(Content::money($misc->kprice)); ?></td>
		                  	<td class="text-right"><?php echo e(Content::money($misc->kamount)); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
					<tr>
						<td colspan="5" class="text-right" style="border-bottom: none; border-bottom: none;" ></td>
						<td colspan="2" class="text-right" style="border-bottom: none; border-bottom: none;">
							<?php 
							$grandtotal = $hotelb->sum('net_amount') + $flightb->sum('book_namount') + $golfb->sum('book_namount') + 
										$cruiseb->sum('net_amount') + $transportb->sum('price') + $guideb->sum('price') + 
										$restaurantb->sum('amount') + $entranb->sum('amount') + 
										$miscb->sum('amount');
							?>
											<h4><b>Total <?php echo e(Content::currency()); ?>: <?php echo e(Content::money($grandtotal)); ?></b></h4>
										</td>
										<td colspan="2" class="text-right" style="border-bottom: none; border-bottom: none;">
							<?php 
							$ktotal = $flightb->sum('book_kamount') + $transportb->sum('kprice') + 
										$golfb->sum('book_kamount') + $guideb->sum('kamount') + 
										$restaurantb->sum('kamount') + $entranb->sum('kamount') + 
										$miscb->sum('kamount'); 
							?>
							<h4><b>Total <?php echo e(Content::currency(1)); ?>: <?php echo e(Content::money($ktotal)); ?></b></h4>
						</td>
					</tr>
					<tr>
						<td colspan="3" style="border:none;">Request By:............................</td>
						<td colspan="3" style="border:none;">Reviewed By:............................</td>
						<td colspan="3" style="border:none;">Confirmeds By:............................</td>
					</tr>
					<tr><td style="border: none;"></td></tr>
					<tr>
						<td colspan="9" style="border: none;">
							<b>Remark</b>
							<p><?php echo e($remark); ?></p>
						</td>
					</tr>
				</table>
			<?php endif; ?>
	  	</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>