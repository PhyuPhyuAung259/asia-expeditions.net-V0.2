<?php $__env->startSection('title', 'All Province'); ?>
<?php
  $active = 'country'; 
  $subactive ='province';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
            <section class="col-lg-12 connectedSortable">
                <h3 class="border">Documentation List <span class="fa fa-angle-double-right"></span> <a href="<?php echo e(route('createDocs',[ 'url' => 'Create'])); ?>" class="btn btn-default btn-sm">Create New Documentation</a></h3>
               
                <table class="datatable table table-hover table-striped">
                  <thead>
                    <tr>
                      <th>Title</th>
                      <th>User</th>
                      <th>Created Date</th>
                      <th class="text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    
                      <td><?php echo e($doc->title); ?></td>
                      <td><?php echo e($doc->user->fullname); ?></td>
                      <td><?php echo e(Content::dateformat($doc->updated_at)); ?></td> 
                      <td class="text-right">                      
                        <a href="<?php echo e(route('createDocs',['url'=> $doc->id, 'eId'=> $doc->id])); ?>" title="Edit Provice">
                          <label class="icon-list ic_book_project"></label>
                        </a>
                      
                      </td>                     
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
            </section>
        </div>
    </section>
  </div>
</div>
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>