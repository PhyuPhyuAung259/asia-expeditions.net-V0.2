<?php $__env->startSection('title', 'Booked Flight List'); ?>
<?php $active = 'booked/project'; 
  $subactive ='booked/flight';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <form method="POST" action="<?php echo e(route('searchProject', ['project'=> 'flight'])); ?>">
             <?php echo e(csrf_field()); ?>

            <section class="col-lg-12 connectedSortable">
                <h3 class="border">Booked Flight List</h3>
                <div class="col-sm-8 pull-right">
                  <div class="col-md-3">
                    <input type="hidden" name="" value="<?php echo e(isset($projectNum) ? $projectNum : ''); ?>" id="projectNum">
                    <input class="form-control input-sm" type="text" id="from_date" name="start_date" placeholder="From Date" value="<?php echo e(isset($startDate) ? $startDate : ''); ?>"> 
                  </div>
                  <div class="col-md-3">
                    <input class="form-control input-sm" type="text" id="to_date" name="end_date" placeholder="To Date" value="<?php echo e(isset($endDate) ? $endDate : ''); ?>"> 
                  </div>
                   <div class="col-md-2" style="padding: 0px;">
                    <button class="btn btn-default btn-sm" type="submit">Search</button>
                  </div>
                </div>
                <table class="datatable table table-hover table-striped">
                  <thead>
                    <tr>                       
                      <th width="65">Project No.</th>
                      <th>Date</th>
                      <th>Flight Agency</th>
                      <th>Flight No.</th>
                      <th>Destination</th>
                      <th>User</th>
                      <th>Pax</th>
                      <th class="text-right">Unit <?php echo e(Content::currency()); ?></th>
                      <th class="text-right">Amount</th>
                      <th>Booking Type</th>
                      <th class="text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fsch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php 
                        $supb  = \App\FlightSchedule::find($fsch->flight_id);
                        $agenb = \App\Supplier::find($fsch->book_agent);
                        $user  = \App\User::find($fsch->book_userId);
                      ?>
                    <tr>
                      <td width="75"><?php echo e($fsch->book_project); ?></td>
                      <td><?php echo e(Content::dateformat($fsch->book_checkin)); ?></td>
                      <td><?php echo e($agenb['supplier_name']); ?></td>
                      <td><?php echo e($supb['flightno']); ?></td>
                      <td><?php echo e(isset($supb->flight_from) ? $supb->flight_from : ''); ?> - <?php echo e(isset($supb->flight_to) ? $supb->flight_to : ''); ?></td>
                      <td><?php echo e(isset($user->fullname) ? $user->fullname : ''); ?></td>
                      <td><?php echo e($fsch->book_pax); ?></td>
                      <td class="text-right"><?php echo e(Content::money($fsch->book_price)); ?></td>
                      <td class="text-right"><?php echo e(Content::money($fsch->book_amount)); ?></td>
                      <td class="text-center">
                        <?php if($fsch->book_option == 1): ?>
                          <span class="text-danger">Quotation</span>
                        <?php else: ?>
                          <span class="text-success">Booking</span>
                        <?php endif; ?>
                      </td>
                      <td class="text-center">
                        <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$fsch->book_project, 'type'=>'details'])); ?>" title="Program Details">
                          <label class="icon-list ic_ops_program"></label>
                        </a>
                        <a target="_blank" href="<?php echo e(route('bookingEdit', ['type'=>'flight', 'bookid'=>$fsch->book_id])); ?>" title="Edit flight booking">
                          <label class="icon-list ic_edit"></label>
                        </a> 
                       <!--  &nbsp;           
                        <a href="javascript:void(0)" class="RemoveHotelRate" data-type="book_flight" data-id="<?php echo e($fsch->book_id); ?>" title="Delete this booking">
                          <label class="icon-list ic_remove"></label>
                        </a>      -->        
                        <?php echo Content::DelUserRole("Delete this Flight Booked ?", "book_flight", $fsch->book_id, $fsch->user_id ); ?>            
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <!-- <div class="pull-left">Check All</div> -->
            </section>
          </form>
        </div>
    </section>
  </div>
  <script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>