<?php $__env->startSection('title', 'Project '.$type); ?>
<?php 
	use App\component\Content;
	$user = App\User::find($project->check_by);
?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="col-lg-12">
    <?php echo $__env->make('admin.report.project_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
		<div class="pull-left">
			<div><b>CRD:</b> <?php echo e(Content::dateformat($project->project_date)); ?>, 
				<?php if($project->project_check ): ?>
				Project No. <b><?php echo e($project->project_number); ?></b> is Already checked by <b><?php echo e(isset($user->fullname) ? $user->fullname : ''); ?></b> at <?php echo e(Content::dateformat($project->project_check_date)); ?>,
				<?php endif; ?>
				<b>Revised Date</b> <?php echo e(Content::dateformat($project->project_revise)); ?>

			</div> 
		</div>
		<div class="pull-right hidden-print">
			<a href="javascript:void(0)" onclick="window.print();"><span class="fa fa-print btn btn-primary"></span></a>&nbsp;&nbsp;&nbsp;&nbsp;
		</div><div class="clearfix"></div>
		<?php if($project->project_hight): ?>
		<div class="form-group"><?php echo $project->project_hight; ?></div>
		<?php endif; ?>
		<table class="table">
			<tr>
				<th style="border-top:0px;">Date</th>
				<th style="border-top:0px;">Service</th>
			</tr>
			<tbody>
				<?php if($booking->count() > 0): ?>
					<?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td width=100px" style="vertical-align: top;"><h5><b><?php echo e(date('d M Y', strtotime($book->book_checkin))); ?></b></h5><?php echo e(date('l', strtotime($book->book_checkin))); ?></td>
						<td style="vertical-align: top;">					
						<?php if(!empty($book->book_checkin) && !empty($book->book_project)): ?>
							<?php 
								$getBook = \App\Booking::where(['book_checkin'=>$book->book_checkin, 'book_project'=>$book->book_project, 'book_status'=> 1])->orderBy('hotel_id','ASC')->orderBy("book_checkin", "DESC")->get();
							?>
							<?php $__currentLoopData = $getBook; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php 
									$bhotel = App\HotelBooked::where(['book_id'=> $prow->id, 'project_number'=> $prow->book_project])->first();
									$bcruise = App\CruiseBooked::where(['book_id'=> $prow->id, 'project_number'=> $prow->book_project])->first();
								?>
								<table style="width: 100%;">
									<tr>
										<?php if(isset($prow->tour->tour_name)): ?>
										<td>
											<div><b><?php echo e(isset($prow->tour->tour_name) ? $prow->tour->tour_name : ''); ?></b>, </div>
											<?php echo $prow->tour->tour_desc; ?>

											<?php										
												$tour = \App\Tour::find($prow->tour_id);
											?>
											<?php if($tour->tour_feasility->count() > 0): ?>
												<div><strong>Tour Facilities:</strong>
													<?php $__currentLoopData = $tour->tour_feasility; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<span><?php echo e($ts->service_name); ?></span>,    
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
												</div>
											<?php endif; ?><br>	
											<table style="width:100%;">
												<?php if($tour->tour_picture || $tour->tour_photo): ?>
												<tr>
													
													<td>
														<div class="row">
															<?php if($tour->tour_photo): ?>
																<div class="col-sm-4 col-xs-4" style="padding-right:4px;">
																	<div class="form-group">
																		<img src="<?php echo e(Content::urlthumbnail($tour->tour_photo, $tour->user_id)); ?>" style="width: 100%;" />
																	</div>
																</div>
															<?php endif; ?>

															<?php if($tour->tour_picture): ?>
																<?php 
																$photos = explode("|", rtrim($tour->tour_picture,'|')); ?>
																<?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																	<?php if($key <= 1): ?>	
																		<div class="col-sm-4 col-xs-4" style="padding-right:4px;">
																			<div class="form-group">
																				<img src="<?php echo e(Content::urlthumbnail($pic, $tour->user_id)); ?>" style="width: 100%;" />
																			</div>
																		</div>
																	<?php endif; ?>
																<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
															<?php endif; ?>
														</div>
													</td>
												</tr>
												<?php endif; ?>
											</table>
										</td>
										<?php endif; ?>

										<?php if(isset($prow->golf->supplier_name)): ?>
										<td>
											<div><b style="text-transform: capitalize;">Golf : <?php echo e(isset($prow->golf->supplier_name) ? $prow->golf->supplier_name : ''); ?>,   <?php echo e(isset($prow->golf_service->name) ? $prow->golf_service->name : ''); ?>, Pax: <?php echo e($prow->book_pax); ?>, Tee Time: <?php echo e($prow->book_golf_time); ?></b> </div>									
										</td>
										<?php endif; ?>

										<?php if(isset($prow->flight->flightno)): ?>
										<td>
											<div><b>Flight : <?php echo e(isset($prow->flight->flightno) ? $prow->flight->flightno : ''); ?>,  D:<?php echo e(isset($prow->flight->dep_time) ? $prow->flight->dep_time : ''); ?> - A:<?php echo e(isset($prow->flight->arr_time) ? $prow->flight->arr_time : ''); ?>, <?php echo e(isset($prow->flight->flight_from) ? $prow->flight->flight_from : ''); ?> -> <?php echo e($prow->flight->flight_to); ?> </b> </div>							
										</td>
										<?php endif; ?>
										
										<?php if(isset($prow->hotel->supplier_name)): ?>
										<td><b><?php echo e(isset($prow->hotel->supplier_name) ? $prow->hotel->supplier_name : ''); ?>,Room: <?php echo e(isset($bhotel->room->name) ? $bhotel->room->name : ''); ?>, CheckIn: <?php echo e(isset($bhotel->checkin) ? $bhotel->checkin : ''); ?> - CheckOut: <?php echo e(isset($bhotel->checkout) ? $bhotel->checkout : ''); ?></b></td>
										<?php endif; ?>

										<?php if(isset($prow->cruise->supplier_name)): ?>
										<td><b><?php echo e(isset($prow->cruise->supplier_name) ? $prow->cruise->supplier_name : ''); ?>, <?php echo e(isset($bcruise->program->program_name) ? $bcruise->program->program_name : ''); ?>, Room: <?php echo e(isset($bcruise->room->name) ? $bcruise->room->name : ''); ?>, </b></td>
										<?php endif; ?>
									</tr>
								</table>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
			</tbody>
		</table>
	<?php if($booking->count() > 0): ?>
		<h4><strong style="text-transform: capitalize;">Program Summary</strong></h4>
		<?php 
			$tourBook = \App\Booking::tourBook($book->book_project); 
		?>
		<?php if(!empty($book->book_project)): ?>		
			<div><strong style="text-transform: uppercase;">EXCURSION OVERVIEW</strong></div>
			<table class="table" id="roomrate">
				<tr style="background-color:#f4f4f4;">
					<th width="100px">Date</th>
					<th width="110px">City</th>
					<th >Title</th>					
				</tr>			
				<?php $__currentLoopData = $tourBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php 				
					$pro = \App\Province::find($tour->province_id); ?>
					<tr>
						<td><?php echo e(Content::dateformat($tour->book_checkin)); ?></td>
						<td><?php echo e(isset($pro->province_name) ? $pro->province_name : ''); ?></td>
						<td><?php echo e($tour->tour_name); ?></td>					
					</tr>				
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		<?php endif; ?>
		<!-- End tour -->
		<?php 
		$hotelBook = \App\HotelBooked::where('project_number', $book->book_project)->orderBy("checkin", 'ASC');
		?>
		<?php if($hotelBook->count() > 0): ?>
			<div><strong style="text-transform: uppercase;">HOTEL OVERVIEW</strong></div>
			<table class="table" id="roomrate">
				<tr style="background-color:#f4f4f4;">
					<th>Hotel</th>
					<th>Checkin - Checkout</th>
					<th>Room</th>
					<td>No. of Room</td>
					<th class="text-center">Nights</th>
					<?php $__currentLoopData = App\RoomCategory::whereIn('id',[1,2,3,4,5])->orderBy('id', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                <th class="text-right"><?php echo e($cat->name); ?></th>
	                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	            
				</tr>

				<?php $__currentLoopData = $hotelBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				
				<tr>
					<td><?php echo e(isset($hotel->hotel->supplier_name) ? $hotel->hotel->supplier_name : ''); ?></td>
					<td><?php echo e(isset($hotel->checkin) ? $hotel->checkin : ''); ?> - <?php echo e(isset($hotel->checkout) ? $hotel->checkout : ''); ?></td>
					<td><?php echo e(isset($hotel->room->name) ? $hotel->room->name : ''); ?></td>
					<td class="text-center"><?php echo e($hotel->no_of_room); ?></td>
					<td class="text-center"><?php echo e($hotel->book_day); ?></td>				
					<td class="text-right"><?php echo ($hotel->ssingle== 0 ? '' : '<span style="position: static;" class="fa fa-check-square check"></span>'); ?> </td>
					<td class="text-right"><?php echo ($hotel->stwin== 0 ? '' : '<span style="position: static;" class="fa fa-check-square check"></span>'); ?> </td>
					<td class="text-right"><?php echo ($hotel->sdouble== 0 ? '' : '<span style="position: static;" class="fa fa-check-square check"></span>'); ?></td>
					<td class="text-right"><?php echo ($hotel->sextra== 0 ? '' : '<span style="position: static;" class="fa fa-check-square check"></span>'); ?> </td>
					<td class="text-right"><?php echo ($hotel->schextra== 0 ? '' : '<span style="position: static;" class="fa fa-check-square check"></span>'); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		<?php endif; ?>
		
		<?php 
			$flightBook = App\Booking::flightBook($book->book_project);
		?>
		<?php if($flightBook->count() > 0): ?>
			<div><strong style="text-transform: uppercase;">Flight OVERVIEW</strong></div>
			<table class="table" id="roomrate">
				<tr style="background-color:#f4f4f4;">
					<th width="100px">Date</th>
					<th>Flight From <i class="fa fa-space-shuttle"></i>  To</th>
					<th>Flight No.</th>
					<th>Flight Dep <i class="fa fa-long-arrow-right"></i> Arr</th>
					<th>Ticketing Agent</th>					
				</tr>
				<?php $__currentLoopData = $flightBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>			
					<?php 
					$flprice = App\Supplier::find($fl->book_agent);
					?>			
					<tr>
						<td><?php echo e(Content::dateformat($fl->book_checkin)); ?></td>
						<td><?php echo e($fl->flight_from); ?> <i class="fa fa-space-shuttle"></i>  <?php echo e($fl->flight_to); ?></td>
						<td><?php echo e($fl->flightno); ?></td>
						<td><?php echo e($fl->dep_time); ?> <i class="fa fa-long-arrow-right"></i> <?php echo e($fl->arr_time); ?></td>
						<td><?php echo e(isset($flprice->supplier_name) ? $flprice->supplier_name : ''); ?></td>
						<td class="text-center"><?php echo e($fl->book_pax); ?></td>
					</tr>				
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		<?php endif; ?>
		<!-- end flight  -->
		<?php 
			$golfBook = App\Booking::golfBook($book->book_project);
		?>
		<?php if($golfBook->count() > 0): ?>
			<div><strong style="text-transform: uppercase;">GOFL COURSES OVERVIEW</strong></div>
			<table class="table" id="roomrate">
				<tr style="background-color:#f4f4f4;">
					<th width="100px">Date</th>
					<th>Golf</th>
					<th>Tee Time</th>
					<th>Golf Service</th>
					<th class="text-center">Pax</th>
				</tr>
				<?php $__currentLoopData = $golfBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>			
					<?php 
					$gsv = App\GolfMenu::find($gf->program_id);
					?>	
					<tr>
						<td><?php echo e(Content::dateformat($gf->book_checkin)); ?></td>
						<td><?php echo e($gf->supplier_name); ?></td>
						<td><?php echo e($gf->book_golf_time); ?></td>
						<td><?php echo e(isset($gsv->name) ? $gsv->name : ''); ?></td>
						<td class="text-center"><?php echo e($gf->book_pax); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		<?php endif; ?>
		<!-- end golf  -->		
		<?php 
			$cruiseBook = App\CruiseBooked::where('project_number', $book->book_project);
		?>
		<?php if($cruiseBook->count() >0): ?>			
			<div><strong style="text-transform: uppercase;">River Cruise OVERVIEW</strong></div>
			<table class="table" id="roomrate">
				<tr style="background-color:#f4f4f4;">
					<th width="170px;">Date</th>
					<th>River Cruise</th>
					<th>Program</th>
					<th>Room</th>
					<th>Night</th>
					<th>No. Cabin</th>
					<?php $__currentLoopData = App\RoomCategory::whereIn('id',[1,2,3,4,5])->orderBy('id', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                <th class="text-right"><?php echo e($cat->name); ?></th>
	                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tr>
				<?php $__currentLoopData = $cruiseBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>			
					<?php 
					$pcr = App\CrProgram::find($crp->program_id);
					$rcr = App\RoomCategory::find($crp->room_id);
					?>	
					<tr>
						<td><?php echo e(Content::dateformat($crp->checkin)); ?> - <?php echo e(Content::dateformat($crp->checkout)); ?> </td>
						<td><?php echo e($crp->cruise->supplier_name); ?></td>
						<td><?php echo e(isset($pcr->program_name) ? $pcr->program_name : ''); ?></td>
						<td><?php echo e(isset($rcr->name) ? $rcr->name : ''); ?></td>					
						<td class="text-center"><?php echo e($crp->book_day); ?></td>
						<td class="text-center"><?php echo e($crp->cabin_pax); ?></td>									
						<td class="text-right"><?php echo ($crp->ssingle == 0 ? '':'<span style="position: static;" class="fa fa-check-square check"></span>'); ?></td>
						<td class="text-right"><?php echo ($crp->stwin == 0 ? '':'<span style="position: static;" class="fa fa-check-square check"></span>'); ?></td>
						<td class="text-right"><?php echo ($crp->sdouble == 0 ? '':'<span style="position: static;" class="fa fa-check-square check"></span>'); ?></td>
						<td class="text-right"><?php echo ($crp->sextra == 0 ? '':'<span style="position: static;" class="fa fa-check-square check"></span>'); ?></td>
						<td class="text-right"><?php echo ($crp->schextra == 0 ? '':'<span style="position: static;" class="fa fa-check-square check"></span>'); ?></td>
					</tr>		
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		<?php endif; ?>
		<h4 class="text-right">
			<?php 
			$getGrandTotal = $cruiseBook->sum('net_amount') + $golfBook->sum('book_namount') + $flightBook->sum('book_namount') + $hotelBook->sum('net_amount') + $tourBook->sum('book_namount');
			 ?>
			<h4 class="text-right"><strong>Grand Total: <?php echo e(Content::marginRate($getGrandTotal, $project->margin_rate )); ?> <?php echo e(Content::currency()); ?></strong></h4>
		</h4>
		<?php
	        $Included=App\Service::where('service_cat',1)->whereIn('id',$servicedata)->get();
	        $Excluded=App\Service::where('service_cat',0)->whereIn('id',$servicedata)->get();
      	?>
		<div class="table-responsive">
			<?php if($Included->count() > 0 || $Excluded->count() > 0): ?>
	        <table class='table'>
	          <thead>
	            <tr class="text-left">
	              <td style="width: 50%;"><strong><?php echo ($Included) ? "Service Included":"";?></strong></td>
	              <td style="width: 50%;"><strong><?php echo ($Excluded) ? "Service Excluded":"";?></strong></td>
	            </tr>
	          </thead>
	          <tbody>
		        <tr> 
		            <td style="vertical-align:top;">
		            	<ul class="list-unstyled">
	                    <?php $__currentLoopData = $Included; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                        <li>- <?php echo e($room->service_name); ?></li>
	                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                    </ul>
		            </td>
		            <td style="vertical-align:top;">
		            	<ul class="list-unstyled">
	                    <?php $__currentLoopData = $Excluded; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                        <li>- <?php echo e($room->service_name); ?></li>
	                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                    </ul>
		            </td>
	          	</tr>
	          </tbody>
	        </table>
	        <?php endif; ?>
	    </div>
	    
	    	<?php echo $__env->make('admin.report.project_hotel_booking', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	    
	<?php endif; ?>
  	</div>
 </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>