<?php $__env->startSection('title', 'Slide Show'); ?>
<?php
  $active = 'setting-options'; 
  $subactive ='slide-show';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
            <section class="col-lg-12 connectedSortable">
                <h3 class="border">Slide Show<span class="fa fa-angle-double-right"></span> <a href="<?php echo e(route('createSlide')); ?>" class="btn btn-default btn-sm">Add New Slide</a></h3>
              
                <table class="datatable table table-hover table-striped">
                  <thead>
                    <tr>
                      <th width="12px">Photo</th>
                      <th>Title</th>
                      <th width="100" class="text-center">Options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><img src="<?php echo e(Content::urlthumbnail($slide->photo)); ?>" style="width: 100%"></td>
                      <td><?php echo e($slide->title); ?></td>
                      <td> 
                         <a href="<?php echo e(route('getSlide', ['eid'=>$slide->id])); ?>">
                          <i style="padding:1px 2px;" class="btn btn-info btn-xs fa fa-pencil-square-o"></i>
                        </a>&nbsp;
                        <a href="javascript:void(0)" class="RemoveHotelRate" data-id="<?php echo e($slide->id); ?>" title="Remove this ?">
                          <i class="fa fa-minus-circle btn-xs btn-danger"></i>
                        </a>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
            </section>
        </div>
    </section>
  </div>
</div>
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>