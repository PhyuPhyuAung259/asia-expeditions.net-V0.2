<?php $__env->startSection('title', 'Edit Province'); ?>
<?php
  $active = 'country';  
  $subactive ='province';
  use App\component\Content;
  $countryId = Auth::user()->country_id ? Auth::user()->country_id : 0;
?>
<?php $__env->startSection('content'); ?>
  <div class="wrapper">
    <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content"> 
        <div class="row">
          <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="col-lg-12"><h3 class="border">Country Management</h3></div>
          <form method="POST" action="<?php echo e(route('updateProvince')); ?>">
              <?php echo e(csrf_field()); ?>

              <input type="hidden" name="eid" value="<?php echo e($province->id); ?>">
              <section class="col-lg-9 connectedSortable">
                <div class="card">                                
                  <div class="row">
                    <div class="col-md-6 col-xs-12">
                      <div class="form-group">
                        <label> Province Name<span style="color:#b12f1f;">*</span></label> 
                        <input autofocus="" type="text" class="form-control" name="province_name" value="<?php echo e($province->province_name); ?>" required>
                      </div> 
                    </div>
                    <div class="col-md-6 col-xs-12">
                      <div class="form-group">
                        <label>Country<span style="color:#b12f1f;">*</span></label> 
                        <select class="form-control" name="country">
                          <?php $__currentLoopData = App\Country::where('country_status', 1)->orderBy('country_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($con->id); ?>" <?php echo e($province->country_id == $con->id ?'selected':''); ?>><?php echo e($con->country_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    
                         
                      </div> 
                    </div>
                  </div>
                  <div class="form-group">
                    <label>Description</label>
                    <script src="<?php echo e(asset('adminlte/editor/tinymce.min.js')); ?>"></script>
                    <textarea class="form-control my-editor" name="province_intro" rows="6" placeholder="Enter ..."><?php echo old('province_intro', $province->province_intro); ?></textarea>             
                  </div>
                  <div class="form-group">
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Status</label>&nbsp;
                        <label style="font-weight:400;"> <input type="radio" name="status" value="1" <?php echo e($province->province_status == 1 ? 'checked':''); ?>>Publish</label>&nbsp;&nbsp;
                        <label style="font-weight: 400;"> <input type="radio" name="status" value="0" <?php echo e($province->province_status == 0 ? 'checked':''); ?>>UnPublish</label>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Website</label>&nbsp;
                        <label style="font-weight:400;"> <input type="radio" name="web" value="1" <?php echo e($province->web == 1 ? 'checked':''); ?>>Yes</label>&nbsp;&nbsp;
                        <label style="font-weight: 400;"> <input type="radio" name="web" value="0" <?php echo e($province->web == 0 ? 'checked':''); ?>>No</label>
                      </div> 
                    </div>
                  </div>             
                </div>
              </section>
              <section class="col-lg-3 connectedSortable"><br>
                <div class="panel panel-default">
                  <div class="panel-body">
                    <div id="wrap-feature-image" style="position:relative;" class="<?php echo e($province->province_photo ? 'open-img':''); ?>">
                      <input type="hidden" name="user_id" value="<?php echo e($province->user_id); ?>">
                      <input type="hidden" name="image" id="data-img" value="<?php echo e($province->province_photo); ?>">
                      <img id="feature-img" src="<?php echo e(Content::urlthumbnail($province->province_photo, $province->user_id)); ?>" style="width:100%;display:none;margin-bottom:12px;" class="btnUploadFiles" data-type="single-img" data-toggle="modal" data-target="#myUpload">
                      <i id="removeImage" class="fa fa-remove (alias)" title="Remove picture" style="display: none;"></i>
                    </div>
                    <a href="#uploadfile" class="btnUploadFiles" data-type="single-img" data-toggle="modal" data-target="#myUpload">Set Feature Image</a>
                  </div>
                  <div class="panel-footer">Feature Image</div>
                </div>
                <div class="panel panel-default">
                  <div class="panel-body" style="padding: 8px;">
                    <div id="wrap-gallery-image" style="position:relative;">
                    <?php 
                      $gallery = explode("|", rtrim($province->province_picture, "|"));
                    ?>
                      <ul class="list-ustyled">
                        <?php if($gallery[0]): ?>                        
                          <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li data-url="<?php echo e($img); ?>"><i class="removegallery fa fa-remove (alias)" title="Remove picture" style="display:none;"></i>
                              <input type="hidden" name="gallery[]" value="<?php echo e($img); ?>">  
                              <img src="<?php echo e(Content::urlthumbnail($img, $province->user_id)); ?>" style='width:100%;'/></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </ul>                    
                      <div class="clearfix"></div>
                      <i id="removeImage" class="fa fa-remove (alias)" title="Remove picture" style="display: none;"></i>
                    </div>
                    <a href="#uploadfile" class="btnUploadFiles" data-type="multi-img" data-toggle="modal" data-target="#myUpload">Set Gallery Image</a>
                  </div>
                  <div class="panel-footer">Gallery Image</div>
                </div>
                <div class="form-group"> 
                  <button type="submit" class="btn btn-success btn-flat btn-sm">Submit</button>&nbsp;&nbsp;
                  <a href="<?php echo e(route('CountryList')); ?>" class="btn btn-danger btn-flat btn-sm">Back</a>
                </div>
              </section>
          </form>
        </div>
      </section>
    </div>  
  </div>
  <?php echo $__env->make('admin.include.windowUpload', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.editor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>