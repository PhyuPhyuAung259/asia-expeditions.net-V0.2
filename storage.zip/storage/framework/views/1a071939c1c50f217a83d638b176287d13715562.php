<?php $__env->startSection('title', 'OutStanding'); ?>
<?php 
  use App\component\Content;
  $comadd = \App\Company::find(1);
?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="container">
      <?php echo $__env->make('admin.report.headerReport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
      <div style="background-color: #e8f1ff;border: 1px solid #c1c1c1; padding: 18px;​​ border-radius: 5px;">
        <form method="GET" action="">      
          <div class="col-md-2 col-xs-6">
            <?php if(\Auth::user()->role_id == 2): ?>
              <div class="form-group">
                <select class="form-control country_account" name="country" data-type="supplier_by_account_transaction">
                  <option>--Choose--</option>
                  <?php $__currentLoopData = \App\Country::LocalPayment(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($con->id); ?>" <?php echo e($conId ==$con->id ? 'selected' : ''); ?>><?php echo e($con->country_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            <?php else: ?>
              <?php $country = App\Country::find($conId); ?>
              <input type="hidden" class="country_account" value="<?php echo e($conId); ?>">
              <input type="text" readonly class="form-control" value="<?php echo e($country['country_name']); ?>">
            <?php endif; ?>
          </div>
          <div class="col-md-2 col-xs-6">
            <div class="form-group">
              <select class="form-control country_book_supplier" data-type="supplier_by_account_transaction" required=>
                <option value="0">--choose--</option>
                <?php $getBusiness= App\Business::where('status',1)->whereHas('accountTransaction', function($query) {
                  $query->where(['status'=>1]);
                })->orderBy('name')->get(); ?>
                <?php $__currentLoopData = $getBusiness; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($bn->id); ?>" <?php echo e($supplier['business_id'] == $bn->id ? 'selected':''); ?>><?php echo e($bn->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
          <div class="col-md-3 col-xs-12" id="supplier_Name">
            <div class="form-group">
              <div class="btn-group" style='display: block;'>
                <button type="button" class="form-control arrow-down" data-toggle="dropdown" aria-haspopup="false" aria-expanded='false' data-backdrop="static" data-keyboard="false" role="dialog" data-backdrop="static" data-keyboard="false">
                  <span class="pull-left"><?php echo e(isset($supplier->supplier_name) ? $supplier->supplier_name : ''); ?></span>
                  <span class="pull-right"></span>
                </button> 
                <div class="obs-wrapper-search" style="max-height:250px; overflow: auto; ">
                  <div><input type="text" data-url="<?php echo e(route('getFilter')); ?>"  id="search_Account" onkeyup="filterAccountName()" class="form-control input-sm"></div>
                  <ul id="myAccountName" class="list-unstyled dropdown_account_name">
                  <?php $getSupplier = App\AccountTransaction::supplierByAccountTransaction($supplier['business_id'], $conId); ?>
                      <?php $__currentLoopData = $getSupplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class='list'>
                          <label style='position: relative;top: 3px; font-weight: 400; line-height:12px;'> 
                          <input type='radio' name='supplier_name' value="<?php echo e($sup->id); ?>" <?php echo e($supplier['id'] == $sup->id ? 'checked' : ''); ?>><span style='position:relative; top:-3px;'><?php echo e($sup->supplier_name); ?></span></label></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4 col-xs-12">
            <div class="form-group">
              <div class="input-group">
                <input type="text" name="start_date" class="form-control text-center" id="from_date" value="<?php echo e(isset($from_date) ? $from_date : ''); ?>" readonly>
                <span class="input-group-addon" id="basic-addon3">From To </span>
                <input type="text" name="end_date" class="form-control text-center" id="to_date" value="<?php echo e(isset($to_date) ? $to_date : ''); ?>" readonly>
              </div>
            </div>
          </div>
          <div class="col-md-1 text-center"><button type="submit" class="btn btn-primary btn-flat row">Search</button></div>
        </form>
        <div class="clearfix"></div>
      </div>
      <div class="clearfix"></div>
      <div class="pull-right">
          <!-- <button type="submit" class="btn btn-default btn-acc btn-xs hidden-print" onclick="window.print();"><i class="fa fa-print Print"></i> Print</button> -->
          <span class="btn btn-default btn-acc btn-xs hidden-print myConvert"><i class="fa fa-download"></i> Download</span>
        </div>
    </div>
    <br>
      
    <form target="_blank" action="<?php echo e(route('getOutstanding')); ?>">
      <?php if($journals->count() > 0): ?>
       <!--  <div class="pull-left">
          <button type="submit" class="btn btn-default btn-acc btn-xs hidden-print"><i class="fa  fa-eye"></i> Preview</button>
        </div> -->
        <div class="clearfix"></div><br>
        <table class="table tableExcel">
          <tr style="background-color: #e8f1ff; color: #3c8dbc;">
            <th width="50">
               <label class="container-CheckBox" style="margin-bottom: 0px;"> No.
                  <input type="checkbox" id="check_all" name="checkbox" >
                  <span class="checkmark hidden-print"></span>
                </label>
            </th>
            <th title="Invoice Paid Date" width="100">INV Paid Date</th>
            <th width="200">Descriptions</th>
            <th width="75">FileNo.</th>
            <th>Client Name</th>            
            <th class="text-right" title="Amount To Pay/Receive">To Pay</th> 
            <th class="text-right">Deposit/Paid </th>
            <th class="text-right" width="112" title="Balance to Pay/Receive">BL To AP/RP</th>            
            <th class="text-right" width="85" title="Amount To Pay <?php echo e(Content::currency(1)); ?>">ToPay <?php echo e(Content::currency(1)); ?></th> 
            <th class="text-right" width="126">Deposit/Paid <?php echo e(Content::currency(1)); ?></th>
            <th class="text-right" width="117" title="Balance to Pay/Receive">BL To AP/RP<?php echo e(Content::currency(1)); ?></th>
            <!-- <th class="text-right" width="128">Paid From/To</th> -->
          </tr>
            <?php
              $totalBalance = 0;
              $totalKBalanceKyat = 0;
              $n=0;
            ?>
          <tbody>
              <?php $__currentLoopData = $journals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                <?php
                  $transaction = App\AccountTransaction::where(['journal_id'=>$jn->id, 'status'=>1])->whereNotIn('supplier_id',[$jn->supplier_id])->get();
                 
                    $totalBalance = $totalBalance + $transaction->sum('credit');
                    $n++;
                ?> 
                <tr>
                  <td>
                    <label class="container-CheckBox" style="margin-bottom: 0px;"> <?php echo e($n); ?>

                      <input type="checkbox" class="checkall" name="journCheck[]" value="<?php echo e($jn->id); ?>">
                      <span class="checkmark hidden-print" ></span>
                    </label>
                  </td>
                  <td class="text-left"><?php echo e(Content::dateformat($jn->entry_date)); ?></td>
                  <td><?php echo e($jn->remark); ?></td>
                  <td class="text-left">
                    <?php $project = ''; ?>
                      <?php if(isset($jn->project)): ?>
                        <?php $project = $jn->project['project_prefix']."-".$jn->project['project_fileno']; ?>
                        <?php echo e($project); ?>

                      <?php endif; ?>
                    </a>
                  </td>
                  <td class="text-left">
                    <?php if(isset($jn->project)): ?>
                      <?php echo e($jn->project['project_client']); ?> <i>x</i> <b><?php echo e($jn->project['project_pax']); ?></b>
                    <?php endif; ?>
                  </td>
                  <td class="text-right" style="color:#3c8dbc;"><?php echo e(Content::money($jn->book_amount - $transaction->sum('credit'))); ?></td>          
                  <td class="text-right" style="color:#3c8dbc;">
                      <?php if($transaction->sum('credit') > 0): ?>
                        <a href="#" data-toggle="modal" data-url="<?php echo e(route('loadData')); ?>"​ data-supplier="<?php echo e($jn->supplier_id); ?>" data-id="<?php echo e($jn->id); ?>" class="PrevViewOutstanding" data-title="<?php echo e($project); ?>" data-target="#myModal">
                          <strong style="color:#8BC34A;"><?php echo e(Content::money($transaction->sum('credit'))); ?></strong>
                          <?php $tranBalace = $jn->book_amount - $transaction->sum('credit'); ?>
                        </a>
                      <?php else: ?>
                        <a href="#" data-toggle="modal" class="PrevViewOutstanding" data-target="#myModal" data-url="<?php echo e(route('loadData')); ?>" data-supplier="<?php echo e($jn->supplier_id); ?>" data-id="<?php echo e($jn->id); ?>" data-title="<?php echo e($project); ?>">
                        <?php $tranBalace = $jn->book_amount - $transaction->sum('debit'); ?>
                          <strong style="color:red;">
                            <?php echo e($transaction->sum('debit') > 0 ? '-'.number_format($transaction->sum('debit'), 2) : ''); ?>

                          </strong>
                        </a>
                      <?php endif; ?>
                  </td>
                  <td class="text-right" style="color:#3c8dbc;font-weight:700;"><?php echo e(number_format($tranBalace,2)); ?></td>
                  <td class="text-right"><?php echo e(Content::money($jn->book_kamount - $transaction->sum('kcredit'))); ?></td>                
                  <td class="text-right" style="color:#3c8dbc;">
                    <?php if($transaction->sum('kcredit') > 0): ?>
                      <strong style="color:#8BC34A;"><?php echo e(Content::money($transaction->sum('kcredit'))); ?></strong>
                    <?php else: ?>
                      <strong style="color:red;">
                        <?php echo e($transaction->sum('kdebit') > 0 ? number_format($transaction->sum('kdebit'), 2) : ''); ?>

                      </strong>
                    <?php endif; ?>
                  </td>
                  <td class="text-right" style="color:#3c8dbc;"><?php echo e(Content::money($jn->book_kamount)); ?></td>
                  
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <tfoot>
            <tr style="background-color: #e8f1ff; font-weight: 700; color: #3c8dbc;">
              <th colspan="7" class="text-right">Sub Total: <?php echo e(number_format($totalBalance,2)); ?></th>
              <th class="text-right" colspan="3">Sub Total: <?php echo e(number_format($totalKBalanceKyat,2)); ?></th>
              <th class="text-right"></th>
            </tr>
          </tfoot>
        </table>  
      <?php endif; ?>
    </form>
    <br>
  <!-- </div> -->
</div>


<div class="modal" id="myModal" role="dialog"  data-backdrop="static" data-keyboard="true">
  <div class="modal-dialog modal-lg" style="width: 1489px">    
    <form method="POST" action="<?php echo e(route('addGolfService')); ?>">
      <div class="modal-content">        
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <strong class="modal-title preview_title_journal">Preview Outstanding</strong>
        </div>
        <div class="modal-body"  style="padding: 0px;">
            <table class="table" id="preview_outstanding_jounal" border="1" cellpadding="1" cellspacing="0">
           
              <tr>
                  <th>#N.</th>
                  <th title="Invoice Paid Date">INV Paid Date</th>
                  <th>Descriptions</th>
                  <th>FileNo.</th>
                  <th>Client Name</th>            
                  <th class="text-right">Deposit/Paid <?php echo e(Content::currency()); ?></th>
                  <th class="text-right">Deposit/Paid <?php echo e(Content::currency(1)); ?></th>
                  <th class="text-right">Paid From/To</th>
              </tr>
              <tbody id="preview_outstanding_by_jounal">
                <!--   <tr>
                    <td>1</td>
                    <td>2019-01-21</td>
                    <td>Descriptions</td>
                    <td>AE-4444</td>
                    <td>Client Name</td>
                    <td>Asia Expeditions.com</td>
                    <td>500USD</td>
                    <td>300</td>
                    <td>155000 Kyat</td>
                    <td>400 kyat</td>
                    <td>20000</td>
                    <td>Cashbook Phnom Penh</td>
                  </tr> -->
              </tbody>
          </table>
         
        </div>
        <div class="modal-footer" style="text-align: center;">
          <a href="#" class="btn btn-acc btn-default btn-flat btn-sm" data-dismiss="modal">Close</a>
          <button type="button" class="btn btn-default btn-acc btn-xs hidden-print pull-right btnPrint" onclick='printDiv();'><i class="fa fa-print Print"></i> Print</button>
        </div>
      </div>      
    </form>
  </div>
</div>


<script type="text/javascript">

  function printDiv() 
      {
        var divToPrint=document.getElementById('preview_outstanding_jounal');

        var newWin=window.open('','Print-Window');

        newWin.document.open();

        // newWin.document.write('<html><body onload="window.print()">'+divToPrint.innerHTML+'</body></html>');
        newWin.document.write('<html><head><title>Program Preview </title></head><body onload="window.print()">'+divToPrint.outerHTML+'</body></html>')
        newWin.document.close();

        setTimeout(function(){newWin.close();},10);

      }



  function filterAccountName(){
    input = document.getElementById("search_Account");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myAccountName");
    li = ul.getElementsByClassName ("list");
    for (i = 0; i < li.length; i++) {
        a = li[i];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
          li[i].style.display = ""; 
        } else {
          li[i].style.display = "none";
        }
    }
  }
</script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.table2excel.min.js')); ?>"></script>
<script type="text/javascript">
  $(document).ready(function(){

    $(document).on("click", ".PrevViewOutstanding", function(){
      
        var journal_id = $(this).data('id'),
          supplier = $(this).data('supplier'),
          title = $(this).data('title'),
          dataUrl = $(this).data("url");
          $(".preview_title_journal").text("Preview By "+ title);
        $.ajax({
            method: "GET",
            url: dataUrl, 
            data: "id="+journal_id +"&supplier="+supplier +"&datatype=preview_journal",
            dataType: 'html',
            beforeSend: function() {
              $("#preview_outstanding_by_jounal").html('<tr><td colspan="8" class="text-center"><i style="padding: 27px;font-size: 43px;" class="fa fa-spinner fa-spin loading"></i></td></tr>');
            },
            success: function(html){
              // alert(html)
                // $(".data_filter", this).next().remove(); 
                $("#preview_outstanding_by_jounal").html(html);
            },
            error: function(xhr, status, error){
                alert("Error!" + xhr.status);
                return false;
            },
            complete: function() {
               // $("#preview_outstanding_by_jounal").html('<tr><td><i class="fa fa-spinner fa-spin loading"></i></td></tr>');
            }
        });
        return false;

    });


    $(".myConvert").click(function(){
        if(confirm('Do you to export in excel?')){
          $(".tableExcel").table2excel({
            exclude: ".noExl",
            name: "Daily Cash",
            filename: "OutStanding of ",
            fileext: ".xls",
            exclude_img: true,
            exclude_links: true,
            exclude_inputs: true
          });
          return false;
        }else{
          return false;
        }
    });
  });
</script>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make("admin.account.accountant", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>