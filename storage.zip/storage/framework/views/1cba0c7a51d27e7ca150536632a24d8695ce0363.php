<?php $__env->startSection('title', "Project Preview"); ?>
<?php 
  use App\component\Content;
  $comadd = \App\Company::find(1);
?>
<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('admin.report.headerReport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
  <div class="container">
      <table class=" table table-hover table-striped">
                  <tr>                       
                    <th >Project No.</th>
                    <th>ClientName</th>
                    <th>Start Date -> End Date</th>
                    <th>Agent</th>
                    <th>Revenue</th>
                    <th title="Cost Of Sales ">CS-Amount</th>
                    <th title="Gross Profit">G-Profit</th>
                    <th class="text-right" title="Gross Profit">( % )</th>
                    <th title="Revenue Received">Revenue Amount</th>
                    <th title="Revenue Receivable">Revenue AR</th>
                    <th title="Cost Of Sales Paid">CS-Paid</th>
                    <th title="Cost Of Sales Payable">CS-AP</th>                    
                  </tr>
                <tbody>
                  <?php if($project_preview->count() > 0): ?>
                    <?php $__currentLoopData = $project_preview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php 
                        $sup = App\Supplier::find($project->supplier_id);
                        $user = App\User::find($project->UserID);
                        $con = App\Country::find($project->country_id);
                        $acc_revenue = App\AccountJournal::where(["project_id"=> $project->id, 'status'=> 1, 'type'=>2, 'account_type_id'=> 8])->sum('credit');
                        $acc_Cost_of_sales = App\AccountJournal::where(["project_id"=> $project->id, 'status'=> 1, 'type'=>1, 'account_type_id'=> 10])->sum('debit');
                        $acc_tran_credit = App\AccountTransaction::where(["project_id"=> $project->id, 'status'=> 1, 'type'=>2, 'account_type_id'=> 10])->sum('credit');
                        $acc_tran_debit = App\AccountTransaction::where(["project_id"=> $project->id, 'status'=> 1, 'type'=>1, 'account_type_id'=> 8])->sum('debit');
                      ?>
                    <tr>
                      <?php 
                      $grossProfit = $acc_revenue - $acc_Cost_of_sales; 
                      $getPercentage = $acc_revenue > 0 ? ($grossProfit / $acc_revenue) * 100 : 0;
                    ?>
                      <td><?php echo e($project->project_number); ?></td>
                      <td><?php echo e($project->project_client); ?></td>
                      <td><?php echo e(Content::dateformat($project->project_start)); ?> -> <?php echo e(Content::dateformat($project->project_end)); ?></td>
                      <td><?php echo e(isset($sup->supplier_name) ? $sup->supplier_name : ''); ?></td>
                      <td class="text-right"><a href="javascript:void(0)"><?php echo e(Content::money($acc_revenue)); ?></a></td>
                      <td class="text-right"><a href="javascript:void(0)"><?php echo e(Content::money($acc_Cost_of_sales)); ?></a></td>
                      <td class="text-right"><a href="javascript:void(0)"><?php echo e(Content::money($grossProfit)); ?></a></td>
                      <td class="text-right"><a href="javascript:void(0)"><b><?php echo e(Content::money($getPercentage)); ?> <?php echo e($getPercentage > 0 ? "%": ''); ?></b></a></td>
                      <td class="text-right"><a href="javascript:void(0)" ><?php echo e(Content::money($acc_tran_debit)); ?></a></td>
                      <td class="text-right"><a href="javascript:void(0)" ><?php echo e(Content::money($acc_revenue - $acc_tran_debit)); ?></a></td>
                      <td class="text-right"><a href="javascript:void(0)" ><?php echo e(Content::money($acc_tran_credit)); ?></a></td>
                      <td class="text-right"><a href="javascript:void(0)" >
                        <?php echo e(Content::money($acc_Cost_of_sales - $acc_tran_credit)); ?>

                      </a></td>                    
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </tbody>
              </table>

</div>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>