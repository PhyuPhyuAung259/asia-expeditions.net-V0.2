<?php $comadd = \App\Company::find(1); ?>
<?php if(isset($project)): ?>
<table class="table" style="margin-bottom: 0px;">
	<tr>
		<td style="border-top: none; border-bottom: 1px solid #f4f4f4; padding-bottom: 0px;">
			<div><strong style="text-transform: capitalize;">Project <?php echo e($type); ?></strong></div>
			<div>File/ Project : <b><?php echo e(isset($project->project_prefix) ? $project->project_prefix : ''); ?>-<?php echo e(isset($project->project_fileno) ? $project->project_fileno: $project->project_number); ?> </b></div>
			<div>Pax Number : <b><?php echo e(isset($project->project_pax) ? $project->project_pax : ''); ?></b></div>
			<div>Client Name/s : <b><?php echo e(isset($project->project_client) ? $project->project_client : ''); ?></b></div>
			<div>Travelling Date : <b><?php echo e(date("d-M-Y", strtotime($project->project_start))); ?> - <?php echo e(date("d-M-Y", strtotime($project->project_end))); ?></b></div>
			<div>
				<?php if($project->flightArr): ?>
					<span>Flight No./Arrival : <b><?php echo e(isset($project->flightArr->flightno) ? $project->flightArr->flightno : ''); ?> - <?php echo e(isset($project->flightArr->arr_time) ? $project->flightArr->arr_time : ''); ?></b></span>, 
				<?php endif; ?>
				<?php if($project->flightDep): ?>
				<span>Flight No./Departure : <b><?php echo e(isset($project->flightDep->flightno) ? $project->flightDep->flightno : ''); ?> - <?php echo e(isset($project->flightDep->dep_time) ? $project->flightDep->dep_time : ''); ?></b></span>
				<?php endif; ?>
			</div>
			<div>
				<span>Travel Consultant :<b><?php echo e($project->project_book_consultant); ?></b></span>, 
				<span>Reference No.: <b><?php echo e($project->project_book_ref); ?></b></span>
			</div>
		</td>
		<td class="text-right" width="150px" style="border-top: none; border-bottom: 1px solid #f4f4f4; padding-bottom: 0px;">
			<img src="<?php echo e(url('storage/avata/'. $comadd['logo'])); ?>" style="width: 100%;">
		</td>
	</tr>
</table> 
<div class="pull-right hidden-print" id="preview_layout" style="color: #009688; cursor: pointer;">
	<input type="hidden" name="preview-type" value="standard">
	<p>Wide View <i class="fa fa-reply"></i></p>
</div>
<div class="clearfix"></div>
<?php endif; ?>