<?php $__env->startSection('title', config('app.title')); ?>
<?php $action = 'student'; ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
            <section class="col-lg-12 connectedSortable">
               <div ng-view></div>
            </section>          
          <!--   <section class="col-lg-5 connectedSortable">
            </section> -->
        </div>
    </section>
  </div>
  <?php echo $__env->make('admin.include.control', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>