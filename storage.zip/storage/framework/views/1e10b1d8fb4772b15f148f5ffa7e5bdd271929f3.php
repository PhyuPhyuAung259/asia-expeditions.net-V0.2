<?php $__env->startSection('title', 'Hotel Booking'); ?>
<?php $active = 'booked/project';
$subactive ='booked/hotel';
  use App\component\Content;
  $countryId = $book->country_id != null ? $book->country_id : Auth::user()->country_id;
  $amount = number_format(($book->book_price * $book->book_pax), 2);
?>
<?php $__env->startSection('content'); ?>
  <div class="wrapper">
    <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content"> 
        
          <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="col-lg-12"><h3 class="border">Hotel Booking</h3></div>
          <form method="POST" action="<?php echo e(route('updateBooked', 'Hotel')); ?>">
              <?php echo e(csrf_field()); ?>

              <input type="hidden" name="bookId" value="<?php echo e($book->id); ?>">
              <section class="col-lg-12">                              
                  <div class="row">
                    <div class="col-md-3 col-xs-12">
                      <div class="form-group">
                        <label>Check-In<span style="color:#b12f1f;">*</span></label> 
                        <input type="text" class="form-control" id="from_date" name="book_start" value="<?php echo e($book->book_checkin); ?>"  placeholder="Tour Date">
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-12">
                      <div class="form-group">
                        <label>Check-Out </label> 
                        <input type="text" class="form-control" id="to_date" name="book_end" value="<?php echo e($book->book_checkout); ?>"  placeholder="Tour Date" required >
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Country <span style="color:#b12f1f;">*</span></label> 
                        <select class="form-control country" name="country" data-type="country"  data-pro_of_bus="sub_bus" data-pro_of_bus_id="1" required>
                          <option value="0">--Choose--</option>
                          <?php $__currentLoopData = App\Country::countryBySupplier([1]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>{
                            <option value="<?php echo e($con->id); ?>" <?php echo e($con->id == $book->country_id ? 'selected':''); ?>><?php echo e($con->country_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>City <span style="color:#b12f1f;">*</span></label> 
                        <select class="form-control book_City" name="city" id="dropdown-country" data-type="pro_hotel">
                          <?php $getProvince = App\Province::provinceBySupplier([1], $countryId); ?>
                          <?php $__currentLoopData = $getProvince; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pro->id); ?>" <?php echo e($pro->id == $book->province_id ? 'selected':''); ?>><?php echo e($pro->province_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div> 
                    </div>
                    <div class="col-md-6 col-xs-6">
                      <div class="form-group">
                        <label>Hotel Name <span style="color:#b12f1f;">*</span></label>
                        <select class="form-control booking_name" name="hotel_name" id="dropdown-booking"  required>
                          <?php $__currentLoopData = App\Supplier::where(['supplier_status'=>1, 'business_id'=> 1, 'province_id'=> $book->province_id, 'company_id'=> Auth::user()->company_id])->orderBy('supplier_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sup->id); ?>" <?php echo e($sup->id==$book->hotel_id?'selected':''); ?>><?php echo e($sup->supplier_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Pax No.</label> 
                        <select class="form-control book_FlightPax" name="book_pax">
                          <?php for($n=1; $n<=16; $n++): ?>
                            <option value="<?php echo e($n); ?>" <?php echo e($n==$book->book_pax?'selected':''); ?>><?php echo e($n); ?></option>
                          <?php endfor; ?>
                        </select>
                      </div>
                    </div>
                </div>
              </section>
              <section class="col-lg-12"><br>
                <div class="panel panel-default">
                 <!--  <div class="panel-body">
                    <div class="form-group">
                      <div><label>Status</label></div>
                      <label style="font-weight:400;"> <input type="radio" name="status" value="1" <?php echo e($book->book_status == 1? 'checked':''); ?>><span style="position: relative;top:-2px;">Publish</span></label>&nbsp;&nbsp;
                      <label style="font-weight: 400;"> <input type="radio" name="status" value="0" <?php echo e($book->book_status == 0? 'checked':''); ?>><span style="position: relative;top:-2px;">UnPublish</span></label>
                    </div> 
                  </div> -->
                  <div class="panel-footer text-center">
                    <button type="submit" class="btn btn-success btn-flat btn-sm">Submit</button> &nbsp;
                    <a href="<?php echo e(route('projectList', ['url'=> $bookType])); ?>" class="btn btn-default btn-flat btn-sm">Go Bak</a>
                  </div>
                </div>
              </section>
          </form>
       
      </section>
    </div>  
  </div>
  <?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>