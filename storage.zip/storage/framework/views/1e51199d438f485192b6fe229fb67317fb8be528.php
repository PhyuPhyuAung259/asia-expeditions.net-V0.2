<?php $__env->startSection('title', 'Room Apply Hotels'); ?>
<?php $active = 'supplier/hotels'; 
  $subactive ='hotel/room';
  use App\component\Content;
?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <div class="row">
        <section class="col-lg-12 connectedSortable">
          <input type="hidden" id="urlRate" value="<?php echo e(route('getRatePrice')); ?>"> 
            <h4 class="border"><span style="color: #f39c12; font-size: 22px;" class="fa fa-hotel (alias)"></span> <b><?php echo e(isset($room->name) ? $room->name : ''); ?> Room For <?php echo e(isset($hotel->supplier_name) ? $hotel->supplier_name : ''); ?> Hotel</b> <small>( currency USD Price )</small></h4>
            <form action="<?php echo e(route('addRoomRate')); ?>" method="POST">
              <input type="hidden" name="hotelId" value="<?php echo e(isset($hotel->id) ? $hotel->id : ''); ?>">
              <input type="hidden" name="roomId" value="<?php echo e(isset($room->id) ? $room->id : ''); ?>">
              <?php echo e(csrf_field()); ?>

              <table class="table table-hover table-striped" id="hotel-rate">
                <thead>
                  <tr>                     
                    <th title="Rate Price From Date to Date" colspan="2" class="text-center" style="width: 19%;">From <span class="fa  fa-long-arrow-right" style="top: 1px; position: relative;"></span> To</th>
                    <?php $__currentLoopData = App\RoomCategory::where('status',1)->orderBy('id', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="text-center" title="<?php echo e($cat->name); ?>" ><?php echo e($cat->category_iso); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th width="80" class="text-center">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td colspan="2">                   
                      <div class="input-group">
                        <input type="text" name="fromdate[]" id="from_date" class="form-control input-sm" required="" placeholder="2018-04-25"><div class="input-group-addon">to</div>
                        <input type="text" name="todate[]" id="to_date" class="form-control input-sm" required="" placeholder="2018-06-25">
                      </div>
                    </td> 
                    <?php $__currentLoopData = \App\RoomCategory::where('status',1)->orderBy('id', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                    <td><input type="text" class="number_only form-control input-sm text-center" name="<?php echo e($cat->key_name); ?>[]" placeholder="0.00"></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><span class="btn btn-info btn-xs addHotelRate" data-type="hotelrate"><i class="fa fa-plus-circle"></i> Add new</span></td>
                  </tr>               
                </tbody>
              </table>  
              <div class="form-group">
                <div class="col-sm-2">
                  <div class="pull-left">
                    <input type="submit" name="btnUpdate" class="btn btn-success btn-flat btn-sm" value="Confirm">
                  </div>
                  <div class="pull-left" style="padding-left: 12px;">
                    <a href="<?php echo e(route('getRoomApplied')); ?>" class="btn btn-danger btn-flat btn-sm"> Cancel</a>
                  </div>
                </div>
              </div>      
              <div id="LoadingRow" style="display:none; position: absolute; margin:0% 30% 41% 46%;">
                <center><span style="font-size: 38px;" id="placeholder" class="fa fa fa-spinner fa-spin"></span></center>
              </div>  
            </form>
        </section>
      </div>
    </section>
  </div>  
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>