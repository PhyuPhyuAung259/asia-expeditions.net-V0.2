<!doctype html>
<html>
    <head>
        <meta charset="utf-8">        
        <title><?php echo e(config('app.title')); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(url('img/jngicon.png')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
        <script src="<?php echo e(asset('js/jquery.1.10.2.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('adminlte/js/all.js')); ?>"></script>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/doc_style.css')); ?>">        
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('adminlte/css/AdminLTE.min.css')); ?>"> 
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('adminlte/bower_components/font-awesome/css/font-awesome.min.css')); ?>">
    </head>
    <body class="skin-purple">
        <?php echo $__env->yieldContent('content'); ?>
    </body>
</html>