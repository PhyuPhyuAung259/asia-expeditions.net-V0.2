<?php $__env->startSection('title', 'Booked Hotel List'); ?>
<?php $active = 'booked/project'; 
$subactive ='booked/hotel';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <form method="POST" action="<?php echo e(route('searchProject', ['project'=> 'hotel'])); ?>">
          <?php echo e(csrf_field()); ?>

          <section class="col-lg-12 connectedSortable">
              <h3 class="border">Booked Hotel List</h3>
              <?php echo $__env->make('admin.project.Search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <table class="datatable table table-hover table-striped">
                <thead>
                  <tr>                       
                    <th width="65">Project No.</th>
                    <th>Check-In</th>
                    <th>Check-Out</th>
                    <th>Location</th>
                    <th>Hotel</th>
                    <th>By User</th>
                    <th class="text-center" style="width: 17%;">Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                      $supb = \App\Supplier::find($hotel->hotel_id);
                      $conb = \App\Country::find($hotel->country_id);
                      $prob = \App\Province::find($hotel->province_id);
                      $user = App\User::find($hotel->book_userId);
                    ?>
                  <tr>
                    <td width="75"><?php echo e($hotel->book_project); ?></td>
                    <td><?php echo e(Content::dateformat($hotel->book_checkin)); ?></td>
                    <td><?php echo e(Content::dateformat($hotel->book_checkout)); ?></td>
                    <td style="color: #605ca8;"><?php echo e(isset($conb->country_name) ? $conb->country_name : ''); ?>,  <?php echo e(isset($prob->province_name) ? $prob->province_name : ''); ?></td>
                    <td><?php echo e(isset($supb->supplier_name) ? $supb->supplier_name : ''); ?></td>
                    <td><?php echo e($user->fullname); ?></td>
                    <td class="text-center">
                      <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$hotel->book_project, 'type'=>'details'])); ?>" title="Program Details">
                        <label class="icon-list ic_ops_program"></label>
                      </a>&nbsp;
                      <a target="_blank" href="<?php echo e(route('bookingEdit', ['url'=>'hotel', 'id'=>$hotel->book_id])); ?>" title="Edit hotel">
                        <label class="icon-list ic_edit"></label>
                      </a>&nbsp;
                      <a target="_blank" href="<?php echo e(route('bapplyRoom', ['pro'=> $hotel->book_project,'hotelid'=>$hotel->hotel_id,'bookid'=> $hotel->book_id])); ?>" title="Apply room for this hotel" >
                        <i class="fa fa-hotel (alias)" style="font-size: 19px;color: #c38015;"></i>
                      </a>&nbsp;
                      <a target="_blank" href="<?php echo e(route('searchProject', ['project'=> 'hotelrate', 'textSearch'=>$hotel->book_project])); ?>" title="View Hotel Booking Rate">
                        <label class="icon-list ic_inclusion"></label>
                      </a>&nbsp;
                      <a onclick="return confirm('Are your sure you want delete this?');" href="<?php echo e(route('RhPrice', ['hotel'=> isset($hotel->hotel_id)? $hotel->hotel_id:0 , 'book'=> $hotel->book_id, 'type'=>'hotel'])); ?>" title="Remove hotel price" >
                        <i class="fa fa-trash" style="font-size: 19px;color: #8e877b;"></i>
                      </a>                  
                       <?php echo Content::DelUserRole("Delete this Hotel Booked ?", "book_hotel", $hotel->book_id, $hotel->user_id ); ?>   
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
          </section>
        </form>
        <div class="clearfix"></div>
    </section>
  </div>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>