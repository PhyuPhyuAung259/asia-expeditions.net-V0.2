
   <ul class="sidebar-menu" data-widget="tree">
      <?php if(Auth::check()): ?>
	        <?php 
		        if (Auth::user()->role_id == 2 || Auth::user()->role_id == 3 || Auth::user()->role_id == 4 || Auth::user()->role_id == 5) {
		          $userId = Auth::user()->role_id;
		        }
	        ?>
        <?php $__currentLoopData = \App\Department::where(['status'=>1, 'type'=>2])->orderBy('order','ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        	<?php if($dep->slug == "suppliers"): ?>

        	<?php else: ?>
		        <li class="<?php echo e(Auth::user()->role_id == 3 ? '':'treeview'); ?> <?php echo e($dep->name == $depart ? 'active':''); ?>" style="border-bottom: 1px dashed rgba(0,0,0,.1);">            
		            <?php
		                $getSubDepartment = \App\DepartmentMenu::where('department_id', $dep->id)->orderBy('order', 'ASC')->get();
		                $getBusinissName = \App\Business::where('category_id', 0)->get();
		            ?>	              
	                <a href="#">
	                  <!-- <i class="<?php echo e($dep->icon); ?>"></i> -->
	                  <span class="menu"><?php echo e($dep->name); ?></span>
	                    <?php if($getSubDepartment->count() > 0 || $dep->slug == "suppliers" ): ?>
	                      <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
	                    <?php endif; ?>     
	                </a>
	                <?php if($getSubDepartment->count() > 0): ?>
	                  <ul class="treeview-menu">
	                    <?php $__currentLoopData = $getSubDepartment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subdep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                    <?php if($subdep->name != "Documentation"): ?>
		                      <li <?php echo e($subdep->name == $sub_depart ? 'class=active': ''); ?>> <a href="<?php echo e(route('getDetail_doc', ['view' => $subdep->slug])); ?>"></i><?php echo e($subdep->name); ?></a></li>
		                    <?php endif; ?>	
	                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                  </ul>
	                <?php endif; ?>
		        </li>
	        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </ul>
