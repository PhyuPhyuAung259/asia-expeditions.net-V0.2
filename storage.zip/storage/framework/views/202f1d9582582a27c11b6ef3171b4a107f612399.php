<?php $__env->startSection('title', 'OutStanding'); ?>
<?php 
  use App\component\Content;
  $comadd = \App\Company::find(1);
?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <?php echo $__env->make('admin.report.headerReport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
    <div class="col-md-8 col-md-offset-2 hidden-print" style="background-color: #e8f1ff;border: 1px solid #c1c1c1;padding: 18px;​​border-radius: 5px;">
      <form method="GET" action="">      
        <div class="col-md-2 col-xs-6">
          <?php if(\Auth::user()->role_id == 2): ?>
            <select class="form-control country" name="country" data-type="supplier_by_account_transaction">
              <option value="">Location</option>
              <?php $__currentLoopData = App\Country::LocalPayment(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($con->id); ?>" <?php echo e($conId == $con->id ? 'selected' : ''); ?>><?php echo e($con->country_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          <?php else: ?>
            <input type="hidden" class="country" value="<?php echo e($conId); ?>">
          <?php endif; ?>
        </div>
        <div class="col-md-2 col-xs-6">
          <select class="form-control country_book_supplier"data-type="supplier_by_account_transaction" required="">
            <option value="0">--choose--</option>
            <?php $busByAccTrasaction= App\AccountJournal::where('status',1)->whereNotNull('business_id')->whereNotIn("business_id", [5])->groupBy('business_id')->get(); ?>
            <?php $__currentLoopData = $busByAccTrasaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($bn->business_id); ?>" <?php echo e($supplier['business_id'] == $bn->business_id ? 'selected':''); ?>><?php echo e($bn->business['name']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="col-md-3 col-xs-6" id="supplier_Name">
          <div class="btn-group" style='display: block;'>
            <button type="button" class="form-control arrow-down" data-toggle="dropdown" aria-haspopup="false" aria-expanded='false' data-backdrop="static" data-keyboard="false" role="dialog" data-backdrop="static" data-keyboard="false">
              <span class="pull-left"><?php echo e(isset($supplier->supplier_name) ? $supplier->supplier_name : ''); ?></span>
              <span class="pull-right"></span>
            </button> 
            <div class="obs-wrapper-search" style="max-height:250px; overflow: auto; ">
              <div><input type="text" data-url="<?php echo e(route('getFilter')); ?>"  id="search_Account" onkeyup="filterAccountName()" class="form-control input-sm"></div>
              <ul id="myAccountName" class="list-unstyled dropdown_account_name">
              <?php $supBybus = App\AccountTransaction::supplierByAccountTransaction($supplier['business_id'], $conId); ?>
                <?php if($supBybus->count() > 0): ?>
                  <?php $__currentLoopData = $supBybus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class='list'><label style='position: relative;top: 3px; font-weight: 400; line-height:12px;'> 
                      <input type='radio' name='supplier_name' value="<?php echo e($sup->supplier_id); ?>" <?php echo e($supplier['id'] == $sup->id ? 'checked' : ''); ?>><span style='position:relative; top:-3px;'> <?php echo e($sup->supplier_name); ?></span></label></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
                <?php endif; ?>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-md-4">
            <div class="input-group">
              <input type="text" name="start_date" class="form-control text-center" id="from_date" value="<?php echo e(isset($e) ? $e : ''); ?>" readonly>
              <span class="input-group-addon" id="basic-addon3">From To </span>
              <input type="text" name="end_date" class="form-control text-center" id="to_date" value="<?php echo e(isset($to_date) ? $to_date : ''); ?>" readonly>
            </div>
        </div>
        <div class="col-md-1" style="padding: 0px;"> <button type="submit" class="btn btn-primary btn-flat">Search</button></div>           
      </form>
    </div>
    <?php if($journals->count() > 0): ?>
      <br><div class="clearfix"></div>
      <div class="pull-right">
        <button type="submit" class="btn btn-default btn-acc btn-xs hidden-print" onclick="window.print();"><i class="fa fa-print Print"></i> Print</button>
        <span class="btn btn-default btn-acc btn-xs hidden-print myConvert"><i class="fa fa-print Print"></i> Download</span>
      </div>
   
      <form target="_blank" action="<?php echo e(route('getOutstanding')); ?>">
        <div class="pull-left">
          <button type="submit" class="btn btn-default btn-acc btn-xs hidden-print"><i class="fa  fa-eye"></i> Preview</button>
        </div>
        <div class="clearfix"></div><br>

        <table class="table tableExcel" border="1">
          <tr style="background-color: #e8f1ff; color: #3c8dbc;">
            <th style="border-top: none;border-bottom: 1px solid #ddd;" width="55px">
              <input name="checkbox" style="font-size: 13px;position: relative;top: 4px;width: 14px;height: 14px;" type="checkbox" id="check_all"> No.</th>
            <th style="border-top: none;border-bottom: 1px solid #ddd;" width="106px" title="Invoice Paid Date">INV Paid Date</th>
            <th style="border-top: none;border-bottom: 1px solid #ddd;" width="200px">Descriptions</th>
            <th style="border-top: none;border-bottom: 1px solid #ddd;">File/Project</th>
            <th style="border-top: none;border-bottom: 1px solid #ddd;">Client Name</th>            
            <th style="border-top: none;border-bottom: 1px solid #ddd;" class="text-right" title="Amount To Pay/Receive"> Amount To Pay</th> 
            <th style="border-top: none;border-bottom: 1px solid #ddd;" class="text-right">Deposit/Paid </th>
            <th style="border-top: none;border-bottom: 1px solid #ddd;" class="text-right" title="Balance to Pay/Receive">Balance To AP/RP</th>
            
            <th style="border-top: none;border-bottom: 1px solid #ddd;" class="text-right" title="Amount To Pay <?php echo e(Content::currency(1)); ?>">To Pay <?php echo e(Content::currency(1)); ?></th> 
            <th style="border-top: none;border-bottom: 1px solid #ddd;" class="text-right">Deposit/Paid <?php echo e(Content::currency(1)); ?></th>
            <th style="border-top: none;border-bottom: 1px solid #ddd;" class="text-right" title="Balance to Pay/Receive">Balance To AP/RP <?php echo e(Content::currency(1)); ?></th>

            <th style="border-top: none;border-bottom: 1px solid #ddd;" class="text-right">Paid From / To</th>
          </tr>
            <?php
              $totalBalance = 0;
              $totalKBalanceKyat = 0;
              $n=0;
            ?>
          <tbody>
            
              <?php $__currentLoopData = $journals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                <?php
                  $jnlTransaction = App\AccountTransaction::where(['journal_id'=>$sup->id, 'status'=>1])->whereNotIn('supplier_book',[$sup->supplier_id])->get();
                ?>

                <?php if($jnlTransaction->count() > 0): ?>
                  <?php $__currentLoopData = $jnlTransaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $sub = App\Supplier::find($tran->supplier_book); 
                     $n++;
                     $DepositAmt = ($tran->credit > 0 ? $tran->credit : $tran->debit);
                     $DepositAmtKyat = ($tran->kcredit > 0 ? $tran->kcredit : $tran->kdebit);
                     $totalBalance = $totalBalance + ($tran->total_amount - $DepositAmt);
                     $totalKBalanceKyat = $totalKBalanceKyat + ($tran->total_kamount - $DepositAmtKyat);
                    ?>
                    <tr>
                      <td><label><input type="checkbox" name="tranCheck[]" value="<?php echo e($tran->id); ?>" class="checkall"> <?php echo e($n); ?></label></td>
                      <td class="text-left"><?php echo e(Content::dateformat($tran->invoice_pay_date)); ?></td>
                      <td><?php echo e($tran->remark); ?></td>
                      <td class="text-left">
                        <?php if($tran->project): ?>
                          <a target="_blank" href="<?php echo e(route('getJournalReport', ['journal_entry'=>$tran->project['project_number']])); ?>"><?php echo e($tran->project['project_prefix']); ?>-<?php echo e($tran->project['project_fileno']); ?></a>
                        <?php endif; ?>
                      </td>
                      <td class="text-left"><?php echo e($tran->project['project_client']); ?></td>
                      <td class="text-right"><?php echo e(Content::money($tran->total_amount)); ?></td>                
                      <td class="text-right" style="color:#3c8dbc;"><?php echo e(Content::money($DepositAmt)); ?></td>
                      <td class="text-right"><?php echo e(number_format(($tran->total_amount - $DepositAmt),2)); ?></td>
                      <td class="text-right"><?php echo e(Content::money($tran->total_kamount)); ?></td>                
                      <td class="text-right" style="color:#3c8dbc;"><?php echo e(Content::money($DepositAmtKyat)); ?></td>
                      <td class="text-right"><?php echo e(number_format(($tran->total_kamount - $DepositAmtKyat), 2)); ?></td>
                      <td class="text-right"><?php echo e($sub['supplier_name']); ?></td> 
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>

                  <?php $totalBalance = $totalBalance + $sup->book_amount;
                  $n++;
                   ?>
                  <tr>
                    <td><?php echo e($n); ?> <input style="position: relative;top: 2px; width: 14px;height: 14px;" type="checkbox" name="journCheck[]" value="<?php echo e($sup->id); ?>" class="checkall" > </td>
                    <td class="text-left"><?php echo e(Content::dateformat($sup->entry_date)); ?></td>
                    <td><?php echo e($sup->remark); ?></td>
                    <td class="text-left">
                      <?php if($sup->project): ?>
                        <a target="_blank" href="<?php echo e(route('getJournalReport', ['journal_entry'=>$sup->project['project_number']])); ?>"><?php echo e($sup->project['project_prefix']); ?>-<?php echo e($sup->project['project_fileno']); ?></a>
                      <?php endif; ?>
                    </td>
                    <td class="text-left"><?php echo e($sup->project['project_client']); ?></td>
                    <td class="text-right"><?php echo e(Content::money($sup->book_amount)); ?></td>                
                    <td class="text-right" style="color:#3c8dbc;"></td>
                    <td class="text-right"><?php echo e(Content::money($sup->book_amount)); ?></td>

                    <td class="text-right"><?php echo e(Content::money($sup->book_kamount)); ?></td>                
                    <td class="text-right" style="color:#3c8dbc;"></td>
                    <td class="text-right"><?php echo e(Content::money($sup->book_kamount)); ?></td>
                    <td class="text-right"></td> 
                  </tr>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </tbody>
          <tfoot>
            <tr style="background-color: #e8f1ff; font-weight: 700;">
              <th colspan="7" class="text-right">Sub Total: </th> 
              <th class="text-right"><?php echo e(number_format($totalBalance,2)); ?></th>
              <th class="text-right" colspan="3"><?php echo e(number_format($totalKBalanceKyat,2)); ?></th>
              <th class="text-right"></th>
            </tr>
          </tfoot>
        </table>  
       
      </form>
       <?php endif; ?>
    <br>
  <!-- </div> -->
</div>
<script type="text/javascript">
  function filterAccountName(){
    input = document.getElementById("search_Account");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myAccountName");
    li = ul.getElementsByClassName ("list");
    for (i = 0; i < li.length; i++) {
        a = li[i];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
          li[i].style.display = "";
        } else {
          li[i].style.display = "none";
        }
    }
  }
</script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.table2excel.min.js')); ?>"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $(".myConvert").click(function(){
        if(confirm('Do you to export in excel?')){
          $(".tableExcel").table2excel({
            exclude: ".noExl",
            name: "Daily Cash",
            filename: "OutStanding of ",
            fileext: ".xls",
            exclude_img: true,
            exclude_links: true,
            exclude_inputs: true
          });
          return false;
        }else{
          return false;
        }
    });
  });
</script>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make("admin.account.accountant", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>