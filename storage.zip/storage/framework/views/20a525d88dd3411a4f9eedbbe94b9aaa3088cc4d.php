<?php $__env->startSection('title', 'Company'); ?>
<?php $active = 'setting-options';
$subactive ='company'; 
use App\component\Content;
?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <form action="POST">
            <section class="col-lg-12 connectedSortable">
                <h3 class="border">Companies List <span style=" font-size: 22px;" class="fa fa-angle-double-right"></span> <a href="<?php echo e(route('companyForm')); ?>" class="btn btn-default btn-sm">Add New Company</a></h3>
                <table class="datatable table table-hover table-striped">
                  <thead>
                    <tr>
                      <th>Logo</th> 
                      <th>Title</th>                     
                      <th>Published on</th>
                      <th>Location</th>
                      <th class="text-center">Status</th>
                      <th width="100" class="text-center">action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <?php 
                        $logo = $cp->logo ? "/storage/avata/".$cp->logo: '/img/nofile.jpg';
                      ?>
                      <td width="120px"><img src="<?php echo e($logo); ?>" width="40px"></td>
                      <td><?php echo e($cp->title); ?></td>
                      <td><?php echo e(Content::dateformat($cp->updated_at)); ?></td>
                      <td><?php echo e(isset($cp->country->country_name) ? $cp->country->country_name : ''); ?></td>
                      <td class="text-center"><?php echo $cp->status > 0 ? '<span class="badge">Enable</span>':'<span class="badge label-warning">Disabled</span>'; ?></td>

                      <td class="text-right">
                        <a target="_blank" href="<?php echo e(route('companyForm', ['cp_id'=> $cp->id])); ?>" title="Edit Profile">
                          <label style="cursor: pointer;" class="icon-list ic_edit"></label>
                        </a>         
                        <a href="javascript:void(0)" class="RemoveHotelRate" data-type="company" data-id="<?php echo e($cp->id); ?>" title="Remove this user?">
                          <label style="cursor: pointer;" class="icon-list ic_remove"></label>
                        </a>
                      </td>                     
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>                
            </section>
          </form>
        </div>
    </section>
  </div>  
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>