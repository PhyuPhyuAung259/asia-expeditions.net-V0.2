<?php $__env->startSection('title', "Operation Report"); ?>
<?php 
	use App\component\Content;
	$user = App\User::find($project->check_by);
	$Probooked = App\Booking::where(['book_project'=>$project->project_number, 'book_status'=>1, "book_option"=>0])->get();
?>
<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<form method="GET" target="_blank" action="<?php echo e(route('requestReport', ['url'=> $project->project_number])); ?>">
			<div class="col-lg-12">
		    	<?php echo $__env->make('admin.report.project_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	 
				<div class="pull-left">
					<p> 
						<b>CRD:</b> <?php echo e(Content::dateformat($project->project_date)); ?>, 
						<?php if($project->project_check ): ?>
							Project No. <b><?php echo e($project->project_number); ?></b> is Already checked by <b><?php echo e(isset($user->fullname) ? $user->fullname : ''); ?></b> at <?php echo e(Content::dateformat($project->project_check_date)); ?>,
						<?php endif; ?>
						<b>Revised Date</b> <?php echo e($project->project_revise); ?>

					</p> 
				</div>
				<?php $clientByProject = App\Admin\ProjectClientName::where('project_number', $project->project_number)->get();?>
				<?php if($Probooked->Count() > 0 ): ?>
				<div class="pull-right hidden-print checkingAction" style="display: none;">
					<div class="row">
						<input type="submit" name="btnstatus" value="Payment Voucher" class="btn btn-primary btn-xs">&nbsp;
						<a href="#" class="myConvert"><span class=" btn btn-default btn-xs"><i class="fa fa-download"></i> Download In Excel</span></a>&nbsp;
						<?php if($clientByProject->count() > 0): ?>
						<a target="_blank" href="<?php echo e(route('getProjectBooked',  [$project->project_number, 'passenger-manifast'])); ?>"><span class=" btn btn-primary btn-xs">Passenger Manifast</span></a>&nbsp;
						<?php endif; ?>
						<input type="submit" name="btnstatus" title="Booking Records" value="Booking Records" class="btn btn-primary btn-xs">&nbsp;
						<input type="submit" name="btnstatus" title="Cash Advance" value="Cash Advance" class="btn btn-primary btn-xs">&nbsp;
						<input type="submit" name="btnstatus" title="Booking Form" value="Booking Form" class="btn btn-primary btn-xs">&nbsp;
						<input type="submit" name="btnstatus" title="Booking Form Without Price" value="B Form WO/P" class="btn btn-primary btn-xs">&nbsp;
						<input type="submit" name="btnstatus" title="Booking Status" value="Booking Status" class="btn btn-primary btn-xs">&nbsp;
						<input type="submit" name="btnstatus" title="Guide Fees" value="Guide Fees" class="btn btn-primary btn-xs">&nbsp;
						<a href="javascript:void(0)" onclick="window.print();"><span class="btn btn-primary btn-xs"><i class="fa fa-print"></i></span></a>&nbsp;&nbsp;&nbsp;&nbsp;
					</div>
				</div>
				<?php endif; ?><div class="clearfix"></div><br>
				
				<?php if($project->project_hight): ?>
				<div class="form-group"><?php echo $project->project_hight; ?></div>
				<?php endif; ?>
				<?php $projectPdF = App\Admin\Photo::where(['project_number'=> $project->project_number])->get(); ?>
				<?php if($projectPdF->count() > 0): ?>
					<ul>
						<?php $__currentLoopData = $projectPdF; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><a target="_blank" href="<?php echo e(asset('storage/contract/projects')); ?>/<?php echo e($val->name); ?>"><?php echo e($val->original_name); ?></a></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				<?php endif; ?>
				<?php if($Probooked->Count() > 0 ): ?>
				<div class="hidden-print">
					<i class="fa"></i>
					<label class="btn">&nbsp;&nbsp;&nbsp;<span style="position: relative; top: 2px;"><input type="checkbox" id="check_all"></span>&nbsp;&nbsp;<span style="color: #3c8dbc;">Check All</span></label>
				</div>
				<?php endif; ?>
				<!-- Hotel Start  -->
				<?php 
				$hotelBook= App\HotelBooked::where(['project_number'=>$project->project_number])->orderBy("checkin", "ASC");
				?>			
				<table class="table operation-sheed">
					<?php if($hotelBook->get()->count() > 0): ?>
						<tr>
							<th style="border-top: none;">
								<div><strong style="text-transform: capitalize;">hotel OverView</strong></div>
							</th>
						</tr>
						<tr style="background-color:#f4f4f4;">
							<th width="330px">Checkin -> Checkout</th>
							<th width="200px">Hotel</th>
							<th width="120px">Room</th>
							<th width="110px" style="font-size: 11px;">No. Room</th>
							<th class="text-center">Nights</th>
							<th class="text-center" width="85px">Single</th>
							<th class="text-center">Twin</th>
							<th class="text-center">Double</th>
							<th class="text-center">Extra</th>
							<th class="text-center" width="188px">Ch-Extra</th>
							<th class="text-left" width="188px">Amount</th>
						</tr>
						<?php $__currentLoopData = $hotelBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				
						<tr>
							<td>
								<span class="hidden-print" style="position: relative;top:2px;"><input type="checkbox" name="checkedhotel[]" class="checkall" value="<?php echo e($hotel->id); ?>">&nbsp;</span>
								<span><?php echo e(Content::dateformat($hotel->checkin)); ?> -> <?php echo e(Content::dateformat($hotel->checkout)); ?></span>
							</td>
							<td><?php echo e(isset($hotel->hotel->supplier_name) ? $hotel->hotel->supplier_name : ''); ?> <small style="color: #9E9E9E;"><?php echo e(isset($hotel->remark)? '('.$hotel->remark.')' :''); ?></small></td>
							<td><?php echo e(isset($hotel->room->name) ? $hotel->room->name : ''); ?></td>
							<td class="text-center"><?php echo e($hotel->no_of_room); ?></td>
							<td class="text-center"><?php echo e($hotel->book_day); ?></td>
							<td class="text-right" width="85px"><?php echo e(Content::money($hotel->nsingle)); ?></td>
							<td class="text-right"><?php echo e(Content::money($hotel->ntwin)); ?></td>
							<td class="text-right"><?php echo e(Content::money($hotel->ndouble)); ?></td>
							<td class="text-right"><?php echo e(Content::money($hotel->nextra)); ?></td>
							<td class="text-right" width="150px"><?php echo e(Content::money($hotel->nchextra)); ?></td>
							<td class="text-left" width="120px"><?php echo e(Content::money($hotel->net_amount)); ?>

								<span class="pull-right hidden-print">
									<a title="Hotel Voucher" target="_blank" href="<?php echo e(route('hVoucher', ['project'=>$hotel->project_number, 'bhotelid'=> $hotel->id, 'bookid'=> $hotel->book_id, 'type'=>'hotel-voucher', 'checkin'=> $hotel->checkin, 'checkout'=> $hotel->checkout])); ?>"><i style="font-size:16px;position: relative;" class="fa fa-newspaper-o"></i></a>&nbsp;
									<a title="Hotel Booking Form" target="_blank" href="<?php echo e(route('hVoucher', ['project'=>$hotel->project_number, 'bhotelid'=> $hotel->id, 'bookid'=> $hotel->book_id, 'type'=>'hotel-booking-form', 'checkin'=> $hotel->checkin, 'checkout'=> $hotel->checkout])); ?>"><i class="fa fa-list-alt" style="font-size:16px;position: relative;"></i></a>&nbsp;
									<span class="changeStatus" data-type="hotel" data-id="<?php echo e($hotel->id); ?>" style="cursor: pointer;">
										<?php if($hotel->confirm == 0 || $hotel->confirm == null): ?>
											<i class="fa fa-warning (alias)"></i>
										<?php else: ?>
											<i class="fa fa-check-circle"></i>
										<?php endif; ?>
									</span>
								</span>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td colspan="11" class="text-right"><h5><strong>Total: <?php echo e(Content::money($hotelBook->sum('net_amount'))); ?> <?php echo e(Content::currency()); ?> </strong></h5></td>
						</tr>				
					<?php endif; ?>
					
					<?php $flightBook = App\Booking::flightBook($project->project_number);?>
					<?php if($flightBook->count() > 0): ?>
						<tr>
							<td style="border-top: none;"><strong>Flight Expenses</strong></td>
						</tr>
						<tr style="background-color:#f4f4f4;">
							<th width="120px">Date</th>
							<th>From</th>
							<th>To City</th>
							<th>Flight No.</th>
							<th width="160px">Flight Dep/Arr</th>
							<th width="119px">Agent</th>
							<th class="text-center">Seats</th>					
							<th class="text-right">Price <?php echo e(Content::currency()); ?></th>
							<th class="text-right">Amount</th>
							<th class="text-right">Price <?php echo e(Content::currency(1)); ?></th>
							<th class="text-left" width="160px">
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Amount</th>
						</tr>
						<?php $__currentLoopData = $flightBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php $flprice = App\Supplier::find($fl->book_agent);?>			
							<tr>
								<td>
									<span class="hidden-print" style="position: relative;top:2px;"><input type="checkbox" name="checkedflight[]" class="checkall" value="<?php echo e($fl->id); ?>">&nbsp;</span><?php echo e(Content::dateformat($fl->book_checkin)); ?></td>
								<td><?php echo e($fl->flight_from); ?></td>
								<td><?php echo e($fl->flight_to); ?></td>
								<td><?php echo e($fl->flightno); ?></td>
								<td>D:<?php echo e($fl->dep_time); ?> - A:<?php echo e($fl->arr_time); ?></td>
								<td><?php echo e(isset($flprice->supplier_name) ? $flprice->supplier_name : ''); ?></td>
								<td class="text-center"><?php echo e($fl->book_pax); ?></td>
								<td class="text-right"><?php echo e(Content::money($fl->book_nprice)); ?></td>
								<td class="text-right"><?php echo e(Content::money($fl->book_namount)); ?></td>
								<td class="text-right"><?php echo e(Content::money($fl->book_kprice)); ?></td>
								<td class="text-left"><?php echo e(Content::money($fl->book_kamount)); ?>

									<span class="changeStatus pull-right" data-type="flight" data-id="<?php echo e($fl->id); ?>" style="cursor: pointer;">
										<?php if($fl->book_confirm == 0 || $fl->book_confirm == null): ?>
											<i class="fa fa-warning (alias)"></i>
										<?php else: ?>
											<i class="fa fa-check-circle"></i>
										<?php endif; ?>
									</span>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
						<tr>
							<td colspan="11" class="text-right">
								<h5><strong>
									<?php if($flightBook->sum('book_namount') > 0): ?>
										Total: <?php echo e(Content::money($flightBook->sum('book_namount'))); ?> <?php echo e(Content::currency()); ?>

									<?php endif; ?>
									<?php echo e($flightBook->sum('book_kamount') > 0 && $flightBook->sum('book_namount') > 0 ? ',&nbsp;' : ''); ?>

									<?php if($flightBook->sum('book_kamount') > 0): ?>
										Total: <?php echo e(Content::money($flightBook->sum('book_kamount'))); ?> <?php echo e(Content::currency(1)); ?>

									<?php endif; ?>
								</strong>
								</h5>
							</td>
						</tr>
					<?php endif; ?>
					<!-- end flight  -->
					<?php $golfBook = App\Booking::golfBook($project->project_number);?>
					<?php if($golfBook->count() > 0): ?>
						<tr>
							<th style="border-top:none;" colspan="3">
								<div><strong style="text-transform:capitalize;">golf Courses Overview</strong></div>
							</th>
						</tr>
						<tr style="background-color:#f4f4f4;">
							<th width="100px">Date</th>
							<th>Golf</th>
							<th>Tee Time</th>
							<th colspan="3">Golf Service</th>
							<th class="text-center">Pax</th>
							<th class="text-right">Price <?php echo e(Content::currency()); ?></th>
							<th class="text-right">Amount </th>
							<th class="text-right">Price <?php echo e(Content::currency(1)); ?></th>
							<th class="text-center" width="160px">Amount</th>
						</tr>
						<?php $__currentLoopData = $golfBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>			
							<?php $gsv = App\GolfMenu::find($gf->program_id);?>	
							<tr>
								<td><span class="hidden-print" style="position: relative;top:2px;"><input type="checkbox" name="checkedgolf[]" class="checkall" value="<?php echo e($gf->id); ?>">&nbsp;</span><?php echo e(Content::dateformat($gf->book_checkin)); ?></td>
								<td><?php echo e($gf->supplier_name); ?></td>
								<td><?php echo e($gf->book_golf_time); ?></td>
								<td colspan="3"><?php echo e(isset($gsv->name) ? $gsv->name : ''); ?></td>
								<td class="text-center"><?php echo e($gf->book_pax); ?></td>			
								<td class="text-right"><?php echo e(Content::money($gf->book_nprice)); ?></td>
								<td class="text-right"><?php echo e(Content::money($gf->book_namount)); ?></td>
								<td class="text-right"><?php echo e(Content::money($gf->book_kprice)); ?></td>
								<td class="text-left"><?php echo e(Content::money($gf->book_kamount)); ?>

									<span class="changeStatus pull-right hidden-print" data-type="golf" data-id="<?php echo e($gf->id); ?>" style="cursor: pointer;">
										<?php if($gf->book_confirm == 0 || $gf->book_confirm == null): ?>
											<i class="fa fa-warning (alias)"></i>
										<?php else: ?>
											<i class="fa fa-check-circle"></i>
										<?php endif; ?>
									</span>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td colspan="11" class="text-right"><h5><strong>
								<?php if($golfBook->sum('book_namount') > 0): ?>
									Total: <?php echo e(Content::money($golfBook->sum('book_namount'))); ?> <?php echo e(Content::currency()); ?>

								<?php endif; ?>

								<?php echo e($golfBook->sum('book_namount') > 0 && $golfBook->sum('book_kamount') > 0 ? ',&nbsp;' : ''); ?>

								
								<?php if($golfBook->sum('book_kamount') > 0): ?>
									Total: <?php echo e(Content::money($golfBook->sum('book_kamount'))); ?> <?php echo e(Content::currency(1)); ?>

								<?php endif; ?>
								</strong></h5>
							</td>
						</tr>
					<?php endif; ?>
					<!-- end golf  -->
					<?php 
					$cruiseBook = App\CruiseBooked::where(['project_number'=>$project->project_number]);
					?>
					<?php if($cruiseBook->count() > 0): ?>
						<tr><th style="border-top: none;"><div><strong style="text-transform:capitalize;">River Cruise OverView</strong></div></th></tr>
							<tr style="background-color:#f4f4f4;">
								<th width="170px;">Date</th>
								<th>River Cruise</th>
								<th>Program</th>
								<th>Room</th>
								<th style="font-size: 11px;">Night/Cabin</th>
								<th class="text-center" width="85px">Single</th>
								<th class="text-center">Twin</th>
								<th class="text-center">Double</th>
								<th class="text-center">EX-Bed</th>
								<th class="text-center" width="153px">CHE-Bed</th>
								<th class="text-left" width="160px" >Amount</th>
							</tr>
							<?php $__currentLoopData = $cruiseBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>			
							<?php 
							$pcr = App\CrProgram::find($crp->program_id);
							$rcr = App\RoomCategory::find($crp->room_id);
							?>	
							<tr>
								<td><span class="hidden-print" style="position: relative;top:2px;"><input type="checkbox" name="checkedcruise[]" class="checkall" value="<?php echo e($crp->id); ?>">&nbsp;</span><?php echo e(Content::dateformat($crp->checkin)); ?> -> <?php echo e(Content::dateformat($crp->checkout)); ?> </td>
								<td><?php echo e($crp->cruise->supplier_name); ?></td>
								<td><?php echo e(isset($pcr->program_name) ? $pcr->program_name : ''); ?></td>
								<td><?php echo e(isset($crp->room->name) ? $crp->room->name : ''); ?></td>					
								<td class="text-center"><?php echo e($crp->book_day); ?>/ <?php echo e($crp->cabin_pax); ?></td>
								<!-- <td class="text-center"></td> -->
								<td class="text-right"><?php echo e(Content::money($crp->nsingle)); ?></td>
								<td class="text-right"><?php echo e(Content::money($crp->ntwin)); ?></td>
								<td class="text-right"><?php echo e(Content::money($crp->ndouble)); ?></td>
								<td class="text-right"><?php echo e(Content::money($crp->nextra)); ?></td>
								<td class="text-right"><?php echo e(Content::money($crp->nchextra)); ?></td>
								<td class="text-left"><?php echo e(Content::money($crp->net_amount)); ?>

									<span class="pull-right hidden-print">
										<a target="_blank" href="<?php echo e(route('hVoucher', ['project'=>$crp->project_number, 'bhotelid'=> $crp->id, 'bookid'=> $crp->book_id, 'type'=>'cruise-voucher'])); ?>"><i style="font-size:16px;position:relative;" class="fa fa-newspaper-o"></i></a>&nbsp;
										<a target="_blank" href="<?php echo e(route('hVoucher', ['project'=>$crp->project_number, 'bhotelid'=> $crp->id, 'bookid'=> $crp->book_id, 'type'=>'cruise-booking-form'])); ?>"><i class="fa fa-list-alt" style="font-size:16px;position: relative;"></i></a>
										&nbsp;
										<span class="changeStatus pull-right" data-type="cruise" data-id="<?php echo e($crp->id); ?>" style="cursor: pointer;">
											<?php if($crp->confirm == 0 || $crp->confirm == null): ?>
												<i class="fa fa-warning (alias)"></i>
											<?php else: ?>
												<i class="fa fa-check-circle"></i>
											<?php endif; ?>
										</span>
									</span>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td colspan="11" class="text-right">
									<h5>
										<strong>
										<?php if($cruiseBook->sum('net_amount') > 0): ?>
											Total: <?php echo e(Content::money($cruiseBook->sum('net_amount'))); ?> <?php echo e(Content::currency()); ?>

										<?php endif; ?>
										</strong>
									</h5>
								</td>
							</tr>
					<?php endif; ?>
					<!-- Transport Start-->
					<?php 
						$tranBook = App\Booking::tourBook($project->project_number); 
						$transportTotal = 0;
						$transportkTotal = 0;
					?>
					<?php if($tranBook->get()->count() != 0): ?>
						<tr><th colspan="11" style="border-top:none;"><div><strong style="text-transform: capitalize;">transport expenses</strong></div></th></tr>
						<tr style="background-color:#f4f4f4;">
							<th width="110px">Date</th>
							<th>City</th>
							<th colspan="2">Title</th>
							<th colspan="2">Service</th>
							<th>Vehicle</th>
							<th>DriverName</th>
							<th width="100px;">Phone</th>
							<th class="text-right" width="160px">Price <?php echo e(Content::currency()); ?></th>
							<th class="text-right" width="160px">Price <?php echo e(Content::currency(1)); ?></th>
						</tr>			
						<?php $__currentLoopData = $tranBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php 
							$pro   = App\Province::find($tran->province_id); 
							$btran = App\BookTransport::where(['project_number'=>$tran->book_project, 'book_id'=>$tran->id])->first();
							$price = isset($btran->price)? $btran->price:0; 
							$kprice = isset($btran->kprice)? $btran->kprice:0;
							$transportTotal = $transportTotal + $price;
							$transportkTotal = $transportkTotal + $kprice;
						?>
						<tr>
							<td><span class="hidden-print" style="position: relative;top:2px;"><input type="checkbox" name="checkedtransport[]" class="checkall" value="<?php echo e(isset($btran->id) ? $btran->id : ''); ?>">&nbsp;</span><?php echo e(Content::dateformat($tran->book_checkin)); ?></td>
							<td><?php echo e(isset($pro->province_name) ? $pro->province_name : ''); ?></td>
							<td colspan="2"><?php echo e($tran->tour_name); ?></td>
							<td colspan="2"><?php echo e(isset($btran->service->title) ? $btran->service->title : ''); ?></td>
			                <td><?php echo e(isset($btran->vehicle->name) ? $btran->vehicle->name : ''); ?></td>
			                <td><?php echo e(isset($btran->driver->driver_name) ? $btran->driver->driver_name : ''); ?></td>
			                <td>
			                  	<?php if(isset( $btran->driver->phone) || isset($btran->driver->phone2)): ?>
		                  			<?php echo e($btran->driver->phone); ?> <?php echo e($btran->driver->phone2); ?>

			                  	<?php else: ?>
			                  		<?php echo e(isset($btran->phone) ? $btran->phone : ''); ?>

			                  	<?php endif; ?>
			                </td> 
			                <td class="text-right"><?php echo e(Content::money($price)); ?></td>
		                  	<td class="text-right"><?php echo e(Content::money($kprice)); ?></td>
						</tr>				
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td colspan="11" class="text-right"><h5><strong>
								<?php if($transportTotal > 0 ): ?>
									Total: <?php echo e(Content::money($transportTotal)); ?> <?php echo e(Content::currency()); ?>

								<?php endif; ?>
								<?php echo e($transportTotal > 0 && $transportkTotal > 0 ? ',&nbps;' :''); ?>

								<?php if($transportkTotal > 0): ?>
									Total: <?php echo e(Content::money($transportkTotal)); ?> <?php echo e(Content::currency(1)); ?>

								<?php endif; ?>
								</strong></h5>
							</td>
						</tr>
					<?php endif; ?>
					<!-- End Transport -->
					<!-- Guide Start-->
					<?php 
						$guideBook = App\Booking::tourBook($project->project_number); 
						$guidTotal = 0;
						$guidkTotal = 0;
					?>
					<?php if($guideBook->count() > 0): ?>
						<tr>
							<th colspan="12" style="border-top: none;"><div><strong style="text-transform: capitalize;">guide expenses</strong></div>
							</th>
						</tr>
						<tr style="background-color:#f4f4f4;">
							<th>StartDate</th>
							<th>City</th>
							<th colspan="2">Tour</th>
							<th colspan="2">Service</th>
							<th>Guide Name</th>
							<th>Guide Phone</th>
							<th>Language</th>
							<th class="text-right">Price <?php echo e(Content::currency()); ?></th>
							<th class="text-right" width="160px">Price <?php echo e(Content::currency(1)); ?></th>
						</tr>			
						<?php $__currentLoopData = $guideBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php 
							$pro = App\Province::find($tran->province_id);
							$bg  = App\BookGuide::where(['project_number'=>$tran->book_project,'book_id'=>$tran->id])->first(); 
							$price = isset($bg->price)?$bg->price :0;
							$guidTotal = $guidTotal + $price;
							$kprice = isset($bg->kprice)? $bg->kprice :0;
							$guidkTotal = $guidkTotal + $kprice;
						?>
						<tr>
							<td><span class="hidden-print" style="position: relative;top:2px;"><input type="checkbox" name="checkedguide[]" class="checkall" value="<?php echo e(isset($bg->id) ? $bg->id : ''); ?>">&nbsp;</span><?php echo e(Content::dateformat($tran->book_checkin)); ?></td>
							<td><?php echo e($pro->province_name); ?></td>         
							<td colspan="2"><?php echo e($tran->tour_name); ?></td>     
							<td colspan="2"><?php echo e(isset($bg->service->title) ? $bg->service->title : ''); ?></td>
							<td><?php echo e(isset($bg->supplier->supplier_name) ? $bg->supplier->supplier_name : ''); ?> </td>
							<td>
								<?php if(isset($bg->supplier->phone) || isset($bg->supplier->phone2)): ?>
									<?php echo e($bg->supplier->phone); ?> <?php echo e($bg->supplier->phone2); ?>

								<?php else: ?>
									<?php echo e(isset($bg->phone) ? $bg->phone : ''); ?>

								<?php endif; ?>
							</td> 
							<td><?php echo e(isset($bg->language->name) ? $bg->language->name : ''); ?></td>
							<td class="text-right"><?php echo e(Content::money($price)); ?></td>
							<td class="text-right"><?php echo e(Content::money($kprice)); ?></td>
						</tr>				
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td colspan="11" class="text-right"><h5><strong>
								<?php if($guidTotal > 0 ): ?>
									Total <?php echo e(Content::currency()); ?>: <?php echo e(Content::money($guidTotal)); ?>

								<?php endif; ?>
								<?php echo e($guidTotal > 0 && $guidkTotal > 0 ? ',&nbps;': ''); ?>

								<?php if( $guidkTotal > 0): ?>
									Total <?php echo e(Content::currency(1)); ?> : <?php echo e(Content::money($guidkTotal)); ?>

								<?php endif; ?>
								</strong></h5>
							</td>
						</tr>
					
					<?php endif; ?>
					<!-- End Guide -->

					<!-- Restaurant Start-->
					<?php
					$restBook = App\BookRestaurant::where('project_number', $project->project_number)->orderBy('start_date', 'ASC');?>
						<?php if($restBook->count() > 0): ?>
							<tr>
								<th style="border-top: none;">
									<div><strong style="text-transform:capitalize;">restaurant expenses</strong></div>
								</th>
							</tr>
							<tr style="background-color:#f4f4f4;">
				                <th width="110px">Start Date</th>
				                <th colspan="2">Restaurant Name</th>
				                <th colspan="3">Menu</th>
				                <th>Pax</th>
				                <th class="text-right">Price <?php echo e(Content::currency()); ?></th>
				                <th class="text-right">Amount</th>
				                <th class="text-right">Price <?php echo e(Content::currency(1)); ?></th>
				                <th class="text-right">Amount</th>
			                </tr>		
							<?php $__currentLoopData = $restBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><span class="hidden-print" style="position: relative;top:2px;"><input type="checkbox" name="checkedRest[]" class="checkall" value="<?php echo e($rest->id); ?>">&nbsp;</span><?php echo e(Content::dateformat($rest->start_date)); ?></td>
				                <td colspan="2"><?php echo e(isset($rest->supplier->supplier_name) ? $rest->supplier->supplier_name : ''); ?></td>         
				                <td colspan="3"><?php echo e(isset($rest->rest_menu->title) ? $rest->rest_menu->title : ''); ?></td>
				                <td><?php echo e($rest->book_pax); ?></td>
				                <td class="text-right"><?php echo e(Content::money($rest->price)); ?></td>
				                <td class="text-right"><?php echo e(Content::money($rest->amount)); ?></td>
				                <td class="text-right"><?php echo e(Content::money($rest->kprice)); ?></td>
			                  	<td class="text-right"><?php echo e(Content::money($rest->kamount)); ?></td>
							</tr>				
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td colspan="11" class="text-right"><h5><strong>
									<?php if($restBook->sum('amount') > 0 ): ?>
										Total: <?php echo e(Content::money($restBook->sum('amount'))); ?> <?php echo e(Content::currency()); ?>

									<?php endif; ?>
										<?php echo e($restBook->sum('amount') > 0 && $restBook->sum('kamount') > 0 ? ',&nbps;':''); ?>

									<?php if( $restBook->sum('kamount') > 0): ?>
										Total : <?php echo e(Content::money($restBook->sum('kamount'))); ?> <?php echo e(Content::currency(1)); ?>

									<?php endif; ?>
									</strong></h5>
								</td>
							</tr>
						<?php endif; ?>
					<!-- End Restaurant -->

					<!-- Entrance Fees Start-->
					<?php 
					$EntranceBook = App\BookEntrance::where('project_number', $project->project_number)->orderBy('start_date', 'ASC'); ?>
						<?php if($EntranceBook->count() > 0): ?>
							<tr><th colspan="11" style="border-top: none;"><div><strong style="text-transform: capitalize;">entrance fees expenses</strong></div></th></tr>
							<tr style="background-color:#f4f4f4;">
								<th width="100px">Start Date</th>
			                  	<th colspan="5">Entrance Fees</th>
			                  	<th>Pax</th>
			                  	<th class="text-right">Price <?php echo e(Content::currency()); ?></th>
			                  	<th class="text-right">Amount</th>
			                  	<th class="text-right">Price <?php echo e(Content::currency(1)); ?></th>
			                  	<th class="text-right" width="160px">Amount</th>
							</tr>			
							<?php $__currentLoopData = $EntranceBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php 
							$pro = App\Province::find($ent->province_id); ?>
							<tr>
								<td><span class="hidden-print" style="position: relative;top:2px;"><input type="checkbox" name="checkedentran[]" class="checkall" value="<?php echo e($ent->id); ?>">&nbsp;</span><?php echo e(Content::dateformat($ent->start_date)); ?></td>
				                <td  colspan="5"><?php echo e(isset($ent->entrance->name) ? $ent->entrance->name : ''); ?></td>
				                <td><?php echo e($ent->book_pax); ?></td>
				                <td class="text-right"><?php echo e(Content::money($ent->price)); ?></td>
				                <td class="text-right"><?php echo e(Content::money($ent->amount)); ?></td>
				                <td class="text-right"><?php echo e(Content::money($ent->kprice)); ?></td>
			                  	<td class="text-right"><?php echo e(Content::money($ent->kamount)); ?></td>
							</tr>				
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td colspan="11" class="text-right"><h5><strong>
									<?php if($EntranceBook->sum('amount') > 0 ): ?>
										Total: <?php echo e(Content::money($restBook->sum('amount'))); ?> <?php echo e(Content::currency()); ?>

									<?php endif; ?>
									<?php echo e($EntranceBook->sum('amount') > 0 && $EntranceBook->sum('kamount') > 0 ? ',&nbps;':''); ?>

									<?php if($EntranceBook->sum('kamount') > 0): ?>
										Total: <?php echo e(Content::money($EntranceBook->sum('kamount'))); ?> <?php echo e(Content::currency(1)); ?>

									<?php endif; ?>
									</strong></h5>
								</td>
							</tr>
						<?php endif; ?>
					<!-- End Entrance Fees -->

					<!-- MISC Start-->
					<?php 
					$MiscBook = App\Booking::tourBook($project->project_number); 
						$miscTotal = 0;
						$misckTotal = 0;
						?>
						<?php if($MiscBook->count() > 0): ?>
							<tr>
								<th colspan="11" style="border-top: none;">
									<div><strong style="text-transform: capitalize;">MISC expenses</strong></div>
								</th>
							</tr>
							<tr style="background-color:#f4f4f4;">
								<th>Date</th>
								<th width="120px">City</th>
								<th colspan="9">Title</th>						
							</tr>			
							<?php $__currentLoopData = $MiscBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php 
								$pro = App\Province::find($tour->province_id); 
								$miscService = App\BookMisc::where(['project_number'=>$tour->book_project,'book_id'=>$tour->id])->orderBy("created_at", "DESC")->get();?>
								<tr>
					                <td><span class="hidden-print" style="position: relative;top:2px;"><input type="checkbox" name="checkedmisc[]" class="checkall" value="<?php echo e($tour->id); ?>">&nbsp;</span><?php echo e(Content::dateformat($tour->book_checkin)); ?></td>
					                <td><?php echo e($pro->province_name); ?></td>         
					                <td colspan="9">
					                  	<div><strong><?php echo e($tour->tour_name); ?></strong></div>
							            <?php if($miscService->count() > 0): ?> 
							            	<hr style="border-top:none; border-bottom: 1px solid #ddd;padding: 5px 0px; margin-top:0px; margin-bottom: 0px;">
						                  	<div class="row "style="font-style: italic;">
							                  	<label class="col-md-6 ">
							                  		<strong class="pcolor">Service Name</strong>
							                  	</label>
							                  	<label class="col-md-1 ">
							                  		<label class="row">
							                  			<strong class="pcolor">PaxNo.</strong>
							                  		</label>
							                  	</label>
							                  	<label class="col-md-1 ">
							                  		<label class="row">
								                  		<strong class="pcolor">Price<?php echo e(Content::currency()); ?></strong>
								                  	</label>
							                  	</label>
							                  	<label class="col-md-1 ">
							                  		<label class="row">
								                  		<strong class="pcolor">Amount</strong>
								                  	</label>
							                  	</label>
							                  	<label class="col-md-1 ">
							                  		<label class="row">
								                  		<strong class="pcolor">Price<?php echo e(Content::currency(1)); ?></strong>
								                  	</label>
							                  	</label>
							                  	<label class="col-md-2 pcolor text-right">
								                  	<strong class="pcolor">Amount</strong>
							                  	</label>
						                  	</div>		                
							            	<?php $__currentLoopData = $miscService; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $misc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							            	<?php 
								            	$miscTotal = $miscTotal + $misc->amount;
								            	$misckTotal = $misckTotal + $misc->kamount;
							            	?>
						                  	<div class="row">
							                  	<label class="col-md-6" style="font-weight: 400;">
							                  		<p><?php echo e(isset($misc->servicetype->name) ? $misc->servicetype->name : ''); ?></p>
							                  	</label>
							                  	<label class="col-md-1" style="font-weight: 400;">
							                  		<p><?php echo e($misc->book_pax); ?></p>
							                  	</label>
							                  	<label class="col-md-1" style="font-weight: 400;">
							                  		<p><?php echo e(Content::money($misc->price)); ?></p>
							                  	</label>
							                  	<label class="col-md-1" style="font-weight: 400;">
							                  		<p><?php echo e(Content::money($misc->amount)); ?></p>
							                  	</label>
							                  	<label class="col-md-1" style="font-weight: 400;">
							                  		<p><?php echo e(Content::money($misc->kprice)); ?></p>
							                  	</label>
							                  	<label class="col-md-2 text-right" style="font-weight: 400;">
							                  		<span><?php echo e(Content::money($misc->kamount)); ?></span> 
							                  	</label>
							                  	<div class="clearfix"></div>
						                  	</div>
						                  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						                <?php endif; ?>
				                  	</td>	                                     
				                </tr>			
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td colspan="11" class="text-right">
									<strong>
										<?php if($miscTotal > 0 ): ?>
											Total: <?php echo e(Content::money($miscTotal)); ?> <?php echo e(Content::currency()); ?>

										<?php endif; ?>
										<?php echo e($miscTotal > 0 && $misckTotal > 0 ? ',&nbps;':''); ?>

										<?php if( $misckTotal > 0): ?>
											Total: <?php echo e(Content::money($misckTotal)); ?> <?php echo e(Content::currency(1)); ?>

										<?php endif; ?>
									</strong>
								</td>
							</tr>
						<?php endif; ?>

				<?php if($Probooked->count() > 0 ): ?>
					<?php 
						$grandtotal = ($hotelBook->sum('net_amount') + $flightBook->sum('book_namount') + $golfBook->sum('book_namount') + $cruiseBook->sum('net_amount') + $restBook->sum('amount') + $EntranceBook->sum('amount')) + $transportTotal + $guidTotal + $miscTotal;
						// echo $transportTotal + $guidTotal + $miscTotal;
						$grandktotal = ($flightBook->sum('book_kamount') + $golfBook->sum('book_kamount') + $restBook->sum('kamount') + $EntranceBook->sum('kamount')) + $transportkTotal + $guidkTotal + $misckTotal;
					?>
						<!-- End MISC -->
						<tr>
							<th rowspan="2" colspan="5" style="border-top: none;" >
								<div class="hidden-print">
									<label class="label-control">Remark</label>
									<textarea class="form-control" rows="5" name="remark" placeholder="Type remark here..."></textarea>
								</div>
							</th>
							<th style="border-top: none; font-size: 17px;" colspan="6" class="text-right"> 
								<strong>
								<?php if($grandtotal): ?>
									Sub Total: <?php echo e(number_format($grandtotal,2)); ?>  <?php echo e(Content::currency()); ?>

								<?php endif; ?>
								<?php if($grandktotal > 0): ?>
									Sub Total: <?php echo e(number_format($grandktotal,2)); ?> <?php echo e(Content::currency(1)); ?>

								<?php endif; ?>
								</strong>
								
							</th>
						</tr> 

						<tr>
							<th style="border-top: none; font-size: 17px;" colspan="11" class="text-right">
								<strong>
									<?php $getExRate = $project->project_ex_rate> 0 ? $grandktotal / $project->project_ex_rate: 0;?>
									<?php if($getExRate > 0): ?>
										Ex-<?php echo e(Content::currency(1)); ?> To <?php echo e(number_format($getExRate,2)); ?> <?php echo e(Content::currency()); ?>,
									<?php endif; ?>
									<?php if(($grandtotal + $getExRate) > 0 ): ?>
										GRAND TOTAL: <?php echo e(number_format(($grandtotal + $getExRate), 2)); ?> <?php echo e(Content::currency()); ?>

									<?php endif; ?>
								</strong>
							</th>
						</tr>
						<tr>
							<td style="border-top: none;" colspan="3">Prepared by <b>.....................................................</b></td>
							<td style="border-top: none;" colspan="3">Checked by <b>.....................................................</b></td>
							<td style="border-top: none;" colspan="5" class="text-right">Approved by <b>.....................................................................</b></td>
						</tr>
					<?php endif; ?>
				</table>
		  	</div>
		  </form>
		</div><br><br>
	</div>

	<script type="text/javascript" src="<?php echo e(asset('js/jquery.table2excel.min.js')); ?>"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$("#check_all").click(function () {
				if($("#check_all").is(':checked')){
			     // Code in the case checkbox is checked.
			     	$(".checkall").prop('checked', true);
				} else {
				     // Code in the case checkbox is NOT checked.
				    $(".checkall").prop('checked', false);
				}
			});

			$(".myConvert").click(function(){
				if(confirm('Do you to export in excel?')){
					$(".table").table2excel({
						exclude: ".noExl",
						name: "Operation Expenses <?php echo e($project->project_number); ?>",
						filename: "Operation Expenses <?php echo e($project->project_number); ?>",
						fileext: ".xls",
						exclude_img: true,
						exclude_links: true,
						exclude_inputs: true
						
					});
					return false;
				}else{
					return false;
				}
			});
		});

		$(document).ready(function(){
	        $('input[type="checkbox"]').click(function(){
	            if($(this).prop("checked") == true){
	                // alert("Checkbox is checked.");
	                $(".checkingAction").fadeIn();
	            }
	            else if($(this).prop("checked") == false){
	                $(".checkingAction").fadeOut();
	            }
	        });
	    });
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>