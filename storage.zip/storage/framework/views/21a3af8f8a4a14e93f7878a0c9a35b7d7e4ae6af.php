<?php $title = "Profit & Loss for File No: ".$project['project_prefix']."-".$project['project_fileno']; ?>

<?php $__env->startSection('title', $title); ?>
<?php 
	use App\component\Content;
	$comadd = \App\Company::find(1);
	$amount = "Amount";
	$invoice = "Invoice";
?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<?php echo $__env->make('admin.report.headerReport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>		
	
	
	<div class="clearfix"></div><br>
	<table class="table tableExcel">
		<tr>
			<td style="border-top: none; padding: 2px;" colspan="3" class="text-center"><h4><strong style="font-size: 16px; text-transform:capitalize; color: #07c;"><?php echo e($title); ?></strong></h4></td>
		</tr>
		<tr>
			<td style="border-top: none; padding: 2px;" class="text-right" colspan="2">Travelling Date:</td>
			<td style="border-top: none; padding: 2px;" class="text-left"><b><?php echo e(Content::dateformat($project['project_start'])); ?> -> <?php echo e(Content::dateformat($project['project_end'])); ?></b></td>
		</tr>
		
		<tr>
			<td style="border-top: none;  padding: 2px;" class="text-right" colspan="2">Client Name:</td><td style="border-top:none; padding: 2px;" class="text-left"><b><?php echo e($project['project_client']); ?></b></td>
		</tr>
		<tr>
			<td style="border-top: none; padding: 2px;" colspan="2" class="text-right" >Agent Name: </td>
			<td style="border-top: none; padding: 2px;"><b><?php echo e($project->supplier['supplier_name']); ?></b></td>
		</tr>
		<tr>
			<td style="border-top: none; padding: 2px;" colspan="2" class="text-right">Pax Number: </td>
			<td style="border-top: none; padding: 2px;"><b><?php echo e($project->project_pax); ?> Pax</b></td>
		</tr>		
		<tr>
			<td style="border-top: none; padding: 2px;" class="hidden-print" colspan="3">
				<div class="pull-right hidden-print">
				   	<a href="javascript:void(0)" class="myConvert hidden-print"><span class=" btn btn-primary btn-acc btn-xs"><i class="fa fa-download"></i> Download In Excel</span></a>&nbsp;
				    <span onclick="window.print()" class="hidden-print btn btn-xs btn-primary btn-acc"><i class="fa fa-print"></i> Print</span>
				</div>
			</td>
		</tr>
	  	<tr>
	  		<td width="320px" style="padding:0px 8px 1px 0px; vertical-align: bottom; border-top: none;">Account</td>
	  		<td style="padding:0px 8px 1px 0px; border-top: none;">Segment </td>
	  		<td style="padding:0px 8px 1px 0px; border-top: none;" class="text-right">Total Dollar</td>
	  	</tr>
	  	<?php $CostOfSaleTotal = 0; $reVenueTotal=0; $otherExpense=0?>
  		<?php $__currentLoopData = $journals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $jour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  			<tr>
	  			<th style="border-bottom:solid 1px #9E9E9E; padding-left: 0px; color:#07C; text-transform: uppercase;" colspan="3"><?php echo e($jour->account_name); ?> </th>
  			</tr>
	  		<?php 
	  			$transactions = \App\AccountTransaction::where(['account_type_id'=>$jour->account_type_id, 'project_id'=>$project->id, 'status'=>1])->groupBy('account_name_id')->orderBy('created_at', 'DESC')->get(); 
	  			$TotalAmt = 0; ?>
	  		<?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kay => $tran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  		<?php 
					$reVenue = App\AccountTransaction::where(["project_id"=>$project->id,'status'=>1, 'account_type_id'=>$jour->account_type_id, 'account_name_id'=>$tran->account_name_id])->whereIn('account_type_id',[8,9]);
				 
					$CostOfSale = App\AccountTransaction::where(["project_id"=>$project->id, 'status'=>1, 'account_type_id'=>$jour->account_type_id, 'account_name_id'=>$tran->account_name_id])->whereNotIn('account_type_id',[8,9]);
					// $CostOfSaleTotal = 0;
					// $reVenueOrReven = 0;
		  			if ($jour->account_type_id == 8 || $jour->account_type_id == 9) {
		  				$reVenueAmt = ($reVenue->sum('debit') + $reVenue->sum('ex_rate_converted'));
		  				$TotalAmt = $TotalAmt + $reVenueAmt;
		  				$reVenueTotal = $reVenueTotal + $reVenueAmt;
						$total = $reVenueAmt;
					}elseif ($jour->account_type_id == 12) {
						$otherExpense = $otherExpense + $CostOfSaleAmt;
					
		  			}else{
		  				$CostOfSaleAmt = ($CostOfSale->sum('credit') + $CostOfSale->sum('ex_rate_converted'));
		  				$TotalAmt = $TotalAmt + $CostOfSaleAmt;
		  				$CostOfSaleTotal = $CostOfSaleTotal + $CostOfSaleAmt;
		  				$total = $CostOfSaleAmt;
		  				// $CostOfSaleTotal = $CostOfSaleTotal + $CostOfSaleAmt;
		  			}
		  		 ?>
	  			<tr>
		  			<td>&nbsp;&nbsp;<?php echo e($tran->account_name['account_code']); ?>-<?php echo e($tran->account_name['account_name']); ?> </td>
		  			<td>
		  				<?php if($project): ?>
		  					<a title="Preview Journal Entry" target="_blank" href="<?php echo e(route('getJournalReport', ['journal_entry'=>$tran->project['project_number']])); ?>"><?php echo e($project['project_prefix']); ?>-<?php echo e($project['project_fileno']); ?></a>
		  				<?php endif; ?>
		  			</td>
		  			<td class="text-right"><?php echo e(number_format($total, 2)); ?></td>
	  			</tr>
	  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  		<tr><th colspan="3" class="text-right">Total <?php echo e($jour->account_name); ?> : <?php echo e(number_format($TotalAmt,2)); ?></th></tr>
			<?php if($jour->account_type_id == 9): ?> 
  			<tr><td style="border:none;" class="text-right" colspan="3">Total Revenue: <?php echo e(number_format($reVenueTotal, 2)); ?></td></tr>
  			<?php elseif($jour->account_type_id == 10): ?>
  			<tr><td style="border:none;" class="text-right" colspan="3">Total Cost Of Sale: <?php echo e(number_format($CostOfSaleTotal, 2)); ?></td></tr>
  			<?php elseif($jour->account_type_id == 12): ?>
  			<tr><td style="border:none;" class="text-right" colspan="3">Total Expense: <?php echo e(number_format($otherExpense, 2)); ?></td></tr>
  			<?php endif; ?>
  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  		<?php $grandTotal = ($reVenueTotal - $CostOfSaleTotal); ?>
	  	<tr><th colspan="3" class="text-right" style="color:#07C"><h3>Gross Profit : <?php echo e(number_format($grandTotal, 2)); ?></h3></th></tr>
	</table>
</div>
<script type="text/javascript">
  	$(document).ready(function(){
      	$(".myConvert").click(function(){
          if(confirm('Do you to export in excel?')){
            $(".tableExcel").table2excel({
              exclude: ".noExl",
              name: "Profit & Loss",
              filename: "<?php echo e($title); ?>",
              fileext: ".xls",
              exclude_img: true,
              exclude_links: true,
              exclude_inputs: true
            });
            return false;
          }else{
            return false;
          }
      	});
  	});
</script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.table2excel.min.js')); ?>"></script>

<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>