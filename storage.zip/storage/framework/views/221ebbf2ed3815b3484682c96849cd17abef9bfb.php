<?php $__env->startSection('title', 'Company Info'); ?>
<?php 
  $active = 'setting-options'; 
  $subactive ='company';
  use App\component\Content;
  $countryId = Auth::user()->country_id ? Auth::user()->country_id : 0;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <div class="row">
        <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="col-lg-12"><h3 class="border text-center">Setting </h3></div>
        <form method="POST" action="<?php echo e(route('updateSetting', ['setID'=> $setting->id])); ?>" enctype="multipart/form-data"> 
          <?php echo e(csrf_field()); ?>

          <section class="col-lg-8 col-lg-offset-2">
            <div class="col-md-12 col-xs-12">
              <div class="form-group <?php echo e($errors->has('title')?'has-error has-feedback':''); ?>">
                <label>Title<span style="color:#b12f1f;">*</span></label> 
                <input type="text" class="form-control" name="title" placeholder="Company Title" value="<?php echo e(isset($setting->title) ? $setting->title : ''); ?>" required=""> 
              </div> 
            </div>
                          
            <div class="col-md-12 col-xs-12">
              <div class="form-group <?php echo e($errors->has('password')?'has-error has-feedback':''); ?>">
                <label>Description</label>
                 <script src="<?php echo e(asset('adminlte/editor/tinymce.min.js')); ?>"></script>
                <textarea class="form-control my-editor" name="details" rows="8" placeholder="Enter ..."><?php echo isset($setting->details) ? $setting->details : ''; ?></textarea>
              </div> 
            </div>
           
            <div class="col-md-12 col-xs-12">
               <?php 
                  if (isset($setting->status) && $setting->status == 1 ) {
                    $check = "checked";
                    $uncheck = "";
                  }else{
                    $check = "";
                    $uncheck = "checked";
                  }
                ?>
              <div class="form-group">
                <label>Status</label>&nbsp;
                <label style="font-weight:400;"> <input type="radio" name="status" value="1" <?php echo e($check); ?>>Publish</label>&nbsp;&nbsp;
                <label style="font-weight: 400;"> <input type="radio" name="status" value="0" <?php echo e($uncheck); ?>>UnPublish</label>
              </div> 
            </div>
            <div class="col-md-12 col-xs-12">
              <div class="modal-footer" style="padding: 5px 13px;">
                <button type="submit" class="btn btn-success btn-flat btn-sm">Publish</button>
              </div>   
            </div>                
          </section>
        </form>
      </div>
    </section>
  </div>  
</div>
<?php echo $__env->make('admin.include.editor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Modal -->
<div class="modal fade" id="exampleModalCenterTitle" role="dialog" data-backdrop="static" data-keyboard="false" data-show="true">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle"><strong>Upload Image</strong></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form method="POST" id="form_uploadeFileOnly" action="<?php echo e(route('uploadOnlyFile')); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="modal-body">
          <input type="hidden" name="cp_id" value="<?php echo e(isset($_GET['cp_id']) ? $_GET['cp_id'] : ''); ?>">
          <p><span>User images are 140px by 140px  Use a jpg, png, or gif image, under 1MB.</span></p>
          <span>Choose file to upload</span>
          <input type="file" name="onlyFile" id="company-logo">        
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Uploade</button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>