<?php $__env->startSection('title', 'Create Payment'); ?>
<?php 
  use App\component\Content;
  $active = 'finance/journal'; 
  $subactive = 'finance/payable/create';
  $bus_id = isset($journal->business_id)? $journal->business_id:'';
  $sup_id = isset($journal->supplier_id)? $journal->supplier_id:'';
  $projectNo = isset($journal->project_number)? $journal->project_number:0;
  $conId = isset($journal->country_id) ? $journal->country_id: \Auth::user()->country_id;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper"> 
    <section class="content"> 
      <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <h3 class="border text-center" style="color:black;text-transform: uppercase;font-weight:bold;">Cash / Bank Transactions </h3>
        <form method="POST" action="<?php echo e(route('createPayment')); ?>" id="account_CreatePayment_form">
          <!-- account_CreatePayment_form -->
          <?php echo e(csrf_field()); ?>

          <div class="row">
            <div class="col-md-10 col-md-offset-1" style="margin-bottom: 20px">
              <div class="account-saction"><br>
                <div class="col-md-1 col-xs-6" style="padding-right:0;">
                  <div class="form-group">
                    <label>Date<span style="color:#b12f1f;">*</span></label> 
                    <input type="text" name="pay_date" class="form-control book_date" value="<?php echo e(date('Y-m-d')); ?>" required="" readonly="">
                  </div>
                </div>   

                <div class="col-md-2 col-xs-6 <?php echo e(\Auth::user()->role_id != 2 ? 'hidden': ''); ?>">
                  <div class="form-group">
                    <label>Location<span style="color:#b12f1f;"></span></label> 
                    <?php if(isset($journal->country_id) && !empty($journal->country_id)): ?>
                      <span class="form-group">
                        <span class="form-control "><?php echo e(isset($journal->country->country_name) ? $journal->country->country_name : ''); ?></span>
                        <input type="hidden" name="country" value="<?php echo e($journal->country_id); ?>">
                      </span>
                    <?php else: ?>
                      <select class="form-control location" name="country" data-type="sup_by_bus" required="">
                        <option value="">Choose Location</option>
                        <?php $__currentLoopData = App\Country::LocalPayment(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($con->id); ?>" <?php echo e($conId == $con->id ? 'selected':''); ?>> <?php echo e($con->country_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    <?php endif; ?>
                  </div>
                </div>
                <div class="col-md-3 col-xs-6">
                  <div class="form-group">
                    <label>Business Type</label>
                    <?php if(isset($journal->business_id) && !empty($journal->business_id)): ?>
                      <span class="form-group">
                        <span class="form-control "><?php echo e(isset($journal->business->name) ? $journal->business->name : ''); ?></span>
                        <input type="hidden" name="business" value="<?php echo e($journal->business_id); ?>">
                      </span>
                    <?php else: ?>
                      <select class="form-control business_type_receive" name="business" data-type="sup_by_bus" required="">
                        <option value="">Choose Business</option>
                          <?php $__currentLoopData = App\Business::PaymentBusiness(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($bn->id); ?>" <?php echo e($bus_id == $bn->id ? "selected":''); ?>><?php echo e($bn->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    <?php endif; ?>
                  </div>
                </div>
                <div class="col-md-3 col-xs-6" id="supplier_Name">
                  <div class="form-group">
                    <label><?php echo e($journal->type == 1 ? "To" : "From"); ?> Supplier <span style="color:#b12f1f;">*</span></label> 
                    <?php if(isset($journal->supplier_id) && !empty($journal->supplier_id)): ?>
                      <span class="form-group">
                        <span class="form-control" id="supplier_<?php echo e($journal->type == 1 ? 'to' : 'from'); ?>"><?php echo e(isset($journal->supplier->supplier_name) ? $journal->supplier->supplier_name : ''); ?></span>
                        <input type="hidden" id="input_supplier_<?php echo e($journal->type == 1 ? 'to' : 'from'); ?>" name="supplier_<?php echo e($journal->type == 1 ? 'to' : 'from'); ?>" value="<?php echo e($journal->supplier_id); ?>">
                      </span>
                    <?php else: ?>
                      <select class="form-control  supplier-receivable" name="supplier" id="dropdown_receive_supplier" data-type="pro_by_sup" data-acc_type="acc_payable" required="">
                        <option value="">Choose Supplier</option>
                          <?php 
                            $getMisc = \App\BookMisc::where(['project_number'=> $projectNo])->orderBy("created_at", "DESC")->get();
                            $getEntran = \App\BookEntrance::where(['project_number'=> $projectNo])->orderBy("created_at", "DESC")->get(); 
                          ?>                      
                      </select>
                    <?php endif; ?>
                  </div>               
                </div>
                 
                <input type="hidden" name="journal_id" id="journal_id" value="<?php echo e(isset($journal->id) ? $journal->id : ''); ?>">
                <div class="col-md-3 col-xs-6">
                  <div class="form-group">
                    <label>Account Type</label>
                    <input type="hidden" name="account_type_id"id="account_typeID" value="<?php echo e(isset($journal->account_type_id) ? $journal->account_type_id : ''); ?>" >
                    <span class="form-control"><?php echo e(isset($journal->account_type->account_name) ? $journal->account_type->account_name : ''); ?></span>
                  </div>
                </div>
                <div class="col-md-3 col-xs-6">
                    <div class="form-group">
                      <label>Account Name</label>
                      <input type="hidden" name="account_name_id" id="account_nameID" value="<?php echo e(isset($journal->account_name_id) ? $journal->account_name_id : ''); ?>">
                      <span class="form-control"><?php echo e(isset($journal->account_name->account_code) ? $journal->account_name->account_code : ''); ?> - <?php echo e(isset($journal->account_name->account_name) ? $journal->account_name->account_name : ''); ?></span>
                    </div>
                </div>

                <?php if(isset($journal->project_number) && !empty($journal->project_number)): ?>
                  <div class="col-md-6 col-xs-6">
                    <div class="form-group">                 
                      <label for="for_project">For Project<span style="color:#b12f1f;">*</span></label>
                      <?php if(isset($journal->project)): ?>
                        <input type="hidden" name="projectNo" value="<?php echo e(isset($journal->project_id) ? $journal->project_id : ''); ?>">
                        <span class="form-control"><?php echo e(isset($journal->project->project_prefix) ? $journal->project->project_prefix : ''); ?>-<?php echo e(isset($journal->project->project_fileno) ? $journal->project->project_fileno : ''); ?> - <?php echo e(isset($journal->project->project_client) ? $journal->project->project_client : ''); ?>,  Date:<?php echo e(Content::dateformat($journal->project->project_start)); ?>-><?php echo e(Content::dateformat($journal->project->project_end)); ?></span>
                     <?php endif; ?>
                    </div>
                  </div>
                <?php endif; ?>
                
                <div class="col-md-3 col-xs-6">
                  <div class="form-group">
                    <label> <?php echo e($journal->type == 1 ? "From" : "To"); ?> Account Book<span style="color:#b12f1f;">*</span></label> 
                    <select class="form-control" id="supplier_<?php echo e($journal->type == 1 ? 'from' : 'to'); ?>" name="supplier_<?php echo e($journal->type == 1 ? 'from' : 'to'); ?>" required="">
                      <?php 
                       $AccBooks = App\Supplier::where(['business_id' => 5, 'country_id'=> $conId ])->orderBy("supplier_name", "ASC")->get()
                      ?>
                      <?php if($AccBooks->count() > 0): ?>
                        <?php $__currentLoopData = $AccBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($bk->id != $journal->supplier_id): ?>
                          <option value="<?php echo e($bk->id); ?>" ><?php echo e($bk->supplier_name); ?></option>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                        <option value="">No Account</option>
                      <?php endif; ?>
                    </select>
                  </div>
                </div> 
                
                <div class="col-md-6 col-xs-6">
                  <div class="row">
                    <div class="col-md-6 col-xs-6">
                      <div class=" total_balance_to_pay" >
                        <?php
                          $accBalance = 0;
                          $fieldName = "deposit_amount";
                          $fieldhiddenName = "pay_amount";

                          if ( isset($journal->id)) {
                            $getAccTran = \App\AccountTransaction::where(["journal_id"=> $journal->id, 'status'=>1]);
                            // echo $journal->credit;
                            if ($journal->debit > 0 || $journal->credit > 0 ) {
                              $amountDebit = ($journal->debit - $getAccTran->sum("credit"));
                              $amountCredit = ($journal->credit - $getAccTran->sum("debit"));

                              $accBalance = $amountDebit > 0 ? $amountDebit : $amountCredit;
                              $fieldName = "deposit_amount";
                              $fieldhiddenName = "pay_amount";
                              $currency = Content::currency();
                              $reqired = ""; 
                            }else{
                              $currency = Content::currency(1);
                              $AcmountKDebit = ($journal->kdebit - $getAccTran->sum("kcredit"));
                              $AcmountKcredit = ($journal->kcredit - $getAccTran->sum("kdebit"));
                              $accBalance = $AcmountKDebit > 0 ? $AcmountKDebit : $AcmountKcredit;
                              $fieldName = "deposit_kamount";
                              $reqired = "required"; 
                              $fieldhiddenName = "pay_kamount";
                            }
                          }                 
                        ?>
                        <input type="hidden" id="currency" value="<?php echo e($currency); ?>">
                        <input type="hidden" name="type" value="<?php echo e(isset($journal->type) ? $journal->type : ''); ?>">
                        <label ><input type="radio" name="payoption" class="payoption" value="1" checked> Pay Full</label>
                        <label ><input type="radio" name="payoption" class="payoption" value="0"> Deposit  &nbsp; <?php echo e($currency); ?></label>
                        <input type="text" name="<?php echo e($fieldName); ?>" class="form-control text-center balance number_only" id="deposit_amount" placeholder="0.00" value="<?php echo e($accBalance); ?>" <?php echo e($accBalance == 0 ? 'readonly': ''); ?> required>
                        <input type="hidden" name="<?php echo e($fieldhiddenName); ?>" class="form-control text-right balance number_only" id="pay_amount" placeholder="00.0" value="<?php echo e($accBalance); ?>">
                       </div>
                    </div>
                    <div class="col-md-3 col-xs-6">                      
                        <div class="amount_to_pay">
                            <div class="form-group amount_to_pay">
                              <label>Balance</label>
                              <span class="form-control" id="amount_to_pay"></span>
                              <input type="hidden" id="input_amount_to_pay">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Exc-Rate</label>
                        <div class="form-group">
                          <input class="form-control text-center" name="exchange_rate" type="text" placeholder="Exchange rate" <?php echo e($reqired); ?>>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 col-xs-6">
                  <div class="form-group">
                    <label title="Please enter actual pay date">INV Paid Date<span style="color:#b12f1f;"> * <small style="font-size: 79%;">Please enter actual pay date</small></span></label>
                    <input type="text" name="invoice_pay_date" id="invoice_pay_date" class="form-control book_date" value="<?php echo e(date('Y-m-d')); ?>" required="" readonly="">
                  </div>
                </div>
                <div class="col-md-3 col-xs-6">
                  <div class="form-group">
                    <label>Payment Voucher<span style="color:#b12f1f;">*</span></label>
                    <input type="text" name="payment_voucher" id="payment_voucher" class="form-control text-right" required placeholder="xxx xxx xxx xxx">
                  </div>
                </div>
                <div class="col-md-3 col-xs-6">
                  <div class="form-group">
                    <label>Invoice Number<span style="color:#b12f1f;">*</span></label>
                    <input type="text" name="invoice_number" id="invoice_number" class="form-control text-right" placeholder="xxx xxx xxx xxx" required>
                  </div>
                </div>
                
                <div class="col-md-3 col-xs-6">
                  <div class="form-group">
                    <label>INV-RCVD Date From Supplier<span style="color:#b12f1f;">*</span></label>
                    <input type="text" name="invoice_from_sup" id="invoice_from_sup" class="form-control book_date" value="<?php echo e(date('Y-m-d')); ?>" required="" readonly="">
                  </div>
                </div>
                <div class="col-md-12 col-xs-12">
                  <div class="form-group">
                    <label>Remarks / Descriptions</label>
                    <textarea class="form-control" rows="4" id="remark" name="remark" placeholder="Message here ...!"><?php echo e(isset($journal->remark) ? $journal->remark : ''); ?></textarea>
                  </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-12 text-center">
                  <div class="form-group">
                    <button class="btn btn-info btn-sm" id="btnSaveCreatedPayment" style="width: 120px;">
                      <?php echo e($journal->type == 1 ? "Pay Now" : "Confirm Receive"); ?>

                    </button>
                  </div>
                </div><div class="clearfix"></div>
              </div>
            </div>
          </div>
        </form>
    </section>
  </div>
</div>

<!-- menun -->
<div class="modal" id="myModal" role="dialog"  data-backdrop="static" data-keyboard="true">
  <div class="modal-dialog modal-md">    
    <form method="POST" action="<?php echo e(route('addNewAccount')); ?>" id="add_new_account_form">
      <div class="modal-content">        
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><strong>Add New Account</strong></h4>
        </div>
        <div class="modal-body">
          <?php echo e(csrf_field()); ?>    
          <div class="row">
            <div class="col-md-6 col-xs-4">
              <div class="form-group">
                <label>Account Type<span style="color:#b12f1f;">*</span></label> 
                <select class="form-control  account_type" name="account_type" data-type="account_name">
                  <?php $__currentLoopData = App\AccountType::where('status', 1)->orderBy('account_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($acc->id); ?>"><?php echo e($acc->account_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <div class="col-md-6 col-xs-4">
              <div class="form-group">
                <label>Account Code<span style="color:#b12f1f;">*</span> <small>(A unique code/number)</small></label> 
                <input type="text" name="code" class="form-control" required="">
              </div>
            </div>
            <div class="col-md-12 col-xs-4">
              <div class="form-group">
                <label>Account Name<span style="color:#b12f1f;">*</span></label> 
                <input type="text" name="name" class="form-control " required="">
              </div>
            </div>
            <div class="col-md-12 col-xs-12">
              <div class="form-group">
                <label>Description (Option)<span style="color:#b12f1f;">*</span></label> 
                <textarea class="form-control" name="account_desc" rows="4"></textarea>
              </div>
            </div>
          </div>
           <div class="col-md-12 col-xs-12">
            <div class="form-group">
              <div class="checkMebox">
                <label>
                  <span style="position: relative;top: 4px;"> 
                    <i class="fa fa-square-o"></i>
                    <input type="checkbox" name="check_paid" >&nbsp;
                  </span>
                  <span>Already Paid</span>
                </label>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer ">
          <div class="text-center">
            <button class="btn btn-info btn-sm" style="width: 120px;" id="btnAddNewAccount">Save</button>
            <a href="#" class="btn btn-default btn-sm" data-dismiss="modal">Cancel</a>
          </div>
        </div>
      </div>      
    </form>
  </div>
</div>

<div class="modal" id="myAlert" role="dialog" data-backdrop="static" data-keyboard="true">
  <div class="modal-dialog modal-md">    
      <div class="modal-content">        
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><strong>Payment Confirmation</strong></h4>
          <div class="clearfix"></div>
        </div>
        <div class="modal-body">
          <div id="modal-body">
            <strong id="message">Result not found...! </strong>        
          </div>
          <p><label>Are you sure to make this payment transaction ?</label></p>
        </div>
        <div class="modal-footer" style="text-align: center;">
          <button type="submit" class="btn btn-info btn-sm btnOkay" onclick="onclick()" >OK</button>
          <button type="button" class="btn btn-default btn-flat btn-sm btn-acc" data-dismiss="modal">Cancel</button>
        </div>  
      </div>  
  </div>
</div>
<?php echo $__env->make("admin.account.accountant", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make("admin.include.datepicker", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>