<?php $__env->startSection('title', 'User List'); ?>
<?php $active = 'users';
  $subactive ='users'; 
  use App\component\Content;
?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <form action="POST">
            <section class="col-lg-12 connectedSortable">
                <h3 class="border">Users List <span style=" font-size: 22px;" class="fa fa-angle-double-right"></span> <a href="<?php echo e(route('userForm')); ?>" class="btn btn-default btn-sm">Add User</a></h3>
                <table class="datatable table table-hover table-striped">
                  <thead>
                    <tr>
                      <th width="30px">Photo</th>
                      <th>UserName</th>
                      <th>Gender</th>
                      <th>Phone</th>
                      <th>Email</th>
                      <th>Password</th>
                      <th>Role</th>
                      <th>Joining on</th>
                      <th>Status</th>
                      <th width="100" class="text-center">action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td width="30px"><img src="/storage/avata/thumbnail/<?php echo e($user->picture); ?>" class="img-responsive"></td>
                      <td><?php echo e($user->fullname); ?></td>
                      <td><?php echo e($user->gender); ?></td>
                      <td><?php echo e($user->phone); ?></td>
                      <td><?php echo e($user->email); ?></td>
                      <td><?php echo e($user->password_text); ?></td>
                      <td><?php echo e(isset($user->role->name) ? $user->role->name : ''); ?></td> 
                      <td><?php echo e(Content::dateformat($user->created_at)); ?></td>   
                      <td><?php echo $user->banned==1? "<label class='label label-default'>Deactive<label>": "<label class='label label-success'>Active</label>"; ?></td>      
                      <td class="text-right">                      
                        <a target="_blank" href="<?php echo e(route('userStore', ['id'=> $user->id])); ?>" class="btn btn-info btn-xs " title="Change User Info">
                         <i class="fa fa-edit"></i>
                        </a>
                        <?php if(Auth::user()->role_id == 2): ?>
                          <a target="_blank" href="<?php echo e(route('editpermission', ['url'=> $user->id])); ?>" class="btn btn-primary btn-xs" title="Change Password & User Permission">
                            <!-- <label style="cursor: pointer;" class="icon-list ic_user_permission"></label> -->
                            <i class="fa fa-gear (alias)"></i>
                          </a>                       

                          <a href="javascript:void(0)" data-type="user" class="RemoveHotelRate btn btn-danger btn-xs" data-id="<?php echo e($user->id); ?>" title="Remove this user?">
                            <!-- <label style="cursor: pointer;" class="icon-list ic_remove"></label> -->
                            <i class="fa fa-minus-circle"></i>
                          </a>
                         <?php endif; ?>
                      </td>                     
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>                
            </section>
          </form>
        </div>
    </section>
  </div>  
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<!-- <div class="modal fade" id="myModal" role="dialog"  data-backdrop="static" data-keyboard="true">
  <div class="modal-dialog modal-lg">    
    <form id="form_submitUser" method="POST" action="<?php echo e(route('addUser')); ?>">
      <div class="modal-content">        
        <div class="modal-header" style="padding: 5px 13px;">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><strong id="form_title">Add MISC Service</strong></h4>
        </div>
        <div class="modal-body">
          <?php echo e(csrf_field()); ?>

          <div class="row">
            <div class="col-md-6 col-xs-6">
              <div class="form-group">
                <label>Full Name <span style="color:#b12f1f;">*</span></label> 
                <input type="text" class="form-control" name="fullname" id="fullname" placeholder="Full Name" required> 
              </div> 
            </div>
            <div class="col-md-6 col-xs-6">
              <div class="form-group">
                <label>UserName <span style="color:#b12f1f;">*</span></label> 
                <input type="text" class="form-control" name="username" id="username" placeholder="User Name" required>
              </div> 
            </div>
            <div class="col-md-6 col-xs-6">
              <div class="form-group">
                <label>Email Address <span style="color:#b12f1f;">*</span></label> 
                <input type="email" class="form-control" name="email" id="email" placeholder="virak@asia-expeditions.com"  required>
              </div> 
            </div>
            <div class="col-md-6 col-xs-6">
              <div class="form-group">
                <label>Phone <span style="color:#b12f1f;">*</span></label>
                <input type="text" class="form-control" name="phone" id="phone" placeholder="(+855) 1234 567 890" required>
              </div>
            </div>
            <div class="col-md-6 col-xs-6">
              <div class="form-group">
                <label>Password<span style="color:#b12f1f;">*</span> <small>(Password at less 6 character)</small></label> 
                <input type="password" class="form-control" name="password" id="password" placeholder="Password " required>
              </div> 
            </div>
            <div class="col-md-6 col-xs-6">
              <div class="form-group">
                <label>Confirm Password <span style="color:#b12f1f;">*</span>  <small>(Must be the same password)</small></label>
                <input type="password" class="form-control" name="con-password" id="con-password" placeholder="Confirm Password" required>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer" style="padding: 5px 13px;">
          <button type="submit" class="btn btn-success btn-flat btn-sm" id="btnSubmit">Register Now</button>
          <a href="#" class="btn btn-danger btn-flat btn-sm" data-dismiss="modal">Cancel</a>
        </div>
      </div>      
    </form>
  </div>
</div> -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>