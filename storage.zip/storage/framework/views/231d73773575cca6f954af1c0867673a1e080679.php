<?php $__env->startSection('title', 'Booked Project List'); ?>
<?php 
  $active = 'booked/project'; 
  $subactive ='booked/project';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <form method="POST" action="<?php echo e(route('searchProject', ['project'=> 'project'])); ?>">
            <?php echo e(csrf_field()); ?>

            <section class="col-lg-12 connectedSortable">
              <h3 class="border">Project List <span class="fa fa-angle-double-right"></span> <a href="<?php echo e(route('proForm')); ?>" class="btn btn-default btn-sm">Create Project</a></h3>
              <div class="col-sm-8 pull-right">
                <div class="col-md-3">
                  <input type="hidden" name="" value="<?php echo e(isset($projectNum) ? $projectNum : ''); ?>" id="projectNum">
                  <input class="form-control input-sm" type="text" id="from_date" name="start_date" placeholder="From Date" value="<?php echo e(isset($startDate) ? $startDate : ''); ?>"> 
                </div>
                <div class="col-md-3">
                  <input class="form-control input-sm" type="text" id="to_date" name="end_date" placeholder="To Date" value="<?php echo e(isset($endDate) ? $endDate : ''); ?>"> 
                </div>
                 <div class="col-md-2" style="padding: 0px;">
                  <button class="btn btn-default btn-sm" type="submit">Search</button>
                </div>
              </div>
              <table class="datatable table table-hover table-striped">
                <thead>
                  <tr>                       
                    <th width="65">Project No.</th>
                    <th>Date</th>    
                    <th>Country</th>    
                    <th>Province</th>                   
                    <th>Type</th>
                    <th>Service</th>
                    <th>Pax</th>
                    <th>Day</th>
                    <th>Price <?php echo e(Content::currency()); ?></th>
                    <th>Amount <?php echo e(Content::currency()); ?></th>
                    <th>Price <?php echo e(Content::currency(1)); ?></th>
                    <th>Amount <?php echo e(Content::currency(1)); ?></th>
                    <th class="text-center" >Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $projectBooked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="studentId" width="75">
                      <input type="checkbox" class="btnCheck"> &nbsp; 
                      <?php echo e($project->book_project); ?></td>
                    <td><?php echo e(Content::dateformat($project->book_checkin)); ?></td>
                    <td><?php echo e(isset($project->country->country_name) ? $project->country->country_name : ''); ?></td>
                    <td><?php echo e(isset($project->province->province_name) ? $project->province->province_name : ''); ?></td>
                      <?php        
                        if($project->tour_id > 0){
                          $bsn = "tour";
                          $service = App\Tour::find($project->tour_id);
                          $serviceName = $service->tour_name;
                        }elseif ($project->hotel_id > 0) {
                          $bsn = "hotel";
                          $service = App\Supplier::find($project->hotel_id);
                          $serviceName = $service->supplier_name;
                        }elseif ($project->flight_id > 0) {
                          $bsn = "flight";
                          $service = App\Supplier::find($project->flight_id);
                          $serviceName = $service->supplier_name;
                        }elseif ($project->cruise_id > 0) {
                          $bsn = "cruise";
                          $service = App\Supplier::find($project->cruise_id);
                          $serviceName = $service->supplier_name;
                        }elseif ($project->golf_id > 0) {
                          $bsn = "golf";
                          $service = App\Supplier::find($project->golf_id);
                          $serviceName = $service->supplier_name;
                        }else{
                          $bsn = "";
                          $serviceName = "";
                        }
                      ?>  
                    <td><span style="text-transform: capitalize;"><?php echo e($bsn); ?></span></td>
                    <td style="width: 15%;"><?php echo e($serviceName); ?></td>
                    <td><?php echo e($project->book_pax); ?></td>
                    <td><?php echo e($project->book_day); ?></td>
                    <td class="text-right"><?php echo e($project->book_price); ?></td>
                    <td class="text-right"><?php echo e($project->book_amount); ?></td>
                    <td class="text-right"><?php echo e($project->book_kprice); ?></td>
                    <td class="text-right"><?php echo e($project->book_kamount); ?></td>
                    <td class="text-center">
                      <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$project->book_project, 'type'=>'details'])); ?>" title="Program Details">
                        <label class="icon-list ic_ops_program"></label>
                      </a>
                      <?php if($bsn != ''): ?>
                      <a target="_blank" href="<?php echo e(route('bookingEdit', ['url'=> $bsn, 'id'=>$project->id])); ?>" title="Edit Cruise">
                      <?php else: ?>
                      <a href="javascript:void(0)" title="Invalid Link">
                      <?php endif; ?>
                        <label class="icon-list ic_edit"></label>
                      </a>&nbsp;          
                      <a href="javascript:void(0)" class="RemoveHotelRate" data-type="booked_project" data-id="<?php echo e($project->id); ?>" title="Delete this booking">
                        <label class="icon-list ic_remove"></label>
                      </a>                    
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </section>
          </form>
        </div>
    </section>
</div>
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>