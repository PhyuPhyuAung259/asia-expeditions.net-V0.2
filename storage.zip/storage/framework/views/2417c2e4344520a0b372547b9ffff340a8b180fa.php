<?php $__env->startSection('title', $view_type); ?>
<?php 
  $active = 'finance/accountPayable/project-booked'; 
  $subactive = 'finance/accountPayable/project-booked';
  use App\component\Content;
  $countryId = Auth::user()->country_id ? Auth::user()->country_id : 0;
 $user_role =  Auth::user()->role_id;
?>
<?php $__env->startSection('content'); ?>
  <div class="wrapper">
    <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content"> 
        <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <h3 class="border text-center" style="color:black;text-transform: uppercase;font-weight:bold;">Select Option to Pay</h3>
          <div class="container-fluid ">
              <div class="text-center"> 
                <a href="<?php echo e(route('accountPayable', ['type' => 'project-booked'])); ?>" class="btn btn-primary 
                  <?php echo e($view_type == 'project-booked' ? 'active' : 'btn-acc'); ?>"> <b>Project Booked</b></a> &nbsp;
                <a href="<?php echo e(route('accountPayable', ['type' => 'office-supply'])); ?>" class="btn btn-primary 
                  <?php echo e($view_type == 'office-supply' ? 'active' : 'btn-acc'); ?>"> <b>Office Supplier</b></a> &nbsp;
              </div>
              <div class="tab-pane">
                   <div class="col-md-6 col-md-offset-3">
                    <div id="search_form" style="padding: 6px;border: solid #d2d6de 1px; position: relative; background: #e8f1ff;margin: 12px 0px;border-radius: 3px;" class="alert alert-dismissible fade in" role="alert"> 
                      <br>
                      <form method="GET" action="">
                        <div class="col-md-3">
                          <?php if(\Auth::user()->role_id == 2): ?>
                              <select class="form-control country_book_supplier input-sm" name="country" data-type="supplier_book">
                                <option value="">Location</option>
                                <?php $__currentLoopData = App\Country::LocalPayment(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($con->id); ?>" <?php echo e(isset($_GET['country']) && $_GET['country']  == $con->id ? 'selected' : ''); ?>><?php echo e($con->country_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          <?php endif; ?>
                        </div>
                        <div class="col-md-3">
                          <div class="form-group">
                            <input type="text" name="from_date" class="form-control input-sm text-center" id="from_date" value="<?php echo e(isset($_GET['from_date']) ? $_GET['from_date'] : ''); ?>" placeholder="Date From" readonly>
                          </div>
                        </div>
                        <div class="col-md-3">
                          <div class="form-group">
                            <input type="text" name="to_date" class="form-control input-sm text-center" id="to_date" value="<?php echo e(isset($_GET['to_date']) ? $_GET['to_date'] : ''); ?>" placeholder="Date To" readonly>
                          </div>
                        </div>
                        <div class="col-md-3">
                          <div class="form-group">
                            <div class="pull-left">
                              <button type="submit" class="btn btn-primary btn-sm btn-flat" id="btnSearchJournal">Search</button>
                            </div>
                          </div>
                        </div> 
                      </form>
                      <div class="clearfix"></div>
                    </div>  
                  </div><div class="clearfix"></div>
                  <?php if(isset($posteData) && $posteData->count() > 0): ?>
                  <form target="_blank" action="<?php echo e(route('PreviewPosted')); ?>"> 

                      <div><label><input id="check_all" type="checkbox" name="checkbox" style="width: 16px; height: 16px;"> Check All</label>
                        <input type="hidden" name="type" value="<?php echo e($view_type); ?>">
                        &nbsp;&nbsp;&nbsp;
                        <input type="submit" name="priviwe_print" value="Preview & Print" class="btn btn-default btn-acc btn-xs">
                      </div>
                      <table class="table table-striped table-borderd table-hover datatable">
                        <thead>
                          <tr>
                            <th width="45px"><a href="#">Action</a></th>
                            <?php if(isset($view_type) && $view_type == 'project-booked'): ?>
                              <th><a href="#">File No.</a></th>
                            <?php endif; ?>
                            <th><a href="javascript:void(1)">Date</a></th>
                            <th><a href="#">Supplier</a></th>
                            <th><a href="#">Account Type - Account Name</a></th>
                            <th class="text-right"><a href="#" style="color: #f39c12; font-style: italic;">EST-Receive</a></th>
                            <th class="text-right"><a href="#" style="color: #f39c12; font-style: italic;">EST-Cost</a></th>
                            <th class="text-right" ><a href="#">To Receive</a></th>
                            <th class="text-right"><a href="#">To Pay</a></th>
                            <th class="text-right"><a href="#">To Receive <?php echo e(Content::currency(1)); ?></a></th>
                            <th class="text-right"><a href="#">To Pay <?php echo e(Content::currency(1)); ?></a></th>
                            <th class="text-right"><a href="#">Deposit</a></th>
                            <th class="text-right">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                         <?php 
                            $getReceiveBalance = 0;
                            $getPaymentBalance = 0;
                            $getReceiveBalanceKyat = 0;
                            $getPaymentBalanceKyat = 0;
                          ?>
                          <?php $__currentLoopData = $posteData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                              $AccTrantotal = \App\AccountTransaction::where(["journal_id"=>$acc->id, "status"=>1]); 
                              $depositAmount = $AccTrantotal->sum("credit") > 0 ? $AccTrantotal->sum("credit"): $AccTrantotal->sum("debit");
                              $depositAmountk = $AccTrantotal->sum("kcredit") > 0 ? $AccTrantotal->sum("kcredit"): $AccTrantotal->sum("kdebit");

                              if ($depositAmount > 0) {
                                $depositTotal = $depositAmount > 0 ? Content::money($depositAmount) : '';
                              }else{
                                $depositTotal = $depositAmountk > 0 ? Content::money($depositAmountk) : '';
                              }

                              $ReceiveAmount = ($acc->credit - $depositAmount);
                              $amountToPay = ($acc->debit - $depositAmount); 
                              if ($depositAmountk > 0 && $depositAmountk > 0 && !empty($acc->kcredit)) {
                                  $ReceiveAmountKyat = ($acc->kcredit - $depositAmountk);
                              }else{
                                $ReceiveAmountKyat = $acc->kcredit;
                              }

                              if (isset($depositAmountk) && $depositAmountk > 0 && !empty($acc->kdebit)) {
                                $amountToPayKyat = ($acc->kdebit - $depositAmountk);
                              }else{
                                $amountToPayKyat = $acc->kdebit;
                              }
                              $getReceiveBalance = $getReceiveBalance + $ReceiveAmount;
                              $getPaymentBalance = $getPaymentBalance + $amountToPay;
                              $getReceiveBalanceKyat = $getReceiveBalanceKyat + $ReceiveAmountKyat;
                              
                            ?>
                            <tr>
                              <td>
                                <input style="width:16px; height:16px;" class="checkall" type="checkbox" name="value_checked[]" value="<?php echo e($acc->id); ?>">
                                <a href="javascript:void(0)" class="btnRemoveOption" data-type="journal-entry" data-id="<?php echo e($acc->id); ?>" title="Remove this ?">
                                  <label class="icon-list ic-trash" style="background-position: 0 -870px !important;"></label>
                                </a>
                                
                                <?php if($ReceiveAmount >= $depositAmount || $amountToPay >= $depositAmount || $ReceiveAmountKyat >= $depositAmountk || $amountToPayKyat >= $depositAmountk || $user_role == 2 ): ?>
                                  <a data-acc_name_title="<?php echo e(isset($acc->account_name->account_code) ? $acc->account_name->account_code : ''); ?> - <?php echo e(isset($acc->account_name->account_name) ? $acc->account_name->account_name : ''); ?>" data-acc_type="<?php echo e(isset($acc->account_type->id) ? $acc->account_type->id : ''); ?>" data-acc_name="<?php echo e(isset($acc->account_name->id) ? $acc->account_name->id : ''); ?>" data-id="<?php echo e($acc->id); ?>" data-type="account_name" data-credit="<?php echo e($acc->credit); ?>" data-debit="<?php echo e($acc->debit); ?>" data-kcredit="<?php echo e($acc->kcredit); ?>" data-kdebit="<?php echo e($acc->kdebit); ?>" class="btnEditJournal" data-pay_date="<?php echo e(date('Y-m-d', strtotime($acc->entry_date))); ?>" data-toggle="modal" data-target="#myModal"><label style="cursor:pointer; height: 16px; width: 16px;" class="icon-list ic_edit" title="Preview Journal Entry"></label></a>
                                <?php endif; ?>                                
                              </td>
                              <?php if(isset($view_type) && $view_type == 'project-booked'): ?>
                                <td><?php echo e(isset($acc->project->project_prefix) ? $acc->project->project_prefix : ''); ?> - <?php echo e($acc->project_fileNo); ?></td>
                              <?php endif; ?>
                              <td style="width: 92px;"><?php echo e(Content::dateformat($acc->entry_date)); ?></td>
                              <td><?php echo e(isset($acc->supplier->supplier_name) ? $acc->supplier->supplier_name : ''); ?></td>
                              <td><a href="#"><?php echo e(isset($acc->account_type->account_name) ? $acc->account_type->account_name : ''); ?> - <?php echo e(isset($acc->account_name->account_code) ? $acc->account_name->account_code : ''); ?> - <?php echo e(isset($acc->account_name->account_name) ? $acc->account_name->account_name : ''); ?></a></td>
                              <td class="text-right" style="color: #f39c12; font-style: italic;">
                                <?php echo e($acc->account_type_id == 8 ? Content::money($acc->debit) > 0 ? Content::money($acc->debit): Content::money($acc->kdebit) :''); ?>

                              </td>
                              <td class="text-right" style="color: #f39c12; font-style: italic;">
                                <?php echo e($acc->account_type_id != 8 ? Content::money($acc->debit) > 0 ? Content::money($acc->debit) : Content::money($acc->kdebit) :''); ?>

                              </td>                              
                              <td class="text-right">
                                  <?php if( $ReceiveAmount > 0): ?>  
                                    <?php echo e(Content::money($ReceiveAmount)); ?>  
                                  <?php else: ?>  
                                    <?php echo "<a href='javascript:void(0)' style='font-weight: 700;'>".Content::money($acc->credit)."</a>"; ?> 
                                  <?php endif; ?>
                              </td>
                              <td class="text-right">
                                  <?php if( $amountToPay > 0): ?>  
                                    <?php echo e(Content::money($amountToPay)); ?>  
                                  <?php else: ?>  
                                    <?php echo "<a href='javascript:void(0)' style='font-weight: 700;'>".Content::money($acc->debit)."</a>"; ?> 
                                  <?php endif; ?>
                              </td>
                              <td class="text-right">
                                  <?php if( $ReceiveAmountKyat > 0): ?>  
                                    <?php echo e(Content::money($ReceiveAmountKyat)); ?>  
                                  <?php else: ?>  
                                    <?php echo "<a href='javascript:void(0)' style='font-weight: 700;'>".Content::money($acc->kcredit)."</a>"; ?> 
                                  <?php endif; ?>
                              </td>
                              <td class="text-right">
                                  <?php if( $amountToPayKyat > 0): ?>  
                                    <?php echo e(Content::money($amountToPayKyat)); ?>  
                                  <?php else: ?>  
                                    <?php echo "<a href='javascript:void(0)' style='font-weight: 700;'>".Content::money($acc->kdebit)."</a>"; ?> 
                                  <?php endif; ?>
                              </td>
                              <td class="text-right"><a href="javascript:void(0)"><?php echo e($depositTotal); ?></a></td>
                              <td class="text-right">
                                
                                <?php if($depositAmount < $acc->credit || $depositAmountk < $acc->kcredit): ?>
                                  <a target="_blank" href="<?php echo e(route('getPayable', ['journal_id'=> $acc->id])); ?>" class="btn btn-default btn-acc btn-xs pull-right hidden-print"> <b>Receive Now</b></a>
                                <?php elseif($depositAmount < $acc->debit || $depositAmountk < $acc->kdebit): ?>
                                  <a target="_blank" href="<?php echo e(route('getPayable', ['journal_id'=> $acc->id])); ?>" class="btn btn-default btn-acc btn-xs pull-right hidden-print"><b>Pay Now</b></a>
                                <?php else: ?>
                                  Full Paid
                                <?php endif; ?>
                              </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tr style="background: #a76a09;color: white;">
                          <th colspan="8" class="text-right"> 
                            <?php if($getReceiveBalance): ?>
                              Amount To Receive: <?php echo e(Content::money($getReceiveBalance)); ?>,&nbsp;&nbsp;
                            <?php endif; ?>
                            <?php if($getPaymentBalance): ?>
                              Amount To Pay: <?php echo e(Content::money($getPaymentBalance)); ?>

                            <?php endif; ?>
                          </th>

                          <th colspan="5  " class="text-right">
                            <?php if($getReceiveBalanceKyat): ?>
                              Amount To Receive: <?php echo e(Content::money($getReceiveBalanceKyat)); ?>,&nbsp;&nbsp;
                            <?php endif; ?>
                            <?php if($getPaymentBalanceKyat): ?>
                              Amount To Pay: <?php echo e(Content::money($getPaymentBalanceKyat)); ?> 
                            <?php endif; ?>
                          </th>
                        </tr>
                      </table>
                    <?php else: ?>
                  </form>
                  <br>
                  <div class="notify-message">
                      <div class="alert alert-dismissible fade show warning " role="alert" style="position: relative; padding-left: 53px;">
                        <p style="text-transform: capitalize;"><i class="fa fa-warning (alias)"></i> <span>You need to choose one of tab above</span></p>
                      </div>
                  </div>
                  <?php endif; ?>
              </div>
          </div>
          <div class="clearfix"></div><br><br>
      </section>
    </div>
  </div>
  <div class="modal" id="myModal" role="dialog"  data-backdrop="static" data-keyboard="true">
    <div class="modal-dialog modal-lg">    
      <form method="POST" action="<?php echo e(route('editJournal')); ?>">
        <div class="modal-content">        
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title"><strong>Edit Journal Entry</strong></h4>
          </div>
          <div class="modal-body">
            <?php echo e(csrf_field()); ?>   
            <input type="hidden" name="journal_id" id="journal_id"> 
            <div class="row">
                <?php if(\Auth::user()->role_id == 2): ?>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label class="col-sm-3 text-right" style="padding-top: 7px;">Country</label>
                      <div class="col-sm-9">
                        <select class="form-control location" name="country" data-type="country">
                          <?php $__currentLoopData = App\Country::countryByProject(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($con->id); ?>"><?php echo e($con->country_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                  </div>
                <?php endif; ?>
                <div class="col-md-5">
                  <div class="form-group">
                      <label class="col-sm-4 text-right" style="padding-top: 7px;">Record Date</label>
                      <div class="col-sm-5">
                        <input type="text" name="pay_date"  id="pay_date"  class="form-control input-sm book_date" readonly="" value="<?php echo e(date('Y-m-d')); ?>">
                      </div>
                      <div class="clearfix"></div>
                  </div>
                </div>
                <table class="table">
                  <tr class="table-head-row">
                    <th width="200px">Account Type</th>
                    <th width="350px">Account Name</th>
                    <th width="120px">Debit</th>
                    <th width="120px">Credit</th>
                    <th width="120px"><?php echo e(Content::currency(1)); ?> Debit</th>
                    <th width="120px"><?php echo e(Content::currency(1)); ?> Credit</th>
                  </tr>
                  <tbody id="data_payment_option">
                    <tr>
                    
                      <td>
                        <select class="form-control account_type input-sm" name="account_type" data-type="account_name" required="">
                          <option value="0">Account Type</option>
                          <?php $__currentLoopData = App\AccountType::where('status', 1)->orderBy('account_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($acc->id); ?>"><?php echo e($acc->account_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </td>
                      <td style="position: relative;">
                         <div class="btn-group" style='display: block;'>
                          <button type="button" class="form-control input-sm arrow-down" data-toggle="dropdown" aria-haspopup="false" aria-expanded='false' data-backdrop="static" data-keyboard="false" role="dialog" data-backdrop="static" data-keyboard="false">
                            <span class="pull-left"></span>
                            <span class="pull-right"></span>
                          </button> 
                          <div class="obs-wrapper-search" style="max-height:250px; overflow: auto; ">
                            <div>
                              <input type="text" data-url="<?php echo e(route('getFilter')); ?>" id="search_Account" onkeyup="filterAccountName()" class="form-control input-sm">
                            </div>
                            <ul id="myAccountName" class="list-unstyled dropdown_account_name">
                            </ul>
                          </div>
                        </div>
                      </td>
                      <td>
                        <input type="text" class="debit form-control input-sm text-right balance number_only" data-type="debit" name="debit" id="debit" placeholder="00.0">
                      </td>
                      <td>
                        <input type="text" class="credit form-control input-sm text-right balance number_only" data-type="credit" name="credit" id="credit" placeholder="00.0">
                      </td>
                      <td>
                        <input type="text" class="kyat-debit form-control input-sm text-right balance number_only" data-type="kyat-debit" name="kyatdebit" id="kyat-debit" placeholder="00.0">
                      </td>
                      <td>
                        <input type="text" class="kyat-credit form-control input-sm text-right balance number_only" data-type="kyat-credit" name="kyatcredit" id="kyat-credit" placeholder="00.0">
                      </td>
                    </tr>
                  </tbody>
                </table>
                <div class="col-md-6">
                </div>
                <div class="col-md-6 text-right">
                  <div style="padding: 4px 0px;">
                    <div class="col-md-6"> <span>Subtotal <?php echo e(Content::currency()); ?></span></div>
                    <div class="col-md-3"> 
                      <span class="sub_total_debit">0.00</span>
                    </div>
                    <div class="col-md-3"> <span class="sub_total_credit">00.00</span>
                      <input type="hidden" name="debit_amount" id="debit_amount">
                    </div>
                    <div class="clearfix"></div>
                  </div>
                
                  <div style="padding: 7px 0px; border-top: solid 1px #999999b3;">
                    <div class="col-md-6"><strong>TOTAL</strong></div>
                    <div class="col-md-3"> 
                      <strong class="sub_total_debit">0.00</strong>
                    </div>
                    <div class="col-md-3"> 
                        <strong class="sub_total_credit">00.00</strong>
                        <input type="hidden" name="credit_amount" id="credit_amount">
                    </div>
                    <div class="clearfix"></div>
                  </div>
                  <div style="padding: 4px 0px;">
                    <div class="col-md-6"> <span>Subtotal <?php echo e(Content::currency(1)); ?></span></div>
                    <div class="col-md-3"> 
                      <span class="kyat_sub_total_debit">0.00</span>
                    </div>
                    <div class="col-md-3"> <span class="kyat_sub_total_credit">00.00</span>
                      <input type="hidden" name="kyat_debit_amount" id="kyat_debit_amount">
                    </div>
                    <div class="clearfix"></div>
                  </div>
                
                  <div style="padding: 7px 0px; border-top: solid 1px #999999b3;">
                    <div class="col-md-6"> <strong>TOTAL</strong> </div>
                    <div class="col-md-3"> 
                      <strong class="kyat_sub_total_debit">0.00</strong>
                    </div>
                    <div class="col-md-3"> 
                        <strong class="kyat_sub_total_credit">00.00</strong>
                        <input type="hidden" name="kyat_credit_amount" id="kyat_credit_amount">
                    </div>                        
                  </div>
                  <div class="clearfix"></div>
                  <hr style="padding: 1px;border: solid 1px #999999b3;margin-top: 0px;border-right: none;border-left: none;">
                </div>
                <div class="clearfix"></div>
            </div>
          </div>
          <div class="modal-footer ">
            <div class="text-center">
              <button class="btn btn-info btn-sm" id="btnUpdateAccount">Save</button>
              <a href="#" class="btn btn-default btn-sm btn-acc" data-dismiss="modal">Cancel</a>
            </div>
          </div>
        </div>      
      </form>
    </div>
  </div>
  

<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
  $(document).ready(function(){
    $(".search_option").on("click", function(){
        $("#search_form").show();
    });
    $("#close").on("click", function(){
      $("#search_form").hide();
    });
    $(document).on("click", ".btnEditJournal", function(){
      dataId = $(this).data("id");
      $("#journal_id").val(dataId);
    });
  
  $("#check_all").click(function () {
    if($("#check_all").is(':checked')){
       // Code in the case checkbox is checked.
        $(".checkall").prop('checked', true);
    } else {
         // Code in the case checkbox is NOT checked.
        $(".checkall").prop('checked', false);
    }
  });

  });
</script>

<script type="text/javascript">
  $(document).ready(function(){
    $(".datatable").DataTable({
      language: {
        searchPlaceholder: "Type search..."
      }
    });
  });


  function filterAccountName(){
    input = document.getElementById("search_Account");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myAccountName");
    li = ul.getElementsByClassName ("list");
    for (i = 0; i < li.length; i++) {
        a = li[i];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
          li[i].style.display = "";
        } else {
          li[i].style.display = "none";
        }
    }
  }
</script>
<?php echo $__env->make("admin.account.accountant", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>