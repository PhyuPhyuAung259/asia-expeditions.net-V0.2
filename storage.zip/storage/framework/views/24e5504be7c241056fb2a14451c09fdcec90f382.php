<?php  use App\component\Content;?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php echo $__env->make('admin.report.headerReport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>   
  <a href="javascript:void(0)" class="pull-right" onclick="window.print();"><span class="btn btn-primary btn-xs"><i class="fa fa-print"></i></span></a>&nbsp;&nbsp;&nbsp;&nbsp;
  <table class="table table-bordered" id="roomrate">
    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <hr>
      <div class="pull-left">
        <h4 style="text-transform: capitalize;"><strong><?php echo e(isset($supplier->country->country_name) ? $supplier->country->country_name : ''); ?> <i class="fa fa fa-angle-double-right"></i> <?php echo e(isset($supplier->province->province_name) ? $supplier->province->province_name : ''); ?> <i class="fa fa fa-angle-double-right"></i>  <?php echo e($supplier->supplier_name); ?> </strong></h4>
      </div>
      <table class="table" id="roomrate">
        <thead style="background-color: rgb(245, 245, 245); font-weight: 600;">
          <tr>
             <td style="padding: 8px;" width="30">No.</td> 
            <td style="padding: 8px;">Menu</td>
            <td style="padding: 8px;">Price US</td> 
            <td style="padding: 8px;">Price Kyat</td> 
          </tr>
        </thead>
        <tbody>
          <?php $data = App\RestaurantMenu::where('supplier_id', $supplier->id)->get(); ?>
          <?php $key = 1; ?>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $key++; ?>
            <tr style="border: 1px solid #eee;">
              <td class="text-center"><?php echo e($key); ?></td>
              <td style="padding: 8px;"><?php echo e($rest->title); ?></td>
              <td style="padding: 8px;"><?php echo e($rest->price); ?> <span class="pcolor"><?php echo e(Content::currency()); ?></span></td>
              <td style="padding: 8px;"><?php echo e($rest->kprice); ?> <span class="pcolor"><?php echo e(Content::currency(1)); ?></span></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <table class="table" id="roomrate">
        <thead style="background-color: rgb(245, 245, 245); font-weight: 600;">
          <tr>
            <td style="padding: 8px;">Info</td>
            <td style="padding: 8px;">Remark</td> 
            <td style="padding: 8px;">Hightlight</td> 
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="padding: 8px; width: 25%;">  
              <address>
                <b>P/H :</b> <?php echo e($supplier->supplier_phone); ?>/<?php echo e($supplier->supplier_phone2); ?><br>
                <b>Email :</b> <?php echo e($supplier->supplier_email); ?><br>
                <b>Address :</b> <?php echo e($supplier->supplier_address); ?><br>
                <b>Website :</b> <?php echo e($supplier->supplier_website); ?></p>
              </address>
            </td>
            <td style="padding: 8px; width: 30%;">
              <?php echo e($supplier->supplier_remark); ?>

            </td>
            <td style="padding: 8px; width: 45%;">
              <?php echo $supplier->supplier_intro; ?>

            </td>
          </tr>
        </tbody>  
      </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>