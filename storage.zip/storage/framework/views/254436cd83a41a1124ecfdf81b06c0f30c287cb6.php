<?php $__env->startSection('title', $project->project_number.' Update'); ?>
<?php $active = 'booked/project'; 
$subactive ='booking/project';
  use App\component\Content;
  $service = '';
  foreach ($project->service as $key => $sv) {
      $service .= $sv->pivot->service_id.',';
  }
  $tag_user = '';
  foreach ($project->usertag as $key => $tag) {
      $tag_user .= $tag->pivot->user_id.',';
  }
?>
<?php $__env->startSection('content'); ?>
  <div class="wrapper">
    <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content"> 
        <div class="row">
          <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="col-lg-12"><h4 class="border">Travelling Booking Form</h4></div>
          <form method="POST" action="<?php echo e(route('updateProject')); ?>">
              <?php echo e(csrf_field()); ?>

              <section class="connectedSortable">
                  <div class="col-md-9">
                    <div class="row">
                      <div class="col-md-3 col-xs-12">
                        <div class="form-group">
                          <input type="hidden" name="olduser" value="<?php echo e($project->user_id); ?>">
                          <label>Project Code<span style="color:#b12f1f;">*</span></label>
                          <input type="text" placeholder="Project Number" class="form-control" name="project_number" value="<?php echo e($project->project_number); ?>" required readonly>
                        </div> 
                      </div>       
                      <div class="col-md-3 col-xs-6">
                        <div class="form-group">
                          <label>Revise date (yyyy-mm-dd)</label> 
                          <input type="text" placeholder="2018-04-26" class="form-control book_date" name="revise_date" value="<?php echo e(isset($project->project_revise) ? $project->project_revise : date('Y-m-d')); ?>" required/>
                        </div> 
                      </div> 
                      <div class="col-md-3 col-xs-6">
                        <div class="form-group">
                          <label>Pax Number <span style="color:#b12f1f;">*</span></label> 
                          <input type="text" placeholder="Pax Number" class="form-control" name="pax_num" required value="<?php echo e(isset($project->project_pax) ? $project->project_pax : old('pax_num')); ?>" />
                        </div> 
                      </div>
                      <div class="col-md-3 col-xs-6">
                        <div class="form-group">
                          <label>Client Name <span style="color:#b12f1f;">*</span></label> 
                          <input type="text" class="form-control" name="client_name" placeholder="Jonh Smit" required value="<?php echo e(isset($project->project_client) ? $project->project_client : old('client_name')); ?>"/>
                        </div> 
                      </div>
                      <div class="col-md-3 col-xs-6">
                        <div class="form-group">
                          <label>File Number</label> 
                          <input type="text" class="form-control" name="fileno" placeholder="File Number" value="<?php echo e(isset($project->project_fileno) ? $project->project_fileno : old('fileno')); ?>" />
                        </div> 
                      </div>
                      <div class="col-md-3 col-xs-6">
                        <div class="form-group">
                          <label>Exchange Rate</label> 
                          <input type="text" class="form-control" name="ex_rate" placeholder="Exchange Rate" value="<?php echo e(isset($project->project_ex_rate) ? $project->project_ex_rate : old('ex_rate')); ?>" />
                        </div> 
                      </div>

                      <div class="col-md-3 col-xs-6">
                        <div class="form-group">
                          <label>Margin</label> 
                          <input type="text" class="form-control" name="margin_rate" placeholder="Margin Rate" value="<?php echo e(isset($project->margin_rate) ? $project->margin_rate : old('margin_rate')); ?>" />
                        </div> 
                      </div>
                      <div class="col-md-3 col-xs-6">
                        <div class="form-group">
                          <label>Selling Rate</label> 
                          <input type="text" class="form-control" name="sell_rate" placeholder="Selling Rate" value="<?php echo e(isset($project->project_selling_rate) ? $project->project_selling_rate : old('sell_rate')); ?>" />
                        </div> 
                      </div>
                      <div class="col-md-3 col-xs-6">
                        <div class="form-group">
                          <label>Additional Invoice</label> 
                          <input type="text" class="form-control" name="add_invoice" placeholder="Additional Invoice" value="<?php echo e(isset($project->project_add_invoice) ? $project->project_add_invoice : old('add_invoice')); ?>" />
                        </div> 
                      </div>
                      <div class="col-md-3 col-xs-6">
                        <div class="form-group">
                          <label>Credit Note</label> 
                          <input type="text" class="form-control" name="cnote_invoice" placeholder="Credits Note" value="<?php echo e(isset($project->project_cnote_invoice) ? $project->project_cnote_invoice : old('cnote_invoice')); ?>" />
                        </div> 
                      </div>
                      <div class="col-md-3 col-xs-6">
                        <div class="form-group">
                          <label>Invoice Number</label> 
                          <input type="text" class="form-control" name="invoice_num" placeholder="Invoice Number" value="<?php echo e(isset($project->project_invoice_number) ? $project->project_invoice_number : old('invoice_num')); ?>" />
                        </div> 
                      </div>
                      <div class="col-md-3 col-xs-6">
                        <div class="form-group">
                          <label>Start Date<span style="color:#b12f1f;">*</span></label> 
                          <input type="text" id="from_date" class="form-control" name="start_date" placeholder="2018-04-24" required  value="<?php echo e(isset($project->project_start) ? $project->project_start : old('start_date')); ?>" />
                        </div> 
                      </div>
                      <div class="col-md-3 col-xs-6">
                        <div class="form-group">
                          <label>End Date<span style="color:#b12f1f;">*</span></label>
                          <input type="text" id="to_date" class="form-control" name="end_date" placeholder="2019-04-24" required value="<?php echo e(isset($project->project_end) ? $project->project_end : old('end_date')); ?>" >
                        </div> 
                      </div>
                      <div class="col-md-3 col-xs-6">
                        <div class="form-group">
                          <label>Departure Time</label> 
                          <select class="form-control" name="dep_time" >
                              <option value="">--Select--</option>
                            <?php $__currentLoopData = App\FlightSchedule::where('flight_status',1)->orderBy('flightno', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($fy->id); ?>" <?php echo e($fy->id == $project->project_dep_time ? 'selected':''); ?>><?php echo e($fy->flightno); ?> - D:<?php echo e($fy->dep_time); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div> 
                      </div>
                      <div class="col-md-3 col-xs-6">
                        <div class="form-group">
                          <label>Arrival Time</label> 
                          <select class="form-control" name="arr_time" >
                            <option value="">--Select--</option>
                            <?php $__currentLoopData = App\FlightSchedule::where('flight_status',1)->orderBy('flightno', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($fy->id); ?>" <?php echo e($fy->id == $project->project_arr_time ?   'selected':''); ?>><?php echo e($fy->flightno); ?> - A:<?php echo e($fy->arr_time); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div> 
                      </div>
                      <div class="col-md-3 col-xs-6">
                        <div class="form-group">
                          <label>Agent<span style="color:#b12f1f;">*</span></label> 
                          <select class="form-control" name="agent" required="" >
                            <option value="">Agent</option>
                            <?php $__currentLoopData = App\Supplier::where(['business_id'=>9, 'supplier_status'=>1])->orderBy('supplier_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($agent->id); ?>"  <?php echo e($agent->id == (isset($project->supplier_id) ?$project->supplier_id:'') ? 'selected':''); ?>><?php echo e($agent->supplier_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div> 
                      </div>                    
                      <div class="col-md-3 col-xs-12">
                        <div class="form-group">
                          <label>Location</label>
                          <select  class="form-control" name="location">
                            <?php $__currentLoopData = App\Country::where('country_status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($con->id); ?>" <?php echo e(isset($project->country_id) ? ($project->country_id == $con->id? 'selected':''):''); ?>><?php echo e($con->country_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                      <div class="col-md-3 col-xs-6">
                        <div class="form-group">
                          <label>Reference</label> 
                          <input class="form-control" type="text" placeholder="Reference" name="reference" value="<?php echo e(isset($project->project_book_ref) ? $project->project_book_ref : old('reference')); ?>" >
                        </div> 
                      </div>
                      <div class="col-md-3 col-xs-6">
                        <div class="form-group">
                          <label>Travel Consultant</label> 
                          <input class="form-control" type="text" placeholder="Travel Consultant" name="consultant" value="<?php echo e(isset($project->project_book_consultant) ? $project->project_book_consultant : old('consultant')); ?>">
                        </div> 
                      </div>    
                      <div class="col-md-12 col-xs-6">
                        <div class="form-group">
                          <label>Description</label>
                          <textarea class="form-control " name="pro_desc" rows="6" placeholder="Enter Here ..."><?php echo e(isset($project->project_desc) ? $project->project_desc : old('pro_desc')); ?></textarea>   
                        </div>
                      </div>
                      <div class="col-md-6 col-xs-6">
                        <div class="form-group">
                          <label>Hightlights</label>
                          <script src="<?php echo e(asset('adminlte/editor/tinymce.min.js')); ?>"></script>
                          <textarea class="form-control my-editor" name="pro_hightlight" rows="6" placeholder="Enter Here..."> <?php echo e(isset($project->project_hight) ? $project->project_hight : old('pro_hightlight')); ?></textarea>            
                        </div>
                      </div>
                      <div class="col-md-6 col-xs-6">
                        <div class="form-group">
                          <label>Additional Descriptions</label>
                          <textarea class="form-control " name="pro_add_desc" rows="6" placeholder="Enter Here..."><?php echo e(isset($project->project_add_desc) ? $project->project_add_desc : old('pro_add_desc')); ?></textarea>            
                        </div>
                      </div>
                      <div class="col-md-6 col-xs-6">
                        <div class="form-group">
                          <label>Credit Note Descriptions</label>
                          <textarea class="form-control" name="pro_note_desc" rows="6" placeholder="Enter Here..." ><?php echo e(isset($project->project_note_desc) ? $project->project_note_desc : old('pro_note_desc')); ?></textarea>
                        </div>
                      </div>
                      <div class="col-md-6 col-xs-6">
                        <div class="form-group">
                          <label>Remarks</label>
                          <textarea class="form-control" name="pro_note" rows="6" placeholder="Included/Excluded" ><?php echo e(isset($project->project_note) ? $project->project_note : old('pro_note')); ?></textarea>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-3">
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="form-group">
                            <div><label>Option Choice</label>&nbsp;</div>
                            <label style="font-weight:400;"> 
                              <input type="radio" name="option" value="1" <?php echo e($project->project_option==1?'checked':''); ?> >
                              <span style="position: relative;top:-2px;" >Invoice</span>
                            </label>&nbsp;&nbsp;
                            <label style="font-weight: 400;">
                                <input type="radio" name="option" value="0" <?php echo e($project->project_option==0?'checked':''); ?>>
                                <span style="position: relative;top:-2px;">Quotation</span>
                            </label>
                          </div> 
                      </div>
                    </div>
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="form-group">
                            <div><label>Project Status</label>&nbsp;</div>
                            <label style="font-weight:400;"> 
                              <input type="radio" name="project_check" value="1" <?php echo e($project->project_check==1?'checked':''); ?>>
                              <span style="position: relative;top:-2px;">Already Check</span>
                            </label>&nbsp;&nbsp;
                            <label style="font-weight: 400;">
                                <input type="radio" name="project_check" value="0" <?php echo e($project->project_check==0?'checked':''); ?>>
                                <span style="position: relative;top:-2px;">Not yet check</span>
                            </label>
                          </div> 
                      </div>
                    </div>
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group">
                              <div><label>Project Prefix</label>&nbsp;</div>
                              <label style="font-weight:400;"> 
                                <input type="radio" name="project_prefix" value="AE" <?php echo e($project->project_prefix == 'AE'?'checked':''); ?>>
                                <span style="position: relative;top:-2px;">AE</span>
                              </label>&nbsp;&nbsp;
                              <label style="font-weight: 400;">
                                  <input type="radio" name="project_prefix" value="AM" <?php echo e($project->project_prefix=='AM'?'checked':''); ?>>
                                  <span style="position: relative;top:-2px;">AM</span>
                              </label> 
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="form-group">
                              <div><label>Prefix</label>&nbsp;</div>
                              <label style="font-weight:400;"> 
                                <input type="radio" name="prefix" value="Main" <?php echo e($project->project_main_status=='Main'?'checked':''); ?>>
                                <span style="position: relative;top:-2px;">Main</span>
                              </label>&nbsp;&nbsp;
                              <label style="font-weight: 400;">
                                  <input type="radio" name="prefix" value="Sub" <?php echo e($project->project_main_status=='Sub'?'checked':''); ?>>
                                  <span style="position: relative;top:-2px;">Sub</span>
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="btn-group" style="display: block;">
                          <button type="button" class="form-control" data-toggle="dropdown" aria-haspopup="false" aria-expanded="false" data-backdrop="static" data-keyboard="false" role="dialog" data-backdrop="static" data-keyboard="false" >
                           <span class="pull-left"><i class="fa fa-user-plus" style="color: #5aabf1;"></i> User Tags</span><span class="pull-right"><i class="caret"></i></span>
                          </button>  
                          <div class="obs-wrapper-search">
                            <ul class="dropdown-data" style="width: 100%;" id="Show_date">
                              <?php $__currentLoopData = App\User::where('banned',0)->orderBy('fullname', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li <?php echo e(in_array($user->id, [Auth::user()->id])? "style=display:none":""); ?>>
                                <div class="checkbox">
                                  <input id="ch<?php echo e($key); ?>" style="width: 14px; height: 14px;" type="checkbox" name="usertag[]" value="<?php echo e($user->id); ?>" <?php echo e(in_array($user->id, explode(',', $tag_user)) ? 'checked':''); ?>  <?php echo e(Auth::user()->id == $user->id ? "checked":""); ?>> 
                                  <label for="ch<?php echo e($key); ?>" style="position: relative;top:3px;"><?php echo e($user->fullname); ?> <small>(<?php echo e(isset($user->role->name) ? $user->role->name : ''); ?>)</small></label>
                                </div>
                              </li>                           
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <div class="clearfix"></div>
                            </ul>
                          </div>
                        </div>
                      </div>                  
                    </div>
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <label>Payment Optoin</label>
                        <?php $__currentLoopData = App\Bank::orderBy('name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$bk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div>                        
                            <label style="font-weight:400;">
                              <input type="radio" name="bank" value="<?php echo e($bk->id); ?>" <?php echo e($bk->id == $project->project_bank ?'checked':''); ?>> 
                              <span style="position: relative;top:-2px"><?php echo e($bk->name); ?></span>
                            </label>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                    </div>
                  
                    <div class="col-md-12 text-center">
                      <div class="form-group">
                        <button type="submit" class="btn btn-success btn-flat btn-sm">Comfirm Booking</button>&nbsp;
                        <a href="<?php echo e(route('projectList', ['url'=> 'project'])); ?>" class="btn btn-danger btn-sm ">Back</a>
                      </div>
                    </div>               
                  </div>
                  <div style="margin-bottom: 30px;"></div>
              </section>
          </form>
        </div>
      </section>
    </div>  
  </div>
  <?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.editor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>