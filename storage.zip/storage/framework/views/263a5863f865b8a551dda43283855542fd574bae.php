<?php $__env->startSection('title', 'Flight Schedule'); ?>
<?php $active = 'supplier/flights'; 
  $subactive = 'supplier/flights';
  use App\component\Content;
?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <section class="col-lg-12 connectedSortable">
              <h3 class="border"> <i class="fa fa-plane"></i> <?php echo e($agent->supplier_name); ?> Ticketing Agent <span class="fa fa-angle-double-right"></span> <a href="<?php echo e(route('createFlightSchedule')); ?>" class="btn btn-default btn-sm">New Schedule </a></h3>
              <form method="GET" action="<?php echo e(route('upscheduleprice')); ?>">
              <?php echo e(csrf_field()); ?>

              <table class="table table-hover table-striped datatable" id="hotel-rate">
                <thead>
                  <tr>
                    <th>Number</th>
                    <th>Dep & Arr Time</th>
                    <th class="text-center">From <i class="fa fa-long-arrow-right"></i> To</th>
                    <th>Airline</th>
                    <th class="text-center" title="Oneway <?php echo e(Content::currency()); ?>">Oneway</th>
                    <th class="text-center" title="Return <?php echo e(Content::currency()); ?>">Return </th>
                    <th class="text-center" title="Oneway Net <?php echo e(Content::currency()); ?>">OnewayNet</th>
                    <th class="text-center" title="Return Net <?php echo e(Content::currency()); ?>">ReturnNet</th>
                    <th class="text-center" title="Oneway <?php echo e(Content::currency(1)); ?>">Oneway<?php echo e(Content::currency(1)); ?></th>
                    <th class="text-center" title="Oneway <?php echo e(Content::currency(1)); ?>">Return<?php echo e(Content::currency(1)); ?></th>
                    <th class="text-center">Action</th> 
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $schedulesNo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <input type="hidden" name="eid" name="eid" value="<?php echo e($schedule->id); ?>">
                  <tr>                      
                    <td><?php echo e($schedule->flightno); ?></td>
                    <td class="text-center"><span style="color: #dbb20c;"><?php echo e($schedule->dep_time); ?></span> <i class="fa fa-fighter-jet"></i> <span style="color: #dbb20c;"><?php echo e($schedule->arr_time); ?></span></td>
                    <td class="text-center"><?php echo e($schedule->flight_from); ?> <i class="fa fa-long-arrow-right"></i> <?php echo e($schedule->flight_to); ?></td>   
                    <?php 
                      $airline = App\Supplier::find($schedule->supplier_id);
                    ?>
                    <td><?php echo e(isset($airline->supplier_name) ? $airline->supplier_name : ''); ?></td>                  
                    <td><input type="text" name="oneway_price" value="<?php echo e($schedule->oneway_price); ?>" class="oneway_price number_only form-control input-sm text-center" style="width: 85px;" title="Double click to enter price "></td>
                    <td><input type="text" name="return_price" value="<?php echo e($schedule->return_price); ?>" class="return_price number_only form-control input-sm text-center" style="width: 85px;" title="Double click to enter price "></td>
                    <td><input type="text" name="oneway_nprice" value="<?php echo e($schedule->oneway_nprice); ?>" class="oneway_nprice number_only form-control input-sm text-center" style="width: 85px;" title="Double click to enter price "></td>
                    <td><input type="text" name="return_nprice" value="<?php echo e($schedule->return_nprice); ?>" class="return_nprice number_only form-control input-sm text-center" style="width: 85px;" title="Double click to enter price "></td>
                    <td><input type="text" name="oneway_kprice" value="<?php echo e($schedule->oneway_kprice); ?>" class="oneway_kprice number_only form-control input-sm text-center" style="width: 85px;" title="Double click to enter price "></td>
                    <td><input type="text" name="return_kprice" value="<?php echo e($schedule->return_kprice); ?>" class="return_kprice number_only form-control input-sm text-center" style="width: 85px;" title="Double click to enter price "></td>
                    <td class="text-center">                    
                      <button type="submit" class="btnSaveFlight btn btn-flat btn-success btn-sm" data-id="<?php echo e($schedule->id); ?>" data-url="<?php echo e(route('upscheduleprice')); ?>">Save</button>
                    </td>                     
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table> 
            </form>   
              <?php if($schedulesNo->count() > 0): ?>
                <div class="form-group text-center">
                  <a href="<?php echo e(route('getFlightSchedule')); ?>" class="btn btn-primary btn btn-flat btn-md">Back</a>                 
                </div>    
              <?php endif; ?>                       
          </section>
        </div>
    </section>
  </div>  
</div>
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>