<?php $__env->startSection('title', 'Apply Price For'. $subhotel->supplier_name); ?>
<?php $active = 'supplier/hotels'; 
  $subactive ='hotel/hotelroom';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
            <section class="col-lg-12 connectedSortable">
                <h3 class="border">Assign Room Type for <b><?php echo e($subhotel->supplier_name); ?> Hotel</b></h3>
                <form method="POST" action="<?php echo e(route('getRoomApplyNow')); ?>">
                  <?php echo e(csrf_field()); ?>

                  <table class="table table-hover table-striped" id="applyroom">
                    <thead>
                      <tr>                     
                        <th width="100">Hotel Name</th>
                        <th colspan="4">
                          <select class="form-control filterHotel" name="hotel">
                            <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($hotel->id); ?>" <?php echo e($hotelId == $hotel->id ? 'selected':''); ?>><?php echo e($hotel->supplier_name); ?></option>      
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                  
                          </select>
                        </th>
                        <th width="100" class="text-center">
                          <input type="submit" name="btnApply" value="Apply Now" class="btn btn-success btn-flat btn-sm">
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $roomApply->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomchunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td></td>
                          <?php $__currentLoopData = $roomchunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><label style="margin-bottom: 0px; font-weight: 400; cursor: pointer;">
                              <span style="display: <?php echo e(in_array($room->id, explode(',', $roomId)) ? 'block':'none'); ?>;" class="fa fa-check-square check"></span>
                              <span style="display: <?php echo e(in_array($room->id, explode(',', $roomId)) ? 'none':'block'); ?>" class="fa fa-square-o nocheck"></span>
                              <input type="checkbox" class="checkRoom" name="roomId[]" value="<?php echo e($room->id); ?>" <?php echo e(in_array($room->id, explode(',', $roomId)) ? 'checked':''); ?>> 
                              <span style="position:relative;left:20px; top:1px;"><?php echo e($room->name); ?></span></label></td>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <td></td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>                
                </form>
            </section>
        </div>
    </section>
  </div>  
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>