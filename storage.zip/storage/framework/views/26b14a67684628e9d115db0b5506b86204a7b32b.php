<?php $__env->startSection('title', 'Booked Golf List'); ?>
<?php $active = 'booked/project'; 
$subactive ='booked/golf';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <form method="POST" action="<?php echo e(route('searchProject', ['project'=> 'golf'])); ?>">
        <?php echo e(csrf_field()); ?>

        <section class="col-lg-12 connectedSortable">
            <h3 class="border">Booked Golf List</h3>
            <?php echo $__env->make('admin.project.Search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <table class="datatable table table-hover table-striped">
              <thead>
                <tr>                       
                  <th width="65">Project No.</th>
                  <th>Date</th>
                  <th>Country</th>
                  <th>City</th>
                  <th>Golf</th>
                  <th>Service</th>
                  <th>User</th>
                  <th class="text-center">Pax No.</th>
                  <th class="text-center">Price</th>
                  <th class="text-center">Amount</th>
                  <th class="text-center" style="width:8%;">Status</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $golf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php 
                    $golfb = \App\Supplier::find($golf->golf_id);
                    $gmenub = \App\GolfMenu::find($golf->program_id);
                    $conb = \App\Country::find($golf->country_id);
                    $prob = \App\Province::find($golf->province_id);
                    $user = App\User::find($golf->book_userId);
                  ?>
                <tr>
                  <td class="studentId" width="75"><?php echo e($golf->book_project); ?></td>
                  <td><?php echo e(Content::dateformat($golf->book_checkin)); ?></td>
                  <td><?php echo e(isset($conb->country_name) ? $conb->country_name : ''); ?></td>
                  <td><?php echo e(isset($prob->province_name) ? $prob->province_name : ''); ?></td>
                  <td><?php echo e(isset($golfb->supplier_name) ? $golfb->supplier_name : ''); ?></td>
                  <td><?php echo e(isset($gmenub->name) ? $gmenub->name : ''); ?></td>
                  <td><?php echo e($user->fullname); ?></td>
                  <td class="text-center"><?php echo e($golf->book_pax); ?></td>
                  <td class="text-right"><?php echo e($golf->book_price); ?></td>
                  <td class="text-right"><?php echo e($golf->book_amount); ?></td>
                  <td class="text-center">
                    <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$golf->book_project, 'type'=>'details'])); ?>" title="Program Details">
                      <label class="icon-list ic_ops_program"></label>
                    </a>&nbsp;
                    <a target="_blank" href="<?php echo e(route('bookingEdit', ['url'=>'golf', 'id'=> $golf->book_id])); ?>" title="Edit hotel">
                      <label class="icon-list ic_edit"></label>
                    </a>&nbsp;
                    <!-- <a href="javascript:void(0)" class="RemoveHotelRate" data-type="book_golf" data-id="<?php echo e($golf->book_id); ?>" title="Delete this booking">
                      <label class="icon-list ic_remove"></label>
                    </a>  -->       
                    <?php echo Content::DelUserRole("Delete this Hotel Booked ?", "book_golf", $golf->book_id, $golf->user_id ); ?>               
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <!-- <div class="pull-left">Check All</div> -->
        </section>
      </form>
      <div class="clearfix"></div>
    </section>
  </div>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>