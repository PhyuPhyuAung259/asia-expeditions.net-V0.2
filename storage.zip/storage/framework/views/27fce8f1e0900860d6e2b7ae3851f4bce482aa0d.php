<?php $__env->startSection('title', config('app.title')); ?>
<?php $active = 'student'; ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
            <section class="col-lg-12 connectedSortable">
              <table class="datatable table table-hover table-striped">
                <thead>
                  <tr>
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <th>Gender</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Options</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="studentId"><?php echo e($student->student_id_card); ?></td>
                    <td><?php echo e($student->student_name_en); ?></td>
                    <td><?php echo e($student->gender); ?></td>
                    <td><?php echo e($student->email); ?></td>
                    <td><?php echo e($student->phone); ?></td>
                    <td>
                      <a href="#Edit Student" title="Edit Info <?php echo e($student->student_name_en); ?>">
                        <img src="#" class="icon ic_e_drop">
                      </a>
                      <a href="#Edit Student" title="Assign Classroom for <?php echo e($student->student_name_en); ?>">
                        <img src="#" class="icon ic_add_sub">
                      </a>
                      <a href="#Edit Student" title="Check Attendance for <?php echo e($student->student_name_en); ?>">
                        <img src="#" class="icon ic_att">
                      </a>
                      <a href="#Edit Student" title="View Times for <?php echo e($student->student_name_en); ?>">
                        <img src="#" class="icon ic_time">
                      </a>
                      <a href="#Edit Student" title="Check Score for <?php echo e($student->student_name_en); ?>">
                        <img src="#" class="icon ic_score">
                      </a>
                      <a href="#Edit Student" title="View Teacher <?php echo e($student->student_name_en); ?>">
                        <img src="#" class="icon ic_teacher">
                      </a> 
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </section>
        </div>
    </section>
  </div>
  <?php echo $__env->make('admin.include.control', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>