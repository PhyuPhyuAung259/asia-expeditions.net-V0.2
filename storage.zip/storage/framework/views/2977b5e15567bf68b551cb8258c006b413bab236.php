<tr>
	<td colspan="5"><br>
		<address>
			<p><b>Hotel Name :</b> <?php echo e($supplier->supplier_name); ?><br>
			<b>P/H :</b> <?php echo e($supplier->supplier_phone); ?>/<?php echo e($supplier->supplier_phone2); ?><br>
			<b>Email :</b> <?php echo e($supplier->supplier_email); ?><br>
			<b>Address :</b> <?php echo e($supplier->supplier_address); ?><br>
			<b>Website :</b> <?php echo e($supplier->supplier_website); ?></p>
		</address>
	</td>
	<td colspan="5"><br>
		<?php echo $supplier->remak; ?>		
	</td>
</tr>