<?php $__env->startSection('title', 'Bank Info'); ?>
<?php 
  $active = 'setting-options'; 
  $subactive ='bank';
  use App\component\Content;
  $countryId = Auth::user()->country_id ? Auth::user()->country_id : 0;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <div class="row">
        <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="col-lg-12"><h3 class="border text-center">Bank Infomation</h3></div>
        <form method="POST" action="<?php echo e(route('addBankInfo')); ?>" enctype="multipart/form-data"> 
          <?php echo e(csrf_field()); ?>

          <section class="col-lg-8 col-lg-offset-2">
            <input type="hidden" name="ebank_id" value="<?php echo e(isset($bank->id) ? $bank->id : ''); ?>">
            <div class="col-md-12 col-xs-12">
              <div class="form-group <?php echo e($errors->has('title')?'has-error has-feedback':''); ?>">
                <label>Bank Name<span style="color:#b12f1f;">*</span></label> 
                <input type="text" class="form-control" name="name" placeholder="Company Title" value="<?php echo e(isset($bank->name) ? $bank->name : ''); ?>" required=""> 
              </div> 
            </div>            
            <div class="col-md-12 col-xs-12">
              <div class="form-group <?php echo e($errors->has('desc')?'has-error has-feedback':''); ?>">
                <label>Bank Details</label> 
                <script src="<?php echo e(asset('adminlte/editor/tinymce.min.js')); ?>"></script>
               <textarea class="form-control my-editor" name="details" rows="8" placeholder="Enter ..."><?php echo isset($bank->details) ? $bank->details : ''; ?></textarea>
              </div> 
            </div>
            <div class="col-md-6 col-xs-6">
              <div class="form-group">
                <?php 
                  if (isset($bank->status) && $bank->status == 1 ) {
                      $check = "checked";
                      $uncheck = "";
                  }else{
                    $check = "";
                    $uncheck = "checked";
                  }

                 ?>
                <label>Status</label>&nbsp;
                <label style="font-weight:400;"> <input type="radio" name="status" value="1" <?php echo e($check); ?>>Publish</label>&nbsp;&nbsp;
                <label style="font-weight: 400;"><input type="radio" name="status" value="0" <?php echo e($uncheck); ?>>UnPublish</label>
              </div> 
            </div>
            <div class="col-md-12 col-xs-12">
              <div class="modal-footer" style="padding: 5px 13px;">
                <button type="submit" class="btn btn-success btn-flat btn-sm" id="btnAddCompany">Publish</button>
              </div>   
            </div>                
          </section>
        </form>
      </div>
    </section>
  </div>  
</div>
<?php echo $__env->make('admin.include.editor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>