<?php 
  use App\component\Content; 
?>
<header class="fixed main-header">
    <!-- Logo -->
    <a href="<?php echo e(route('adminhome')); ?>" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><img src="<?php echo e(Auth::user()->company->logo > 0 ? Storage::url(Auth::user()->company->logo) : url('img/no-logo.png')); ?>" style="width: 50px;"></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><img src="<?php echo e(Auth::user()->company->logo > 0 ? Storage::url(Auth::user()->company->logo) : url('img/no-logo.png')); ?>" style="width: 50px;"></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button"><span class="sr-only"></span> </a>
      <h3 class="pull-left" id="name" style="text-transform: capitalize;"><?php echo e(Auth::user()->company->title); ?></h3>
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="<?php echo e(Auth::user()->picture > 0 ? Storage::url(Auth::user()->picture) : Storage::url('avata/user_icon.png')); ?>" class="user-image">
              <span class="hidden-xs"></span>
              <div class="clearfix"></div>
            </a>
            <ul class="dropdown-menu">           
              <li class="user-header">
                <img src="<?php echo e(Auth::user()->picture > 0 ? Storage::url(Auth::user()->picture) : Storage::url('avata/user_icon.png')); ?>" class="img-circle">
                <p>
                 <?php echo e(Auth::user()->fullname); ?> - <?php echo e(Auth::user()->position); ?>

                  <small>Member since <?php echo e(date('d-M-Y', strtotime(Auth::user()->created_at))); ?></small>
                </p>
              </li>
              <li class="user-footer">
                <div class="pull-left">
                  <a href="<?php echo e(route('userStore', ['id'=> Auth::user()->id])); ?>" class="btn btn-default btn-flat ">Edit Profile</a>
                </div>
                <div class="pull-right">
                  <form method="GET" action="<?php echo e(route('logOut')); ?>">
                    <?php echo e(csrf_field()); ?>                  
                    <input type="submit" name="btnSignout" value="Sign out" class="btn btn-default btn-flat " >
                  </form>
                </div>
              </li>
            </ul>
          </li>        
        </ul>
      </div>
    </nav>
</header>



