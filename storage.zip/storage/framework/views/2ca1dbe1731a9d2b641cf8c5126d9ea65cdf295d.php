<?php $__env->startSection('title', 'Passenger Manifest'); ?>
<?php 
	use App\component\Content;
	$comId = Auth::user()->company_id ? Auth::user()->company_id: 1;
	$comadd = \App\Company::find($comId);
?>
<?php $__env->startSection('content'); ?>
	<div class="container">
    <?php echo $__env->make('admin.report.headerReport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>		
		<div class="text-center"><strong class="btborder" style="text-transform:uppercase;">Passenger Manifest</strong></div>
		<table class="table">
			<tr>				
				<td style="border-top: none; vertical-align: top;">
					<?php if($clientByProject->count() > 0): ?>
						<table class="table">
							<tr>
								<th colspan="12" style="text-transform: capitalize; border: none; background: #dddddd78"><strong>
									File No. <?php echo e($project->project_prefix); ?>-<?php echo e($project->project_fileno); ?> | Group Name: <?php echo e($project->project_client); ?> | Travelling Date From: <?php echo e(Content::dateformat($project->project_start)); ?> To: <?php echo e(Content::dateformat($project->project_end)); ?>

								</strong></th>
							</tr>
							<tr>
								<th>No.</th>
								<th>Client Name</th>
								<th>Nationality</th>
								<th>Passport Number</th>
								<th>Expired Date</th>
								<th>Date Of Birth</th>
								<th>Shared With</th>
								<th>Dietary</th>
								<th>Allergies</th>
								<th>Mobile Phone</th>
								<th>Arrival Flight</th>
								<th>Departure Flight</th>
							</tr>
							<?php $n = 1; ?>
							<?php $__currentLoopData = $clientByProject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								
								<tr>
									<td><?php echo e($n++); ?></td>
									<td><?php echo e($cl->client_name); ?></td>
									<td><?php echo e(isset($cl->country->nationality) ? $cl->country->nationality : ''); ?></td>
									<td><?php echo e($cl->passport); ?></td>
									<td><?php echo e(isset($cl->expired_date) ? Content::dateformat($cl->expired_date) : ''); ?></td>
									<td><?php echo e(isset($cl->date_of_birth) ? Content::dateformat($cl->date_of_birth) : ''); ?></td>
									<td><?php echo e($cl->share_with); ?></td>
									<td><?php echo e($cl->dietary); ?></td>
									<td><?php echo e($cl->allergies); ?></td>
									<td><?php echo e($cl->phone); ?></td>
									<td>
										<?php echo e($cl->flight_arr); ?>

									</td>
									<td>
										<?php echo e($cl->flight_dep); ?>

									</td>
									
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<td style="border-top: none"><strong>Remark:</strong><div class="well"><?php echo $project->project_hight; ?></div></td>
			</tr>
			<tr>			
				<td style="border-top: none">
					Printed On <?php echo e(date("d F Y")); ?>

				</td>
			</tr>
			
		</table>		
  	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>