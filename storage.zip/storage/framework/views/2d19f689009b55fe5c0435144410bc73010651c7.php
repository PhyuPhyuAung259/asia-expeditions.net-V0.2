<?php $__env->startSection('title', 'Transportation Assignment'); ?>
<?php
  $active = 'restaurant/menu'; 
  $subactive = 'transport/service';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="content-wrapper">
	    <section class="content"> 
		    <div class="row">
		      	<?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		        <section class="col-lg-12 connectedSortable">
		          <h3 class="border" style="text-transform:capitalize;">Booking Transportation for Project No. <b><?php echo e($project->project_number); ?> </b></h3>
		            <table class="datatable table table-hover table-striped">
		              <thead>
		                <tr>
		                  <th width="70px">Start Date</th>
		                  <!-- <th width="67px">City</th> -->
		                  <th>Tour Name</th>
		                  <th>Service</th>
		                  <th>Vehicle</th>
		                  <th style="width:77px;s">Driver</th>
		                  <th>Phone</th>
		                  <th title="Meeting / PickUp Time">MT/PKTime</th>
		                  <th title="Flight Number & Time ">FlightNo./Time</th>
		                  <th style="width: 70px;">Price </th>
		                  <th style="width: 70px;">Price <?php echo e(Content::currency(1)); ?></th>
		                  <th class="text-center" style="width:75px;">Status</th>
		                </tr>
		              </thead>
		              <tbody>
		                <?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <?php 
					            $pro   = App\Province::find($tran->province_id);
					            $btran = App\BookTransport::where(['project_number'=>$tran->book_project,'book_id'=>$tran->id])->first();
					            $TranJournal = App\AccountJournal::where(['supplier_id'=>$btran['transport_id'], 'business_id'=>7,'project_number'=>$project->project_number, 'book_id'=>$tran->id, 'type'=>1, 'status'=>1])->first();
				            ?>
			                <tr>
			                  <td><?php echo e(Content::dateformat($tran->book_checkin)); ?></td>
			                  <!-- <td></td>          -->
			                  <td><?php echo e($tran->tour_name); ?> <span class="badge"><?php echo e($pro->province_name); ?></span></td>          
			                  <td><?php echo e(isset($btran->service->title) ? $btran->service->title : ''); ?></td>
			                  <td><?php echo e(isset($btran->vehicle->name) ? $btran->vehicle->name : ''); ?></td>
			                  <td><?php echo e(isset($btran->driver->driver_name) ? $btran->driver->driver_name : ''); ?></td>
			                  <td>
			                  	<?php if(isset($btran->transport->phone) || isset($btran->transport->phone2)): ?>
			                  		<?php echo e($btran->transport->phone); ?> <?php echo e($btran->transport->phone2); ?>

			                  	<?php else: ?>
			                  		<?php echo e(isset($btran->transport_phone) ? $btran->transport_phone : ''); ?>

			                  	<?php endif; ?>
			                  </td> 
			                  <td><?php echo e(isset($btran->pickup_time) ? $btran->pickup_time : ''); ?></td>
			                  <td><?php echo e(isset($btran->flightno) ? $btran->flightno : ''); ?></td>
			                  <td class="text-right"><?php echo e(isset($btran->price)?Content::money($btran->price):''); ?></td>
			                  <td class="text-right"><?php echo e(isset($btran->kprice)? Content::money($btran->kprice):''); ?></td>
			                  <td class="text-right">     
			                  	<?php if($TranJournal == Null): ?>    
				                  	<?php if(isset($btran->id)): ?>
										<span class="btn btn-acc btn-xs btnRefresh" title="Clear this service" data-type="clear-transport" data-id="<?php echo e(isset($btran->id) ? $btran->id : ''); ?>"><i class="fa fa-refresh"></i></span>
									<?php endif; ?>      
				                    <label title="Edit Service" class="btnEditTran"   
				                    	data-label="<?php echo e($tran->tour_name); ?>" data-type="vehicle" data-restmenu="<?php echo e(isset($btran->service_id) ? $btran->service_id : ''); ?>" 
				                    	data-restname="<?php echo e(isset($btran->transport_id) ? $btran->transport_id : ''); ?>" data-vehicle="<?php echo e(isset($btran->vehicle_id) ? $btran->vehicle_id : ''); ?>" 
				                    	data-country="<?php echo e(isset($btran->country_id) ? $btran->country_id : ''); ?>" data-province="<?php echo e(isset($btran->province_id) ? $btran->province_id : ''); ?>" 
				                    	data-price="<?php echo e(isset($btran->price) ? $btran->price : ''); ?>" data-kprice="<?php echo e(isset($btran->kprice) ? $btran->kprice : ''); ?>" 
				                    	data-phone="<?php echo e(isset($btran->phone) ? $btran->phone : ''); ?>" data-id="<?php echo e($tran->id); ?>" data-toggle="modal" data-target="#myModal">
				                      <i style="font-size:17px; color: #03A9F4;" class="btn btn-xs fa fa-pencil-square-o"></i>
				                    </label>
				                <?php else: ?>
				                	<span title="Project have been posted. can't edit" style="border-radius: 50px;border: solid 1px #795548; padding: 0px 6px;">Posted</span>
			                   	<?php endif; ?> 
			                    <?php if(isset($btran->id)): ?>
								<a target="_blank" href="<?php echo e(route('getBookingVoucher', [$tran->book_project, $tran->id])); ?>" title="View Restaurant Booking">
					               	<label class="fa fa-list-alt btn btn-xs" style="font-size:17px; color: #527686;"></label>
					            </a>   
					            <?php endif; ?>
					            
			                  </td>                     
			                </tr>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		              </tbody>
		            </table>
		        </section>
		    </div>
	    </section>
	</div>
</div>

<div class="modal fade" id="myModal" role="dialog" data-backdrop="static" data-keyboard="true">
	<div class="modal-dialog modal-lg">
	    <form method="POST" action="<?php echo e(route('assignTransport')); ?>">
	      <div class="modal-content">        
	        <div class="modal-header">
	          <button type="button" class="close" data-dismiss="modal">&times;</button>
	          <h4 class="modal-title"><strong id="form_title"> Transportation Assignment</strong> <strong id="title_of_tour"></strong></h4>
	        </div>
	        <div class="modal-body">
	          <?php echo e(csrf_field()); ?>    
	          <input type="hidden" name="bookid" id="tour_id">
	          <input type="hidden" name="project_number" id="project_number" value="<?php echo e($project->project_number); ?>">
		        <div class="row">
		            <div class="col-md-4 col-xs-6">
		              <div class="form-group">
		                <label>Country <span style="color:#b12f1f;">*</span></label> 
		                <select class="form-control country" id="country" name="country" data-type="booking_transport" data-locat="driver_data"required>
		                    <option value="">--Choose--</option>
		                  <?php $__currentLoopData = App\Country::Where('country_status',1)->wherehas('transportservice')->orderBy('country_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                    <option value="<?php echo e($con->id); ?>"><?php echo e($con->country_name); ?></option>
		                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                </select>
		              </div> 
		            </div>
		            <div class="col-md-4 col-xs-6">
		              <div class="form-group">
		                <label>Transportation</label>
		               	<select class="form-control transport" name="transport"  id="dropdown-booking_transport" data-type="booking_driver">
		               		<option>--Choose--</option>
		               		<?php $__currentLoopData = App\Supplier::where(['business_id'=> 7, 'supplier_status'=>1])->orderBy('supplier_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		               		<option value="<?php echo e($sup->id); ?>" data-phone="<?php echo e($sup->supplier_phone); ?>"  data-phone2="<?php echo e($sup->supplier_phone2); ?>"><?php echo e($sup->supplier_name); ?></option>
		               		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		               	</select>
		              </div>
		            </div>
		            <div class="col-md-4 col-xs-6">
		              <div class="form-group">
		                <label>Service Name</label>
		               	<select class="form-control tran_service" name="tran_name" id="dropdown-transervice" data-type="vehicle">
		               		
		               	</select>
		              </div>
		            </div>
		            <div class="col-md-4 col-xs-6">
			            <div class="form-group">
			                <label>Vehicle</label>
			               	<select class="form-control vehicle" name="vehicle" id="dropdown-vehicle">
			               	</select>
			            </div>
		            </div>
		            <div class="col-md-4 col-xs-3">
		              <div class="form-group">
		                <label>Price <?php echo e(Content::currency()); ?></label>
		                <input type="text" name="price" id="price" class="form-control editprice" placeholder="00.0" readonly>
		              </div>
		            </div>
		            <div class="col-md-4 col-xs-3">
		              <div class="form-group">
		                <label>Price <?php echo e(Content::currency(1)); ?></label>
		                <input type="text" name="kprice" id="kprice" class="form-control editprice" placeholder="00.0" readonly>
		              </div>
		            </div>       
		           
		            <div class="col-md-4 col-xs-6">
		            	<div class="form-group">
		            		<label><br></label>
		            		<input type="text" name="phone1" id="phone" class="form-control" placeholder="(+855) 123 456 789" >
		            	</div>
		            </div>
		            <div class="col-md-2 col-xs-6">
		            	<div class="form-group">
		            		<label>Driver Name</label>
		               		<select class="form-control driver_name" name="driver_name"  id="dropdown-booking_driver">
		               		</select>
		            	</div>
		            </div>
		            <div class="col-md-2 col-xs-6">
		            	<div class="form-group">
		            		<label><br></label>
		            		<input type="text" name="phone2" id="phone2" class="form-control" placeholder="(+855) 123 456 789" >
		            	</div>
		            </div>
		            <div class="col-md-2 col-xs-6">
		            	<div class="form-group">
		            		<label>Meeting/PickUpTime</label>
		               		<input type="text" name="pickup_time" id="pickup_time" class="form-control" placeholder="Meeting / Pick Up Time" >
		            	</div>
		            </div>
		            <div class="col-md-2 col-xs-6">
		            	<div class="form-group">
		            		<label>Flight No./time</label>
		               		<input type="text" name="flightno" id="flightno" class="form-control" placeholder="Flight No./time">
		            	</div>
		            </div>

		            <div class="col-md-12 col-xs-12">
		            	<div class="form-group">
		            		<label>Remarks</label>
		               		<textarea class="form-control" rows="7" name="remark" placeholder="Type Remark here..."></textarea>
		            	</div>
		            </div>
		        </div>

	        </div>
	        <div class="modal-footer">
	          <button type="submit" class="btn btn-success btn-flat btn-sm" >Save</button>
	          <a href="#" class="btn btn-danger btn-flat btn-sm" data-dismiss="modal">Close</a>
	        </div>
	      </div>      
	    </form>
	</div>
</div>
<script type="text/javascript">
  	$(document).ready(function(){
  		$(document).on("click", ".btnEditTran", function(){
  			$("#title_of_tour").text("For " + $(this).data('label'));
  		});
  		// $("#title_of_tour")$("#tour_id").val()
  		// alert("")
     $(".datatable").DataTable();
  	});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>