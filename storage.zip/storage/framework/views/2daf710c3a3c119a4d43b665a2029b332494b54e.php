<?php $__env->startSection('title', 'Create New Booking'); ?>
<?php 
$active = 'booked/project'; 
$subactive ='booking/project';
  use App\component\Content;
  if (isset($_GET['ref']) && !empty($_GET['ref'])) {
    $permission = "readonly";
    $projectEdit = '<input type="hidden" name="project_edit" value="'.$_GET['ref'].'">';
    $projectNumber = $_GET['ref'];
    $service = '';
    foreach ($project->service as $key => $sv) {
      $service .= $sv->pivot->service_id.',';
    }
    $tag_user = '';
    foreach ($project->usertag as $key => $tag) {
      $tag_user .= $tag->pivot->user_id.',';
    }
  }else{
    $service ='';
    $tag_user ='';
    $projectNumber = $projectNo;
    $permission = "";
    $projectEdit = "";
  }
?>

<?php $__env->startSection('content'); ?>
  <div class="wrapper">
    <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content"> 
        <div class="row">
          <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="col-lg-12"><h4 class="border">Travelling Booking Form</h4></div>
          <form method="POST" action="<?php echo e(route('createProject')); ?>">
            <?php echo $projectEdit; ?>

            <?php echo e(csrf_field()); ?>

            <section class="connectedSortable">
                <div class="col-md-9">
                  <div class="row">
                    <div class="col-md-2 col-xs-12" style="padding-right: 0px;">
                      <div class="form-group">
                        <label>Project<span style="color:#b12f1f;">*</span></label>
                        <input type="text" placeholder="Project Number" class="form-control" name="project_number" value="<?php echo e(isset($project->project_number) ? $project->project_number : $projectNo); ?>" required readonly>
                      </div> 
                    </div>        
                    <div class="col-md-1 col-xs-6">
                      <div class="form-group">
                        <label>PaxNo.</label> 
                        <input type="text" placeholder="Pax" class="form-control text-center" name="pax_num"  value="<?php echo e(isset($project->project_pax) ? $project->project_pax : old('pax_num')); ?>" <?php echo e($permission); ?>/>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Client Name <span style="color:#b12f1f;">*</span></label> 
                        <input type="text" class="form-control" name="client_name" placeholder="Jonh Smit" required value="<?php echo e(isset($project->project_client) ? $project->project_client : old('client_name')); ?>" <?php echo e($permission); ?>/>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Client Email</label> 
                        <input type="email" placeholder="Example@google.com" class="form-control" name="client_email" <?php echo e($permission); ?> />
                      </div> 
                    </div> 
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>File Number</label> 
                        <input type="text" class="form-control" name="fileno" placeholder="File Number" value="<?php echo e(isset($project->project_fileno) ? $project->project_fileno : old('fileno')); ?>"  <?php echo e($permission); ?>/>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Start Date<span style="color:#b12f1f;">*</span></label> 
                        <input type="text" id="from_date" class="form-control" name="start_date" placeholder="2018-04-24" required  value="<?php echo e(isset($project->project_start) ? $project->project_start : old('start_date')); ?>"  <?php echo e($permission); ?>/>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>End Date<span style="color:#b12f1f;">*</span></label>
                        <input type="text" id="to_date" class="form-control" name="end_date" placeholder="2019-04-24" required value="<?php echo e(isset($project->project_end) ? $project->project_end : old('end_date')); ?>"  <?php echo e($permission); ?>>
                      </div> 
                    </div>

                    <!--Flight Schedule Lists ------------------- -->
                    <div class="col-md-6 col-xs-6">
                      <?php 
                        $dep_id   = isset($project) ? $project['project_dep_time'] : '';
                        $dep_name = isset($project->flightDep) ? $project->flightDep['flightno']. '-' . $project->flightDep['dep_time'] : '';
                        $arr_id   = isset($project) ? $project['project_arr_time'] : '';
                        $arr_name = isset($project->flightArr) ? $project->flightArr->flightno. '-' . $project->flightArr->arr_time : '';

                      ?>
                      <?php echo $__env->make('admin.include.FlightFilter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                    <!-- -------------------- -->
 
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Agent<span style="color:#b12f1f;">*</span></label> 
                       <select class="form-control" name="agent" required="" <?php echo e($permission); ?>>
                          <option value="">Agent</option>
                          <?php $getAgent = App\Supplier::where(['business_id'=>9, 'supplier_status'=>1])->orderBy('supplier_name', 'ASC')->get(); 
                            $supId = isset($project->supplier_id) ? $project->supplier_id:'';
                          ?>
                          <?php if($getAgent->count() > 0): ?>
                            <?php $__currentLoopData = $getAgent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($agent->id); ?>" <?php echo e($agent->id == $supId ? 'selected':''); ?>><?php echo e($agent->supplier_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                        </select>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Reference</label> 
                        <input class="form-control" type="text" placeholder="Reference" name="reference" value="<?php echo e(isset($project->project_book_ref) ? $project->project_book_ref : old('reference')); ?>" <?php echo e($permission); ?>>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Travel Consultant</label> 
                        <input class="form-control" type="text" placeholder="Travel Consultant" name="consultant" value="<?php echo e(isset($project->project_book_consultant) ? $project->project_book_consultant : old('consultant')); ?>" <?php echo e($permission); ?>>
                      </div> 
                    </div>                                  
                    <div class="col-md-3 col-xs-12">
                      <div class="form-group">
                        <label>Location</label>
                        <select  class="form-control" name="location" <?php echo e($permission); ?>>
                          <?php $__currentLoopData = App\Country::where('country_status',1)->orderBy('country_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($con->id); ?>" <?php echo e(isset($project->country_id) ? ($project->country_id == $con->id? 'selected':''):''); ?>><?php echo e($con->country_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-6 col-xs-6">
                      <div class="form-group">
                        <script src="<?php echo e(asset('/adminlte/editor/tinymce.min.js')); ?>"></script>
                        <label>Hightlights</label>
                        <?php if(isset($_GET['ref'])): ?>
                          <div class="form-control" disabled <?php echo e(strlen($project->project_hight) > 0 ? 'style=height:auto;' : ""); ?>>
                            <?php echo $project->project_hight; ?>

                          </div>
                        <?php else: ?>
                          <textarea class="form-control my-editor" name="pro_hightlight" rows="6" placeholder="Enter Here..." <?php echo e($permission); ?>> 
                          <?php echo isset($project->project_hight) ? $project->project_hight : old('pro_hightlight'); ?></textarea> 
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="col-md-6 col-xs-6">
                      <div class="form-group">
                        <label>Description</label>
                        <?php if(isset($_GET['ref'])): ?>
                          <div class="form-control" disabled <?php echo e(strlen($project->project_desc) > 0 ? 'style=height:auto;' : ""); ?>>
                            <?php echo $project->project_desc; ?>

                          </div>
                        <?php else: ?>
                          <textarea class="form-control my-editor" name="pro_desc" rows="6" placeholder="Enter Here ..." <?php echo e($permission); ?>><?php echo e(isset($project->project_desc) ? $project->project_desc : old('pro_desc')); ?></textarea>  
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="col-md-6 col-xs-6">
                      <div class="form-group">
                        <label>Additional Descriptions</label>
                        <?php if(isset($_GET['ref'])): ?>
                          <div class="form-control" disabled <?php echo e(strlen($project->project_add_desc) > 0 ? 'style=height:auto;' : ""); ?>>
                            <?php echo $project->project_add_desc; ?>

                          </div>
                        <?php else: ?>
                          <textarea class="form-control my-editor" name="pro_add_desc" rows="6" placeholder="Enter Here..." <?php echo e($permission); ?>><?php echo e(isset($project->project_add_desc) ? $project->project_add_desc : old('pro_add_desc')); ?></textarea>    
                        <?php endif; ?>
                                
                      </div>
                    </div>
                    <div class="col-md-6 col-xs-6">
                      <div class="form-group">
                        <label>Credit Note Descriptions</label>
                        <?php if(isset($_GET['ref'])): ?>
                          <div class="form-control" disabled <?php echo e(strlen($project->project_note_desc) > 0 ? 'style=height:auto;' : ""); ?>>
                            <?php echo $project->project_note_desc; ?>

                          </div>
                        <?php else: ?>
                          <textarea class="form-control my-editor" name="pro_note_desc" rows="6" placeholder="Enter Here..." <?php echo e($permission); ?>><?php echo e(isset($project->project_note_desc) ? $project->project_note_desc : old('pro_note_desc')); ?></textarea>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-3"><br>
                  <div class="panel panel-default">
                    <div class="panel-body">
                      <div class="form-group">
                          <div><label>Option Choice</label>&nbsp;</div>
                          <label style="font-weight:400;"> 
                            <input type="radio" name="option" value="0" <?php echo e(isset($_GET['type']) ? "":"checked"); ?>>
                            <span style="position: relative;top:-2px;">Booking</span>
                          </label>&nbsp;&nbsp;
                          <label style="font-weight: 400;">
                              <input type="radio" name="option" value="1" <?php echo e(isset($_GET['type']) ? "checked":""); ?>>
                              <span style="position: relative;top:-2px;">Quotation</span>
                          </label>
                      </div> 
                    </div>
                  </div>
                  <div class="panel panel-default">
                    <div class="panel-body">
                      <div class="btn-group" style="display: block;">
                        <button type="button" class="form-control" data-toggle="dropdown" aria-haspopup="false" aria-expanded="false" data-backdrop="static" data-keyboard="false" role="dialog" data-backdrop="static" data-keyboard="false" <?php echo e($permission); ?>>
                         <span class="pull-left"><i class="fa fa-user-plus" style="color: #5aabf1;"></i> User Tags</span><span class="pull-right"><i class="caret"></i></span>
                        </button>  
                        <?php 
                        $getUserTage = App\User::where('banned',0)->whereNotIn('id', [Auth::user()->id])->whereHas('role')->orderBy('role_id')->get(); ?>
                        <div class="obs-wrapper-search">
                          <ul class="dropdown-data" style="width: 100%;" id="Show_date">
                            <?php $__currentLoopData = $getUserTage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li <?php echo e(in_array($user->id, [Auth::user()->id])? "style=display:none":""); ?>>
                                <label class="container-CheckBox" style="margin-bottom: 0px;"><?php echo e($user->fullname); ?>

                                  <input id="ch<?php echo e($key); ?>" type="checkbox" name="usertag[]" value="<?php echo e($user->id); ?>" <?php echo e(in_array($user->id, explode(',', $tag_user)) ? 'checked':''); ?> <?php echo e(in_array($user->id, [Auth::user()->id])? 'checked':''); ?>> 
                                  <span class="checkmark hidden-print" ></span>
                                </label>
                            </li>                           
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="clearfix"></div>
                          </ul>
                        </div>
                      </div>
                    </div>                  
                  </div>
                  <div class="panel panel-default">
                    <div class="panel-body">
                      <label>Payment Optoin</label>
                      <?php $__currentLoopData = App\Bank::orderBy('name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$bk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>                        
                          <label style="font-weight:400;">
                            <input type="radio" name="bank" value="<?php echo e($bk->id); ?>" <?php echo e($key == 0 ?'checked':''); ?>> 
                            <span style="position: relative;top:-2px"><?php echo e($bk->name); ?></span>
                          </label>
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- <div class="panel-footer">Payment Optoin</div> -->
                  </div>
                </div>
                <div class="col-md-12">
                  <table class="table" id="add_book_project">
                    <thead class="text-center">
                      <tr>
                        <th class="text-center" style="width: 25%;">Date</th>
                        <th class="text-center">Country</th>
                        <th class="text-center">City</th>
                        <th class="text-center" style="width: 22%;">Description</th>
                        <th class="text-center">Pax</th>
                        <th class="text-center">Price</th>
                        <th class="text-center">Total</th>
                        <th class="text-right" style="width: 6%;">
                          <div class="dropdown">
                            <button class="btn btn-xs btn-primary dropdown-toggle" type="button" id="menu1" data-toggle="dropdown"> Add <i class="fa fa-plus-square"></i> 
                            </button>
                            <?php $quotation = isset($_GET['type']) && $_GET['type'] == "quotation" ? "quotation" : 'hotel_quotation';  ?>
                            <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="#" class="add_row" data-type="tour" data-option="" data-url="<?php echo e(route('add_row')); ?>">Tour</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="#" class="add_row" data-type="hotel" data-option=<?php echo e($quotation); ?> data-url="<?php echo e(route('add_row')); ?>">Hotel</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="#" class="add_row" data-type="flight" data-option="" data-url="<?php echo e(route('add_row')); ?>">Flight</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="#" class="add_row" data-type="cruise" data-option=""  data-url="<?php echo e(route('add_row')); ?>">Cruise</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="#" class="add_row" data-type="golf" data-option="" data-url="<?php echo e(route('add_row')); ?>">Golf</a></li>
                            </ul>
                          </div>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr></tr>
                    </tbody>
                
                  </table>
                  <div id="LoadingRow" style="display:none; position: absolute; margin:-4% 42% 17% 45%">
                    <center><span style="font-size: 38px;" id="placeholder" class="fa fa fa-spinner fa-spin"></span></center>
                  </div> 
                </div>
                <div class="col-md-12 text-right">
                  <div class="form-group">
                    <button type="submit" class="btn btn-success btn-flat btn-sm">Comfirm Booking</button>&nbsp;
                    <span class="btn btn-danger btn-sm reset_booking">Reset Booking</span>     
                  </div>
                </div>               
                <div class="col-md-12">
                  <table class='table'>
                    <thead>
                      <tr class="text-center">
                        <td style="width: 50%;"><strong>Service Included</strong></td>
                        <td style="width: 50%;"><strong>Service Excluded</strong></td>
                      </tr>
                    </thead>
                    <tbody>
                    <?php
                    $Included=App\Service::where(['service_cat'=>1,'status'=>1])->orderBy('service_name')->get();
                    $Excluded=App\Service::where(['service_cat'=>0,'status'=>1])->orderBy('service_name')->get();
                    ?>
                    <tr> 
                      <td style="vertical-align: top;">
                        <table class="table" style="width: 100%">
                          <?php $__currentLoopData = $Included->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <?php $__currentLoopData = $roomService; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <td style="width: 50%;">
                                 <label class="container-CheckBox" style="margin-bottom: 0px;"><?php echo e($room->service_name); ?>

                                  <input type="checkbox" id="check_all" name="service[]" value="<?php echo e($room->id); ?>" <?php echo e(in_array($room->id, explode(',', $service))? 'checked':''); ?>  >
                                  <span class="checkmark hidden-print" ></span>
                                </label>
                              </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                      </td>

                      <td style="vertical-align: top;">
                        <table class="table" style="width: 100%">
                          <?php $__currentLoopData = $Excluded->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $svChunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <?php $__currentLoopData = $svChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td style="width: 50%;">
                                <label class="container-CheckBox" style="margin-bottom: 0px;"><?php echo e($room->service_name); ?>

                                  <input type="checkbox" id="check_all" name="service[]" value="<?php echo e($room->id); ?>" <?php echo e(in_array($room->id, explode(',', $service))? 'checked':''); ?>  >
                                  <span class="checkmark hidden-print" ></span>
                                </label>
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </div>
                <div style="margin-bottom: 30px;"></div>
            </section>
          </form>
        </div>
      </section>
    </div>  
  </div>


  <?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>