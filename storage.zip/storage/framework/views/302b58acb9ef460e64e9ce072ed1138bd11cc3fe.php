<?php $__env->startSection('title', 'Update User'); ?>
<?php $active = 'users'; 
$subactive ='user/register';
  use App\component\Content;
  $countryId = Auth::user()->country_id ? Auth::user()->country_id : 0;
 
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="row">          
        <div class="col-lg-12"><h3 class="border text-center">User Management</h3></div>
          <form method="POST" action="<?php echo e(route('changePermission')); ?>">
            <?php echo e(csrf_field()); ?>

            <section class="col-lg-8 col-lg-offset-2">
              <div class="card"> 
                <div class="row">
                  <input type="hidden" name="eid" value="<?php echo e($user->id); ?>">
                  <div class="col-md-3 col-xs-6">
                    <div class="form-group <?php echo e($errors->has('first_name')?'has-error has-feedback':''); ?>">
                      <label>First Name <span style="color:#b12f1f;">*</span></label> 
                      <input type="text" class="form-control" name="first_name" placeholder="Full Name" value="<?php echo e(old('first_name', $user->first_name)); ?>"> 
                    </div> 
                  </div>
                  <div class="col-md-3 col-xs-6">
                    <div class="form-group <?php echo e($errors->has('last_name')?'has-error has-feedback':''); ?>">
                      <label>Last Name <span style="color:#b12f1f;">*</span></label> 
                      <input type="text" class="form-control" name="last_name" placeholder="Full Name" value="<?php echo e(old('last_name', $user->last_name)); ?>"> 
                    </div> 
                  </div>
                  <div class="col-md-6 col-xs-6">
                    <div class="form-group <?php echo e($errors->has('username')?'has-error has-feedback':''); ?>">
                      <label>Full Name<span style="color:#b12f1f;">*</span></label> 
                      <input type="text" class="form-control"  placeholder="User Name" value="<?php echo e(old('username', $user->fullname)); ?>">
                    </div> 
                  </div>
                  <div class="col-md-6 col-xs-6">
                    <div class="form-group <?php echo e($errors->has('email')?'has-error has-feedback':''); ?>">
                      <label>Email Address<span style="color:#b12f1f;">*</span></label> 
                      <input type="email" class="form-control" value="<?php echo e(old('email', $user->email)); ?>"  readonly>
                    </div> 
                  </div>
                  <div class="col-md-6 col-xs-6">
                    <div class="form-group">
                      <label>Currently Password</label> 
                      <input type="password" class="form-control" name="old_password" value="<?php echo e(old('old_password', $user->password_text)); ?>" required>
                    </div> 
                  </div>
                  <div class="col-md-3 col-xs-6">
                    <div class="form-group <?php echo e($errors->has('password')?'has-error has-feedback':''); ?>">
                      <label>New Password</label> 
                      <input type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" placeholder="New Password">
                    </div> 
                  </div>
                  <div class="col-md-3 col-xs-6">
                    <div class="form-group <?php echo e($errors->has('con-password')?'has-error has-feedback':''); ?>">
                      <label>Confirm Password</label> 
                      <input type="password" class="form-control" name="con-password" value="<?php echo e(old('con-password')); ?>" placeholder="Confirm Password" >
                    </div> 
                  </div>
                  <div class="col-md-4 col-xs-6">
                    <div class="form-group">
                      <label>Role</label> 
                        <?php
                          if (\Auth::user()->role_id == 2 && \Auth::user()->user_type == 2) {
                            $getAllRole = \App\Role::where(['status'=>1, 'company_id'=> \Auth::user()->company_id])
                                      ->orderBy('name', "ASC")->get();
                          }else{
                            $getAllRole = \App\Role::where(['status'=>1, 'company_id'=> \Auth::user()->company_id])
                                      ->whereNotIn('id', [2])
                                      ->orderBy('name', "ASC")->get();
                          }
                        ?>             
                        <select class="form-control" name="role">
                          <?php $__currentLoopData = $getAllRole; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e(Crypt::encryptString($role->id)); ?>" <?php echo e($role->id == $user->role_id ? 'selected': ''); ?>><?php echo e($role->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>    
                    </div> 
                  </div>
                  <div class="col-md-2 col-xs-6">
                    <div class="form-group">
                      <div><label>Status</label></div>
                      <label style="font-weight:400;"> <input type="radio" name="banned" value="1" <?php echo e($user->banned==1? 'checked':''); ?>> Inactive</label>&nbsp;&nbsp;
                      <label style="font-weight:400;"> <input type="radio" name="banned" value="0" <?php echo e($user->banned==0? 'checked':''); ?>> Active</label>
                    </div> 
                  </div>
                </div>
              </div>   
              <div class="modal-footer" style="padding: 5px 13px; text-align: center;">
                <button type="submit" class="btn btn-success btn-flat btn-sm">Update Permission</button>
              </div>           
            </section>
          </form>
      </div>
    </section>
  </div>  
</div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>