<?php $__env->startSection('title', 'Company Profile'); ?>
<?php 
  $active = 'setting-options'; 
  $subactive ='company';
  use App\component\Content;
  $countryId = Auth::user()->country_id ? Auth::user()->country_id : 0;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <div class="row">
        <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="col-lg-12"><h3 class="border text-center">Company Information</h3></div>
        <form method="POST" action="<?php echo e(route('addCompany')); ?>" enctype="multipart/form-data"> 
          <?php echo e(csrf_field()); ?>

          <section class="col-lg-8 col-lg-offset-2">            
            <input type="hidden" name="company_id" value="<?php echo e(isset($cp->id) ? $cp->id : ''); ?>">
            <div class="col-md-4 col-xs-6 col-md-offset-4 text-center">
                <div id="wrap-feature-image" style="position:relative;" <?php echo isset($cp->logo) ? "class='open-img'":''; ?>>
                  <input type="hidden" name="image" id="data-img" value="<?php echo e(isset($cp->logo) ? $cp->logo : ''); ?>">
                  <img id="feature-img" src="<?php echo e(isset($cp->logo) ? Storage::url($cp->logo) : Storage::url('/avata/logo.png')); ?>" style="width:100%;margin-bottom:12px; display: <?php echo e(isset($cp->logo) ? 'block':'none'); ?>;" class="btnUploadFiles" data-type="single-img" data-toggle="modal" data-target="#myUpload">
                  <i id="removeImage" class="fa fa-remove (alias)" title="Remove picture" style="display: none;"></i>
                </div>
                <a href="#uploadfile" class="btnUploadFiles" data-type="single-img" data-toggle="modal" data-target="#myUpload">Set Feature Image</a>
            </div>
            <div class="col-md-6 col-xs-6">
              <div class="form-group <?php echo e($errors->has('title')?'has-error has-feedback':''); ?>">
                <label>Company Name<span style="color:#b12f1f;">*</span></label> 
                <input type="text" class="form-control" name="title" placeholder="Company Title" value="<?php echo e(isset($cp->title) ? $cp->title : ''); ?>" required=""> 
              </div> 
            </div>
            <div class="col-md-6 col-xs-6">
              <div class="form-group <?php echo e($errors->has('name')?'has-error has-feedback':''); ?>">
                <label>Sub Title <span style="color:#b12f1f;">*</span></label> 
                <input type="text" class="form-control" name="name" placeholder="Company Name" value="<?php echo e(isset($cp->name) ? $cp->name : ''); ?>" required="">
              </div> 
            </div>
            <div class="col-md-3 col-xs-6">
              <div class="form-group">
                <label>Country <span style="color:#b12f1f;">*</span></label> 
                <select class="form-control country" name="country" data-type="country" data-locat="data" required>
                  <?php $__currentLoopData = App\Country::where('country_status', 1)->orderBy('country_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($con->id); ?>" <?php echo e($conId == $con->id ? 'selected':''); ?>><?php echo e($con->country_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div> 
            </div>
            <div class="col-md-3 col-xs-6">
              <div class="form-group">
                <label>City <span style="color:#b12f1f;">*</span></label> 
                <select class="form-control" name="city" id="dropdown-data" required>
                  <?php $__currentLoopData = App\Province::where(['province_status'=>1, 'country_id'=> $conId])->orderBy('province_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($pro->id); ?>" <?php echo e((isset($cp->province_id)? $cp->province_id:'') == $pro->id ? 'selected':''); ?>><?php echo e($pro->province_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div> 
            </div>       
            <div class="col-md-6 col-xs-6">
              <div class="form-group">
                <label>Currency<span style="color:#b12f1f;">*</span></label> 
                <select class="form-control" name="currency" id="dropdown-data" required>
                  <?php $__currentLoopData = App\Currency::where(['status'=>1])->orderBy('title')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($pro->id); ?>"><?php echo e($pro->title); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div> 
            </div>                  
        </section>
        <section class="container">
            <div class="col-md-6 col-xs-12">
              <div class="form-group <?php echo e($errors->has('password')?'has-error has-feedback':''); ?>">
                <label>Address</label>
                 <script src="<?php echo e(asset('adminlte/editor/tinymce.min.js')); ?>"></script>
                <textarea class="form-control my-editor" name="address" rows="8" placeholder="Enter ..."><?php echo isset($cp->address) ? $cp->address : ''; ?></textarea>
              </div> 
            </div>
            <div class="col-md-6 col-xs-12">
              <div class="form-group <?php echo e($errors->has('desc')?'has-error has-feedback':''); ?>">
                <label>Description</label> 
                <textarea class="form-control my-editor" name="desc" rows="8" placeholder="Enter ..."><?php echo isset($cp->descs) ? $cp->descs : ''; ?></textarea>
              </div> 
            </div>
            <div class="col-md-6 col-xs-6">
               <?php 
                  if (isset($cp->status) && $cp->status == 1 ) {
                    $check = "checked";
                    $uncheck = "";
                  }else{
                    $check = "";
                    $uncheck = "checked";
                  }
                ?>
              <div class="form-group">
                <label>Status</label>&nbsp;
                <label style="font-weight:400;"> <input type="radio" name="status" value="1" <?php echo e($check); ?>>Publish</label>&nbsp;&nbsp;
                <label style="font-weight: 400;"> <input type="radio" name="status" value="0" <?php echo e($uncheck); ?>>UnPublish</label>
              </div> 
            </div>
            <div class="col-md-12 col-xs-12" style="text-align: center;">
              <div class="modal-footer" style="padding: 5px 13px;">
                <button type="submit" class="btn btn-success btn-flat btn-sm" id="btnAddCompany">Publish</button>
              </div>   
            </div>                
          </section>
        </form>
      </div>
    </section>
  </div>  
</div>
<?php echo $__env->make('admin.include.editor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.include.windowUpload', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>