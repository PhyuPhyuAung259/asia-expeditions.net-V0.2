<?php $__env->startSection('title', config('app.title')); ?>
<?php
  use App\component\Content;
?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">    
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
<style type="text/css">
  .addcol{color: #002aff !important; }
  .addcol1:focus{color: red !important; border-color: red !important;}
</style>
<?php $__env->startSection('content'); ?>
<div class="wrapper-login">
  <div class="col-md-4 offset-md-4" style="position: relative;">
    <center>
      <img src="<?php echo e(url('img/jnglogo.png')); ?>" style="width: 100%">
      <p><strong style="text-shadow: 0px 1px 3px #f8f9fa;font-weight: 700;">COMPLETE TOUR BOOKING SYSTEM</strong></p>
    </center>
      <?php echo $__env->make('include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="card" style="padding:12px;">  
      <form action="<?php echo e(route('doLogin')); ?>" method="POST">     
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
          <label for="phone">Email Address</label>
          <input type="email" name="email" id="eshow" class="form-control" placeholder="Email" required="required" value="<?php echo e(old('email')); ?>">
        </div>
        <div class="form-group">
          <label for="phone">Password</label>            
          <input type="password" name="password" id="password" class="form-control" placeholder="Password" required="required" value="<?php echo e(old('password')); ?>">
        </div>
        <div class="row" id="notrobot">
            <div class="col-md-4 col-sm-6 col-6">
              <div class="form-group">
              <input type="text" id="num1" class="form-control textbox_color"  disabled></div>
            </div>
            <div class="col-md-4 col-sm-6 col-6">
              <div class="form-group">
                <input type="text" id="num2" class="form-control textbox_color"  disabled >
              </div>
            </div>
            <div class="col-md-4 col-xs-12">
              <div class="form-group">
                <input type="text" name="myResult" id="myResult" class="form-control textbox_color text-center" required >
              </div>
            </div>
          </div>
        
        <div class="col-md-12 col-xs-12">
          <div class="form-group">
            <label><input type="checkbox" name="remember">Remember me ?</label>
          </div>
        </div>
        <div class="col-md-12 col-xs-12">
          <div class="form-group text-center" >
            <input type="submit" name="btnLogin" class="btn btn-info btnSubmit" value="Login">
          </div>
        </div>
      </form>   
    </div>
  </div>
</div>

<script type="text/javascript">
  $(document).ready(function(){

    var datanum1=Math.floor(Math.random() * 11)+1;
    var datanum2=Math.floor(Math.random() * 11)+1;
    $('#num1').val(datanum1);
    $('#num2').val(datanum2);
    $('#myResult').on('keyup',function(){

      var getdata=$(this).val();
      var total = datanum1 + datanum2;
      
      
      if (getdata == total) {
        $('#myResult').removeClass('addcol1');
           $('.btnSubmit').on('click',function(){
           $('#myResult').val(getdata);
        });
      }
      else{
         $('#myResult').addClass('addcol1');
         $('#myResult').attr('required', true);

         $('.btnSubmit').on('click',function(){
           $('#myResult').val('');
      
          });
      }
    });
    // $('#notrobot').css({'display':'none'});
    // $('#eshow').on('keyup', function(){
    //     var eshow= $('#eshow').val();
    //       if (eshow.length>0) {
    //         $('#notrobot').css({'display':'block'});
    //   console.log(eshow);
    //     }
    //     else{
    //        $('#notrobot').css({'display':'none'});
    //     }
    // });

  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>