<?php $__env->startSection('title', 'Banks'); ?>
<?php $active = 'setting-options';
$subactive ='bank'; 
use App\component\Content;
?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <form action="POST">
            <section class="col-lg-12 connectedSortable">
                <h3 class="border">Setting <span style=" font-size: 22px;" class="fa fa-angle-double-right"></span> <a href="<?php echo e(route('setting')); ?>">Bank</a></h3>
                <table class="datatable table table-hover table-striped">

                  <thead>
                    <tr>
                      <th>Title</th>                     
                      <th>Created at</th>
                      <th width="120px" class="text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>                     
                      <td><?php echo e($ab->title); ?></td>
                      <td><?php echo e(Content::dateformat($ab->updated_at)); ?></td>
                      <td class="text-right">
                        <a href="<?php echo e(route('settingForm', ['setId'=>$ab->id])); ?>" title="Edit Form">
                          <label style="cursor: pointer;" class="icon-list ic_edit"></label>
                        </a>         
                      </td>                     
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>                
            </section>
          </form>
        </div>
    </section>
  </div>  
  <script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>