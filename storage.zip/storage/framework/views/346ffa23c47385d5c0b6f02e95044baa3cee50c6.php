<aside class="main-sidebar">
  <section class="sidebar">
    <ul class="sidebar-menu" data-widget="tree">
      <li class="header">MAIN NAVIGATION</li>
   
      <?php if(Auth::check()): ?>
        <?php 
          $depart_id  = [];
          $roleDepart = \App\Role::find(\Auth::user()->role_id);
          // dd($roleDepart);
          if (!empty($roleDepart->department )) {
            foreach ($roleDepart->department as $key => $dep) {
              $depart_id[] = $dep->pivot->department_id;
            } 
          }
        ?>
        <?php $__currentLoopData = \App\Department::where(['status'=>1, 'type'=>2, 'status'=>1])->whereIn('id', $depart_id)->orderBy('order','ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                $getSubDepartment = \App\DepartmentMenu::getDepartment_menu($dep->id);
              ?>
            <?php if($getSubDepartment->count() > 0): ?>
              <li class="<?php echo e(Auth::user()->role_id == 3 ? '':'treeview'); ?> <?php echo e($dep->slug == $active ? 'active':''); ?>"> 
                  <a href="<?php echo e(Auth::user()->role_id == 3 ? route('finance').'/'.$dep->slug:'javascript:void(0)'); ?>">
                    <i class="<?php echo e($dep->icon); ?>" style="font-size: 15px;"></i>
                    <span><?php echo e($dep->name); ?></span>
                      <?php if($dep->role->count() > 0 || $dep->slug == "suppliers" ): ?>
                        <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
                      <?php endif; ?>     
                  </a>
                  
                  <ul class="treeview-menu">
                    <?php $__currentLoopData = $getSubDepartment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subdep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li <?php echo e($subdep->slug == $subactive ? 'class=active': ''); ?>><a <?php echo e(empty($subdep->link) ? '' : "target=_blank"); ?> href="<?php echo e(route('adminhome')); ?>/<?php echo e($subdep->slug); ?>"><i class="fa fa-circle-o"></i><?php echo e($subdep->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>      
              </li>
            <?php endif; ?>   
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </ul>
  </section>
</aside>