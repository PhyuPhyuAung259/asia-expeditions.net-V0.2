<?php $__env->startSection('title', 'Booked Hotel List'); ?>
<?php $active = 'booked/project'; 
$subactive ='booked/hotel';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <form method="POST" action="<?php echo e(route('searchProject', ['project'=> 'hotel'])); ?>">
             <?php echo e(csrf_field()); ?>

            <section class="col-lg-12 connectedSortable">
                <h3 class="border">Booked Hotel List</h3>
                <?php echo $__env->make('admin.project.Search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <table class="datatable table table-hover table-striped">
                  <thead>
                    <tr>                       
                      <th width="75">Project No.</th>
                      <th width="65">File No.</th>
                      <th width="175px">CheckIn<i class="fa fa-long-arrow-right" style="color: #72afd2"></i>CheckOut</th>
                      <th>Location</th>
                      <th>Hotel</th>
                      <th>User</th>
                      <th width="120px" class="text-center">Type</th>
                      <th class="text-center" style="width: 17%;">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php 
                          $supb = \App\Supplier::find($hotel->hotel_id);
                          $conb = \App\Country::find($hotel->country_id);
                          $prob = \App\Province::find($hotel->province_id);
                          $user = \App\User::find($hotel->book_userId);
                          $hJnl = App\AccountJournal::where(['supplier_id'=>$hotel->hotel_id, 'business_id'=>1,'project_number'=>$hotel->book_project, 'status'=>1])->first(); 
                          $project = App\Project::where('project_number', $hotel->book_project)->first();
                        ?>
                        <tr>
                          <td><?php echo e($project['project_number']); ?></td>
                          <td><?php echo e($project['project_fileno'] ? $project['project_prefix']."-".$project['project_fileno'] : ''); ?></td>
                          <td><?php echo e(Content::dateformat($hotel->book_checkin)); ?> <i class="fa fa-long-arrow-right" style="color: #72afd2"></i> <?php echo e(Content::dateformat($hotel->book_checkout)); ?></td>
                          <td><?php echo e(isset($prob->province_name) ? $prob->province_name : ''); ?></td>
                          <td><a target="_blank" href="<?php echo e(route('supplierReport' ,['reportId' => $supb->id,'type'=> 'hotels'])); ?>?type=contract"><?php echo e(isset($supb->supplier_name) ? $supb->supplier_name : ''); ?></a></td>
                          <td><?php echo e($user['fullname']); ?></td>
                          <td class="text-center">
                            <?php if($hotel->book_option == 1): ?>
                            <span class="text-danger">Quotation</span>
                            <?php else: ?>
                              <span class="text-success">Booking</span>
                            <?php endif; ?>
                          </td>
                          <td class="text-center">
                            <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$hotel->book_project, 'type'=>'details'])); ?>" title="Program Details">
                              <label class="icon-list ic_ops_program"></label>
                            </a>&nbsp;
                            <?php if($hJnl == Null): ?>
                              <a target="_blank" href="<?php echo e(route('bookingEdit', ['url'=>'hotel', 'id'=>$hotel->book_id])); ?>" title="Edit hotel">
                                <label class="icon-list ic_edit"></label>
                              </a>&nbsp;
                            <?php endif; ?>
                            <a target="_blank" href="<?php echo e(route('bapplyRoom', ['pro'=> $hotel->book_project,'hotelid'=>$hotel->hotel_id,'bookid'=> $hotel->book_id])); ?>" title="Apply room for this hotel" >
                              <i class="fa fa-hotel (alias)" style="font-size: 19px;color: #c38015;"></i>
                            </a>&nbsp;

                            <a target="_blank" href="<?php echo e(route('searchProject', ['project'=> 'hotelrate', 'textSearch'=>$hotel->book_project])); ?>" title="View Hotel Booking Rate">
                              <label class="icon-list ic_inclusion"></label>
                            </a>&nbsp;                            
                            <?php if($hJnl == Null): ?>
                                <a onclick="return confirm('Are your sure you want delete this?');" href="<?php echo e(route('RhPrice', ['hotel'=> isset($hotel->hotel_id)? $hotel->hotel_id:0 , 'book'=> $hotel->book_id, 'type'=>'hotel'])); ?>" title="Remove hotel price" >
                                  <i class="fa fa-trash" style="font-size: 19px;color: #8e877b;"></i>
                                </a>                   
                               <?php echo Content::DelUserRole("Delete this Hotel Booked ?", "book_hotel", $hotel->book_id, $hotel->user_id ); ?>   
                            <?php else: ?> 
                              <span title="Project have been posted. can't edit" style="border-radius: 50px;border: solid 1px #795548; padding: 0px 6px;  position: relative;top: -4px;">Posted</span>
                            <?php endif; ?>
                          </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
            </section>
          </form>
        </div>
    </section>
  </div>
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>