<?php $__env->startSection('title', $tour->tour_name); ?>
<?php  use App\component\Content;?>
<?php $__env->startSection('content'); ?>
	<div class="col-lg-12">
    <?php echo $__env->make('admin.report.headerReport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<h3>
			<a class="hidden-print" href="javascript:void(0)" onclick="window.print();"><span class="fa fa-print"></span></a> &nbsp;
			<a class="hidden-print" href=""><span class="fa fa-cloud-download"></span></a>
		</h3>
		<h4><strong><?php echo e($tour->tour_name); ?></strong></h4>
		<div><strong>Destination: <?php echo e(isset($tour->province->province_name) ? $tour->province->province_name : ''); ?></strong> <small><span class="fa fa-exchange"></span></small> <strong><?php echo e($tour->tour_dest); ?></strong></div>
		<strong>Itinerary</strong>
		<table class="table">
			<tbody>
				<tr>
					<td style="width: 75%; vertical-align: top;" >
						<div><strong>HightLights</strong></div>
						<p><?php echo $tour->tour_intro; ?></p>
					</td>
					<td rowspan="3" style="vertical-align: top;">
						<table class="table">
							<tr>
								<th class="text-center" style="border-top: none;">Tour Pax</th>
								<th class="text-center" style="border-top: none;">Tariff Price</th>
							</tr>							
								<?php $__currentLoopData = $tour->pricetour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pax_price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($type == "selling"): ?>
										<?php if($pax_price->sprice > 0): ?>
											<tr>
												<td class="text-center"><?php echo e($pax_price->pax_no); ?></td>
												<td class="text-center"><?php echo e(Content::money($pax_price->sprice)); ?> <span class="pcolor"><?php echo e(Content::currency()); ?></span></td>
											</tr>
										<?php endif; ?>
									<?php else: ?>
										<?php if($pax_price->tour_nprice > 0): ?>
											<tr>
												<td class="text-center"><?php echo e($pax_price->pax_no); ?></td>
												<td class="text-center"><?php echo e(Content::money($pax_price->tour_nprice)); ?><span class="pcolor"><?php echo e(Content::currency()); ?></span></td>	
											</tr>
										<?php endif; ?>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
					</td>		
				</tr>	
				<tr>
					<td style="vertical-align: top;">
						<div><strong>Description</strong></div>
						<p><?php echo $tour->tour_desc; ?></p>
					</td>
				</tr>	
				<tr>					
					<td style="vertical-align: top;">
						<div><strong>Includes</strong></div>
						<p><?php echo $tour->tour_remark; ?></p>
					</td>
				</tr>
				<tr>					
					<td style="vertical-align: top;">
						<div><strong>Tour Feasility</strong></div>
						<ul>
							<?php $__currentLoopData = $tour->tour_feasility; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($ts->service_name); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</td>
				</tr>
				<?php if($tour->tour_picture || $tour->tour_photo): ?>
				<tr>
					<?php 
					$photos = explode("|", rtrim($tour->tour_picture,'|')); ?>
					<td>
						<div class="row">
						<?php if($tour->tour_photo): ?>
						<div class="col-sm-4 col-xs-4" style="padding-right:4px;">
							<div class="form-group">
								<img src="<?php echo e(Content::urlthumbnail($tour->tour_photo, $tour->user_id)); ?>" style="width: 100%;" />
							</div>
						</div>
						<?php endif; ?>
						<?php if($tour->tour_picture != ''): ?>
							<?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($key <= 1): ?>	
									<div class="col-sm-4 col-xs-4" style="padding-right:4px;">
										<div class="form-group">
											<img src="<?php echo e(Content::urlthumbnail($pic, $tour->user_id)); ?>" style="width: 100%;" />
										</div>
									</div>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						</div>
					</td>
				</tr>
				<?php endif; ?>
			</tbody>
		</table>
  	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>