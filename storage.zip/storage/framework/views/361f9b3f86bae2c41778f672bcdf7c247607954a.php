<?php $__env->startSection('title', 'Client Arrival Report'); ?>
<?php
  $active = 'reports'; 
  $subactive = 'arrival_report';
  use App\component\Content;
  $agent_id = isset($agentid) ?  $agentid:0;
  $locat = isset($location) ? $location:0;
  $main = isset($sort_main) ? $sort_main:0;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <div class="row">
        <section class="col-lg-12 connectedSortable">
          <h3 class="border">Client Arrival Report</h3>
          <form method="POST" action="<?php echo e(route('searchArrival')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="col-sm-8 pull-right">
              <div class="col-md-2">
                <input type="hidden" name="" value="<?php echo e(isset($projectNo) ? $projectNo : ''); ?>" id="projectNum">
                <input readonly class="form-control input-sm" type="text" id="from_date" name="start_date" placeholder="From Date" value="<?php echo e(isset($startDate) ? $startDate : ''); ?>"> 
              </div>
              <div class="col-md-2" style="padding-right: 0px;">
                <input readonly class="form-control input-sm" type="text" id="to_date" name="end_date" placeholder="To Date" value="<?php echo e(isset($endDate) ? $endDate : ''); ?>"> 
              </div>
              <div class="col-md-2" style="padding-right: 0px;">
                <select class="form-control input-sm" name="agent">
                  <?php $__currentLoopData = App\Supplier::getSupplier(9)->whereNotIn('pro.project_fileno', ["","Null",0])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($agent->id); ?>" <?php echo e($agent->id == $agent_id ? 'selected':''); ?>><?php echo e($agent->supplier_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>             
              <div class="col-md-2">
                <select class="form-control input-sm" name="sort_location">
                  <option value="AE" <?php echo e($locat == 'AE' ? 'selected':''); ?>>AE</option>
                  <option value="AM" <?php echo e($locat == 'AM' ? 'selected':''); ?>>AM</option>
                </select>
              </div>
              <div class="col-md-2" style="padding: 0px;">
                <button class="btn btn-primary btn-sm" type="submit">Search</button>
              </div>          
            </div>
        
            <table class="datatable table table-hover table-striped">
              <thead>
                <tr>
                  <th width="48px">File No.</th>
                  <th>Client Name & Pax</th>
                  <th class="text-center">Status</th>
                  <th>Flight Arrival</th>
                  <th width="123px">Flight Departure</th>
                  <th width="162px">Start Date-End Date</th>
                  <th width="280px">Guide Name</th>
                  <th class="text-center">Preview</th>
                </tr>
              </thead>
              <tbody>
                <?php $toTalPax = 0; ?>
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php 
                    $guideSupplier = App\BookGuide::where(['project_number'=>$pro->project_number])->groupBy('supplier_id')->orderBy("created_at")->get(); 
                    $toTalPax = $toTalPax + $pro->project_pax;
                  ?>
                  <tr>
                    <td><?php echo e($pro->project_prefix); ?>-<?php echo e($pro->project_fileno); ?></td>
                    <td><?php echo e($pro->project_client); ?> 
                      <?php if($pro->project_pax): ?>
                        <span style="font-weight: 700; color: #3F51B5;">x <?php echo e($pro->project_pax); ?></span>
                      <?php endif; ?>
                    </td> 
                    <td class="text-center">
                      <div class="btn-group">
                        <span style="cursor: pointer;-webkit-box-shadow:none;box-shadow:none;" class=" dropdown-toggle" data-toggle="dropdown"> 
                          <i class="fa fa-circle" style="color: <?php echo e($pro->active == 1 ? '#21ef91': '#FF5722'); ?>; font-size:12px;"></i> &nbsp; <?php echo e($pro->active == 1 ? 'Active': 'Inactive'); ?>

                        &nbsp;&nbsp;<i  class="fa fa-angle-down"></i>
                        </span>
                        <ul class="dropdown-menu" style="min-width: 100%; padding: 0px;">
                          <li><a href="#" style="padding: 10px;"><i class="fa fa-circle" style="color: #21ef91;"></i>Active <?php echo $pro->active==1?'<i class="fa fa-check" style="color: #009688;font-style: italic;"></i>' : ''; ?></a></li>
                          <li><a href="#" style="padding: 10px;"><i class="fa fa-circle" style="color: #FF5722;"></i>Inactive 
                          <?php echo $pro->active==0?'<i class="fa fa-check" style="color: #009688;font-style: italic;"></i>' : ''; ?> </a> </li>
                        </ul>
                      </div>
                    </td>
                    <td>
                      <?php if(isset($pro->flightArr->flightno)): ?>
                        <?php echo e(isset($pro->flightArr->flightno) ? $pro->flightArr->flightno : ''); ?>-D:<?php echo e(isset($pro->flightArr->dep_time) ? $pro->flightArr->dep_time : ''); ?>->A:<?php echo e(isset($pro->flightArr->arr_time) ? $pro->flightArr->arr_time : ''); ?>

                      <?php endif; ?>
                    </td>   
                    <td>
                      <?php if(isset($pro->flightDep->flightno)): ?>
                        <?php echo e(isset($pro->flightDep->flightno) ? $pro->flightDep->flightno : ''); ?>-D:<?php echo e(isset($pro->flightDep->dep_time) ? $pro->flightDep->dep_time : ''); ?>->A:<?php echo e(isset($pro->flightDep->arr_time) ? $pro->flightDep->arr_time : ''); ?>

                      <?php endif; ?>
                    </td>          

                    <td>
                      <?php echo e(Content::dateformat($pro->project_start)); ?> - <?php echo e(Content::dateformat($pro->project_end)); ?>

                    </td>
                    <td>
                      <?php if($guideSupplier->count() > 0): ?>
                        <?php $__currentLoopData = $guideSupplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($sup->supplier): ?>
                            <span style="margin: 0px 2px; border: solid 1px #9e9e9ea1;padding: 0px 3px;border-radius: 3px;"><?php echo e(isset($sup->supplier->supplier_name) ? $sup->supplier->supplier_name : ''); ?> <span style="color: #034ea2;"><?php echo e(isset($sup->province->province_name) ? $sup->province->province_name : ''); ?>,</span></span>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                    </td>
                    <!-- <td><span style="text-transform: capitalize;"></span></td> -->
                    <td class="text-right">                      
                      <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$pro->project_number, 'type'=>'operation'])); ?>" title="Operation Program">
                        <label style="cursor: pointer;" class="icon-list ic_ops_program"></label>
                      </a>
                      <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$pro->project_number, 'type'=>'sales'])); ?>" title="Prview Details">
                        <label style="cursor: pointer;" class="icon-list ic_del_drop"></label>
                      </a>     
                    </td>                     
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <tfoot>
                  <tr><th colspan="8" class="text-right"><h3>Total Number of Pax: <?php echo e($toTalPax); ?></h3></th></tr>
              </tfoot>
            </table>
          </form>
        </section>
      </div>
    </section>
  </div>
</div>
<script type="text/javascript">
  $(document).ready(function(){
    $(".datatable").DataTable({
      language: {
        searchPlaceholder: "Number No., File No.",
      }
    });
  });
</script>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>