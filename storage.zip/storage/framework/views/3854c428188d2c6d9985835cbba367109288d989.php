<tr>
	<td colspan="5"><br>
		<address>
			<p><b style="text-transform: capitalize;"><?php echo e($type); ?> Name :</b> <?php echo e($supplier->supplier_name); ?><br>
			<b>P/H :</b> <?php echo e($supplier->supplier_phone); ?>/<?php echo e($supplier->supplier_phone2); ?><br>
			<b>Email :</b> <?php echo e($supplier->supplier_email); ?><br>
			<b>Address :</b> <?php echo e($supplier->supplier_address); ?><br>
			<b>Website :</b> <?php echo e($supplier->supplier_website); ?></p>
		</address>
	</td>
	<?php $getClient = \App\Admin\Photo::where(['supplier_id'=> $supplier->id])->get(); ?>
	<?php if($getClient->count() > 0): ?>
		<td colspan="6">
			<div><strong>Hotel Contract</strong></div>
			<?php  $pdfPolicies = explode('/', rtrim($supplier->supplier_contract, "/")); ?>				
			<ul>
				<?php $__currentLoopData = $getClient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><a target="_blank" href="<?php echo e(asset('storage/contract/hotels')); ?>/<?php echo e($val->name); ?>"><?php echo e($val->original_name); ?></a></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</td>
	<?php endif; ?>
	<td colspan="5"><br>
		<?php echo $supplier->remak; ?>		
	</td>
</tr>