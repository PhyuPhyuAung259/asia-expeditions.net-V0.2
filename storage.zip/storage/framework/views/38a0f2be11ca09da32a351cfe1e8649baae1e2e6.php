<?php $__env->startSection('title', 'Guide Assignment'); ?>
<?php
  $active = 'restaurant/menu'; 
  $subactive = 'transport/service';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="content-wrapper">
	    <section class="content"> 
		    <div class="row">
		      	<?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		        <section class="col-lg-12 connectedSortable">
		          <h3 class="border" style="text-transform:capitalize;">Booking Guide for Project No. <b><?php echo e($project->project_number); ?> </b></h3>
		            <table class="datatable table table-hover table-striped">
		              <thead>
		                <tr>
		                  <th width="60px">StartDate</th>
		                  <th style="width: 9%;">City</th>
		                  <th>Tour</th>
		                  <th>Service</th>
		                  <th>GuideName</th>
		                  <th>GuidePhone</th>
		                  <th>Language</th>
		                  <th style="width: 70px;">Price <?php echo e(Content::currency()); ?></th>
		                  <th style="width: 70px;">Price <?php echo e(Content::currency(1)); ?></th>
		                  <th class="text-center">Status</th>
		                </tr>
		              </thead>
		              <tbody>
		                <?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			            <?php
			            $pro = App\Province::find($tran->province_id);
			            $bg  = App\BookGuide::where(['project_number'=>$tran->book_project, 'book_id'=>$tran->id])->first();
			            ?>
		                <tr>
							<td><?php echo e(Content::dateformat($tran->book_checkin)); ?></td>
							<td><?php echo e($pro->province_name); ?></td>         
							<td><?php echo e($tran->tour_name); ?></td>     
							<td><?php echo e(isset($bg->service->title) ? $bg->service->title : ''); ?></td>
							<td><?php echo e(isset($bg->supplier->supplier_name) ? $bg->supplier->supplier_name : ''); ?> </td>
							<td>
								<?php if(isset($bg->supplier->phone) || isset($bg->supplier->phone2)): ?>
									<?php echo e($bg->supplier->phone); ?> <?php echo e($bg->supplier->phone2); ?>

								<?php else: ?>
									<?php if(!empty($bg->supplier_id) ): ?>
										<?php echo e(isset($bg->phone) ? $bg->phone : ''); ?>

									
									<?php endif; ?>
								<?php endif; ?>
							</td> 
							<td><?php echo e(isset($bg->language->name) ? $bg->language->name : ''); ?></td>
							<td class="text-right"><?php echo e(isset($bg->price)?Content::money($bg->price):''); ?></td>
							<td class="text-right"><?php echo e(isset($bg->price)? Content::money($bg->kprice):''); ?></td>
							<td class="text-right">      
								<?php if(isset($bg->id)): ?>
								<span class="btn btn-acc btn-xs btnRefresh" title="Clear this service" data-type="clear-guide" data-id="<?php echo e(isset($bg->id) ? $bg->id : ''); ?>"><i class="fa fa-refresh"></i></span>
								<?php endif; ?>     
								<button class="btnEditTran"  style="padding:0px;border:none;"  
									data-type="apply_guide"
									data-restmenu="<?php echo e(isset($bg->service_id) ? $bg->service_id : ''); ?>" 
									data-transport="<?php echo e(isset($bg->supplier_id) ? $bg->supplier_id : ''); ?>" 
									data-language="<?php echo e(isset($bg->language_id) ? $bg->language_id : ''); ?>" 
									data-country="<?php echo e(isset($pro->country_id) ? $pro->country_id : ''); ?>" 
									data-province="<?php echo e(isset($pro->id) ? $pro->id : ''); ?>"  
									data-price="<?php echo e(isset($bg->price) ? $bg->price : ''); ?>" 
									data-kprice="<?php echo e(isset($bg->kprice) ? $bg->kprice : ''); ?>" 
									data-phone="<?php echo e(isset($bg->phone) ? $bg->phone : ''); ?>"  
									data-pro_of_bus_id="6" 
									data-id="<?php echo e($tran->id); ?>" data-toggle="modal" data-target="#myModal">
								  <i style="padding:1px 2px;" class="btn btn-info btn-xs fa fa-pencil-square-o"></i>
								</button> 
							</td>                     
		                </tr>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		              </tbody>
		            </table>
		        </section>
		    </div>
	    </section>
	</div>
</div>

<div class="modal in" id="myModal" role="dialog" data-backdrop="static" data-keyboard="true">
	<div class="modal-dialog modal-lg">
	    <form method="POST" action="<?php echo e(route('assignGuide')); ?>">
		    <div class="modal-content">        
		        <div class="modal-header">
		          	<button type="button" class="close" data-dismiss="modal">&times;</button>
		          	<h4 class="modal-title"><strong id="form_title">Guide Assignment</strong></h4>
		        </div>
		        <div class="modal-body">
		          	<?php echo e(csrf_field()); ?>    
		          	<input type="hidden" name="bookid" id="tour_id">
	 	          	<input type="hidden" name="project_number" id="project_number" value="<?php echo e($project->project_number); ?>">
			        <div class="row">
			            <div class="col-md-6 col-xs-6">
			              <div class="form-group">
			                <label>Country <span style="color:#b12f1f;">*</span></label> 
			                <select class="form-control country" id="country" name="country" data-type="country" data-locat="guide_data" data-pro_of_bus_id="6" required>
			                    <option value="">Country</option>
				                <?php $__currentLoopData = App\Country::getGuideCon(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                    <option value="<?php echo e($con->id); ?>"><?php echo e($con->country_name); ?></option>
				                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                </select>
			              </div> 
			            </div>
			            <div class="col-md-6 col-xs-6">
			              <div class="form-group">
			                <label>City Name <span style="color:#b12f1f;">*</span></label> 
			                <select class="form-control province" name="city" data-type="apply_guide" id="dropdown-data"  required>
			                  <option value="">--choose--</option>			                  
			                </select>
			              </div> 
			            </div>
			        </div>
			        <div class="row">
			            <div class="col-md-6 col-xs-6 ">
			              <div class="form-group">
			                <label>Service Name</label>
			               	<select class="form-control tran_name" name="tran_name" data-type="apply_language"  id="dropdown-transervice">
			               		<option>Select Service</option>
			               		
			               	</select>
			              </div>
			            </div>
			            
			            <div class="col-md-6 col-xs-6">
				            <div class="form-group">
				                <label>Language</label>
				               	<select class="form-control language" name="language" id="dropdown-rest_menu" data-type="language-supplier">
				               		<option>Choose Language</option>
				               		
				               	</select>
				            </div>
			            </div>
			            <div class="col-md-3 col-xs-6 ">
			              	<div class="form-group">
				                <label>Guide Name</label>
				               	<select class="form-control guide_name" name="guide_name" data-type="guide_name" id="dropdown-language-data">
				               		<option>No Guide</option>			               	
				               	</select>
				            </div>
			            </div>
			            <div class="col-md-3 col-xs-6">
			            	<div class="form-group">
			            		<label>Telephone</label>
			            		<input type="text" name="phone" id="phone" class="form-control" placeholder="(+855) 123 456 789" >
			            	</div>
			            </div>
			            <div class="col-md-3 col-xs-6">
			              <div class="form-group">
			                <label>Price <?php echo e(Content::currency()); ?></label>
			                <input type="text" name="price" id="price" class="form-control editprice" placeholder="00.0" readonly>
			              </div>
			            </div>
			            <div class="col-md-3 col-xs-6">
			              <div class="form-group">
			                <label>Price <?php echo e(Content::currency(1)); ?></label>
			                <input type="text" name="kprice" id="kprice" class="form-control editprice" placeholder="00.0" readonly>
			              </div>
			            </div>			            
			        </div>
		        </div>
		        <div class="modal-footer" style="text-align: center !important;">
		          	<button type="submit" class="btn btn-success btn-flat btn-sm" >Publish</button>
		         	<a href="#" class="btn btn-danger btn-flat btn-sm" data-dismiss="modal">Close</a>
		        </div>
		    </div>      
	    </form>
	</div>
</div>
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>