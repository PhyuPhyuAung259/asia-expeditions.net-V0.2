<?php $__env->startSection('title', $project->project_number.' Update'); ?>
<?php $active = 'booked/project'; 
$subactive ='booking/project';
  use App\component\Content;
  $service = '';
  foreach ($project->service as $key => $sv) {
      $service .= $sv->pivot->service_id.',';
  }
  $tag_user = '';
  foreach ($project->usertag as $key => $tag) {
      $tag_user .= $tag->pivot->user_id.',';
  }
?>
<?php $__env->startSection('content'); ?>
<style type="text/css">
  @media (min-width: 992px){
    .modal-lg {
      width: 1300px;
    }
  }
</style>
  <div class="wrapper">
    <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content"> 
        <div class="row">
          <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="col-lg-12"><h4 class="border">Travelling Booking Form</h4></div>
          <form method="POST" action="<?php echo e(route('updateProject')); ?>">
              <?php echo e(csrf_field()); ?>

              <section class="connectedSortable">
                <div class="col-md-9">
                  <div class="row">
                    <div class="col-md-1 col-xs-12" style="padding-right: 0px">
                      <div class="form-group">
                        <input type="hidden" name="olduser" value="<?php echo e($project->user_id); ?>">
                        <label>Project <span style="color:#b12f1f;">*</span></label>
                        <input type="text" placeholder="Project Number" class="form-control" name="project_number" value="<?php echo e($project->project_number); ?>" required readonly>
                      </div> 
                    </div>       
                    <div class="col-md-2 col-xs-6">
                      <div class="form-group">
                        <label>Revise date (yyyy-mm-dd)</label> 
                        <input type="text" placeholder="2018-04-26" class="form-control book_date" name="revise_date" value="<?php echo e(isset($project->project_revise) ? $project->project_revise : date('Y-m-d')); ?>" required/>
                      </div> 
                    </div> 
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Client Email</label> 
                        <input type="email" placeholder="Example@google.com" class="form-control" name="client_email" value="<?php echo e(isset($project->project_email) ? $project->project_email : ''); ?>"/>
                      </div> 
                    </div> 
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Pax Number <span style="color:#b12f1f;">*</span></label> 
                        <input type="text" placeholder="Pax Number" class="form-control" name="pax_num" required value="<?php echo e(isset($project->project_pax) ? $project->project_pax : old('pax_num')); ?>" />
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Client Name <span style="color:#b12f1f;">*</span> &nbsp; <a href="#" data-toggle="modal" data-target="#AddClient"> <i class="fa  fa-users"></i> Add More Client</a></label> 
                        <input type="text" class="form-control" name="client_name" placeholder="Jonh Smit" required value="<?php echo e(isset($project->project_client) ? $project->project_client : old('client_name')); ?>"/>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>File Number</label> 
                        <input type="text" class="form-control" name="fileno" placeholder="File Number" value="<?php echo e(isset($project->project_fileno) ? $project->project_fileno : old('fileno')); ?>" />
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Exchange Rate</label> 
                        <input type="text" class="form-control" name="ex_rate" placeholder="Exchange Rate" value="<?php echo e(isset($project->project_ex_rate) ? $project->project_ex_rate : old('ex_rate')); ?>" />
                      </div> 
                    </div>

                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Margin</label> 
                        <input type="text" class="form-control" name="margin_rate" placeholder="Margin Rate" value="<?php echo e(isset($project->margin_rate) ? $project->margin_rate : old('margin_rate')); ?>" />
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Selling Rate</label> 
                        <input type="text" class="form-control" name="sell_rate" placeholder="Selling Rate" value="<?php echo e(isset($project->project_selling_rate) ? $project->project_selling_rate : old('sell_rate')); ?>" />
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Additional Invoice</label> 
                        <input type="text" class="form-control" name="add_invoice" placeholder="Additional Invoice" value="<?php echo e(isset($project->project_add_invoice) ? $project->project_add_invoice : old('add_invoice')); ?>" />
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Credit Note</label> 
                        <input type="text" class="form-control" name="cnote_invoice" placeholder="Credits Note" value="<?php echo e(isset($project->project_cnote_invoice) ? $project->project_cnote_invoice : old('cnote_invoice')); ?>" />
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Invoice Number</label> 
                        <input type="text" class="form-control" name="invoice_num" placeholder="Invoice Number" value="<?php echo e(isset($project->project_invoice_number) ? $project->project_invoice_number : old('invoice_num')); ?>" />
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Start Date<span style="color:#b12f1f;">*</span></label> 
                        <input type="text" id="from_date" class="form-control" name="start_date" placeholder="2018-04-24" required  value="<?php echo e(isset($project->project_start) ? $project->project_start : old('start_date')); ?>" />
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>End Date<span style="color:#b12f1f;">*</span></label>
                        <input type="text" id="to_date" class="form-control" name="end_date" placeholder="2019-04-24" required value="<?php echo e(isset($project->project_end) ? $project->project_end : old('end_date')); ?>" >
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Departure Time</label> 
                        <select class="form-control" name="dep_time" >
                            <option value="">--Select--</option>
                          <?php $__currentLoopData = App\FlightSchedule::where('flight_status',1)->orderBy('flightno', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($fy->id); ?>" <?php echo e($fy->id == $project->project_dep_time ? 'selected':''); ?>><?php echo e($fy->flightno); ?> - D:<?php echo e($fy->dep_time); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Arrival Time</label> 
                        <select class="form-control" name="arr_time" >
                          <option value="">--Select--</option>
                          <?php $__currentLoopData = App\FlightSchedule::where('flight_status',1)->orderBy('flightno', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($fy->id); ?>" <?php echo e($fy->id == $project->project_arr_time ?   'selected':''); ?>><?php echo e($fy->flightno); ?> - A:<?php echo e($fy->arr_time); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Agent<span style="color:#b12f1f;">*</span></label> 
                        <select class="form-control" name="agent" required="" >
                          <option value="">Agent</option>
                          <?php $__currentLoopData = App\Supplier::where(['business_id'=>9, 'supplier_status'=>1])->orderBy('supplier_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($agent->id); ?>"  <?php echo e($agent->id == (isset($project->supplier_id) ?$project->supplier_id:'') ? 'selected':''); ?>><?php echo e($agent->supplier_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div> 
                    </div>                    
                    <div class="col-md-3 col-xs-12">
                      <div class="form-group">
                        <label>Location</label>
                        <select class="form-control" name="location">
                          <?php $__currentLoopData = App\Country::where('country_status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($con->id); ?>" <?php echo e(isset($project->country_id) ? ($project->country_id == $con->id? 'selected':''):''); ?>><?php echo e($con->country_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Reference</label> 
                        <input class="form-control" type="text" placeholder="Reference" name="reference" value="<?php echo e(isset($project->project_book_ref) ? $project->project_book_ref : old('reference')); ?>" >
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Travel Consultant</label> 
                        <input class="form-control" type="text" placeholder="Travel Consultant" name="consultant" value="<?php echo e(isset($project->project_book_consultant) ? $project->project_book_consultant : old('consultant')); ?>">
                      </div> 
                    </div> 
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <br><br>
                        <label><a href="#" data-toggle="modal" data-target="#uploadPDF"><i class="fa fa-folder" style="font-size: 15px;"></i> Upload PDF Files</a></label> 
                        
                      </div> 
                    </div>    
                    <div class="col-md-12 col-xs-6">
                      <div class="form-group">
                        <script src="<?php echo e(asset('/adminlte/editor/tinymce.min.js')); ?>"></script>
                        <label>Description</label>
                        <textarea class="form-control my-editor " name="pro_desc" rows="6" placeholder="Enter Here ..."><?php echo e(isset($project->project_desc) ? $project->project_desc : old('pro_desc')); ?></textarea>   
                      </div>
                    </div>
                    <div class="col-md-6 col-xs-6">
                      <div class="form-group">
                        <label>Hightlights</label>
                        
                        <textarea class="form-control my-editor" name="pro_hightlight" rows="6" placeholder="Enter Here..."> <?php echo e(isset($project->project_hight) ? $project->project_hight : old('pro_hightlight')); ?></textarea>            
                      </div>
                    </div>
                    <div class="col-md-6 col-xs-6">
                      <div class="form-group">
                        <label>Additional Descriptions</label>
                        <textarea class="form-control " name="pro_add_desc" rows="6" placeholder="Enter Here..."><?php echo e(isset($project->project_add_desc) ? $project->project_add_desc : old('pro_add_desc')); ?></textarea>            
                      </div>
                    </div>
                    <div class="col-md-6 col-xs-6">
                      <div class="form-group">
                        <label>Credit Note Descriptions</label>
                        <textarea class="form-control" name="pro_note_desc" rows="6" placeholder="Enter Here..." ><?php echo e(isset($project->project_note_desc) ? $project->project_note_desc : old('pro_note_desc')); ?></textarea>
                      </div>
                    </div>
                    <div class="col-md-6 col-xs-6">
                      <div class="form-group">
                        <label>Remarks</label>
                        <textarea class="form-control" name="pro_note" rows="6" placeholder="Included/Excluded" ><?php echo e(isset($project->project_note) ? $project->project_note : old('pro_note')); ?></textarea>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-3"><br>
                  <div class="panel panel-default">
                    <div class="panel-body">
                      <div class="col-md-7">
                        <div class="form-group">
                            <div><label>Option Choice</label>&nbsp;</div>
                            <label style="font-weight:400;"> 
                              <input type="radio" name="option" value="0" <?php echo e($project->project_option==0?'checked':''); ?> >
                              <span style="position: relative;top:-2px;">Booking</span>
                            </label>&nbsp;&nbsp;
                            <?php if(isset($_GET['action'])): ?>
                            <label style="font-weight: 400;">
                                <input type="radio" name="option" value="1" <?php echo e($project->project_option==1?'checked':''); ?>>
                                <span style="position: relative;top:-2px;">Quotation</span>
                            </label>
                            <?php endif; ?>
                        </div>
                      </div> 
                      <div class="col-md-5">
                          <div class="form-group">
                            <div><label>Project Type</label>&nbsp;</div>
                            <div class="row">
                              <label style="font-weight:400;"> 
                                <input type="radio" name="active" value="1" <?php echo e($project->active== 1 ?'checked':''); ?>>
                                <span style="position: relative;top:-2px;">Active</span>
                              </label>&nbsp;&nbsp;
                              <label style="font-weight: 400;">
                                  <input type="radio" name="active" value="0" <?php echo e($project->active == 0 ?'checked':''); ?>>
                                  <span style="position: relative;top:-2px;">InActive</span>
                              </label>
                            </div>
                          </div>
                      </div>
                    </div>
                  </div>
                  <div class="panel panel-default">
                    <div class="panel-body">
                      <div class="form-group">
                        <div><label>Project Status</label>&nbsp;</div>
                        <label style="font-weight:400;"> 
                          <input type="radio" name="project_check" value="1" <?php echo e($project->project_check==1?'checked':''); ?>>
                          <span style="position: relative;top:-2px;">Already Check</span>
                        </label>&nbsp;&nbsp;
                        <label style="font-weight: 400;">
                            <input type="radio" name="project_check" value="0" <?php echo e($project->project_check==0?'checked':''); ?>>
                            <span style="position: relative;top:-2px;">Not yet check</span>
                        </label>  
                      </div>                      
                    </div>
                  </div>
                  <div class="panel panel-default">
                    <div class="panel-body">
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <div><label>Project Prefix</label>&nbsp;</div>
                            <label style="font-weight:400;"> 
                              <input type="radio" name="project_prefix" value="AE" <?php echo e($project->project_prefix == 'AE'?'checked':''); ?>>
                              <span style="position: relative;top:-2px;">AE</span>
                            </label>&nbsp;&nbsp;
                            <label style="font-weight: 400;">
                                <input type="radio" name="project_prefix" value="AM" <?php echo e($project->project_prefix=='AM'?'checked':''); ?>>
                                <span style="position: relative;top:-2px;">AM</span>
                            </label> 
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <div><label>Prefix</label>&nbsp;</div>
                            <label style="font-weight:400;"> 
                              <input type="radio" name="prefix" value="Main" <?php echo e($project->project_main_status=='Main'?'checked':''); ?>>
                              <span style="position: relative;top:-2px;">Main</span>
                            </label>&nbsp;&nbsp;
                            <label style="font-weight: 400;">
                                <input type="radio" name="prefix" value="Sub" <?php echo e($project->project_main_status=='Sub'?'checked':''); ?>>
                                <span style="position: relative;top:-2px;">Sub</span>
                            </label>
                          </div>
                        </div>                       
                      </div>
                    </div>
                  </div>
                  <div class="panel panel-default">
                    <div class="panel-body">
                      <div class="btn-group" style="display: block;">
                        <button type="button" class="form-control" data-toggle="dropdown" aria-haspopup="false" aria-expanded="false" data-backdrop="static" data-keyboard="false" role="dialog" data-backdrop="static" data-keyboard="false" >
                         <span class="pull-left"><i class="fa fa-user-plus" style="color: #5aabf1;"></i> User Tags</span><span class="pull-right"><i class="caret"></i></span>
                        </button>  
                        <div class="obs-wrapper-search">
                          <ul class="dropdown-data" style="width: 100%;" id="Show_date">
                            <?php $__currentLoopData = App\User::where('banned',0)->whereNotIn('role_id',[7])->orderBy('fullname', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li <?php echo e(in_array($user->id, [Auth::user()->id])? "style=display:none":""); ?>>
                              <div class="checkbox">
                                <input id="ch<?php echo e($key); ?>" style="width: 14px; height: 14px;" type="checkbox" name="usertag[]" value="<?php echo e($user->id); ?>" <?php echo e(in_array($user->id, explode(',', $tag_user)) ? 'checked':''); ?>  <?php echo e(Auth::user()->id == $user->id ? "checked":""); ?>> 
                                <label for="ch<?php echo e($key); ?>" style="position: relative;top:3px;"><?php echo e($user->fullname); ?> <small>(<?php echo e(isset($user->role->name) ? $user->role->name : ''); ?>)</small></label>
                              </div>
                            </li>                           
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="clearfix"></div>
                          </ul>
                        </div>
                      </div>
                    </div>                  
                  </div>
                  <div class="panel panel-default">
                    <div class="panel-body">
                      <label>Payment Optoin</label>
                      <?php $__currentLoopData = App\Bank::orderBy('name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$bk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>                        
                          <label style="font-weight:400;">
                            <input type="radio" name="bank" value="<?php echo e($bk->id); ?>" <?php echo e($bk->id == $project->project_bank ?'checked':''); ?>> 
                            <span style="position: relative;top:-2px"><?php echo e($bk->name); ?></span>
                          </label>
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                  </div>
                
                  <div class="col-md-12 text-center">
                    <div class="form-group">
                      <button type="submit" class="btn btn-success btn-flat btn-sm">Comfirm Booking</button>&nbsp;
                      <a href="<?php echo e(route('projectList', ['url'=> 'project'])); ?>" class="btn btn-danger btn-sm ">Back</a>
                    </div>
                  </div>               
                </div>
                <div style="margin-bottom: 30px;"></div>
              </section>
          </form>
        </div>
      </section>
    </div>  
  </div>
  <?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.editor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="modal" id="AddClient" role="dialog"  data-backdrop="static" data-keyboard="true">
  <div class="modal-dialog modal-lg">    
    <form id="AddMultiClientForm" method="POST" action="<?php echo e(route('addClientForProject')); ?>">
      <div class="modal-content">        
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><strong>Add Client Name For File No. <?php echo e($project->project_prefix); ?>-<?php echo e($project->project_fileno ? $project->project_fileno : $project->project_number); ?></strong></h4>
        </div>
        <div class="modal-body">
          <?php echo e(csrf_field()); ?>    
          <input type="hidden" name="client_project_number" value="<?php echo e($project->project_number); ?>">
          <input type="hidden" name="project_id" value="<?php echo e($project->id); ?>">       
            <table class="table table_row">
              <tr>
                <th style="border:none; width: 200px;">Client Name</th>
                <th style="border:none;">Nationality</th>
                <th style="border:none;">Passport Number</th>
                <th style="border:none;">Date of Expiry</th>
                <th style="border:none;">Date Of Birth</th>
                <th style="border:none;">Phone</th>
                <th style="border:none;">Dietary</th>
                <th style="border:none;">Allergies</th>
                <th style="border:none;">Share With</th>
                <th style="border:none;">Arrival Flight</th>
                <th style="border:none;">Departure Flight</th>
              </tr>
              <tbody style="border-top: none;">
                <?php $getClient = \App\Admin\ProjectClientName::where('project_number', $project->project_number)->get(); ?>

                <?php if($getClient->count() > 0): ?>
                  <?php $__currentLoopData = $getClient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="clonrow">
                      <td style="padding-left: 0px;">
                        <div class="row">
                          <div class="col-md-6">
                            <input type="hidden" name="eid[]" value="<?php echo e($cl->id); ?>">
                            <input type="text" name="first_name[]" class="form-control" value="<?php echo e($cl->first_name); ?>">
                          </div>
                          <div class="col-md-6" style="padding-left: 0px;">
                            <input type="text" name="last_name[]" class="form-control" value="<?php echo e($cl->last_name); ?>">
                          </div>
                        </div>
                        <div class="clearfix"></div>
                      </td>
                      <td>
                        <select class="form-control" name="country_id[]" required>
                          <?php $__currentLoopData = App\Country::where(['country_status'=> 1])->orderBY('nationality')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($con->id); ?>" <?php echo e($con->id == $cl->country_id ? 'selected' : 
                             ''); ?>><?php echo e($con->nationality); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </td>
                      <td><input type="text" name="passport[]" class="form-control" value="<?php echo e($cl->passport); ?>"></td>
                      <td><input type="text" name="expire_date[]" class="form-control book_date" value="<?php echo e(isset($cl->expired_date) ? date('Y-m-d', strtotime($cl->expired_date)) : ''); ?>">
                      </td>
                      <td><input  type="text" name="date_of_birth[]" class="form-control book_date" value="<?php echo e(isset($cl->date_of_birth) ? date('Y-m-d', strtotime($cl->date_of_birth)) : ''); ?>"></td>
                      <td><input type="text" name="phone[]" class="form-control " placeholder="Phone No" value="<?php echo e($cl->phone); ?>"></td>
                      <td><input type="text" name="dietary[]" class="form-control " placeholder="Dietary" value="<?php echo e($cl->dietary); ?>"></td>
                      <td><input type="text" name="allergies[]" class="form-control " placeholder="Allergies" value="<?php echo e($cl->allergies); ?>"></td>
                      <td style="padding-right: 0px;"><input type="text" name="share_with[]" class="form-control" placeholder="Share With...." value="<?php echo e($cl->share_with); ?>"></td>
                      <td>
                        <input type="text" name="flight_arr[]" class="form-control" placeholder="Arrival Flight" value="<?php echo e($cl->flight_arr); ?>">
                      </td>
                      <td style="padding-right: 0px;">
                        <input type="text" name="flight_dep[]" class="form-control" placeholder="Departure Flight" value="<?php echo e($cl->flight_dep); ?>">
                      </td>
                      <td><a href="#" data-id="<?php echo e($cl->id); ?>" data-title="<?php echo e($cl->client_name); ?>" class="RemoveClientRow"><i style="color:#913412;font-size:14px;" class="fa fa-minus-circle"></i></a></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <tr class="clonrow">
                  <td style="padding-left: 0px;">
                    <div class="row">
                      <div class="col-md-6">
                        <input type="text" name="first_name[]" class="form-control" placeholder="First Name">
                      </div>
                      <div class="col-md-6" style="padding-left: 0px;">
                        <input type="text" name="last_name[]" class="form-control" placeholder="Last Name">
                      </div>
                    </div>
                    <div class="clearfix"></div>
                  </td>
                  <td>
                    <select class="form-control" name="country_id[]" required>
                      <?php $__currentLoopData = App\Country::where(['country_status'=> 1])->orderBy('country_name')->orderBY('country_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($con->id); ?>"><?php echo e($con->country_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </td>
                  <td><input type="text" name="passport[]" class="form-control " placeholder="Passport Number"></td>
                  <td><input type="text" name="expire_date[]" class="form-control book_date" placeholder="Expire Date" pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}">
                  </td>
                  <td><input type="text" name="date_of_birth[]" class="form-control book_date" placeholder="Date Of Birth:"></td>
                  <td><input type="text" name="phone[]" class="form-control " placeholder="Phone No"></td>
                  <td><input type="text" name="dietary[]" class="form-control " placeholder="Dietary"></td>
                  <td><input type="text" name="allergies[]" class="form-control " placeholder="Allergies"></td>
                  <td style="padding-right: 0px;"><input type="text" name="share_with[]" class="form-control" placeholder="Share With...." ></td>
                  <td>
                    <input type="text" name="flight_arr[]" class="form-control" placeholder="Departure Flight">
                  </td>
                  <td style="padding-right: 0px;">
                    <input type="text" name="flight_dep[]" class="form-control" placeholder="Departure Flight" >
                  </td>
                  <td><a href="#" class="addClientRow"><i class="fa fa-plus"></i></a></td>
                </tr>
              </tbody>
            </table>
        </div>
        <div class="modal-footer" style="text-align: center;">
          <button type="submit" class="btn btn-success btn-sm" >Save</button>
          <a href="#" class="btn btn-default btn-flat btn-sm btn-acc" data-dismiss="modal">Close</a>
        </div>
      </div>      
    </form>
  </div>
</div>

<div class="modal" id="uploadPDF" role="dialog"  data-backdrop="static" data-keyboard="true">
  <div class="modal-dialog modal-md">    
    <form method="POST" action="<?php echo e(route('addProjectPdF')); ?>" enctype="multipart/form-data">
      <div class="modal-content">        
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><strong>Upload Project Data File No. <?php echo e($project->project_prefix); ?>-<?php echo e($project->project_fileno ? $project->project_fileno : $project->project_number); ?></strong></h4>
        </div>
        <div class="modal-body">
          <?php echo e(csrf_field()); ?>    
            <input type="hidden" name="project_number_pdf" value="<?php echo e($project->project_number); ?>">
            <input type="hidden" name="project_id_pdf" value="<?php echo e($project->id); ?>">   
            <input type="hidden" name="pdf_type" value="project_pdf">       
            <div class="form-group">
              <input type="file" name="project_pdf[]" multiple>
            </div>
            <?php $getClient = \App\Admin\Photo::where('project_number', $project->project_number)->get(); ?>
            <?php if($getClient->count() > 0): ?>
            <table class="table ">
                <tr>
                  <th style="border:none;"> Title</th>
                  <th style="border:none;">By User</th>
                  <th style="border:none;" width="8px">Action</th>
                </tr>
                <tbody style="border-top: none;">
                    <?php $__currentLoopData = $getClient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td> <a target="_blank" href="<?php echo e(asset('storage/contract/projects')); ?>/<?php echo e($cl->name); ?>"><?php echo e($cl->original_name); ?> </td>
                        <td><?php echo e(isset($cl->user->fullname) ? $cl->user->fullname : ''); ?></td>
                        <td>
                          <span style="cursor:pointer;" class="RemoveHotelRate" data-type="project_pdf" data-id="<?php echo e($cl->id); ?>" title="Delete this ?"><i style="color:#913412;font-size:14px;" class="fa fa-minus-circle"></i></span></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            <?php endif; ?>
        </div>
        <div class="modal-footer" style="text-align: center;">
          <button type="submit" class="btn btn-success btn-sm">Save</button>
          <span class="btn btn-default btn-flat btn-sm btn-acc" data-dismiss="modal">Close</span>
        </div>
      </div>      
    </form>
  </div>
</div>
<script type="text/javascript">
  $(document).ready(function(){
    $(".addClientRow").click(function(){
      var this_row = $(this).closest("tr");
      var cloneRow = '<tr><td style="padding-left: 0px;"><div class="row"><div class="col-md-6"><input type="text" name="first_name[]" class="form-control" placeholder="First Name"></div><div class="col-md-6" style="padding-left: 0px;"><input type="text" name="last_name[]" class="form-control" placeholder="Last Name"></div></div><div class="clearfix"></div></td><td><select class="form-control" name="country_id[]" required><?php $__currentLoopData = App\Country::where(["country_status"=> 1])->whereNotNull("nationality")->orderBy("nationality")->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($con->id); ?>"><?php echo e($con->nationality); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></td><td><input type="text" name="passport[]" class="form-control " placeholder="Passport Number"></td><td><input type="text" name="expire_date[]" class="form-control book_date" placeholder="Expire Date"></td><td><input type="text" name="date_of_birth[]" class="form-control book_date" placeholder="Date Of Birth:"></td><td><input type="text" name="phone[]" class="form-control" placeholder="Phone No"></td><td><input type="text" name="dietary[]" class="form-control " placeholder="Dietary"></td><td><input type="text" name="allergies[]" class="form-control " placeholder="Allergies"></td><td style="padding-right: 0px;"><input type="text" name="share_with[]" class="form-control" placeholder="Share With...." ></td><td><input type="text" name="flight_arr[]" class="form-control" placeholder="Arrival Flight"></td><td style="padding-right: 0px;"><input type="text" name="flight_dep[]" class="form-control" placeholder="Departure Flight"></td><td><a data-type="new_row" href="#" class="RemoveClientRow"><i class="fa fa-minus-circle" style="color:#913412;font-size:14px;"></i></a></td></tr>';
      $(".table_row tbody tr:last").before(cloneRow);
      
    });

    $(document).on("click", ".RemoveClientRow", function(){
      var this_row = $(this).closest("tr");
      if(confirm("Are you sure you want to delete this?")){ 
        var id = $(this).data('id');
        if ($(this).data('type') == "new_row") {
          this_row.css({'background-color':'#9E9E9E'});
          this_row.fadeOut(500, function(){
            $(this_row).remove();
          });
        }else{
          $.ajax({
              method: "GET",
              url: baseUrl+"option/remove",      
              data: "dataId=" + id+"&type="+ "projectForClient"+ "&title="+$(this).data("title"),   
              dataType: 'html',
              success: function(data){                
                this_row.css({'background-color':'#9E9E9E'});
                this_row.fadeOut(500, function(){
                  $(this_row).remove();
                });
              },
              error: function(){
                  alert("Something Wrong.");
                  return false;
              },
          });
        }
      }
    });
  });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>