<?php $__env->startSection('title', 'Restaurant Assignment'); ?>
<?php
  $active = 'restaurant/menu'; 
  $subactive = 'restaurant/service';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="content-wrapper">
	    <section class="content"> 
		    <div class="row">
		      	<?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		        <section class="col-lg-12 connectedSortable">
		           <h3 class="border" style="text-transform:capitalize;">Booking Restaurant for Project No. <b><?php echo e($project->project_number); ?> </b> <span class="fa fa-angle-double-right"></span> <a href="#" class="btn btn-default btn-sm" data-toggle="modal" data-target="#myModal">Add Restaurant</a></h3>
		            <table class="datatable table table-hover table-striped">
			            <thead>
			                <tr>
			                  <th width="100px">Start Date</th>
			                  <th>Restuarant Name</th>
			                  <th>Menu</th>
			                  <th>Pax</th>
			                  <th style="width: 70px;">Price <?php echo e(Content::currency()); ?></th>
			                  <th style="width: 70px;">Amount</th>
			                  <th style="width: 70px;">Price <?php echo e(Content::currency(1)); ?></th>
			                  <th style="width: 70px;">Amount</th>
			                  <th class="text-center">Status</th>
			                </tr>
			            </thead>
			            <tbody>
			                <?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                <tr>
			                  	<td><?php echo e(Content::dateformat($rest->start_date)); ?></td>
				                <td><?php echo e(isset($rest->supplier->supplier_name) ? $rest->supplier->supplier_name : ''); ?></td>         
				                <td><?php echo e(isset($rest->rest_menu->title) ? $rest->rest_menu->title : ''); ?></td>
				                <td><?php echo e($rest->book_pax); ?></td>
				                <td class="text-right"><?php echo e(Content::money($rest->price)); ?></td>
				                <td class="text-right"><?php echo e(Content::money($rest->amount)); ?></td>
				                <td class="text-right"><?php echo e(Content::money($rest->kprice)); ?></td>
			                  	<td class="text-right"><?php echo e(Content::money($rest->kamount)); ?></td>
			                  	<td class="text-right">                      
				                    <span class="btnEditTran" data-type="rest_name" data-country="<?php echo e($rest->country_id); ?>" data-province="<?php echo e($rest->province_id); ?>" data-restname="<?php echo e(isset($rest->supplier->id) ? $rest->supplier->id : ''); ?>" data-restmenu="<?php echo e(isset($rest->rest_menu->id) ? $rest->rest_menu->id : ''); ?>" data-bookpax="<?php echo e($rest->book_pax); ?>" data-price="<?php echo e($rest->price); ?>" data-kprice="<?php echo e($rest->kprice); ?>" data-bookdate="<?php echo e($rest->start_date); ?>" data-bookingdate="<?php echo e($rest->book_date); ?>" data-remark="<?php echo e($rest->remark); ?>" data-id="<?php echo e($rest->id); ?>" data-toggle="modal" data-target="#myModal">
				                      <i style="padding:1px 2px; position: relative;top: -5px;" class="btn btn-info btn-xs fa fa-pencil-square-o"></i>
				                    </span>  
				                    <a target="_blank" href="<?php echo e(route('restBooking',['project'=> $rest->project_number,'restid'=> $rest->id])); ?>" title="View Restaurant Booking">
				                        <label class="icon-list ic_inclusion"></label>
				                    </a>
				                    <a target="_blank" href="<?php echo e(route('restVoucher',['project'=> $rest->project_number,'restid'=> $rest->id])); ?>" title="View Restaurant Voucher">
				                        <label class="icon-list ic_invoice_drop"></label>
				                    </a> 
							        <a href="javascript:void(0)" class="RemoveHotelRate" data-type="apply_rest" data-id="<?php echo e($rest->id); ?>" title="Delete this ">
			                          <label class="icon-list ic_remove"></label>
			                        </a>
				                </td>                     
			                </tr>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			            </tbody>
		            </table>
		        </section>
		    </div>
	    </section> 
	</div>
</div>

<div class="modal fade" id="myModal" role="dialog" data-backdrop="static" data-keyboard="true">
	<div class="modal-dialog modal-lg">
	    <form method="POST" action="<?php echo e(route('assignRestuarant')); ?>">
	      <div class="modal-content">        
	        <div class="modal-header">
	          <button type="button" class="close" data-dismiss="modal">&times;</button>
	          <h4 class="modal-title"><strong id="form_title">Restaurant Booking</strong><strong><?php echo e($project->project_number); ?></strong></h4>
	        </div>
	        <div class="modal-body">
	          <?php echo e(csrf_field()); ?>    
	          	<input type="hidden" name="restId" id="tour_id">
	          	<input type="hidden" name="bookid" value="<?php echo e(isset($booking->id) ? $booking->id : ''); ?>">
	          	<input type="hidden" name="project_number" id="project_number" value="<?php echo e($project->project_number); ?>">
		        <div class="row">
		        	<div class="col-md-6 col-xs-6">
			            <div class="form-group">
			                <label>Start Date</label> 
			            	<input type="text" name="start_date" class="form-control start_date" placeholder="Start Date" value="<?php echo e(date('Y-m-d')); ?>">	
			            </div> 
		            </div>
		            <div class="col-md-6 col-xs-6">
			            <div class="form-group">
			                <label>Booking Date</label> 
			            	<input type="text" name="book_date" class="form-control booking_date" placeholder="Booking Date" value="<?php echo e(date('Y-m-d')); ?>">
			            </div> 
		            </div>
		            <div class="col-md-6 col-xs-6">
		              <div class="form-group">
		                <label>Country <span style="color:#b12f1f;">*</span></label> 
		                <select class="form-control country" id="country" name="country" data-type="country"  data-pro_of_bus_id="2" data-locat="data" required>
		                    <option value="">Country</option>
		                  <?php $__currentLoopData = App\Country::getRestCon(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                    <option value="<?php echo e($con->id); ?>"><?php echo e($con->country_name); ?></option>
		                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                </select>
		              </div> 
		            </div>
		            <div class="col-md-6 col-xs-6">
		              <div class="form-group">
		                <label>City Name <span style="color:#b12f1f;">*</span></label> 
		                <select class="form-control province" name="city" data-type="rest_name" id="dropdown-data" required>
		                  	<option value="">City</option>
			                <?php $__currentLoopData = App\Province::getRestPro(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                    <option value="<?php echo e($pro->id); ?>"><?php echo e($pro->province_name); ?></option>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                </select>
		              </div> 
		            </div>
		        </div>
		        <div class="row">
		            <div class="col-md-6">
		              <div class="form-group">
		                <label>Restaurant Name</label>
		               	<select class="form-control rest_name" name="rest_name" data-type="rest_menu" id="dropdown-transervice">
		               		<option>Select Service</option>
		               		<?php $__currentLoopData = App\Supplier::where(['business_id'=> 2 , 'supplier_status'=> 1])->orderBy('supplier_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		               		<option value="<?php echo e($rest->id); ?>"><?php echo e($rest->supplier_name); ?></option>
		               		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		               	</select>
		              </div>
		            </div>
		            <div class="col-md-6 col-xs-12">
			            <div class="form-group">
			                <label>Menu </label>
			               	<select class="form-control rest_menu" name="rest_menu" id="dropdown-rest_menu">
			               		<option>Select Menu</option>
			               	<!-- 	<?php $__currentLoopData = App\RestaurantMenu::whereNotIn('title', [''])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			               		<option value="<?php echo e($rm->id); ?>" data-price="<?php echo e($rm->price); ?>" data-kprice="<?php echo e($rm->kprice); ?>"><?php echo e($rm->title); ?></option>
			               		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
			               	</select>
			            </div>
		            </div>
		            <div class="col-md-6 col-xs-6">
		              <div class="form-group">
		                <label>Pax No.</label>
		                <input type="number" name="pax" id="pax" class="form-control text-center">
		              </div>
		            </div>
		            <div class="col-md-3 col-xs-3">
		              <div class="form-group">
		                <label>Price <?php echo e(Content::currency()); ?></label>
		                <input type="text" name="price" id="price" class="form-control editprice" placeholder="00.0" readonly>
		              </div>
		            </div>
		            <div class="col-md-3 col-xs-3">
		              <div class="form-group">
		                <label>Price <?php echo e(Content::currency(1)); ?></label>
		                <input type="text" name="kprice" id="kprice" class="form-control editprice" placeholder="00.0" readonly>
		              </div>
		            </div>
		            <div class="col-md-12 col-xs-12">
		              <div class="form-group">
		                <label>Remark</label>
		                <textarea class="form-control" id="remark" name="remark" rows="5" placeholder="Remark..."></textarea>
		              </div>
		            </div>
		        </div>
	        </div>
	        <div class="modal-footer" >
	          <button type="submit" class="btn btn-success btn-flat btn-sm" >Publish</button>
	          <a href="#" class="btn btn-danger btn-flat btn-sm" data-dismiss="modal">Cancel</a>
	        </div>
	      </div>      
	    </form>
	</div>
</div>
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
  <?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>