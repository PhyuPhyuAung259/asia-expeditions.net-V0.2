<?php $__env->startSection('title', 'Resturant Booking Form'); ?>
<?php 
	use App\component\Content;
	$comId = Auth::user()->company_id ? Auth::user()->company_id: 1;
	$comadd = \App\Company::find($comId);
 ?>
<?php $__env->startSection('content'); ?>
	<div class="col-lg-12">
		<table class="table" style="margin-bottom: 0px;">
			<tr>
				<td style="border-top: none;" class="text-left">
					<h4 style="text-transform: uppercase;">Reservation Form</h4>
					<div><b>File / Project No.</b>: <?php echo e($project->project_fileno ? $project->project_prefix.'-'.$project->project_fileno : $project->project_number); ?></div>
					<div><b>Issue Date</b>: <?php echo e(Date('d-M-Y')); ?></div>
					<div><b>Client Name:</b><?php echo e($project->project_client); ?></div>
					<div><b>Travelling Date:</b><?php echo e(Content::dateformat($project->project_start)); ?> -  <?php echo e(Content::dateformat($project->project_end)); ?></div>
				</td>
				<td style="border-top: none;" width="200px">
					<img src="<?php echo e(Storage::url('avata/')); ?><?php echo e($comadd->logo); ?>" style="width: 100%;">
				</td>
			</tr>
		</table>
		<div class="col-md-12">			
			<div class="pull-right hidden-print">
				<a href="javascript:void(0)" onclick="window.print();"><span class="fa fa-print btn btn-primary"></span></a>
			</div>
		</div>
		
		<table class="table" style="width: 100%;" >
			<tr>				
				<td style="border-top: none" colspan="2">
					<div class="well" style="padding: 4px;margin-bottom: 0px; background-color: #ddd0;">
						<address style="margin-bottom: 0px;">
							<i class="glyphicon glyphicon-user"></i>&nbsp;&nbsp;<?php echo e(isset($restb->supplier->supplier_name) ? $restb->supplier->supplier_name : ''); ?><br>
						 	<i class="glyphicon glyphicon-home"></i>&nbsp;&nbsp;<?php echo e(isset($restb->supplier->supplier_address) ? $restb->supplier->supplier_address : ''); ?><br>
							<i class="glyphicon glyphicon-phone-alt"></i>&nbsp;&nbsp;<?php echo e(isset($restb->supplier->supplier_phone) ? $restb->supplier->supplier_phone : ''); ?> / <?php echo e(isset($restb->supplier->supplier_phone2) ? $restb->supplier->supplier_phone2 : ''); ?><br>
							<i class="glyphicon glyphicon-envelope"></i>&nbsp;&nbsp;<?php echo e(isset($restb->supplier->supplier_email) ? $restb->supplier->supplier_email : ''); ?><br>
						</address>
					</div>
				</td>
			</tr>
			<tr>
				<td colspan="3" style="border-top: none;">
					<p><b>Booking Date:</b> <?php echo e(Content::dateformat($restb->book_date)); ?></p>
					<p>Dear Reservation Team,<br>
					Could you please kindly book and confirm the following reservation?</p>
				</td>
			</tr>
			<tr>
				<td class="text-right hotel_booking" style="width: 190px;"><strong>Client Name</strong>:</td><td class="text-left"><?php echo e($project->project_client); ?></td>
			</tr>
			<tr>
				<td class="text-right"><strong>Pax Number</strong>:</td><td class="text-left"><?php echo e($restb->book_pax); ?></td>
			</tr>
			<tr>
				<td class="text-right"><strong>Start Date</strong>:</td><td class="text-left"><?php echo e($restb->start_date); ?></td>
			</tr>
			<tr>
				<td class="text-right hotel_booking"><strong>Resturant Menu</strong>:</td><td class="text-left"><?php echo e(isset($restb->rest_menu->title) ? $restb->rest_menu->title : ''); ?></td>
			</tr>
			<tr>
				<td class="text-right hotel_booking"><strong>Remark</strong>:</td><td class="text-left"><?php echo e($restb->remark); ?></td>
			</tr>
			<tr>
				<td colspan="3">
					<p>Thank you very much and we look forward to receiving your confirmation soon. Should you need any further information, please do not hesitate to contact us.<br>
						With Best Regards,<br>
						Operation Department<br>
						<p><?php echo $comadd->address; ?></p>
					</p>
				</td>
			</tr>
		</table>
  	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>