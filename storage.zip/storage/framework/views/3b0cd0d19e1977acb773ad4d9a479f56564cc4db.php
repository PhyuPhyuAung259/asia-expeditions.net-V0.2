<?php $__env->startSection('title', 'Hotel & Room Rate'); ?>
<?php $active = 'supplier/hotels'; 
  $subactive ='hotel/hotelroom';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <div class="row">
        <section class="col-lg-12 connectedSortable">
          <h3 class="border"><span style="color: #f39c12; font-size: 22px;" class="fa fa-hotel (alias)"></span> Hotel Room</h3>
            <form action="" method="">
              <div class="col-sm-2 pull-right" style="text-align: right;">
                <label class="location">
                  <span class="fa fa-map-marker"></span>
                  <select class="form-control input-sm locationchange" name="location">
                    <?php $__currentLoopData = \App\Country::where('web', 1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($loc->id); ?>" <?php echo e($locationid == $loc->id ? 'selected':''); ?>><?php echo e($loc->country_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </label>
              </div>
            </form>                  
            <table class="datatable table table-hover table-striped">
              <thead>
                <tr>                     
                  <th>Hotel</th>
                  <th>RoomType</th>
                  <th width="100" class="text-center">Status</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $roomHotel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($app->supplier_name); ?></td>      
                  <td><?php echo e($app->name); ?></td>        					                  
      						<td class="text-center"> 
                    <!-- <a href="#Edit Tour" title="Edit Supplier">
                      <img src="#" class="icon-list ic_edit">
                    </a> -->
                    <a href="<?php echo e(route('getHotelRate', ['hotelid'=>$app->supplier_id, 'roomId' => $app->room_id])); ?>" title="Add hotel Rate">
                      <label class="icon-list ic_book_add"></label>
                    </a>
                    <a href="<?php echo e(route('getEditHotelRate', ['hotelid'=>$app->supplier_id, 'roomId' => $app->room_id])); ?>" title="Edit hotel rate">
                      <label class="icon-list ic_edit_hprice"></label>
                    </a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>                
        </section>
      </div>
    </section>
  </div>
</div>
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>