<?php  use App\component\Content;?>
<table class="table" id="roomrate">
	<tr style="background-color: rgb(245, 245, 245);">
		<th style="padding: 2px;"><span>Restaurant Name</span></td>
		<th style="padding: 2px;"><span>Menu</span></th>		
		<th style="padding: 2px;"><span>Price US</span></th>
		<th style="padding: 2px;"><span>Price Kyat</span></th>
		<!-- <th style="padding: 2px;"><span>remark</span></th> -->
	</tr>
		<?php $data = App\RestaurantMenu::where('supplier_id', $supplier->id)->get(); ?>
		<tr>
			<td style="vertical-align: middle; border: 1px solid #eee;" rowspan="<?php echo e($data->count()+1); ?>" ><?php echo e($supplier->supplier_name); ?></td>
		</tr>
	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr style="border: 1px solid #eee;">
			<td><?php echo e($rest->title); ?></td>
			<td><?php echo e($rest->price); ?> <span class="pcolor"><?php echo e(Content::currency()); ?></span></td>
			<td><?php echo e($rest->kprice); ?> <span class="pcolor"><?php echo e(Content::currency(1)); ?></span></td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php echo $__env->make('admin.report.supplier_info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</table>