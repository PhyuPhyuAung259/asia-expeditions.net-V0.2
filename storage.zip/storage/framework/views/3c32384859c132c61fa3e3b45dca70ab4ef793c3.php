<?php $__env->startSection('title', 'Journal Entry'); ?>
<?php 
  $active = 'finance'; 
  $subactive = 'finance/journal';
  use App\component\Content;
  $countryId = Auth::user()->country_id ? Auth::user()->country_id : 0;
?>
<?php $__env->startSection('content'); ?>
  <script type="text/javascript" src="<?php echo e(asset('adminlte/js/accountant.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('adminlte/js/account_controller.js')); ?>"></script>
  <style type="text/css">
  .table-head-row{
      /*background: linear-gradient(to bottom, #f4f4f4 0%,#eeeeee1a 50%);*/
      background: -webkit-linear-gradient(top, #ffffff, #cccccc54);
    }
  #data_payment_option td{
    padding: 0px;
  }
  #data_payment_option tr td:last-child i:hover, #account_journal_data tr td:last-child i.btnRemoveOption:hover{
    color:#b81c1c;
    cursor: pointer;
  }
  #account_journal_data tr td:last-child i.fa-edit:hover{
    color: #3c8dbc;
  }
  #account_journal_data tr td:last-child i.fa-edit{
    color: #3c8dbc85;
    cursor: pointer;
  }
  </style>
  <div class="wrapper">
    <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content"> 
          <h3 class="border text-center" style="color:black;text-transform: uppercase;font-weight:bold;">Journal Entry</h3>
           <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <form method="POST" action="<?php echo e(route('createJournal')); ?>" id="account_payment_form">
            <?php echo e(csrf_field()); ?>

            <div class="row">
              <div class="col-md-10 col-md-offset-1" style="margin-bottom: 20px">
                <div class="account-saction"><br>
                  <div class="col-md-4 col-xs-6">
                    <div class="form-group">
                      <label>Entry Date<span style="color:#b12f1f;">*</span></label> 
                      <input type="text" name="entry_date" class="form-control book_date" value="<?php echo e(date('Y-m-d')); ?>" required="">
                    </div>
                  </div>
                  <div class="col-md-4 col-xs-6">
                    <div class="form-group">
                      <label>location</label>
                      <select class="form-control location" name="country" data-type="country">
                        <?php $__currentLoopData = App\Country::where(['country_status'=>1, 'web'=>1])->orderBy('country_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($con->id); ?>"><?php echo e($con->country_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-4 col-xs-6">
                    <div class="form-group">
                      <label>Project Number </label> 
                      <select class="form-control projectNo" name="project_number" id="dropdown_project" required="">
                        <?php 
                         $projects = App\Project::whereNotIn('project_fileno', ["", "Null"])->orderBy('project_start', 'DESC')->get();
                         ?>
                         <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($pro->project_number); ?>"><?php echo e($pro->project_number); ?> - <?php echo e($pro->project_client); ?> - <?php echo e($pro->project_fileno); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div> 
                  </div>
                  <div class="col-md-4 col-xs-6">
                    <div class="form-group">
                      <label>Business Type</label>
                      <select class="form-control business_type " name="business_type" data-type="sup_by_project">
                        <option value="">Choose Business</option>
                        <?php $__currentLoopData = App\Business::where(['status'=>1, 'category_id'=>0])->whereNotIn('id', ['4','5'])->orderBy('id', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option data-bus_type="<?php echo e($bn->slug); ?>" value="<?php echo e($bn->id); ?>"><?php echo e($bn->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <option value="others-payment"> Other Payments</option>
                      </select>
                    </div>
                  </div>

                  <div class="col-md-4 col-xs-6">
                    <div class="form-group supplier_Names">
                      <label>Supplier Name <span style="color:#b12f1f;">*</span></label> 
                      <select class="form-control suppliers " name="supplier" id="dropdown_supplier">
                      </select>
                    </div>
                  </div>
                  <div class="col-md-2 col-xs-6">
                    <div class="form-group">
                      <label>Amount from OPS/Sales</label> 
                      <input type="text" name="book_amount" class="form-control text-right balance number_only" id="total_payable" placeholder="00.0" readonly="">
                    </div>
                  </div>
                  <div class="clearfix"></div>
                  <div class="col-md-12">
                    <table class="table">
                      <tr class="table-head-row">
                        <th>Descriptions</th>
                        <th width="250px">Account Type</th>
                        <th width="250px">Account Name</th>
                        <th width="120px">Debit</th>
                        <th width="120px">Credit</th>
                        <th></th>
                      </tr>
                      <tbody id="data_payment_option">
                        <tr>
                          <td>
                            <textarea class="form-control" name="desc[]" rows="1"></textarea>
                          </td>
                          <td>
                            <select class="form-control account_type input-sm" name="account_type[]" data-type="account_name" required="">
                              <option value="0">Choose Account Types</option>
                              <?php $__currentLoopData = App\AccountType::where('status', 1)->orderBy('account_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($acc->id); ?>"><?php echo e($acc->account_name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </td>
                          <td style="position: relative;">
                            <select class="form-control input-sm" name="account_name[]" id="dropdown-account_name">
                            </select>
                          </td>
                          <td>
                            <input type="text" class="form-control input-sm text-right balance number_only" data-type="debit" name="debit[]" id="debit" placeholder="00.0">
                          </td>
                          <td>
                            <input type="text" class="form-control input-sm text-right balance number_only" data-type="credit" name="credit[]" id="credit" placeholder="00.0">
                          </td>
                          <td class="text-center" style="background: #ddd;"><span class="btnRemoveEntry"><i class="fa fa-times-circle" style="font-size: 19px;"></i></span></td>
                        </tr>
                        <tr>
                          <td>
                            <textarea class="form-control" name="desc[]" rows="1"></textarea>
                          </td>
                          <td>
                            <select class="form-control account_type input-sm" name="account_type[]" data-type="account_name" required="">
                              <option value="0">Choose Account Types</option>
                              <?php $__currentLoopData = App\AccountType::where('status', 1)->orderBy('account_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($acc->id); ?>"><?php echo e($acc->account_name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </td>                           
                          <td style="position: relative;">
                            <select class="form-control input-sm" name="account_name[]" id="dropdown-account_name">
                            </select>
                          </td>
                          <td>
                            <input type="text" class="form-control input-sm text-right balance number_only" data-type="debit" name="debit[]" id="debit" placeholder="00.0">
                          </td>
                          <td>
                            <input type="text" class="form-control input-sm text-right balance  number_only" data-type="credit" name="credit[]" id="credit" placeholder="00.0">
                          </td>
                          <td class="text-center" style="background: #ddd;"><span class="btnRemoveEntry"><i class="fa fa-times-circle" style="font-size: 19px;"></i></span></td>
                        </tr>
                      </tbody>
                    </table>
                    <button type="button" class=" btn btn-default btn btn-xs" id="addNewLine"><i class="fa fa-plus-circle"></i> Add New Line</button>
                    <div class="clearfix"></div>
                    <div class="col-md-12 text-center">
                      <div class="form-group">
                        <button class="btn btn-info btn-sm btn-flat" id="btnSaveReceivable" style="width: 120px;">Save</button>
                      </div>
                    </div>
                  </div>
                <div class="clearfix"></div>
                </div>
              </div>
            </div>
          </form>
          <div class="col-md-12">
            
            <div class="col-md-10 col-md-offset-1">
              <div class="row">
                <div class="row" style="border: solid 1px #ddd;padding: 6px;">
                  <form id="journal_search_form">
                    <div class="pull-right">
                      <div class="pull-left">
                        <input type="text" name="search"  class="form-control input-sm" placeholder="Type Project File / No.">
                      </div>
                      <div class="pull-right">
                        <button class="btn btn-primary btn-sm btn-flat" id="btnSearchJournal">Search</button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <div class="clearfix"></div>
            <table class="table table-striped table-borderd">
              <thead>
                <tr>
                  <th width="25px">#</th>
                  <th width="81px">File Number</th>
                  <th width="290px">Account Name</th>
                  <th width="72px">Entry Date</th>
                  <th>Description</th>                    
                  <th>Supplier Name</th>
                  <th width="80px">Debit</th>
                  <th width="80px" style="border-right: none;">Credit</th>
                  <th style="border-right: none;"></th>
                </tr>
              </thead>
              <tbody id="account_journal_data">
              </tbody>
            </table>
          </div>
          <div class="clearfix"></div><br><br>
      </section>
    </div>
  </div>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- <div class="modal" id="myModal" role="dialog" data-backdrop="static" data-keyboard="true">
  <div class="modal-dialog modal-md">    
    <form method="POST" action="<?php echo e(route('addNewAccount')); ?>" id="add_new_account_form">
      <div class="modal-content">        
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><strong>Add New Account</strong></h4>
        </div>
        <div class="modal-body">
          <?php echo e(csrf_field()); ?>    
          <div class="row">
            <div class="col-md-6 col-xs-4">
              <div class="form-group">
                <label>Account Type<span style="color:#b12f1f;">*</span></label> 
                <select class="form-control input-sm account_type" name="account_type" data-type="account_name">
                  <?php $__currentLoopData = App\AccountType::where('status', 1)->orderBy('account_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($acc->id); ?>"><?php echo e($acc->account_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <div class="col-md-6 col-xs-4">
              <div class="form-group">
                <label>Account Code<span style="color:#b12f1f;">*</span> <small>(A unique code/number)</small></label> 
                <input type="text" name="code" class="form-control input-sm" required="">
              </div>
            </div>
            <div class="col-md-12 col-xs-4">
              <div class="form-group">
                <label>Account Name<span style="color:#b12f1f;">*</span></label> 
                <input type="text" name="name" class="form-control input-sm" required="">
              </div>
            </div>
            <div class="col-md-12 col-xs-12">
              <div class="form-group">
                <label>Description (Option)<span style="color:#b12f1f;">*</span></label> 
                <textarea class="form-control" name="account_desc" rows="4"></textarea>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <div class="text-center">
            <button class="btn btn-info btn-sm btn-flat" style="width: 120px;" id="btnAddNewAccount">Save</button>
            <a href="#" class="btn btn-default btn-sm" data-dismiss="modal">Cancel</a>
          </div>
        </div>
      </div>      
    </form>
  </div>
</div>
 -->
<div class="modal" id="myAlert" role="dialog" data-backdrop="static" data-keyboard="true">
  <div class="modal-dialog modal-sm">    
    <form method="POST" action="<?php echo e(route('addNewAccount')); ?>" id="add_new_account_form">
      <div class="modal-content">        
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><strong>Delete line item</strong></h4>
        </div>
        <div class="modal-body">
          <strong>You must have at least 2 line items.</strong>        
        </div>
        <div class="modal-footer">
          <div class="text-center">
            <a href="#" class="btn btn-danger btn-xs" data-dismiss="modal">OK</a>
          </div>
        </div>    
      </div>  
    </form>
  </div>
</div>

<div class="modal" id="myEditForm" role="dialog" data-backdrop="static" data-keyboard="true">
  <div class="modal-dialog modal-lg">    
    <form method="POST" action="<?php echo e(route('editJournal')); ?>" id="edit_account_journ_form">
      <?php echo e(csrf_field()); ?>

      <input type="hidden" name="edit" id="edit_id">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><strong>Update journal for this project file Number <b id="project_fileno"></b></strong></h4>
        </div>
        <div class="modal-body">
         <table>
            <tr>
              <th>Descriptions</th>
              <th width="200px">Account Type</th>
              <th width="200px">Account Name</th>
              <th width="120px">Debit</th>
              <th width="120px">Credit</th>
            </tr>
            <tr>
              <td>
                <textarea class="form-control" name="edesc" rows="1" id="edesc"></textarea>
              </td>
              <td>
                <select class="form-control account_type edit_account_type input-sm" name="edit_account_type" data-type="account_name" required="">
                  <option value="0">Choose Account Types</option>
                  <?php $__currentLoopData = App\AccountType::where('status', 1)->orderBy('account_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($acc->id); ?>"><?php echo e($acc->account_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </td>                           
              <td style="position: relative;">
                <select class="form-control input-sm edit_account_name" name="edit_account_name" id="dropdown-account_name">
                  <?php $__currentLoopData = App\AccountName::where('status', 1)->orderBy('account_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($acc->id); ?>"><?php echo e($acc->account_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </td>
              <td>
                <input type="text" class="form-control input-sm text-right balance number_only" data-type="debit" name="edebit" id="debit" placeholder="00.0" >
              </td>
              <td>
                <input type="text" class="form-control input-sm text-right balance number_only" data-type="credit" name="ecredit" id="credit" placeholder="00.0">
              </td>
            </tr>
         </table>  
        </div>
        <div class="modal-footer">
          <div class="text-center">
            <div class="col-md-3 col-md-offset-4">
              <button class="btn btn-info btn-sm btn-block btn-flat" id="btnEditJournal">Save</button>
            </div>
            <div class="col-md-1">
              <div class="row">
                <a href="#" class="btn btn-danger btn-sm btn-block btn-flat" data-dismiss="modal">OK</a>
              </div>
            </div>
            <div class="clearfix"></div>
          </div>
        </div>    
      </div>  
    </form>
  </div>
</div>

<script type="text/javascript">
$(document).ready(function(){
  $("#addNewLine").on("click", function(){
    $("tbody#data_payment_option tr:last").after(' <tr><td><textarea class="form-control" rows="1" name="desc[]"></textarea></td><td><select class="form-control input-sm account_type" name="account_type[]" data-type="account_name" required><option value="0">Choose Account Types</option><?php $__currentLoopData = App\AccountType::where('status', 1)->orderBy('account_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($acc->id); ?>"><?php echo e($acc->account_name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></td><td style="position:relative"> <select class="form-control input-sm" name="account_name[]" id="dropdown-account_name">                   </select></td><td><input type="text" class="form-control input-sm text-right balance  number_only" name="debit[]" data-type="debit" id="debit" placeholder="00.0"></td><td><input type="text" class="form-control input-sm text-right balance number_only" name="credit[]" data-type="credit" id="credit" placeholder="00.0"></td> <td class="text-center" style="background: #ddd;"><span class="btnRemoveEntry"><i class="fa fa-times-circle" style="font-size: 19px;"></i></span></td></tr>');
    });
  });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>