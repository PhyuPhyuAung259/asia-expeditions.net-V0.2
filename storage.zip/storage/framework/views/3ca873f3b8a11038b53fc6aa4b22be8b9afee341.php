<?php $__env->startSection('title', 'Tour Edit'); ?>
<?php $active = 'tours'; 
  $subactive ='tour/create/new';
  use App\component\Content;
  $countryId = isset($tour->country_id) ? $tour->country_id : Auth::user()->country_id;
?>
<?php $__env->startSection('content'); ?>
  <div class="wrapper">
    <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content"> 
        <div class="row">
          <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="col-lg-12"><h3 class="border">Tour Management</h3></div>
          <form method="POST" action="<?php echo e(route('updateTour')); ?>">
              <?php echo e(csrf_field()); ?>

              <input type="hidden" name="eid" value="<?php echo e($tour->id); ?>">
              <section class="col-lg-9 connectedSortable">
                <div class="card">                                
                  <div class="row">
                    <div class="col-md-6 col-xs-12">
                      <div class="form-group">
                        <label>Tour name<span style="color:#b12f1f;">*</span></label> 
                        <input type="text" placeholder="Tour Name" class="form-control" name="title" value="<?php echo e($tour->tour_name); ?>" required >
                      </div> 
                    </div>        
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Country <span style="color:#b12f1f;">*</span></label> 
                        <select class="form-control country" name="country" data-type="country" data-locat="data" required>
                          <option>--Choose--</option>
                          <?php $__currentLoopData = App\Country::where('country_status', 1)->orderBy('country_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($con->id); ?>" <?php echo e($tour->country_id == $con->id ? 'selected':''); ?>><?php echo e($con->country_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>City <span style="color:#b12f1f;">*</span></label> 
                        <select class="form-control" name="city" id="dropdown-data" required>
                          <?php $__currentLoopData = App\Province::where(['province_status'=> 1,'country_id' =>$countryId])->orderBy('province_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pro->id); ?>" <?php echo e($tour->province_id == $pro->id ? 'selected':''); ?>><?php echo e($pro->province_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Tour Type <span style="color:#b12f1f;">*</span></label>
                         <div class="btn-group" style="display: block;">
                            <button type="button" class="form-control " data-toggle="dropdown" aria-haspopup="false" aria-expanded="false" data-backdrop="static" data-keyboard="false" role="dialog" data-backdrop="static" data-keyboard="false">
                             <span class="pull-left"> Tour Type </span><span class="pull-right"><i class="caret"></i></span>
                            </button>  
                            <div class="obs-wrapper-search">
                              <div class="">
                                <input type="text" data-url="<?php echo e(route('getFilter')); ?>" id="data_filter" class="form-control" >
                              </div>
                              <ul class="dropdown-data" style="width: 100%;" id="Show_date">
                                <?php $__currentLoopData = App\Business::where(['category_id'=>1, 'status'=>1])->orderBy('name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                  <div class="checkbox" style="margin:0px">
                                    <input id="checkid<?php echo e($key); ?>" type="checkbox" name="type[]" value="<?php echo e($cat->id); ?>" <?php echo e(in_array($cat->id, explode(',', $dataId)) ? 'checked':''); ?>> 
                                    <label style="position: relative;top: 5px;" for="checkid<?php echo e($key); ?>"><?php echo e($cat->name); ?></label>
                                  </div>
                                </li>                           
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="clearfix"></div>
                              </ul>
                            </div>
                          </div>
                      </div>
                    </div>                 
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Destination<span style="color:#b12f1f;">*</span></label>
                         <input type="text" name="destination" class="form-control" placeholder="Destination" required value="<?php echo e($tour->tour_dest); ?>">
                      </div>
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Days/Nights<span style="color:#b12f1f;">*</span></label> 
                        <input type="text" name="daynight" class="form-control" placeholder="Days/Nights" required value="<?php echo e($tour->tour_daynight); ?>">
                      </div>
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Price <small>(<?php echo e(Content::currency()); ?>)</small></label> 
                        <input type="text" name="tour_price" class="form-control number_only" placeholder="00.00 <?php echo e(Content::currency()); ?>" value="<?php echo e($tour->tour_price); ?>" required>
                      </div>
                    </div>
                  </div>  
                  <div class="form-group">
                    <label>Service Included/Exluded</label>
                    <script src="<?php echo e(asset('adminlte/editor/tinymce.min.js')); ?>"></script>
                    <textarea class="form-control my-editor" name="tour_remark" rows="6" placeholder="Enter ..."><?php echo old('tour_remark', $tour->tour_remark); ?></textarea>             
                  </div>
                  <div class="form-group">
                    <label>Hightlights</label>
                    <textarea class="form-control my-editor" name="tour_hight" rows="6" placeholder="Enter ..."><?php echo old('tour_hight', $tour->tour_intro); ?></textarea>             
                  </div>
                  <div class="form-group">
                    <label>Description</label>
                    <textarea class="form-control my-editor" name="tour_desc" rows="6" placeholder="Enter ..."><?php echo old('tour_desc', $tour->tour_desc); ?></textarea>             
                  </div>
                  <div class="form-group">
                    <div class="col-md-2 col-xs-6">
                      <div class="form-group">
                        <label>Website</label>&nbsp;
                        <label style="font-weight: 400;"> <input type="radio" name="web" value="1"<?php echo e($tour->web == 1 ? 'checked':''); ?>>Yes</label>&nbsp;&nbsp;
                        <label style="font-weight: 400;"> <input type="radio" name="web" value="0" <?php echo e($tour->web == 1 ? '':'checked'); ?>>No</label>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Status</label>&nbsp;
                        <label style="font-weight:400;"> <input type="radio" name="status" value="1" <?php echo e($tour->tour_status == 1 ? 'checked':''); ?>>Publish</label>&nbsp;&nbsp;
                        <label style="font-weight: 400;"> <input type="radio" name="status" value="0" <?php echo e($tour->tour_status == 1 ? '':'checked'); ?>>UnPublish</label>
                      </div> 
                    </div>
                  </div>             
                </div>
              </section>
              <section class="col-lg-3 connectedSortable">
                <div class="panel panel-default">
                  <div class="panel-body">
                    <div id="wrap-feature-image" style="position:relative;" class="<?php echo e($tour->tour_photo ? 'open-img':''); ?>">
                      <input type="hidden" name="user_id" value="<?php echo e($tour->user_id); ?>">
                      <input type="hidden" name="image" id="data-img" value="<?php echo e($tour->tour_photo); ?>">
                      <img id="feature-img" src="<?php echo e(Content::urlthumbnail($tour->tour_photo, $tour->user_id)); ?>" style="width:100%;display:none;margin-bottom:12px;" class="btnUploadFiles" data-type="single-img" data-toggle="modal" data-target="#myUpload">
                      <i id="removeImage" class="fa fa-remove (alias)" title="Remove picture" style="display: none;"></i>
                    </div>
                    <a href="#uploadfile" class="btnUploadFiles" data-type="single-img" data-toggle="modal" data-target="#myUpload">Set Feature Image</a>
                  </div>
                  <div class="panel-footer">Feature Image</div>
                </div>
                <div class="panel panel-default">
                  <div class="panel-body" style="padding: 8px;">
                    <div id="wrap-gallery-image" style="position:relative;">
                    <?php 
                      $gallery = explode("|", rtrim($tour->tour_picture, "|"));
                    ?>
                      <ul class="list-ustyled">
                        <?php if(!empty($tour->tour_picture)): ?>                        
                          <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li data-url="<?php echo e($img); ?>"><i class="removegallery fa fa-remove (alias)" title="Remove picture" style="display:none;"></i>
                              <input type="hidden" name="gallery[]" value="<?php echo e($img); ?>">  
                              <img src="<?php echo e(Content::urlthumbnail($img, $tour->user_id)); ?>" style='width:100%;'/></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </ul>                    
                      <div class="clearfix"></div>
                      <i id="removeImage" class="fa fa-remove (alias)" title="Remove picture" style="display: none;"></i>
                    </div>
                    <a href="#uploadfile" class="btnUploadFiles" data-type="multi-img" data-toggle="modal" data-target="#myUpload">Set Gallery Image</a>
                  </div>
                  <div class="panel-footer">Gallery Image</div>
                </div>

                <div class="form-group"> 
                  <button type="submit" class="btn btn-success btn-flat btn-sm">Submit</button>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading"><strong>Tours Facilities</strong></div>
                    <div class="panel-body scrolTourFeasility" style="padding: 8px; max-height: 277px; ">
                      <ul class="list-unstyled">
                        <?php $__currentLoopData = \App\Service::where('service_cat',0)->orderBy('service_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li>
                            <div class="checkMebox">
                              <label>
                                <span style="position:relative; top:4px;"> 
                                  <i class="fa <?php echo e(in_array($sv->id, explode(',', $datatour)) ? 'fa fa-check-square-o':'fa-square-o'); ?>"></i>
                                  <input type="checkbox" name="tour_feasilitiy[]" value="<?php echo e($sv->id); ?>"<?php echo e(in_array($sv->id, explode(',', $datatour)) ? 'checked':''); ?>>&nbsp;
                                </span>
                                <span><?php echo e($sv->service_name); ?></span>
                              </label>
                            </div>
                          </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                    </div>
                    <div class="panel-footer"></div>
                </div>

                <div class="panel panel-default">
                    <div class="panel-heading"><strong>Accommodation</strong></div>
                    <div class="panel-body scrolTourAccommodation" style="padding: 8px; max-height: 277px; overflow: auto;">
                      <ul class="list-unstyled">
                        <?php $__currentLoopData = \App\Supplier::where(['business_id'=>1, 'supplier_status'=>1, 'country_id'=> $tour->country_id])->orderBy('supplier_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li>
                            <div class="checkMebox">
                              <label>
                                <span style="position:relative; top:4px;"> 
                                  <i class="fa <?php echo e(in_array($sup->id, explode(',', $tourAccommodation)) ? 'fa fa-check-square-o':'fa-square-o'); ?>"></i>
                                  <input type="checkbox" name="tour_supplier[]" value="<?php echo e($sup->id); ?>"<?php echo e(in_array($sup->id, explode(',', $tourAccommodation)) ? 'checked':''); ?>>&nbsp;
                                </span>
                                <span><?php echo e($sup->supplier_name); ?></span>
                              </label>
                            </div>
                          </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                    </div>
                    <div class="panel-footer"></div>
                </div>
              </section>
          </form>
        </div>
      </section>
    </div>  
  </div>
  <?php echo $__env->make('admin.include.windowUpload', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.editor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>