<?php $__env->startSection('title', 'Miscellaneous Assignment'); ?>
<?php
  	$active = 'restaurant/menu'; 
  	$subactive = 'misc/service';
  	use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  	<?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  	<?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="content-wrapper">
	    <section class="content"> 
		    <div class="row">
		      	<?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		        <section class="col-lg-12 ">
		          	<h3 class="border" style="text-transform:capitalize;">Miscellaneouse Assignment For File Number <b><?php echo e($project->project_number); ?> </b></h3>
		            <table class="datatable table table-hover table-striped">
			            <thead>
			                <tr>
			                  <th width="100px">Date</th>
			                  <th>City</th>
			                  <th>Tour</th>		                 
			                  <th class="text-center" width="20px">Option</th>
			                </tr>
			            </thead>
		              	<tbody>
		                <?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                	<?php 
			                	$pro = App\Province::find($tran->province_id);
						        $miscService = App\BookMisc::where(['project_number'=>$tran->book_project,'book_id'=>$tran->id])->orderBy("created_at", "DESC")->get();
				        	?>
			                <tr>
				                <td><?php echo e(Content::dateformat($tran->book_checkin)); ?></td>
				                <td><?php echo e($pro->province_name); ?></td>         
				                <td>
				                  	<div><strong><?php echo e($tran->tour_name); ?></strong></div>
						            <?php if($miscService->count() > 0): ?> 
						            	<hr  style="border-top:none; border-bottom: 1px solid #ddd;padding: 5px 0px; margin-top:0px; margin-bottom: 0px;">
					                  	<div class="row "style="font-style: italic; color: #c36f04;" >
						                  	<div class="col-md-6">
						                  		<p><strong>Service Name</strong></p>
						                  	</div>
						                  	<div class="col-md-1">
						                  		<p><strong>Pax No.</strong></p>
						                  	</div>
						                  	<div class="col-md-1">
						                  		<p><strong>Price<?php echo e(Content::currency()); ?></strong></p>
						                  	</div>
						                  	<div class="col-md-1">
						                  		<p><strong>Amount</strong></p>
						                  	</div>
						                  	<div class="col-md-1">
						                  		<p><strong>Price<?php echo e(Content::currency(1)); ?></strong></p>
						                  	</div>
						                  	<div class="col-md-2">
						                  		<p><strong>Amount</strong></p>
						                  	</div>
					                  	</div>				                
						            	<?php $__currentLoopData = $miscService; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $misc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                  	<div class="row row-item">
						                  	<div class="col-md-6">
						                  		<p><?php echo e(isset($misc->servicetype->name) ? $misc->servicetype->name : ''); ?></p>
						                  	</div>
						                  	<div class="col-md-1">
						                  		<p><?php echo e($misc->book_pax); ?></p>
						                  	</div>
						                  	<div class="col-md-1">
						                  		<p><?php echo e(Content::money($misc->price)); ?></p>
						                  	</div>
						                  	<div class="col-md-1">
						                  		<p><?php echo e(Content::money($misc->amount)); ?></p>
						                  	</div>
						                  	<div class="col-md-1">
						                  		<p><?php echo e(Content::money($misc->kprice)); ?></p>
						                  	</div>
						                  	<div class="col-md-2">
						                  		<span><strong><?php echo e(Content::money($misc->kamount)); ?></strong></span> 
						                  		
						                  		<span class="pull-right">
						                  			<a class="btnEditTran" data-type="apply_misc" href="#" data-id="<?php echo e($misc->id); ?>" data-country="<?php echo e($misc->country_id); ?>" data-province="<?php echo e($misc->province_id); ?>" data-pax="<?php echo e($misc->book_pax); ?>" data-restmenu="<?php echo e($misc->service_id); ?>" data-price="<?php echo e($misc->price); ?>" data-kprice="<?php echo e($misc->kprice); ?>" data-remark="<?php echo e($misc->remark); ?>" data-toggle="modal" data-target="#myModal"><i style="font-size: 16px;" class="fa fa-pencil"></i></a>

						                  			<span class="btn btn-xs btnRefresh" title="Clear this service" data-type="clear-misc" data-id="<?php echo e($misc->id); ?>">
						                  				<label class="icon-list ic-trash"></label>
						                  			</span>
						                  		</span>
						                  	</div>
					                  	</div>
					                  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                <?php endif; ?>
				                </td>
				                <td class="text-center">                      
				                    <span class="btnEditTran" data-country="<?php echo e($tran->country_id); ?>" data-province="<?php echo e($tran->province_id); ?>" data-id="<?php echo e($tran->id); ?>" data-toggle="modal" data-target="#myModal">
				                      	<i style="padding:1px 2px;" class="fa fa-plus-circle btn btn-info btn-xs"> </i> 
				                    </span>                   
				                </td>                     
			                </tr>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		              	</tbody>
		            </table>
		        </section>
		    </div>
	    </section>
	</div>
</div>

<div class="modal fade" id="myModal" role="dialog" data-backdrop="static" data-keyboard="true">
	<div class="modal-dialog modal-lg">
	    <form method="POST" action="<?php echo e(route('assignMisc')); ?>">
		    <div class="modal-content">        
		        <div class="modal-header">
		          <button type="button" class="close" data-dismiss="modal">&times;</button>
		          <h4 class="modal-title"><strong> Miscellaneouse Assignment</strong></h4>
		        </div>
		        <div class="modal-body">
		          <?php echo e(csrf_field()); ?>    
		          	<input type="hidden" name="bookid" id="tour_id">
		          	<input type="hidden" name="project_number" id="project_number" value="<?php echo e($project->project_number); ?>">
			        <div class="row">
			            <div class="col-md-6 col-xs-6">
				            <div class="form-group">
				                <label>Country <span style="color:#b12f1f;">*</span></label> 
				                <select class="form-control country" id="country" name="country" data-type="country" data-pro_of_bus_id="misc_type" data-locat="data" required>
				                    <option value="">Country</option>
				                  <?php $__currentLoopData = App\Country::countryByProject(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                    <option value="<?php echo e($con->id); ?>"><?php echo e($con->country_name); ?></option>
				                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                </select>
				            </div> 
			            </div>
			            <div class="col-md-6 col-xs-6">
				            <div class="form-group">
				                <label>City Name <span style="color:#b12f1f;">*</span></label> 
				                <select class="form-control province" name="city" data-type="apply_misc" id="dropdown-data" required>
				                  <option value="">City</option>
				                  <?php $__currentLoopData = App\Province::where(['province_status'=> 1])->orderBy('province_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                    <option value="<?php echo e($pro->id); ?>"><?php echo e($pro->province_name); ?></option>
				                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                </select>
				             </div>
			            </div>
			        </div>
			        <div class="row">
			            <div class="col-md-6 col-xs-6">
				            <div class="form-group">
				                <label>Service Type</label>
				               	<select class="form-control tran_name service_type" name="service_type" id="dropdown-transervice">
				               		<option>Select Service</option>
				               		<?php $__currentLoopData = App\MISCService::where(['status'=> 1])->orderBy('name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				               		<option value="<?php echo e($sv->id); ?>" data-price="<?php echo e($sv->price); ?>" data-kprice="<?php echo e($sv->kprice); ?>"><?php echo e($sv->name); ?></option>
				               		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				               	</select>
				            </div>
			            </div>
			            <div class="col-md-6 col-xs-6">
				            <div class="form-group">
				                <label>Pax No.</label>
				               	<input type="number" name="book_pax" id="book_pax" class="form-control text-center" value="1">
				            </div>
			            </div>
			            <div class="col-md-6 col-xs-6">
				            <div class="form-group">
				                <label>Price <?php echo e(Content::currency()); ?></label>
				                <input type="text" name="price" id="price" class="form-control" placeholder="00.0" >
				            </div>
			            </div>
			            <div class="col-md-6 col-xs-6">
			              	<div class="form-group">
				                <label>Price <?php echo e(Content::currency(1)); ?></label>
				                <input type="text" name="kprice" id="kprice" class="form-control" placeholder="00.0" >
				            </div>
			            </div>
			        </div>
			        <div class="row">
			        	<div class="col-md-12 col-xs-12">
			              	<div class="form-group">
				                <label>Remark</label>
				                <textarea class="form-control" name="remark" id="remark" rows="5" placeholder="Remark here..."></textarea>
				            </div>
			            </div>
			        </div>
		        </div>
		        <div class="modal-footer">
		          	<button type="submit" class="btn btn-success btn-flat btn-sm">Publish</button>
		          	<a href="#" class="btn btn-danger btn-flat btn-sm" data-dismiss="modal">Cancel</a>
		        </div>
		    </div>      
	    </form>
	</div>
</div>
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>