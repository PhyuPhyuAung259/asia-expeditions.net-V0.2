<?php $__env->startSection('title', ' Booking Form'); ?>
<?php 
use App\component\Content;
 ?>
<?php $__env->startSection('content'); ?>
	<div class="col-lg-12">
		<h3 class="text-center"><strong class="btborder" style="text-transform:uppercase;">Booking Form</strong></h3>
		<?php 
		$comadd = \App\Company::where('country_id', \Auth::user()->country_id)->first();
		?>
		<table class="table" style="margin-bottom: 0px;">
			<tr>
				<td style="border-top: none; vertical-align: bottom;">
					<div><b>File / Project No.</b>: <?php echo e($project->project_fileno ? $project->project_prefix.'-'.$project->project_fileno : $project->project_number); ?></div>
					<div><b>Issue Date</b>: <?php echo e(Date('d-M-Y')); ?></div>
				</td>
				<td style="border-top: none" class="text-right">
					<img src="<?php echo e(url('/')); ?>/img/<?php echo e($comadd->logo); ?>" width="135px">
				</td>
			</tr>
		</table>
		<div class="col-md-12">			
			<div class="pull-right hidden-print">
				<a href="javascript:void(0)" onclick="window.print();"><span class="fa fa-print btn btn-primary"></span></a>
			</div>
		</div>
		<table class="table" style="width: 100%;" >
			<tr>				
				<td style="border-top: none" colspan="2">
					<div class="well" style="padding: 4px;margin-bottom: 0px; background-color: #ddd0;">
						<address style="margin-bottom: 0px;">
							<i class="glyphicon glyphicon-user"></i>&nbsp;&nbsp;<?php echo e(isset($bcruise->cruise->supplier_name) ? $bcruise->cruise->supplier_name : ''); ?><br>
						 	<i class="glyphicon glyphicon-home"></i>&nbsp;&nbsp;<?php echo e(isset($bcruise->cruise->supplier_address) ? $bcruise->cruise->supplier_address : ''); ?><br>
							<i class="glyphicon glyphicon-phone-alt"></i>&nbsp;&nbsp;<?php echo e(isset($bcruise->cruise->supplier_phone) ? $bcruise->cruise->supplier_phone : ''); ?> / <?php echo e(isset($bcruise->cruise->supplier_phone2) ? $bcruise->cruise->supplier_phone2 : ''); ?><br>
							<i class="glyphicon glyphicon-envelope"></i>&nbsp;&nbsp;<?php echo e(isset($bcruise->cruise->supplier_email) ? $bcruise->cruise->supplier_email : ''); ?><br>
						</address>
					</div>
				</td>
			</tr>
			<tr>
				<td style="border-top: none" colspan="2"><p>Dear Reservation Team,<br>
					Could you please kindly book and confirm the following reservation?</p>
				</td>
			</tr>
			<tr>
				<td style="border-top: none" colspan="2">					
					<table class="table table-padding">
						<tr>
							<td width="230px" class="text-right hotel_booking"><strong>Client Name</strong>:</td><td class="text-left"><?php echo e($project->project_client); ?></td>
							<td class="text-right"><strong>Room Type</strong>:</td><td class="text-left"><?php echo e(isset($bcruise->room->name) ? $bcruise->room->name : ''); ?></td>
						</tr>
						<tr>
							<td class="text-right"><strong>Check-In</strong>:</td><td class="text-left"><?php echo e(Content::dateformat($booking->book_checkin)); ?></td>
							<td class="text-right"><strong>Check-Out</strong>:</td><td class="text-left"><?php echo e(Content::dateformat($booking->book_checkout)); ?></td></tr>
						<tr>
							<td class="text-right"><strong>Number of Room <?php echo e(isset($bcruise->category->name) ? $bcruise->category->name : ''); ?></strong>:</td><td class="text-left"><?php echo e($bcruise->cabin_pax); ?></td>
							<td class="text-right"><strong>Number Of Pax</strong>:</td><td class="text-left"><?php echo e($booking->book_pax); ?></td>
						</tr>
						<tr>
							<td class="text-right"><strong>Days / Nights</strong>:</td><td class="text-left"><?php echo e($bcruise->book_day); ?></td>
							<td></td><td></td>
						</tr>
					</table>
				</td>
			</tr>
			<tr>
				<td colspan="2" style="border-top: none" >
					<div class="well" style="padding: 1px;margin-bottom: 0px; background-color: #ddd0;">
						<address style="margin-bottom: 0px;">
							<strong>Remark:</strong>
							<?php echo e($bcruise->remark); ?>

						</address>
					</div>
				</td>
			</tr>
			<tr>
				<td style="border-top: none">
					<p>Thank you very much and we look forward to receiving your confirmation soon. Should you need any further information, please do not hesitate to contact us.<br>
					With Best Regards,<br>
					Operation Department</p>
					<?php echo $comadd->address; ?>

				</td>
			</tr>
		</table>		
  	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>