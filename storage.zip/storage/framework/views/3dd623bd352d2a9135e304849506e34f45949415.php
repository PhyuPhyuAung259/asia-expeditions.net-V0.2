<?php $__env->startSection('title', 'Project Quotation'); ?>
<?php 
  $active = 'booked/project'; 
  $subactive ='booked/project?type=quotation';
  use App\component\Content;
  $status = isset($_GET['type']) ? $_GET['type'] : '';
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <div class="col-md-12">
            <h3 class="border">Project List <span class="fa fa-angle-double-right"></span>​​​ <a href="<?php echo e(route('proForm', ['type'=> 'quotation'])); ?>" class="btn btn-primary btn-sm">Add Project Quotation</a>
            </h3>
          </div>
          <form method="POST" action="<?php echo e(route('searchProject', ['project'=> 'project', 'type'=> $status])); ?>">            
            <?php echo e(csrf_field()); ?>

            <section class="col-lg-12 connectedSortable">
              <div class="col-sm-8 col-xs-12 pull-right" style="position: relative; z-index: 2;">
                <div class="col-md-3 col-xs-5">
                  <input type="hidden" value="<?php echo e(isset($projectNum) ? $projectNum : ''); ?>" id="projectNum">
                  <input class="form-control input-sm" type="text" id="from_date" name="start_date" placeholder="Date From" value="<?php echo e(isset($startDate) ? $startDate : ''); ?>" readonly>  
                </div>
                <div class="col-md-3 col-xs-5">
                  <input class="form-control input-sm" type="text" id="to_date" name="end_date" placeholder="Date To" value="<?php echo e(isset($endDate) ? $endDate : ''); ?>" readonly>  
                </div>
                <div class="col-md-2" style="padding: 0px;">
                  <button class="btn btn-primary btn-sm" type="submit">Search</button>
                </div>
              </div>
              <table class="datatable table table-hover table-striped">
                <thead>
                  <tr>                       
                    <th width="65">Project No.</th>
                    <th>ClientName</th>
                    <th style="width: 62.8125px;">Start Date</th>
                    <th style="width: 58.8125px;">End Date</th>
                    <th>Agent</th>
                    <th style="width: 79.8125px;">User</th>
                    <th>Country</th>
                    <th class="text-center" style="width: 230px;">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                      $sup = App\Supplier::find($project->supplier_id);
                      $user= App\User::find($project->UserID);
                      $con = App\Country::find($project->country_id);
                    ?>
                    <tr>
                      <td width="75"><?php echo e($project->project_number); ?></td>
                      <td><?php echo e($project->project_client); ?></td>
                      <td><?php echo e(Content::dateformat($project->project_start)); ?></td>
                      <td><?php echo e(Content::dateformat($project->project_end)); ?></td>
                      <td><?php echo e(isset($sup->supplier_name) ? $sup->supplier_name : ''); ?></td>
                      <td><?php echo e(isset($user->fullname) ? $user->fullname : ''); ?></td>
                      <td><?php echo e(isset($con->country_name) ? $con->country_name : ''); ?></td>
                      <td class="text-center">
                        <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$project->project_number, 'type'=>'details'])); ?>" title="Program Details">
                          <label style="cursor:pointer;" class="icon-list ic_del_drop"></label>
                        </a>                      
                        <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$project->project_number, 'type'=>'sales'])); ?>" title="Prview Details">
                          <label style="cursor:pointer;" class="icon-list ic_delpro_drop"></lable>
                        </a> 
                      
                        <a target="_blank" href="<?php echo e(route('proForm', ['ref'=> $project->project_number, 'type' => 'quotation'])); ?>" title="Additional Booking">
                          <label style="cursor:pointer;" class="icon-list ic_book_add"></lable>
                        </a>     
                        <a target="_blank" href="<?php echo e(route('proFormEdit', ['project'=> $project->project_number, 'action'=>'copy'])); ?>" title="Edit Project">
                          <label style="cursor:pointer;" class="icon-list ic_book_project"></lable>
                        </a>    
                        <a target="_blank" href="<?php echo e(route('preProject', ['project'=> $project->project_number])); ?>" title="View One Project">
                          <label style="cursor:pointer;" class="icon-list ic_inclusion"></lable>
                        </a>   
                        <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$project->project_number, 'type'=>'details-net'])); ?>" title="Program Details Net">
                          <label style="cursor:pointer;" class="icon-list ic_del_net"></lable>
                        </a> 

                        <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$project->project_number, 'type'=>'sales-net'])); ?>" title="Program Sales Net">
                          <label style="cursor:pointer; background-position: 0 -1574px !important;" class="icon-list ic_delpro_drop"></lable>
                        </a> 
                        <a style="font-size: 13px;position: relative;top: -2px;" target="_blank" href="<?php echo e(route('previewProject', ['project'=>$project->project_number, 'type'=>'group-price'])); ?>"  title="Project Group Price">
                          <label style="cursor:pointer; background-position: 0 -1429px !important;" class="icon-list ic_delpro_drop"></lable>
                        </a>   
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table> 
            </section>
          </form>
        </div>
    </section>
</div>

<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
  $(document).ready(function(){
    $(".datatable").DataTable({
      language: {
        searchPlaceholder: "File/Project No., ClientName"
      }
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>