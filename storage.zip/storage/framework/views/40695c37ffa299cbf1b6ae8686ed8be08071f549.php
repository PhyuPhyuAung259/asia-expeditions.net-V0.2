<?php $__env->startSection('title', $title); ?>
<?php 
	use App\component\Content;
	$comadd = \App\Company::where('country_id', \Auth::user()->country_id)->first();
?>

<?php $__env->startSection('content'); ?>
<?php if($guideb->get()->count() > 0): ?>
<?php 
	$guid = \App\BookGuide::whereIn("guide_book.id", $_GET['checkedguide'])->first();
	$guid->supplier->supplier_name;
?>
<?php endif; ?>
<div class="container">
	<?php echo $__env->make('admin.report.headerReport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<div class="col-lg-12">
		<div class="pull-right hidden-print">
			<a href="javascript:void(0)" onclick="window.print();"><span class="fa fa-print btn btn-primary"></span></a>
		</div>		
		<h3 class="text-center"><span style="text-transform:capitalize; text-decoration:underline;"> Request for Guide Fees</span></h3><br><br>		
		<table class="table ">
			<tr><td style="border: none;"></td><td style="border: none;"><div><label> Issue Date</label>: <?php echo e(Content::dateformat(date('Y-m-d') )); ?></div></td></tr>
			<tr>
				<td style="width: 15%; border: none;" class="text-right">
					<p>Guide Name: </p>
					<p>Tour File / Project No.:</p>
					<p>Client Name: </p>
					<p>Tour Date:</p>
				</td>
				<td style="width: 85%; vertical-align: top; border: solid 1px #ddd;">
					<p><?php echo e($guideb->get()->count() > 0 ? $guid->supplier->supplier_name : '............................................'); ?> </p>
					<p> <?php echo e($project->project_prefix); ?>-<?php echo e($project->project_fileno ? $project->project_fileno: $project->project_number); ?></p>
					<p> <?php echo e(isset($project->project_client) ? $project->project_client : ''); ?> </p>
					<p> <i><?php echo e(Content::dateformat($project->project_start)); ?> - <?php echo e(Content::dateformat($project->project_end)); ?></i></p>
				</td>
			</tr>
			
		</table>	


		<table class="table operation-sheed table-bordered">
		<?php $n = 1; 
			$getTotalUSd = 0;
			$getTotalkyat = 0;
		?>
			<tr class="header-row">
				<th width="10px"><b>No.</b></th>
				<th>Description</th>
				<th>Service Name</th>
				<th class="text-center">Date</th>
				<th class="text-center">Qty</th>
				<th class="text-center"><?php echo e(Content::currency()); ?> Price </th>
				<th class="text-center">Amount <?php echo e(Content::currency()); ?></th>
				<th class="text-center"><?php echo e(Content::currency(1)); ?> Price </th>
				<th class="text-center">Amount <?php echo e(Content::currency(1)); ?></th>
			</tr>
			<?php if($hotelb->get()->count() > 0): ?>
				<?php $__currentLoopData = $hotelb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php 
					$hbook = \App\Booking::find($hb->book_id);
				?>
				<tr>
					<td class="text-center"><?php echo e($n++); ?></td>
					<td><?php echo e(isset($hb->hotel->supplier_name) ? $hb->hotel->supplier_name : ''); ?></td>
					<td class="text-left"><?php echo e(isset($hb->room->name) ? $hb->room->name : ''); ?></td>
					<td><?php echo e(Content::dateformat($hb->checkin)); ?> - <?php echo e(Content::dateformat($hb->checkout)); ?></td>
					<td class="text-center"><?php echo e($hb->book_day); ?></td>
					<td class="text-right">
						<?php if( $hb->nsingle > 0 ): ?>
							<?php $hprice = $hb->nsingle; ?>
						<?php elseif($hb->ntwin > 0): ?>
							<?php $hprice = $hb->ntwin; ?>
						<?php elseif($hb->ndouble > 0): ?>
							<?php $hprice = $hb->ndouble; ?>
						<?php elseif($hb->nextra > 0): ?>
							<?php $hprice = $hb->nextra; ?>
						<?php else: ?>
							<?php $hprice = $hb->nchextra; ?>
						<?php endif; ?>
						<?php echo e(Content::money($hprice)); ?>

					</td>
					<td class="text-right"><?php echo e(Content::money($hb->net_amount)); ?></td>
					<td></td>
					<td></td>
					<?php $getTotalUSd = $getTotalUSd + $hb->net_amount; ?>

				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>

			<?php if($guideb->get()->count() > 0): ?>
				<?php $__currentLoopData = $guideb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php 
						$dateb = \App\Booking::find($bg->book_id);
						$sb = \App\GuideService::find($bg->service_id);
						$langb = \App\GuideLanguage::find($bg->language_id);
					?>
					<tr>	
						<td class="text-center"><?php echo e($n++); ?></td>
						<td><?php echo e(isset($sb->title) ? $sb->title : ''); ?></td>
						<td class="text-left"><?php echo e(isset($langb->name) ? $langb->name : ''); ?></td>
						<td><?php echo e(Content::dateformat($dateb->book_checkin)); ?></td>
				        <td class="text-center"></td>
						<td class="text-right"><?php echo e(Content::money($bg->price)); ?></td>
						<td class="text-right"><?php echo e(Content::money($bg->price)); ?></td>
						<td class="text-right"><?php echo e(Content::money($bg->kprice)); ?></td>
						<td class="text-right"><?php echo e(Content::money($bg->kprice)); ?></td>
					</tr>
					<?php $getTotalUSd = $getTotalUSd + $bg->price; ?>
					<?php $getTotalkyat = $getTotalkyat + $bg->kprice; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>

			<?php if($transportb->get()->count() >0): ?>				
				<?php $__currentLoopData = $transportb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php 				
					$dateb = \App\Booking::find($bk->book_id);
					$tranb = \App\BookTransport::find($bk->tran_id);
				?>
				<tr>	
					<td class="text-center"><?php echo e($n++); ?></td>					
					<td><?php echo e(isset($tranb->service->title) ? $tranb->service->title : ''); ?></td>
			        <td class="text-left"><?php echo e(isset($tranb->vehicle->name) ? $tranb->vehicle->name : ''); ?></td>
			        <td><?php echo e(Content::dateformat($dateb->book_checkin)); ?></td>
					<td class="text-center"></td>
					<td class="text-right"><?php echo e(Content::money($bk->price)); ?></td>	
					<td class="text-right"><?php echo e(Content::money($bk->price)); ?></td>		
					<td class="text-right"><?php echo e(Content::money($bk->kprice)); ?></td>	
					<td class="text-right"><?php echo e(Content::money($bk->kprice)); ?></td>		
				</tr>
				<?php $getTotalUSd = $getTotalUSd + $bk->price; ?>
				<?php $getTotalkyat = $getTotalkyat + $bk->kprice; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>

			<?php if($restaurantb->get()->count() > 0): ?>
				<?php $__currentLoopData = $restaurantb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>	
					<td class="text-center"><?php echo e($n++); ?></td>
					<td><?php echo e(isset($rb->supplier->supplier_name) ? $rb->supplier->supplier_name : ''); ?></td>         
				    <td><?php echo e(isset($rb->rest_menu->title) ? $rb->rest_menu->title : ''); ?></td>
				    <td><?php echo e(Content::dateformat($rb->start_date)); ?></td>
				    <td class="text-center"><?php echo e($rb->book_pax); ?></td>
					<td class="text-right"><?php echo e(Content::money($rb->price)); ?></td>
	                <td class="text-right"><?php echo e(Content::money($rb->amount)); ?></td>
	                <td class="text-right"><?php echo e(Content::money($rb->kprice)); ?></td>
                  	<td class="text-right"><?php echo e(Content::money($rb->kamount)); ?></td>
				</tr>
				<?php $getTotalUSd = $getTotalUSd + $rb->amount; ?>
				<?php $getTotalkyat = $getTotalkyat + $rb->kamount; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>

			<?php if($entranb->get()->count() > 0): ?>
				<?php $__currentLoopData = $entranb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>	
					<td class="text-center"><?php echo e($n++); ?></td>
					<td><?php echo e(isset($ent->entrance->name) ? $ent->entrance->name : ''); ?></td>       
					<td></td>
					<td><?php echo e(Content::dateformat($ent->start_date)); ?></td>
				    <td class="text-center"><?php echo e($ent->book_pax); ?></td>
	                <td class="text-right"><?php echo e(Content::money($ent->price)); ?></td>
	                <td class="text-right"><?php echo e(Content::money($ent->amount)); ?></td>
	                <td class="text-right"><?php echo e(Content::money($ent->kprice)); ?></td>
                  	<td class="text-right"><?php echo e(Content::money($ent->kamount)); ?></td>
				</tr>
				<?php $getTotalUSd = $getTotalUSd + $ent->amount; ?>
				<?php $getTotalkyat = $getTotalkyat + $ent->kamount; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>

			<?php if($miscb->get()->count() > 0): ?>
				<?php $__currentLoopData = $miscb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $misc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php
					$dateb = \App\Booking::find($misc->book_id);
				?>
				<tr>	
					<td class="text-center"><?php echo e($n++); ?></td>
					<td ><?php echo e(isset($misc->servicetype->name) ? $misc->servicetype->name : ''); ?></td>    
					<td></td>   
					<td><?php echo e(Content::dateformat($dateb->book_checkin)); ?></td>
				    <td class="text-center"><?php echo e($misc->book_pax); ?></td>
	                <td class="text-right"><?php echo e(Content::money($misc->price)); ?></td>
	                <td class="text-right"><?php echo e(Content::money($misc->amount)); ?></td>
	                <td class="text-right"><?php echo e(Content::money($misc->kprice)); ?></td>
                  	<td class="text-right"><?php echo e(Content::money($misc->kamount)); ?></td>
				</tr>
				<?php $getTotalUSd = $getTotalUSd + $misc->amount; ?>
				<?php $getTotalkyat = $getTotalkyat + $misc->kamount; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>

			<?php if($flightb->get()->count() > 0): ?>
				<?php $__currentLoopData = $flightb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td class="text-center"><?php echo e($n++); ?></td>
					<td><?php echo e(isset($fb->supplier->supplier_name) ? $fb->supplier->supplier_name : ''); ?></td>
					<td><?php echo e(isset($fb->fagent->supplier_name) ? $fb->fagent->supplier_name : ''); ?></td>			
					<td><?php echo e(Content::dateformat($fb->book_checkin)); ?></td>	
					<td class="text-center"><?php echo e($fb->book_pax); ?></td>
					<td class="text-right"><?php echo e(Content::money($fb->book_price)); ?></td>
					<td class="text-right"><?php echo e(Content::money($fb->book_namount)); ?></td>
					<td class="text-right"><?php echo e(Content::money($fb->book_nkprice)); ?></td>
					<td class="text-right"><?php echo e(Content::money($fb->book_kamount)); ?></td>
				</tr>
				<?php $getTotalUSd = $getTotalUSd + $fb->book_namount; ?>
				<?php $getTotalkyat = $getTotalkyat + $fb->book_kamount; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>

			<?php if($golfb->get()->count() > 0): ?>
				<?php $__currentLoopData = $golfb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td class="text-center"><?php echo e($n++); ?></td>					
					<td><?php echo e(isset($gb->golf->supplier_name) ? $gb->golf->supplier_name : ''); ?></td>
					<td ><?php echo e(isset($gb->golf_service->name) ? $gb->golf_service->name : ''); ?></td>
					<td><?php echo e(Content::dateformat($gb->book_checkin)); ?></td>
					<td class="text-center"><?php echo e($gb->book_pax); ?></td>
					<td class="text-right"><?php echo e(Content::money($gb->book_nprice)); ?></td>
					<td class="text-right"><?php echo e(Content::money($gb->book_namount)); ?></td>
					<td class="text-right"><?php echo e(Content::money($gb->book_nkprice)); ?></td>
					<td class="text-right"><?php echo e(Content::money($gb->book_nkamount)); ?></td>
				</tr>
				<?php $getTotalUSd = $getTotalUSd + $gb->book_namount; ?>
				<?php $getTotalkyat = $getTotalkyat + $gb->book_kamount; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>

			<?php if($cruiseb->get()->count() > 0): ?>
				<?php $__currentLoopData = $cruiseb->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php 
						if (!empty($cb->nsingle) && $cb->nsingle != 0) {
							$hprice = $cb->nsingle;
						}elseif (!empty($cb->ntwin) && $cb->ntwin != 0) {
							$hprice = $cb->ntwin;
						}elseif(!empty($cb->ndouble) && $cb->ndouble != 0){
							$hprice = $cb->ndouble;
						}elseif (!empty($cb->nextra) && $cb->nextra != 0) {
							$hprice = $cb->nextra;
						}else{
							$hprice = $cb->nchextra;
						}		
					?>
				<tr> 
					<td class="text-center"><?php echo e($n++); ?></td>					
					<td><?php echo e(isset($cb->program->program_name) ? $cb->program->program_name : ''); ?></td>
					<td><?php echo e($cb->room->name); ?></td>
					<td><?php echo e(Content::dateformat($cb->checkin)); ?> - <?php echo e(Content::dateformat($cb->checkout)); ?></td>
					<td class="text-center"><?php echo e($cb->book_day); ?></td>
					<td class="text-right"><?php echo e(Content::money($hprice)); ?></td>
					<td class="text-right"><?php echo e(Content::money($cb->net_amount)); ?></td>
				</tr>
				<?php $getTotalUSd = $getTotalUSd + $cb->net_amount; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>	
			
			<tr>
				<th style="border: solid #ddd 1px; background-color: #9e9e9e3b; font-size: 16px;" colspan="10" class="text-right"> 
					<?php if($getTotalUSd): ?>
					<strong><?php echo e(Content::currency()); ?> Total: <?php echo e(Content::money($getTotalUSd)); ?></strong>, &nbsp;&nbsp;&nbsp; 
					<?php endif; ?>
					<?php if($getTotalkyat): ?>
					<strong><?php echo e(Content::currency(1)); ?> Total: <?php echo e(Content::money($getTotalkyat)); ?></strong>
					<?php endif; ?>
				</th>
			</tr>
		</table>
		<table class="table">
			<tr>
				<td style="border-top: none;"><div> Request By ....................................</div></td>
				<td style="border-top: none;"><div>  Approved By ....................................</div></td>
				<td style="border-top: none;"><div> Account Dept ...................................</div></td>
				<td style="border-top: none;"><div> Received By ....................................</div></td>
			</tr>
		</table>
		<p><b>Remark</b>
		<p><?php echo e($remark); ?></p></p>

  	</div>
</div>
<br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>