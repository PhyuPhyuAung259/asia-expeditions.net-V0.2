<?php $__env->startSection('title', "Edit Flight Schedule"); ?>
<?php $active = 'supplier/flights'; 
$subactive = 'flight-schedule/add/new';
  use App\component\Content;
?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <section class="col-lg-12 connectedSortable">
          <h3 class="border"> <i class="fa fa-plane"></i> Flight Schedule</h3>
          <div class="card">
            <form method="POST" action="<?php echo e(route('updateSchedule')); ?>">
              <?php echo e(csrf_field()); ?>    
              <input type="hidden" name="flgihtId" value="<?php echo e($flight->id); ?>">
              <div class="row">
                <div class="col-md-3 col-xs-6">
                  <div class="form-group">
                    <label>Flight Number <span style="color:#b12f1f;">*</span></label> 
                    <input type="text" class="form-control" name="flightNo" required value="<?php echo e($flight->flightno); ?>">
                  </div> 
                </div>        
                <div class="col-md-3 col-xs-6">
                  <div class="form-group">
                    <label>Country <span style="color:#b12f1f;">*</span></label> 
                    <select class="form-control country" name="country" data-type="country_flight" data-locat="data" required>
                      <?php $__currentLoopData = App\Country::countryBySupplier([4,37]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($con->id); ?>" <?php echo e($flight->country_id == $con->id ? 'selected':''); ?>><?php echo e($con->country_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div> 
                </div>
                <div class="col-md-3 col-xs-6">
                  <div class="form-group">
                    <label>City <span style="color:#b12f1f;">*</span></label> 
                    <select class="form-control" name="city" id="dropdown-country_flight" required>
                      <?php $__currentLoopData = App\Province::provinceBySupplier([4, 37], $flight->country_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($pro->id); ?>" <?php echo e($flight->province_id == $pro->id ? 'selected':''); ?>><?php echo e($pro->province_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div> 
                </div>
                <div class="col-md-3 col-xs-6">
                  <div class="form-group">
                    <label>Airlines Name <span style="color:#b12f1f;">*</span></label> 
                    <select class="form-control" name="airline">
                      <?php $__currentLoopData = App\Supplier::where(['business_id'=> 4, 'supplier_status'=>1,'company_id'=>Auth::user()->company_id])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flightagetn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($flightagetn->id); ?>" <?php echo e($flight->supplier_id == $flightagetn->id ? 'selected':''); ?> ><?php echo e($flightagetn->supplier_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div> 
                </div>               
                <div class="col-md-3 col-xs-6">
                  <div class="form-group">
                    <label>Ticketing Agents <span style="color:#b12f1f;">*</span></label>
                     <div class="btn-group" style="display: block;">
                        <button type="button" class="form-control " data-toggle="dropdown" aria-haspopup="false" aria-expanded="false">
                         <span class="pull-left">Choose Agent </span><span class="pull-right"><i class="caret"></i></span>
                        </button>  
                        <div class="obs-wrapper-search">
                          <div>
                            <input type="text" id="search" onkeyup="myFunction()" class="form-control" >
                          </div>
                          <ul class="dropdown-data" style="width: 100%;" id="Show_date">
                            <?php $__currentLoopData = App\Supplier::where(['business_id'=>37, 'supplier_status'=>1,'company_id'=>Auth::user()->company_id])->orderBy('supplier_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li style="padding:5px;">
                                <div class="checkbox" style="margin: 0px">
                                  <input id="checkid<?php echo e($key); ?>" type="checkbox" name="flightAgent[]" value="<?php echo e($sup->id); ?>" <?php echo e(in_array($sup->id, explode(',', $dataid)) ? 'checked':''); ?>> 
                                  <label for="checkid<?php echo e($key); ?>" style="position: relative;top: 5px;"><?php echo e($sup->supplier_name); ?></label>
                                </div>
                              </li>                              
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="clearfix"></div>
                          </ul>
                        </div>
                      </div>
                  </div>
                </div>       

                <div class="col-md-3 col-xs-6">
                  <div class="form-group">
                    <label class="pull-left" style="width: 50%;text-align: center;">Departure Time<span style="color:#b12f1f;">*</span></label> 
                    <label class="pull-right" style="width: 50%;text-align: center;">Arrival Time <span style="color:#b12f1f;">*</span></label> <div class="clearfix"></div>
                    <div class="input-group">
                      <input type="text" name="dep_time" value="<?php echo e($flight->dep_time); ?>" class="form-control text-center" placeholder="09:00 AM" aria-describedby="basic-addon3" required>
                      <span class="input-group-addon" id="basic-addon3">-></span>
                      <input type="text" name="arr_time" value="<?php echo e($flight->arr_time); ?>" class="form-control text-center" placeholder="12:00 AM" aria-describedby="basic-addon3" required>
                    </div>
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group has-feedback ">
                    <label class="pull-left" style="width: 50%;text-align: center;">Flight From <span style="color:#b12f1f;">*</span></label> 
                    <label class="pull-right" style="width: 50%;text-align: center;">Flight To <span style="color:#b12f1f;">*</span></label> <div class="clearfix"></div>
                    <div class="input-group">
                      <div style="position: relative;">
                        <input type="text" name="flight_from" value="<?php echo e($flight->flight_from); ?>" id="flight_from" class="form-control text-center" placeholder="From: Phnom Penh" aria-describedby="basic-addon3" onKeyPress="searchData()" onkeyup="searchData()" required>
                        <ul class="obs-wrapper-search list-unstyled" id="ulFrom" style="display: block; overflow: auto;max-height: 200px; display: none; top: 34px;">  
                          <?php $__currentLoopData = $destJson; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li style="padding:6px;"><b><?php echo e($ed->province_name); ?></b>, <?php echo e($ed->country->country_name); ?></li>       
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>   
                      </div>
                      <span class="input-group-addon" id="basic-addon3"><i class="fa fa-fighter-jet" style="color: #4f4ab8;"></i></span>
                      <div style="position: relative;">
                        <input type="text" name="flight_to" value="<?php echo e($flight->flight_to); ?>" id="flight_to" class="form-control text-center" placeholder="To: Siem Reap" aria-describedby="basic-addon3" onKeyPress="searchFlightTo()" onkeyup="searchFlightTo()" required>
                        <ul class="obs-wrapper-search list-unstyled" id="ulFlightTo" style="display: block; overflow: auto;max-height: 200px;  top: 34px; display: none;">
                          <?php $__currentLoopData = $destJson; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li style="padding:6px;"><b><?php echo e($ed->province_name); ?></b>, <?php echo e($ed->country->country_name); ?></li>       
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>   
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-xs-6">
                  <div class="form-group">
                    <div><label>Operation Days</label></div>
                    <?php $__currentLoopData = App\WeekDay::orderBy('id', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <input id="checkday<?php echo e($key); ?>" name="weekday[]" type="checkbox" value="<?php echo e($day->id); ?>"  style="position: relative;top:4px; width: 16px; height: 16px;" <?php echo e(in_array($day->id, explode(',', $weekday)) ? 'checked':''); ?> > 
                      <label class="label label-default" for="checkday<?php echo e($key); ?>"><?php echo e($day->days_name); ?></label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
              
                <div class="col-md-3 col-xs-6">
                  <div class="form-group">
                    <label>Status</label>&nbsp;
                    <div>
                      <label><input type="radio" name="status" value="1" checked> Publish</label>&nbsp;&nbsp;
                      <label><input type="radio" name="status" value="0"> UnPublish</label></div>
                    </div> 
                  <div class="form-group">
                    <button type="submit" class="btn btn-success btn-flat btn-sm">Submit</button>      
                  </div>
                </div>
              </div>
            </form>
          </div>
        </section>
        <div class="clearfix"></div>
    </section>
  </div>  
</div>
<script type="text/javascript">
  $(document).ready(function(){
    $(document).on('click',"#ulFrom li", function() {
      $("#flight_from").val($('b', this).text());
    });

    $(document).on('click',"#ulFlightTo li", function() {
      $("#flight_to").val($('b', this).text());
    });
    $(".wrapper").click(function(){
      $(".obs-wrapper-search").css({'display': 'none'});
    })
  });

  function searchData() {
    input = document.getElementById("flight_from");
    filter = input.value.toUpperCase();
    ul = document.getElementById("ulFrom");
    li = ul.getElementsByTagName("li");
    if (filter != '') {
      for (i = 0; i < li.length; i++) {
        a = li[i];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
          li[i].style.display = "";
          ul.style.display = 'block';
        } else {
          li[i].style.display = "none";

        }
      }
    }
  }

  function searchFlightTo() {
    input = document.getElementById("flight_to");
    filter = input.value.toUpperCase();
    ul = document.getElementById("ulFlightTo");
    li = ul.getElementsByTagName("li");
    // ul.style.display = 'b';
    if (filter != '') {
      for (i = 0; i < li.length; i++) {
        a = li[i];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
          li[i].style.display = "";
          ul.style.display = 'block';
        } else {
          li[i].style.display = "none";

        }
      }
    }
  }

  function myFunction() {
      input = document.getElementById("search");
      filter = input.value.toUpperCase();
      ul = document.getElementById("myUL");
      li = ul.getElementsByTagName("li");
      for (i = 0; i < li.length; i++) {
        a = li[i];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
          li[i].style.display = "";
        } else {
          li[i].style.display = "none";
        }
      }
  }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>