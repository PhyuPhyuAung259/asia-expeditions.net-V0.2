<?php $__env->startSection('title', 'Transport Service'); ?>
<?php
  $active = 'restaurant/menu'; 
  $subactive ='transport/service';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<style type="text/css">
  .obs-wrapper-search ul li{
    padding: 0px;
  }
</style>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <div class="row">
        <section class="col-lg-12 connectedSortable">
          <h3 class="border">Transport Services <span class="fa fa-angle-double-right"></span> <a href="#" data-toggle="modal" data-target="#myModal" class="btn btn-default btn-sm" id="btnCreateTransport">Add Transport Service</a></h3>
            <table class="datatable table table-hover table-striped">
              <thead>
                <tr>
                  <th>Title</th>
                  <th class="text-center">Supplier</th>
                  <th>Country</th>
                  <th>Province</th>
                  <th class="text-center" width="80px">Status</th>
                </tr>
              </thead> 
              <tbody>
                <?php $__currentLoopData = $tranService; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($tran->title); ?></td>
                  <td width="120px" class="text-center">
                    <?php $title = ""; ?>
                    <?php $__currentLoopData = $tran->supplier_transport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php 
                        $title .= $sup->supplier_name;
                      ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($tran->supplier_transport->count() > 0): ?>
                      <label class="badge" data-toggle="tooltip" title="<?php echo $title; ?>"><?php echo e($tran->supplier_transport->count()); ?></label>
                    <?php endif; ?>
                  </td> 
                  <td><?php echo e(isset($tran->country->country_name) ? $tran->country->country_name : ''); ?></td>
                  <td><?php echo e(isset($tran->province->province_name) ? $tran->province->province_name : ''); ?></td>
                  <td class="text-right">       
                    <?php if($tran->supplier_transport->count() > 0): ?>
                      <a class="btnEditVehicle" data-id="<?php echo e($tran->id); ?>" data-type="addVehicle" data-toggle="modal" data-target="#myModalVehicle" title="Add & View Vehicle">
                        <i style="padding:1px 2px;" class="btn btn-primary btn-xs fa fa-list-alt"></i>
                      </a>&nbsp;
                    <?php else: ?> 
                      <a href="#" title="You need to add Transport before you click on this">
                        <i style="padding:1px 2px;" class="btn btn-primary btn-xs fa fa-list-alt"></i>
                      </a>&nbsp;
                    <?php endif; ?>
                    <button class="btnTranUpdate" data-id="<?php echo e($tran->id); ?>" style="padding:0px; border:none;" data-toggle="modal" data-target="#myModal">
                      <i style="padding:1px 2px;" class="btn btn-info btn-xs fa fa-pencil-square-o"></i>
                    </button>&nbsp;
                    <a href="javascript:void(0)" class="RemoveHotelRate" data-type="transport_service" data-id="<?php echo e($tran->id); ?>" title="Remove this menu ?">
                      <label class="icon-list ic-trash"></label>
                    </a>
                  </td>                     
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        </section>
      </div>
    </section>
  </div>
</div>
<script type="text/javascript">
  $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
  });
</script>
<div class="modal in" id="myModal" role="dialog" data-backdrop="static" data-keyboard="true">
  <div class="modal-dialog modal-lg">    
    <form id="form_submittransportService" method="POST" action="<?php echo e(route('addtranService')); ?>">
      <div class="modal-content">        
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><strong id="form_title">Add Transport Service</strong></h4>
        </div>
        <div class="modal-body">
          <?php echo e(csrf_field()); ?>    
          <input type="hidden" name="eid" id="eid">
          <div class="row">
            <div class="col-md-6 col-xs-6">
              <div class="form-group">
                <label>Country <span style="color:#b12f1f;">*</span></label> 
                <select class="form-control country" id="country" name="country" data-type="country" required>
                    <option value="">Country</option>
                  <?php $__currentLoopData = App\Country::where('country_status', 1)->orderBy('country_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($con->id); ?>"><?php echo e($con->country_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div> 
            </div>
            <div class="col-md-6 col-xs-6">
              <div class="form-group">
                <label>City Name <span style="color:#b12f1f;">*</span></label> 
                <select class="form-control province_transport" name="city" data-type="transport_service" id="dropdown-data" required>
                </select>
              </div> 
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label>Service Name</label>
                <input type="text" name="service_name" id="service_name" class="form-control" placeholder="Service Name">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label>Choose Supplier<span style="color:#b12f1f;">*</span></label>
                <div class="btn-group" style="display: block;">
                  <button type="button" class="form-control " data-toggle="dropdown" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="false">
                   <span class="pull-left">Choose Supplier</span><span class="pull-right"><i class="caret"></i></span>
                  </button>  
                  <div class="obs-wrapper-search">
                    <div class="">
                      <input type="text" data-type="transport_service" data-url="<?php echo e(route('getFilter')); ?>" id="data_filter" class="form-control" autofocus>
                    </div>
                    <ul class="dropdown-data" style="width: 100%;" id="dropdown-transport_service" style="min-height: 250px;">
                      <div class="clearfix"></div>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success btn-flat btn-sm" id="btnSubmitTran">Publish</button>
          <a href="#" class="btn btn-danger btn-flat btn-sm" data-dismiss="modal">Cancel</a>
        </div>
      </div>      
    </form>
  </div>
</div>
<!-- add vehicle form -->
<div class="modal in" id="myModalVehicle" role="dialog"  data-backdrop="static" data-keyboard="true">
  <div class="modal-dialog modal-lg">    
    <form id="form_submitVehicle" method="POST" action="<?php echo e(route('addVehicle')); ?>">
      <?php echo e(csrf_field()); ?>

      <div class="modal-content">        
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <div class="modal-title col-md-4 col-xs-4 text-right"><strong id="form_title" style="font-size: 1.3vw; ">Add Vehicle For Supplier</strong></div>
          <div class="col-md-6 col-xs-6">            
            <select class="form-control input-sm" id="addVehicleTransport" name="supplier" required="">
            </select>
            <input type="hidden" name="transport_id" id="transport_id">
          </div>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-11">
              <div class="row">
                <div class="col-md-5 col-xs-4">
                  <div class="form-group">
                    <label>Vehicle Name <span style="color:#b12f1f;">*</span></label> 
                    <input type="text" name="vehicle" id="title" class="form-control input-sm" required placeholder="Vehicle Name">
                  </div> 
                  <input type="hidden" name="eid" id="languid" class="clearValue" >
                </div>
                <div class="col-md-3 col-xs-4">
                  <div class="form-group">
                    <label>Price <?php echo e(Content::currency()); ?></label> 
                    <input type="text" name="price" id="price" class="form-control input-sm number_only" placeholder="00.0">
                  </div> 
                </div>
                <div class="col-md-3 col-xs-4">
                  <div class="form-group">
                    <label>Price <?php echo e(Content::currency(1)); ?></label> 
                    <input type="text" name="kprice" id="kprice" class="form-control input-sm number_only" placeholder="00.0">
                  </div> 
                </div>
            
                <div class="col-md-1">        
                  <button style="position: relative;top: 22px;right: 6px;" type="submit" class="btn btn-primary btn-sm" id=""  data-url="<?php echo e(route('addLanguage')); ?>" value="Add">
                    <i class="fa fa-plus-circle"></i>&nbsp;&nbsp;
                    <span id="btnAddLanguage">Add</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
          <table class="table table-hover table-striped">
            <thead>
              <tr>
                <th>Vihecle</th>
                <th width="130px">Price <?php echo e(Content::currency()); ?></th>
                <th width="130px">Price <?php echo e(Content::currency(1)); ?></th>
                <th width="100px" class="text-center">Status</th>
              </tr>
            </thead>
            <tbody id="TransportDataList">
             
            </tbody>
          </table>          
        </div>
        <div class="modal-footer">
        </div>
      </div>      
    </form>
  </div>
</div>


<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>