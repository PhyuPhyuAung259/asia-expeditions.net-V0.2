  
  <?php $__env->startSection('title', 'Journal Entry By Project'. $project->project_number); ?>
  <?php 
    $active = 'finance/accountPayable/project-booked'; 
    $subactive = 'finance/journal';
    use App\component\Content;
    $countryId = Auth::user()->country_id ? Auth::user()->country_id : 0;
  ?>
  <?php $__env->startSection('content'); ?>
    <div class="wrapper">
      <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="content-wrapper">
        <section class="content"> 
          <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <h3 class="border text-center" style="color:#777;">Journal Entry By Project No.: <?php echo e(isset($project->project_number) ? $project->project_number : ''); ?>, & File No.: <?php echo e(isset($project->project_fileno) ? $project->project_fileno : ''); ?></h3>
            <div class="row">
              <form target="_blank" action="<?php echo e(route('PreviewPosted')); ?>"> 
                <div class="col-md-12">
                  <div><label><input id="check_all" type="checkbox" name="checkbox" style="width: 16px; height: 16px;"> Check All</label>
                    &nbsp;&nbsp;&nbsp;
                    <input type="submit" name="priviwe_print" value="Preview & Print" class="btn btn-default btn-acc btn-xs">
                  </div>
                  <table class="table table-striped table-borderd table-hover">
                    <thead>
                      <tr>
                        <th><a href="#">Option</a></th>
                        <th>Entry Date</th>
                        <th><a href="#">Supplier</a></th>
                        <th width="300px"><a href="#">Account Type - Account Name</a></th>
                        <th class="text-right"><a href="#" style="color: #f39c12; font-style: italic;">EST: Receive</a></th>
                        <th class="text-right"><a href="#" style="color: #f39c12; font-style: italic;">EST: Cost</a></th>
                        <th class="text-right"><a href="#">To Receive</a></th>
                        <th class="text-right"><a href="#">To Pay</a></th>
                        <th class="text-right"><a href="#">To Receive <?php echo e(Content::currency(1)); ?></a></th>
                        <th class="text-right"><a href="#">To Pay <?php echo e(Content::currency(1)); ?></a></th>
                        <th class="text-right"><a href="#">Deposit</a></th>
                        
                      </tr>
                    </thead>
                    <tbody>
                      <?php 
                        $tatolToPay = 0;
                      ?>
                      <?php $__currentLoopData = $journalList->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <?php
                          $supplier = App\Supplier::find($acc->supplier_id);
                          $supName = isset($supplier->supplier_name)? $supplier->supplier_name: '';
                          $AccTrantotal = \App\AccountTransaction::where(["journal_id"=>$acc->id, "status"=>1]); 
                          $depositAmount = $AccTrantotal->sum("debit") > 0 ? $AccTrantotal->sum("debit") : $AccTrantotal->sum("credit");
                          $depositAmountk = $AccTrantotal->sum("kdebit") > 0 ? $AccTrantotal->sum("kdebit") : $AccTrantotal->sum("kcredit");
                          $depositTotal = $depositAmount > 0 ? $depositAmount : $depositAmountk;
                          $amountToPay = ($acc->debit - $depositAmount);
                          $tatolToPay = $tatolToPay + $amountToPay;
                          if ($depositAmount > 0) {
                            $depositTotal = $depositAmount > 0 ? Content::money($depositAmount) : '';
                          }else{
                            $depositTotal = $depositAmountk > 0 ? Content::money($depositAmountk) : '';
                          }


                           $ReceiveAmount = ($acc->credit - $depositAmount);
                            $amountToPay = ($acc->debit - $depositAmount); 
                            if ($depositAmountk > 0) {
                                $ReceiveAmountKyat = ($acc->kcredit - $depositAmountk);
                            }else{
                              $ReceiveAmountKyat = $acc->kcredit;
                            }

                            if ($depositAmountk > 0) {
                              $amountToPayKyat = ($acc->kdebit - $depositAmountk);
                            }else{
                              $amountToPayKyat = $acc->kdebit;
                            }
                        ?>
                        <tr>
                          <td>
                            <input style="width:16px; height:16px;" class="checkall" type="checkbox" name="value_checked[]" value="<?php echo e($acc->id); ?>">
                            <a href="javascript:void(0)" class="btnRemoveOption" data-type="journal-entry" data-id="<?php echo e($acc->id); ?>" title="Remove this ?">
                              <label class="icon-list ic-trash" style="background-position: 0 -870px !important;"></label>
                            </a>                         
                            <a data-acc_type="<?php echo e(isset($acc->account_type->id) ? $acc->account_type->id : ''); ?>" data-acc_name="<?php echo e(isset($acc->account_name->id) ? $acc->account_name->id : ''); ?>" data-id="<?php echo e($acc->id); ?>" data-type="account_name" data-credit="<?php echo e($acc->credit); ?>" data-debit="<?php echo e($acc->debit); ?>" data-kcredit="<?php echo e($acc->kcredit); ?>" data-kdebit="<?php echo e($acc->kdebit); ?>" data-pay_date="<?php echo e(date('Y-m-d', strtotime($acc->entry_date))); ?>"  class="btnEditJournal" data-toggle="modal" data-target="#myModal">
                              <label style="cursor:pointer; height: 16px; width: 16px;" class="icon-list ic_edit" title="Preview Journal Entry"></label></a>
                          </td>
                          <td style="width: 92px;"><?php echo e(Content::dateformat($acc->entry_date)); ?></td>
                          <td><?php echo e(isset($supName) ? $supName : ''); ?></td>
                          <td><a href="#"><?php echo e(isset($acc->account_type->account_name) ? $acc->account_type->account_name : ''); ?> - <?php echo e(isset($acc->account_name->account_code) ? $acc->account_name->account_code : ''); ?> - <?php echo e(isset($acc->account_name->account_name) ? $acc->account_name->account_name : ''); ?></a></td>
                          <td class="text-right" style="color: #f39c12; font-style: italic;">
                            <?php echo e($acc->account_type_id == 8 ? Content::money($acc->debit) > 0 ? Content::money($acc->debit): Content::money($acc->kdebit) :''); ?>

                          </td>
                           <td class="text-right">
                            <?php if( $ReceiveAmount > 0): ?>  
                              <?php echo e(Content::money($ReceiveAmount)); ?>  
                            <?php else: ?>  
                              <?php echo "<a href='javascript:void(0)' style='font-weight: 700;'>".Content::money($acc->credit)."</a>"; ?> 
                            <?php endif; ?>
                        </td>
                        <td class="text-right">
                            <?php if( $amountToPay > 0): ?>  
                              <?php echo e(Content::money($amountToPay)); ?>  
                            <?php else: ?>  
                              <?php echo "<a href='javascript:void(0)' style='font-weight: 700;'>".Content::money($acc->debit)."</a>"; ?> 
                            <?php endif; ?>
                        </td>
                        <td class="text-right">
                            <?php if( $ReceiveAmountKyat > 0): ?>  
                              <?php echo e(Content::money($ReceiveAmountKyat)); ?>  
                            <?php else: ?>  
                              <?php echo "<a href='javascript:void(0)' style='font-weight: 700;'>".Content::money($acc->kcredit)."</a>"; ?> 
                            <?php endif; ?>
                        </td>
                        <td class="text-right">
                            <?php if( $amountToPayKyat > 0): ?>  
                              <?php echo e(Content::money($amountToPayKyat)); ?>  
                            <?php else: ?>  
                              <?php echo "<a href='javascript:void(0)' style='font-weight: 700;'>".Content::money($acc->kdebit)."</a>"; ?> 
                            <?php endif; ?>
                        </td>
                          <td class="text-right"><?php echo e($depositTotal); ?></td>
                          <td class="text-right">
                            <?php if($depositAmount < $acc->debit || $depositAmountk < $acc->kdebit): ?>
                              <a target="_blank" href="<?php echo e(route('getPayable', ['journal_id'=> $acc->id])); ?>" class="btn btn-default btn-acc btn-xs pull-right hidden-print"> <b>Pay Now</b></a>
                            <?php elseif($depositAmount < $acc->credit || $depositAmountk < $acc->kcredit): ?>
                             <a target="_blank" href="<?php echo e(route('getPayable', ['journal_id'=> $acc->id])); ?>" class="btn btn-default btn-acc btn-xs pull-right hidden-print"> <b>Receive Now</b></a>
                            <?php else: ?>
                              <span class="badge badge-light" style="line-height: 1.5">Full Paid</span>
                            <?php endif; ?>
                          </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <tr style="background: #a76a09;color: white;">
                        <td colspan="12" class="text-right">
                          <?php 
                            $opsTotal = $journalList->whereNotIn("account_type_id", ['8'])->sum("book_amount"); 
                            $totalTopay = $journalList->sum("debit");
                          ?>
                          <strong>
                            <?php if( $opsTotal != 0 ): ?>
                              Difference <?php echo e(Content::currency()); ?>: <?php echo e(Content::money($opsTotal)); ?> - <?php echo e(Content::money($tatolToPay)); ?> =  
                              <?php $difTotal = ($opsTotal - $tatolToPay); ?>
                              <?php echo $difTotal < 0 ? "<b style='color:#f39c12;'><?php echo e(Content::money($difTotal)); ?></b>" : Content::money($difTotal); ?>

                            <?php endif; ?>
                          </strong>

                          <?php 
                            $opsTotalK = $journalList->whereNotIn('account_type_id',['8'])->sum("book_kamount"); 
                            $totalTopayK = $journalList->sum("kdebit");
                          ?>
                          <?php if($opsTotalK != 0): ?>
                          <strong>
                            Difference <?php echo e(Content::currency(1)); ?>: <?php echo e(Content::money($opsTotalK)); ?> - <?php echo e(Content::money($totalTopayK)); ?> =  
                            <?php $difTotal = ($opsTotalK - $totalTopayK); ?>
                            <?php echo e(number_format($difTotal, 2)); ?>

                          </strong>
                          <?php endif; ?>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </form>
            </div>
        </section>
      </div>
    </div>

  <?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="modal" id="myModal" role="dialog"  data-backdrop="static" data-keyboard="true">
    <div class="modal-dialog modal-lg">    
      <form method="POST" action="<?php echo e(route('editJournal')); ?>">
        <div class="modal-content">        
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title"><strong>Edit Journal Entry</strong></h4>
          </div>
          <div class="modal-body">
            <?php echo e(csrf_field()); ?>   
            <input type="hidden" name="journal_id" id="journal_id"> 
            <div class="row">
              <div class="col-md-12">
                <?php if(\Auth::user()->role_id == 2): ?>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label class="col-sm-3 text-right" style="padding-top: 7px;">Country</label>
                      <div class="col-sm-9">
                        <select class="form-control location" name="country" data-type="country">
                          <option>--choose--</option>
                          <?php $__currentLoopData = App\Country::countryByProject(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($con->id); ?>"><?php echo e($con->country_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                      <div class="clearfix"></div>
                    </div>
                  </div>
                <?php endif; ?>
                <div class="col-md-5 col-xs-12">
                  <div class="form-group">
                      <label class="col-sm-4 text-right" style="padding-top: 7px;">Record Date</label>
                      <div class="col-sm-5">
                        <input type="text" name="pay_date"  id="pay_date"  class="form-control book_date" readonly="" value="<?php echo e(date('Y-m-d')); ?>">
                      </div>
                      <div class="clearfix"></div>
                  </div>
                </div>
                <table class="table ">
                  <tr class="table-head-row">
                    <th width="250px">Account Type</th>
                    <th width="250px">Account Name</th> 
                    <th width="120px">Debit</th>
                    <th width="120px">Credit</th>
                    <th width="120px"><?php echo e(Content::currency(1)); ?> Debit</th>
                    <th width="120px"><?php echo e(Content::currency(1)); ?> Credit</th>
                  </tr>
                  <tbody id="data_payment_option">
                    <tr>                      
                      <td>
                        <select class="form-control account_type input-sm" name="account_type" data-type="account_name" required="">
                          <option value="0">Choose Account Types</option>
                          <?php $__currentLoopData = App\AccountType::where('status', 1)->orderBy('account_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($acc->id); ?>"><?php echo e($acc->account_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </td>
                      <td style="position: relative; width: 40%;">
                         <div class="btn-group" style='display: block;'>
                          <button type="button" class="form-control input-sm arrow-down" data-toggle="dropdown" aria-haspopup="false" aria-expanded='false' data-backdrop="static" data-keyboard="false" role="dialog" data-backdrop="static" data-keyboard="false">
                            <span class="pull-left"></span>
                            <span class="pull-right"></span>
                          </button> 
                          <div class="obs-wrapper-search" style="max-height:250px; overflow: auto; ">
                            <div>
                              <input type="text" data-url="<?php echo e(route('getFilter')); ?>" id="search_Account" onkeyup="filterAccountName()" class="form-control input-sm">
                            </div>
                            <ul id="myAccountName" class="list-unstyled dropdown_account_name">
                            </ul>
                          </div>
                        </div>
                      </td>
                      <td>
                        <input type="text" class="debit form-control input-sm text-right balance number_only" data-type="debit" name="debit" id="debit" placeholder="00.0">
                      </td>
                      <td>
                        <input type="text" class="credit form-control input-sm text-right balance number_only" data-type="credit" name="credit" id="credit" placeholder="00.0">
                      </td>
                      <td>
                        <input type="text" class="kyat-debit form-control input-sm text-right balance number_only" data-type="kyat-debit" name="kyatdebit" id="kyat-debit" placeholder="00.0">
                      </td>
                      <td>
                        <input type="text" class="kyat-credit form-control input-sm text-right balance number_only" data-type="kyat-credit" name="kyatcredit" id="kyat-credit" placeholder="00.0">
                      </td>
                    </tr>
                  </tbody>
                </table>
                <div class="col-md-6">
                </div>

                <div class="col-md-6 text-right">
                  <div style="padding: 4px 0px;">
                    <div class="col-md-6"> <span>Subtotal <?php echo e(Content::currency()); ?></span></div>
                    <div class="col-md-3"> 
                      <span class="sub_total_debit">0.00</span>
                    </div>
                    <div class="col-md-3"> <span class="sub_total_credit">00.00</span>
                      <input type="hidden" name="debit_amount" id="debit_amount">
                    </div>
                    <div class="clearfix"></div>
                  </div>
                
                  <div style="padding: 7px 0px; border-top: solid 1px #999999b3;">
                    <div class="col-md-6"><strong>TOTAL</strong></div>
                    <div class="col-md-3"> 
                      <strong class="sub_total_debit">0.00</strong>
                    </div>
                    <div class="col-md-3"> 
                        <strong class="sub_total_credit">00.00</strong>
                        <input type="hidden" name="credit_amount" id="credit_amount">
                    </div>
                    <div class="clearfix"></div>
                  </div>
                  <div style="padding: 4px 0px;">
                    <div class="col-md-6"> <span>Subtotal <?php echo e(Content::currency(1)); ?></span></div>
                    <div class="col-md-3"> 
                      <span class="kyat_sub_total_debit">0.00</span>
                    </div>
                    <div class="col-md-3"> <span class="kyat_sub_total_credit">00.00</span>
                      <input type="hidden" name="kyat_debit_amount" id="kyat_debit_amount">
                    </div>
                    <div class="clearfix"></div>
                  </div>
                
                  <div style="padding: 7px 0px; border-top: solid 1px #999999b3;">
                    <div class="col-md-6"> <strong>TOTAL</strong> </div>
                    <div class="col-md-3"> 
                      <strong class="kyat_sub_total_debit">0.00</strong>
                    </div>
                    <div class="col-md-3"> 
                        <strong class="kyat_sub_total_credit">00.00</strong>
                        <input type="hidden" name="kyat_credit_amount" id="kyat_credit_amount">
                    </div>                        
                  </div>
                  <div class="clearfix"></div>
                  <hr style="padding: 1px;border: solid 1px #999999b3;margin-top: 0px;border-right: none;border-left: none;">
                </div>
                <div class="clearfix"></div>
              </div>
            </div>
          </div>
          <div class="modal-footer ">
            <div class="text-center">
              <button class="btn btn-info btn-sm" id="btnUpdateAccount">Save</button>
              <a href="#" class="btn btn-default btn-sm" data-dismiss="modal">Cancel</a>
            </div>
          </div>
        </div>      
      </form>
    </div>
  </div>
  <script type="text/javascript">
    $(document).ready(function(){
      $(document).on("click", ".btnEditJournal", function(){
        dataId = $(this).data("id");
        $("#journal_id").val(dataId);
      });   
    });
  </script>
  <?php echo $__env->make("admin.account.accountant", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <script type="text/javascript">
    $("#check_all").click(function () {
      if($("#check_all").is(':checked')){
         // Code in the case checkbox is checked.
          $(".checkall").prop('checked', true);
      } else {
           // Code in the case checkbox is NOT checked.
          $(".checkall").prop('checked', false);
      }
    });

      function filterAccountName(){
        input = document.getElementById("search_Account");
        filter = input.value.toUpperCase();
        ul = document.getElementById("myAccountName");
        li = ul.getElementsByClassName ("list");
        for (i = 0; i < li.length; i++) {
            a = li[i];
            if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
              li[i].style.display = "";
            } else {
              li[i].style.display = "none";
            }
        }
      }
    </script>

  <?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>