<?php $__env->startSection('title', 'Booked Cruise List'); ?>
<?php $active = 'booked/project'; 
$subactive ='booked/cruiserate';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <form method="POST" action="<?php echo e(route('searchProject', ['project'=> 'cruiserate'])); ?>">
            <?php echo e(csrf_field()); ?>

            <section class="col-lg-12 connectedSortable">
                <h3 class="border">Booked Cruise Rate List</h3>
                <div class="col-sm-8 pull-right">
                  <div class="col-md-3">
                    <input type="hidden" name="" value="<?php echo e(isset($projectNum) ? $projectNum : ''); ?>" id="projectNum">
                    <input class="form-control input-sm" type="text" id="from_date" name="start_date" placeholder="From Date" value="<?php echo e(isset($startDate) ? $startDate : ''); ?>"> 
                  </div>
                  <div class="col-md-3">
                    <input class="form-control input-sm" type="text" id="to_date" name="end_date" placeholder="To Date" value="<?php echo e(isset($endDate) ? $endDate : ''); ?>"> 
                  </div>
                   <div class="col-md-2" style="padding: 0px;">
                    <button class="btn btn-default btn-sm" type="submit">Search</button>
                  </div>
                </div>
                <table class="datatable table table-hover table-striped">
                  <thead>
                    <tr>                       
                      <th width="75">Project No.</th>
                      <th>Check-In</th>
                      <th>Check-Out</th>
                      <th>Cruise Name</th>
                      <th>Cabin Type</th>
                      <?php $__currentLoopData = App\RoomCategory::take(5)->orderBy('id', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e($cat->name); ?></th>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <th>Booking Type</th>
                      <th class="text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crRate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr> 
                      <td width="65"><?php echo e($crRate->project_number); ?></td>
                      <td><?php echo e(Content::dateformat($crRate->checkin)); ?></td>
                      <td><?php echo e(Content::dateformat($crRate->checkout)); ?></td>
                      <td><?php echo e(isset($crRate->cruise->supplier_name) ? $crRate->cruise->supplier_name : ''); ?></td>
                      <td><?php echo e(isset($crRate->room->name) ? $crRate->room->name : ''); ?></td>
                      <td class="text-right"><?php echo e(Content::money($crRate->ssingle)); ?></td>
                      <td class="text-right"><?php echo e(Content::money($crRate->stwin)); ?></td>
                      <td class="text-right"><?php echo e(Content::money($crRate->sdouble)); ?></td>
                      <td class="text-right"><?php echo e(Content::money($crRate->sextra)); ?></td>
                      <td class="text-right"><?php echo e(Content::money($crRate->schextra)); ?></td>
                      <td class="text-center">
                        <?php if($crRate->option == 1): ?>
                          <span class="text-danger">Quotation</span>
                        <?php else: ?>
                          <span class="text-success">Booking</span>
                        <?php endif; ?>
                      </td>
                      <?php $RCJournal = App\AccountJournal::where(['book_id'=>$crRate->id, 'business_id'=>3,'project_number'=>$crRate->project_number, 'status'=>1, 'type'=>1])->first(); ?>
                      <td class="text-right">
                          <a target="_blank" href="<?php echo e(route('hVoucher', ['project'=>$crRate->project_number, 'bcruise'=> $crRate->id, 'bookid'=>$crRate->book->id, 'type'=>'cruise-voucher'])); ?>" title="Cruise Voucher">
                          <label class="icon-list ic_inclusion"></label>
                          </a> &nbsp;
                        <?php if($RCJournal == Null): ?>
                          <?php echo Content::DelUserRole("Delete this Cruise Rate ?", "book_cruiserate", $crRate->id, $crRate->user_id ); ?>        
                        <?php else: ?>
                          <span title="Project have been posted. can't edit" style="border-radius: 50px;border: solid 1px #795548; padding: 0px 6px;  position: relative;top: -4px;">Posted</span>
                        <?php endif; ?>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
            </section>
          </form>
        </div>
    </section>
  </div>
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>