<?php $__env->startSection('title', 'Hotel Voucher'); ?>
<?php 
	use App\component\Content;
	$comadd = \App\Company::where('country_id', \Auth::user()->country_id)->first();
?>
<?php $__env->startSection('content'); ?>
	<div class="col-lg-12">
    <?php echo $__env->make('admin.report.headerReport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>		
		<h3 class="text-center"><strong class="btborder" style="text-transform:uppercase;">service voucher</strong></h3>
		<div class="col-md-10 col-md-offset-2">
			<div class="row">
				<div class="pull-left hotel_voucher_title" style="position: relative;bottom:-12px;left:55px">
					<strong style="font-size:16px;">File / Project No. <?php echo e($project->project_fileno ? $project->project_prefix.'-'.$project->project_fileno : $project->project_number); ?></strong>
				</div>
				<div class="pull-right hidden-print">
					<a href="javascript:void(0)" onclick="window.print();"><span class="fa fa-print btn btn-primary"></span></a>&nbsp;&nbsp;&nbsp;&nbsp;
				
				</div>
			</div>
		</div>
		<table class="table" style="width: 100%;" >
			<tr>
				<td style="border-top: none" class="text-right hotel_voucher" width="205px">
					<address style="margin-bottom: 0px;">
						Name:<br>
						Address:<br>
						Phone:<br>
						Email:
					</address>
				</td>
				<td style="border-top: none" colspan="3" >
					<div class="well" style="padding: 4px;margin-bottom: 0px; background-color: #ddd0;">
						<address style="margin-bottom: 0px;">
							<?php echo e(isset($bcruise->cruise->supplier_name) ? $bcruise->cruise->supplier_name : ''); ?><br>
							<?php echo e(isset($bcruise->cruise->supplier_address) ? $bcruise->cruise->supplier_address : ''); ?><br>
							<?php echo e(isset($bcruise->cruise->supplier_phone) ? $bcruise->cruise->supplier_phone : ''); ?> / <?php echo e(isset($bcruise->cruise->supplier_phone2) ? $bcruise->cruise->supplier_phone2 : ''); ?><br>
							<?php echo e(isset($bcruise->cruise->supplier_email) ? $bcruise->cruise->supplier_email : ''); ?><br>
						</address>
					</div>
				</td>
			</tr>
			<tr>
				<td style="border-top: none" class="text-right" >
					<address>
						<label style="font-weight:400;margin-top: 8px;">Client Name:</label><br>
						<label style="font-weight:400;margin-top: 11px;">Check-In:</label><br>
						<label style="font-weight:400;margin-top: 10px;">No. of Room <?php echo e(isset($bcruise->category->name) ? $bcruise->category->name : ''); ?> </label><br>
						<label style="font-weight:400;margin-top: 12px;">No. of  Nights </label>
					</address>
				</td>
				<td style="border-top: none; width: 34%;">
					<div class="well" style="padding: 1px;margin-bottom: 0px; background-color: #ddd0; border:none;">
						<address>
							<div style="margin: 0px 0px 4px 0px;" class="form-control input-sm"><?php echo e($project->project_client); ?></div>
							<div style="margin: 0px 0px 4px 0px; " class="form-control input-sm"><?php echo e(Content::dateformat($booking->book_checkin)); ?></div>
							<div style="margin: 0px 0px 4px 0px;" class="form-control input-sm"><?php echo e($bcruise->cabin_pax); ?></div>
							<div style="margin: 0px 0px 4px 0px;" class="form-control input-sm"><?php echo e($bcruise->book_day); ?></div>
						</address>
					</div>
				</td>
				<td style="border-top: none; width: 12%; vertical-align: top; text-align: right;">
					<address>
						<label style="font-weight: 400; margin-top: 10px">No. of Pax:</label><br>
						<label style="font-weight: 400; margin-top: 12px;">Check-Out:</label><br>
						<label style="font-weight: 400; margin-top: 10px">Cabin Type:</label>
					</address>
				</td>
				<td style="border-top: none; width: 34%; vertical-align: top;">
					<div class="well" style="padding: 1px;margin-bottom: 0px; background-color: #ddd0; border:none;">
						<address>
							<div style="margin: 0px 0px 4px 0px;" class="form-control input-sm"><?php echo e($booking->book_pax); ?></div>
							<div style="margin: 0px 0px 4px 0px;" class="form-control input-sm"><?php echo e(Content::dateformat($booking->book_checkout)); ?></div>
							<div style="margin: 0px 0px 4px 0px;" class="form-control input-sm"><?php echo e(isset($bcruise->room->name) ? $bcruise->room->name : ''); ?></div>
						</address>
					</div>
				</td>
			</tr>
			<tr>
				<td style="border-top: none" class="text-right"><strong>Remark:</strong></td>
				<td style="border-top: none" colspan="3"><div class="form-control input-sm"><?php echo e($bcruise->remark); ?></div></td>
			</tr>
			<tr><td style="border-top: none"></td></tr>
			
			<tr>
				<td style="border-top: none" ></td>
				<td style="border-top: none">
					<?php echo e($comadd->title); ?>

				</td>
			</tr>
			<tr>
				<td style="border-top: none" ></td>
				<!-- <td style="border-top: none" colspan="2" class="text-left"></td> -->
				<td style="border-top: none" colspan="2" class="text-left">Signed By: ........................................</td>
			</tr>
		</table>		
  	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>