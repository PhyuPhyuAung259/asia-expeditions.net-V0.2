<?php $__env->startSection('title', config('app.title')); ?>
<?php $__env->startSection('active', 'active'); ?>
<?php $active = 'active'; ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="col-sm-1 col-md-1 col-lg-1 col-xs-4 no-padding">
            <a href="#">
              <div class="small-box btn btn-default <?php echo $__env->yieldContent('active'); ?>">
                  <div class="icon">
                    <i class="fa fa-home"></i>
                  </div>
                  <span>Home</span>
              </div>
            </a>
        </div>       
        <?php $__currentLoopData = \App\Department::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-1 col-md-1 col-lg-1 col-xs-4 no-padding">
            <a href="<?php echo e(route('getDepart', ['depart'=>$dep->slug])); ?>">
              <div class="small-box btn btn-default">
                  <div class="icon">
                    <i class="<?php echo e($dep->icon); ?>"></i>
                  </div>
                  <span class="text-shadow"><?php echo e($dep->name); ?></span>
              </div>
            </a>
        </div>     
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        <div class="row">
            <section class="col-lg-7 connectedSortable">

              
            </section>
            <section class="col-lg-5 connectedSortable">
            </section>
        </div>
    </section>
  </div>
  <?php echo $__env->make('admin.include.control', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>