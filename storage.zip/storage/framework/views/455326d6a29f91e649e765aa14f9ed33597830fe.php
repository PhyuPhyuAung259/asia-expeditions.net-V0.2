<?php $__env->startSection('title', 'Create Documentation'); ?>
<?php
  $active = 'setting-options'; 
  $subactive ='create/form';
  use App\component\Content;
  $countryId = Auth::user()->country_id ? Auth::user()->country_id : 0;
  $busId = isset($edoc->business_id) ? $edoc->business_id: 1 ;
  $catId = isset($edoc->category_id) ? $edoc->category_id: '';
  $desc = isset($edoc->desc) ? $edoc->desc: '';
?>
<?php $__env->startSection('content'); ?>
  <div class="wrapper">
    <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content"> 
        <div class="row">
          <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="col-lg-12"><h3 class="border">Create Documentation</h3></div>
          <form method="POST" action="<?php echo e(route('createNewDocs')); ?>">
              <?php echo e(csrf_field()); ?>

              <section class="col-lg-12 connectedSortable">                 
                  <div class="row">
                    <input type="hidden" name="eid" value="<?php echo e(isset($edoc->id) ? $edoc->id : ''); ?>">
                    <div class="col-md-6 col-xs-12">
                      <div class="form-group">
                        <label>Tittle <span style="color:#b12f1f;">*</span></label> 
                        <input type="text" placeholder="Tittle" class="form-control" name="title" value="<?php echo e(isset($edoc->title) ? $edoc->title : ''); ?>" required>
                      </div> 
                    </div>        
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Business Type<span style="color:#b12f1f;">*</span></label> 
                        <select class="form-control businessType" name="business_id" data-type="business_docs">
                          <?php $__currentLoopData = \App\Department::where(['status'=>1, 'type'=>2])->orderBy('order','ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($dep->slug != "suppliers"): ?>
                              <option value="<?php echo e($dep->id); ?>" <?php echo e($dep->id == $busId ? "selected":""); ?>><?php echo e($dep->name); ?></option>
                            <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div> 
                    </div>   
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Category Type<span style="color:#b12f1f;">*</span></label> 
                        <select class="form-control" id="CategoryType_data" name="category_id">
                          <?php $__currentLoopData = \App\DepartmentMenu::where('department_id', $busId)->orderBy('order','ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($dep->slug != "suppliers"): ?>
                              <option value="<?php echo e($dep->id); ?>" <?php echo e($dep->id == $catId ? "selected":""); ?>><?php echo e($dep->name); ?></option>
                            <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div> 
                    </div>  
                  </div>  
                  <div class="form-group">
                    <label>Document Descriptions</label>
                    <script src="<?php echo e(asset('adminlte/editor/tinymce.min.js')); ?>"></script>
                    <textarea class="form-control my-editor" name="desc" rows="6" placeholder="Enter ..."><?php echo $desc; ?></textarea>             
                  </div>
                  <div class="form-group">
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Status</label>&nbsp;
                        <label style="font-weight:400;"> <input type="radio" name="status" value="1" checked="">Publish</label>&nbsp;&nbsp;
                        <label style="font-weight: 400;"> <input type="radio" name="status" value="0">UnPublish</label>
                      </div> 
                    </div>
                </div>

                <div class="form-group"> 
                  <button type="submit" class="btn btn-success btn-flat btn-sm">Submit</button>&nbsp;&nbsp;
                </div>
              </section>
             
          </form>
        </div>
      </section>
    </div>  
  </div>
<script>
    var editor_config = {
      path_absolute : "/",
      selector: "textarea.my-editor","height":"550",
      plugins: [
        "advlist autolink lists link image charmap print preview hr anchor pagebreak",
        "searchreplace wordcount visualblocks visualchars code fullscreen",
        "insertdatetime media nonbreaking save table contextmenu directionality",
        "emoticons template paste textcolor colorpicker textpattern"
      ],
      toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media",
      relative_urls: false,
      file_browser_callback : function(field_name, url, type, win) {
        var x = window.innerWidth || document.documentElement.clientWidth || document.getElementsByTagName('body')[0].clientWidth;
        var y = window.innerHeight|| document.documentElement.clientHeight|| document.getElementsByTagName('body')[0].clientHeight;

        var cmsURL = editor_config.path_absolute + 'laravel-filemanager?field_name=' + field_name;
        if (type == 'image') {
          cmsURL = cmsURL + "&type=Images";
        } else {
          cmsURL = cmsURL + "&type=Files";
        }

        tinyMCE.activeEditor.windowManager.open({
          file : cmsURL,
          title : 'Filemanager',
          width : x * 0.8,
          height : y * 0.8,
          resizable : "yes",
          close_previous : "no"
        });
      }
    };

    tinymce.init(editor_config);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>