<?php $__env->startSection('title', 'Room Applied Hotel Booking'); ?>
<?php $active = 'booked/project';
$subactive ='booked/hotel';
  use App\component\Content;

?>
<?php $__env->startSection('content'); ?>
  <div class="wrapper">
    <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content"> 
        <div class="row">
          <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="col-lg-12"><h3 class="border"><small>Room Applied for</small> <strong><?php echo e($hotel->supplier_name); ?></strong> <small>Hotel</small>, <strong style="font-size: 14px;">CheckIn:<?php echo e(Content::dateformat($project->book_checkin)); ?>, CheckOut:<?php echo e(Content::dateformat($project->book_checkout)); ?></strong></h3></div>
          <form method="POST" action="<?php echo e(route('bookingAppliedroom')); ?>">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="bookId" value="<?php echo e($project->id); ?>">
            <input type="hidden" name="projectNo" value="<?php echo e($project->book_project); ?>">
            <input type="hidden" name="hotelId" value="<?php echo e($hotel->id); ?>">
            <input type="hidden" name="book_day" id="book_day" value="<?php echo e($project->book_day); ?>">
            <input type="hidden" name="book_checkin" id="book_checkin" value="<?php echo e($project->book_checkin); ?>">
            <input type="hidden" name="book_checkout" id="book_checkout" value="<?php echo e($project->book_checkout); ?>">
            <section class="col-lg-12">
              <table class="table" style="margin-bottom: 0px !important;">
                <thead>
                  <tr>
                    <th style="width:11%;">Room Type</th>
                    <th style="width: 13%;">Room Category</th>
                    <th style="width: 11%;">No. of Room</th>
                    <th class="text-center">Selling Price</th>
                    <th class="text-center">Amount</th>
                    <th class="text-center">Net Price</th>
                    <th class="text-center">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $hotel->room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                    $rate = \App\RoomRate::Where(['supplier_id'=>$hotel->id, 'room_id'=>$room->pivot->room_id])
                          ->whereDate('start_date','<=', $project->book_checkin)
                          ->whereDate('end_date','>=', $project->book_checkout)
                          ->first();
                    ?>
                    <tr>
                      <td class="container_room" style="padding-right:10px;">
                        <label style="margin-bottom: 0px; font-weight: 400; cursor: pointer;">
                          <span style="display:none;" class="fa fa-check-square check"></span>
                          <span style="display:block;" class="fa fa-square-o nocheck"></span>
                          <input type="checkbox" id="checkRoom" class="checkRoom" name="roomtype[]" value="<?php echo e($room->id); ?>" > 
                          <span style="position:relative;left:20px;top:2px;"><?php echo e($room->name); ?></span>
                        </label>
                      </td>
                      <td colspan="6">
                        <table class="table" style="margin-bottom: 0px;">
                          <?php $__currentLoopData = App\RoomCategory::whereIn('id',['1','2','3','4','5'])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                              if ($cat->id == 1) {
                                $selling_price = $rate['ssingle'];
                              }elseif ($cat->id == 2) {
                                $selling_price = $rate['stwin'];
                              }elseif($cat->id == 3){
                                $selling_price = $rate['sdbl_price'];
                              }elseif($cat->id == 4){
                                $selling_price = $rate['sextra'];
                              }else {
                                $selling_price = $rate['schexbed'];
                              }

                              if ($cat->id == 1) {
                                $net_price = $rate['nsingle'];
                              }elseif ($cat->id == 2) {
                                $net_price = $rate['ntwin'];
                              }elseif($cat->id == 3){
                                $net_price = $rate['ndbl_price'];
                              }elseif($cat->id == 4){
                                $net_price = $rate['nextra'];
                              }else {
                                $net_price = $rate['nchexbed'];
                              }                 
                            ?>
                            <tr>
                              <td class="container_category" style="width: 13%;">
                                <label style="margin-bottom: 0px; font-weight: 400; cursor: pointer;">
                                  <span class="fa fa-square-o" id="checkStatus"></span>
                                  <input type="checkbox" id="roomCat" class="checkRoom" name="roomCat<?php echo e($room->id); ?>[]" value="<?php echo e($cat->id); ?>" data-selling="<?php echo e($selling_price); ?>"  data-net="<?php echo e($net_price); ?>">
                                  <span style="position:relative;left:20px; top:2px;"><?php echo e($cat->name); ?></span>
                                </label>
                              </td>
                              <td style="width:13%;" class="container_room_no">
                                <select class="form-control input-sm " id="no_of_room" name="no_of_room<?php echo e($room->id); ?>_<?php echo e($cat->id); ?>">
                                  <option value="">0</option>
                                  <?php for($n=1; $n <= 29; $n++): ?>
                                  <option value="<?php echo e($n); ?>"><?php echo e($n); ?></option>
                                  <?php endfor; ?>
                                </select>
                              </td>
                              <td style="width:24%;" class="text-right container_selling_price">
                                <input type="hidden" name="price_<?php echo e($room->id); ?>_<?php echo e($cat->id); ?>" id="room_price">
                                <span>00.0</span>
                              </td>
                              <td style="width:16%;" class="text-right container_selling_amount">
                                <input type="hidden" name="sell_amount_<?php echo e($room->id); ?>_<?php echo e($cat->id); ?>" id="selling_amount" value="00.0">
                                <span>00.0</span>
                              </td>
                              <td style="width:18%;" class="text-right container_net_price">
                                <input type="hidden" name="nprice_<?php echo e($room->id); ?>_<?php echo e($cat->id); ?>" id="room_net_price">
                                <span>00.0</span>
                              </td>
                              <td style="width:21%;" class="text-right container_net_amount">
                                <input type="hidden" name="net_amount_<?php echo e($room->id); ?>_<?php echo e($cat->id); ?>" id="net_amount" value="00.0">
                                <span>00.0</span>
                              </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </table>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              <hr>
              <div class="col-md-6 col-xs-6 col-md-offset-1" style="padding-left: 33px;">
                <textarea class="form-control" rows="5" name="remark" cols="5" placeholder="Enter remark...!"></textarea>
              </div>
              <div class="col-md-5 col-xs-6">
                <input type="submit" class="btn btn-success btn-flat btn-sm" id="confirm-booking" value="Confirm Booking">
              </div>
              <div class="clearfix"></div>
              <br>
              <!-- <hr style="border-bottom: 1px solid #f4f4f5;"> -->
              <div class="col-md-12">
                <h4>Hotel Booking Result for project: <strong><?php echo e($project->book_project); ?></strong></h4>
                <table class="table">
                  <tr>
                      <th>Hotel</th>
                      <th>CheckIn - CheckOut</th>
                      <th>Room</th>
                      <?php $__currentLoopData = App\RoomCategory::whereIn('id',['1','2','3','4','5'])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <th class="text-center"><?php echo e($cat->name); ?></th>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <th class="text-right">Status</th>
                  </tr>
                  <tbody>
                  <?php 
                  $hbooked = App\HotelBooked::where(['hotel_id'=>$hotel->id, 'book_id'=>$project->id])->orderBy('room_id', 'ASC'); 
                  ?>
                    <?php $__currentLoopData = $hbooked->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bhotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e(isset($bhotel->hotel->supplier_name) ? $bhotel->hotel->supplier_name : ''); ?></td>
                      <td style="font-size: 12px;"><?php echo e(Content::dateformat($bhotel->checkin)); ?> -> <?php echo e(Content::dateformat($bhotel->checkout)); ?></td>
                      <td><?php echo e(isset($bhotel->room->name) ? $bhotel->room->name : ''); ?></td>
                      <?php $status = "<label class='icon-list ic_status'></label>"; ?>
                      <td class="text-center"><?php echo $bhotel->ssingle != 0 ? "$status":""; ?></td>
                      <td class="text-center"><?php echo $bhotel->stwin != 0 ? "$status":""; ?></td>
                      <td class="text-center"><?php echo $bhotel->sdouble != 0 ? "$status":""; ?></td>
                      <td class="text-center"><?php echo $bhotel->sextra != 0 ? "$status":""; ?></td>
                      <td class="text-center"><?php echo $bhotel->schextra != 0 ? "$status":""; ?></td>
                      <td class="text-right">
                        <a target="_blank" href="<?php echo e(route('hVoucher', ['project'=>$bhotel->project_number, 'bhotelid'=> $bhotel->id, 'bookid'=> $project->id, 'type'=>'hotel-voucher'])); ?>" title="Hotel Voucher">
                          <label class="icon-list ic_inclusion"></label>
                        </a>
                        &nbsp;
                         <a target="_blank" href="<?php echo e(route('hVoucher', ['project'=>$bhotel->project_number, 'bhotelid'=> $bhotel->id, 'bookid'=> $project->id, 'type'=> 'hotel-booking-form'])); ?>" title="Hotel Booking Form">
                          <label  class="icon-list ic_invoice_drop"></label>
                        </a>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td colspan="9" class="text-right">
                        <strong class="totalsize">Hotel Total: <?php echo e(number_format($hbooked->sum('sell_amount'),2)); ?> <?php echo e(Content::currency()); ?></strong>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <br><br>
            </section>
          </form>
        </div>
      </section>
    </div>  
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>