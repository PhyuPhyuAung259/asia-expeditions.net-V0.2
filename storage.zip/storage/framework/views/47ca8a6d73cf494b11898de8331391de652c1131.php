<?php $__env->startSection('title', 'Booked Project List'); ?>
<?php 
  $active = 'booked/project'; 
  $subactive ='booked/project';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <form method="POST" action="<?php echo e(route('searchProject', ['project'=> 'project'])); ?>">
            <?php echo e(csrf_field()); ?>

            <section class="col-lg-12 connectedSortable">
              <h3 class="border">Project List <span class="fa fa-angle-double-right"></span> <a href="<?php echo e(route('proForm')); ?>" class="btn btn-default btn-sm">Create Project</a></h3>
              <div class="col-sm-8 col-xs-12 pull-right" style="position: relative; z-index: 2;">
                <div class="col-md-3 col-xs-5">
                  <input type="hidden" value="<?php echo e(isset($projectNum) ? $projectNum : ''); ?>" id="projectNum">
                  <input class="form-control input-sm" type="text" id="from_date" name="start_date" placeholder="Date From" value="<?php echo e(isset($startDate) ? $startDate : ''); ?>"> 
                </div>
                <div class="col-md-3 col-xs-5">
                  <input class="form-control input-sm" type="text" id="to_date" name="end_date" placeholder="Date To" value="<?php echo e(isset($endDate) ? $endDate : ''); ?>"> 
                </div>
                <div class="col-md-2" style="padding: 0px;">
                  <button class="btn btn-default btn-sm" type="submit">Search</button>
                </div>
                <?php if(\Auth::user()->role_id == 2): ?>
                  <div class="col-md-1" style="padding: 0px;">
                    <a href="<?php echo e(route('createPaymentLink')); ?>" class="btn btn-primary btn-sm">Create Payment Link</a>
                  </div>
                <?php endif; ?>
              </div>
              <table class="datatable table table-hover table-striped">
                <thead>
                  <tr>                       
                    <th width="65">Project No.</th>
                    <th>ClientName</th>
                    <th style="width: 62.8125px;">Start Date</th>
                    <th style="width: 58.8125px;">End Date</th>
                    <th>Agent</th>
                    <th style="width: 79.8125px;">User</th>
                    <th>Country</th>
                    <th class="text-center" style="width: 210px;">Sales</th>
                    <th class="text-center" style="width: 181px;">Operation</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                      $sup = App\Supplier::find($project->supplier_id);
                      $user = App\User::find($project->UserID);
                      $con = App\Country::find($project->country_id);
                     ?>
                  <tr>
                    <td class="studentId" width="75">
                      <input type="checkbox" class="btnCheck"> &nbsp; 
                      <?php echo e($project->project_number); ?></td>
                    <td><?php echo e($project->project_client); ?></td>
                    <td><?php echo e(Content::dateformat($project->project_start)); ?></td>
                    <td><?php echo e(Content::dateformat($project->project_end)); ?></td>
                    <td><?php echo e(isset($sup->supplier_name) ? $sup->supplier_name : ''); ?></td>
                    <td><?php echo e(isset($user->fullname) ? $user->fullname : ''); ?></td>
                    <td><?php echo e(isset($con->country_name) ? $con->country_name : ''); ?></td>
                    <td class="text-center">
                      <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$project->project_number, 'type'=>'details'])); ?>" title="Program Details">
                        <label style="cursor:pointer;" class="icon-list ic_del_drop"></label>
                      </a>                      
                      <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$project->project_number, 'type'=>'sales'])); ?>" title="Prview Details">
                        <label style="cursor:pointer;" class="icon-list ic_delpro_drop"></lable>
                      </a> 
                    
                      <a target="_blank" href="<?php echo e(route('getInvoice', ['prject'=>$project->project_number, 'type'=> 'invoice'])); ?>" title="View Invoice">
                        <label style="cursor:pointer;" class="icon-list ic_invoice_drop"></lable>
                      </a> 
                      <a target="_blank" href="<?php echo e(route('getInvoice', ['prject'=>$project->project_number, 'type'=> 'add_invoice'])); ?>" title="View Additional Invoice">
                        <label style="cursor:pointer;" class="icon-list ic_invoice_add"></lable>
                      </a> 
                      <a target="_blank" href="<?php echo e(route('getInvoice', ['prject'=>$project->project_number, 'type'=> 'credit_not_invoice'])); ?>" title="View Credit Not Invoice">
                        <label style="cursor:pointer;" class="icon-list ic_invoice_credit"></lable>
                      </a>                     
                      <a target="_blank" href="<?php echo e(route('proForm')); ?>?ref=<?php echo e($project->project_number); ?>" title="Additional Booking">
                        <label style="cursor:pointer;" class="icon-list ic_book_add"></lable>
                      </a>     
                      <a target="_blank" href="<?php echo e(route('proFormEdit', ['project'=> $project->project_number])); ?>" title="Edit Project">
                        <label style="cursor:pointer;" class="icon-list ic_book_project"></lable>
                      </a>    
                      <a target="_blank" href="<?php echo e(route('preProject', ['project'=> $project->project_number])); ?>" title="View One Project">
                        <label style="cursor:pointer;" class="icon-list ic_inclusion"></lable>
                      </a>   
                      <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$project->project_number, 'type'=>'details-net'])); ?>" title="Program Details Net">
                        <label style="cursor:pointer;" class="icon-list ic_del_net"></lable>
                      </a> 

                      <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$project->project_number, 'type'=>'sales-net'])); ?>" title="Program Sales Net">
                        <label style="cursor:pointer; background-position: 0 -1574px !important;" class="icon-list ic_delpro_drop"></lable>
                      </a> 
                      <!-- <a href="#Edit Student" title="Edit Project">
                        <img src="#" class="icon-list ic_book_project">
                      </a>    
                      <a href="#Edit Student" title="Edit Project">
                        <img src="#" class="icon-list ic_book_project">
                      </a>      -->                
                    </td>
                    <td class="text-center">
                      <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$project->project_number, 'type'=>'operation'])); ?>" title="Operation Program">
                        <label style="cursor:pointer;" class="icon-list ic_ops_program"></label>
                        <!-- <div class="clearfix"></div> -->
                      </a>
                      <a target="_blank" href="<?php echo e(route('getops', ['ops'=>'entrance', 'project'=> $project->project_number])); ?>" title="Entrance Fees">
                        <label style="cursor:pointer;" class="icon-list ic_entrance_fee"></label>
                      </a> 
                      <a target="_blank" href="<?php echo e(route('getops', ['ops'=>'restaurant', 'project'=> $project->project_number])); ?>" title="Booking Restaurant">
                        <label style="cursor:pointer;" class="icon-list ic_restuarant"></label>
                      </a> 
                      <a target="_blank" href="<?php echo e(route('getops', ['ops'=>'transport', 'project'=> $project->project_number])); ?>" title="Booking Transport">
                        <label style="cursor:pointer;" class="icon-list ic_transport"></label>
                      </a> 
                      <a target="_blank" href="<?php echo e(route('getops', ['ops'=>'guide', 'project'=> $project->project_number])); ?>" title="Booking Guide">
                        <label style="cursor:pointer;" class="icon-list ic_guide"></label>
                      </a> 
                      <a target="_blank" href="<?php echo e(route('getops', ['ops'=>'golf', 'project'=> $project->project_number])); ?>" title="Bookig Golf Courses">
                        <label style="cursor:pointer;" class="icon-list ic_golf"></label>
                      </a>
                      <a target="_blank" href="<?php echo e(route('getops', ['ops'=>'misc', 'project'=> $project->project_number])); ?>" title="Booking MISC"> 
                        <label style="cursor:pointer;" class="icon-list ic_misc"></label>
                      </a>         
                      <?php echo Content::DelUserRole("Delete this project ?", "book_project", $project->project_id, $project->UserID ); ?> 
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              <!-- <div class="pull-left">Check All</div> -->
            </section>
          </form>
        </div>
    </section>
</div>

<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
  $(document).ready(function(){
    $(".datatable").DataTable({
      language: {
        searchPlaceholder: "Number, File No., ClientName"
      }
    });
  });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>