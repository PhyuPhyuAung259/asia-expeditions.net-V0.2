<?php $__env->startSection('title', 'Create New Booking'); ?>
<?php 
$active = 'booked/project'; 
$subactive ='booking/project';
  use App\component\Content;
  if (isset($_GET['ref']) && !empty($_GET['ref'])) {
    $permission = "readonly";
    $projectEdit = '<input type="hidden" name="project_edit" value="'.$_GET['ref'].'">';
    $projectNumber = $_GET['ref'];
    $service = '';
    foreach ($project->service as $key => $sv) {
      $service .= $sv->pivot->service_id.',';
    }
    $tag_user = '';
    foreach ($project->usertag as $key => $tag) {
      $tag_user .= $tag->pivot->user_id.',';
    }
  }else{
    $service ='';
    $tag_user ='';
    $projectNumber= $projectNo;
    $permission = "";
    $projectEdit ="";
  }
?>

<?php $__env->startSection('content'); ?>
  <div class="wrapper">
    <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content"> 
        <div class="row">
          <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="col-lg-12"><h4 class="border">Travelling Booking Form</h4></div>
          <form method="POST" action="<?php echo e(route('createProject')); ?>">
            <?php echo $projectEdit; ?>

            <?php echo e(csrf_field()); ?>

            <section class="connectedSortable">
                <div class="col-md-9">
                  <div class="row">
                    <div class="col-md-3 col-xs-12">
                      <div class="form-group">
                        <label>Project Code<span style="color:#b12f1f;">*</span></label>
                        <input type="text" placeholder="Project Number" class="form-control" name="project_number" value="<?php echo e(isset($project->project_number) ? $project->project_number : $projectNo); ?>" required readonly>
                      </div> 
                    </div>        
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Pax Number <span style="color:#b12f1f;">*</span></label> 
                        <input type="text" placeholder="Pax Number" class="form-control" name="pax_num" required value="<?php echo e(isset($project->project_pax) ? $project->project_pax : old('pax_num')); ?>" <?php echo e($permission); ?>/>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Client Name <span style="color:#b12f1f;">*</span></label> 
                        <input type="text" class="form-control" name="client_name" placeholder="Jonh Smit" required value="<?php echo e(isset($project->project_client) ? $project->project_client : old('client_name')); ?>" <?php echo e($permission); ?>/>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>File Number</label> 
                        <input type="text" class="form-control" name="fileno" placeholder="File Number" value="<?php echo e(isset($project->project_fileno) ? $project->project_fileno : old('fileno')); ?>"  <?php echo e($permission); ?>/>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Start Date<span style="color:#b12f1f;">*</span></label> 
                        <input type="text" id="from_date" class="form-control" name="start_date" placeholder="2018-04-24" required  value="<?php echo e(isset($project->project_start) ? $project->project_start : old('start_date')); ?>" readonly <?php echo e($permission); ?>/>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>End Date<span style="color:#b12f1f;">*</span></label>
                        <input type="text" id="to_date" class="form-control" name="end_date" placeholder="2019-04-24" required value="<?php echo e(isset($project->project_end) ? $project->project_end : old('end_date')); ?>" readonly <?php echo e($permission); ?>>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Arrival Time</label> 
                        <select class="form-control" name="arr_time" <?php echo e($permission); ?>>
                          <option value="">--Select--</option>
                          <?php $__currentLoopData = App\FlightSchedule::where('flight_status',1)->orderBy('flightno', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($fy->id); ?>" <?php echo e($fy->id === (isset($project->project_arr_time)?$project->project_arr_time:'') ? 'selected':''); ?>><?php echo e($fy->flightno); ?> - A:<?php echo e($fy->arr_time); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Departure Time</label> 
                        <select class="form-control" name="dep_time" <?php echo e($permission); ?>>
                            <option value="">--Select--</option>
                          <?php $__currentLoopData = App\FlightSchedule::where('flight_status',1)->orderBy('flightno', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($fy->id); ?>" <?php echo e($fy->id === (isset($project->project_dep_time)?$project->project_dep_time:'') ? 'selected':''); ?>><?php echo e($fy->flightno); ?> - D:<?php echo e($fy->dep_time); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Agent<span style="color:#b12f1f;">*</span></label> 
                       <select class="form-control" name="agent" required="" <?php echo e($permission); ?>>
                          <option value="">Agent</option>
                          <?php $getAgent = App\Supplier::where(['business_id'=>9, 'supplier_status'=>1])->orderBy('supplier_name', 'ASC')->get(); 
                            $supId = isset($project->supplier_id) ? $project->supplier_id:'';
                          ?>
                          <?php if($getAgent->count() > 0): ?>
                            <?php $__currentLoopData = $getAgent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($agent->id); ?>" <?php echo e($agent->id == $supId ? 'selected':''); ?>><?php echo e($agent->supplier_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                        </select>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Reference</label> 
                        <input class="form-control" type="text" placeholder="Reference" name="reference" value="<?php echo e(isset($project->project_book_ref) ? $project->project_book_ref : old('reference')); ?>" <?php echo e($permission); ?>>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Travel Consultant</label> 
                        <input class="form-control" type="text" placeholder="Travel Consultant" name="consultant" value="<?php echo e(isset($project->project_book_consultant) ? $project->project_book_consultant : old('consultant')); ?>" <?php echo e($permission); ?>>
                      </div> 
                    </div>                                  
                    <div class="col-md-3 col-xs-12">
                      <div class="form-group">
                        <label>Location</label>
                        <select  class="form-control" name="location" <?php echo e($permission); ?>>
                          <?php $__currentLoopData = App\Country::where('country_status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($con->id); ?>" <?php echo e(isset($project->country_id) ? ($project->country_id == $con->id? 'selected':''):''); ?>><?php echo e($con->country_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-6 col-xs-6">
                      <div class="form-group">
                        <label>Hightlights</label>
                        <textarea class="form-control my-editor" name="pro_hightlight" rows="6" placeholder="Enter Here..." <?php echo e($permission); ?>> <?php echo e(isset($project->project_hight) ? $project->project_hight : old('pro_hightlight')); ?></textarea>            
                      </div>
                    </div>
                    <div class="col-md-6 col-xs-6">
                      <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control my-editor" name="pro_desc" rows="6" placeholder="Enter Here ..." <?php echo e($permission); ?>><?php echo e(isset($project->project_desc) ? $project->project_desc : old('pro_desc')); ?></textarea>   
                      </div>
                    </div>
                    <div class="col-md-6 col-xs-6">
                      <div class="form-group">
                        <label>Additional Descriptions</label>
                        <textarea class="form-control my-editor" name="pro_add_desc" rows="6" placeholder="Enter Here..." <?php echo e($permission); ?>><?php echo e(isset($project->project_add_desc) ? $project->project_add_desc : old('pro_add_desc')); ?></textarea>            
                      </div>
                    </div>
                    <div class="col-md-6 col-xs-6">
                      <div class="form-group">
                        <label>Credit Note Descriptions</label>
                        <textarea class="form-control my-editor" name="pro_note_desc" rows="6" placeholder="Enter Here..." <?php echo e($permission); ?>><?php echo e(isset($project->project_note_desc) ? $project->project_note_desc : old('pro_note_desc')); ?></textarea>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="panel panel-default">
                    <div class="panel-body">
                      <div class="form-group">
                          <div><label>Option Choice</label>&nbsp;</div>
                          <label style="font-weight:400;"> 
                            <input type="radio" name="option" value="1" checked="">
                            <span style="position: relative;top:-2px;">Invoice</span>
                          </label>&nbsp;&nbsp;
                          <label style="font-weight: 400;">
                              <input type="radio" name="option" value="0">
                              <span style="position: relative;top:-2px;">Quotation</span>
                          </label>
                        </div> 
                    </div>
                  </div>
                  <div class="panel panel-default">
                    <div class="panel-body">
                      <div class="btn-group" style="display: block;">
                        <button type="button" class="form-control" data-toggle="dropdown" aria-haspopup="false" aria-expanded="false" data-backdrop="static" data-keyboard="false" role="dialog" data-backdrop="static" data-keyboard="false" <?php echo e($permission); ?>>
                         <span class="pull-left"><i class="fa fa-user-plus" style="color: #5aabf1;"></i> User Tags</span><span class="pull-right"><i class="caret"></i></span>
                        </button>  
                        <div class="obs-wrapper-search">
                          <ul class="dropdown-data" style="width: 100%;" id="Show_date">
                            <?php $__currentLoopData = App\User::where('banned',0)->orderBy('fullname', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li <?php echo e(in_array($user->id, [Auth::user()->id])? "style=display:none":""); ?>>
                              <div class="checkbox">
                                <input id="ch<?php echo e($key); ?>" type="checkbox" name="usertag[]" value="<?php echo e($user->id); ?>" <?php echo e(in_array($user->id, explode(',', $tag_user)) ? 'checked':''); ?>   <?php echo e(in_array($user->id, [Auth::user()->id])? "checked":""); ?>> 
                                <label style="position: relative;top: 5px;" for="ch<?php echo e($key); ?>"><?php echo e($user->fullname); ?> <small>(<?php echo e(isset($user->role->name) ? $user->role->name : ''); ?>)</small></label>
                              </div>
                            </li>                           
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="clearfix"></div>
                          </ul>
                        </div>
                      </div>
                    </div>                  
                  </div>
                  <div class="panel panel-default">
                    <div class="panel-body">
                      <label>Payment Optoin</label>
                      <?php $__currentLoopData = App\Bank::orderBy('name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$bk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>                        
                          <label style="font-weight:400;">
                            <input type="radio" name="bank" value="<?php echo e($bk->id); ?>" <?php echo e($key == 0 ?'checked':''); ?>> 
                            <span style="position: relative;top:-2px"><?php echo e($bk->name); ?></span>
                          </label>
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- <div class="panel-footer">Payment Optoin</div> -->
                  </div>
                </div>
                <div class="col-md-12">
                  <table class="table" id="add_book_project">
                    <thead class="text-center">
                      <tr>
                        <th class="text-center" style="width: 25%;">Date</th>
                        <th class="text-center">Country</th>
                        <th class="text-center">City</th>
                        <th class="text-center" style="width: 22%;">Description</th>
                        <th class="text-center">Pax</th>
                        <th class="text-center">Price</th>
                        <th class="text-center">Total</th>
                        <th class="text-right" style="width: 6%;">
                          <div class="dropdown">
                            <button class="btn btn-xs btn-primary dropdown-toggle" type="button" id="menu1" data-toggle="dropdown"> Add <i class="fa fa-plus-square"></i> 
                            </button>
                            <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="#" class="add_row" data-type="tour" data-url="<?php echo e(route('add_row')); ?>">Tour</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="#" class="add_row" data-type="hotel" data-url="<?php echo e(route('add_row')); ?>">Hotel</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="#" class="add_row" data-type="flight" data-url="<?php echo e(route('add_row')); ?>">Flight</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="#" class="add_row" data-type="cruise" data-url="<?php echo e(route('add_row')); ?>">Cruise</a></li>
                              <li role="presentation"><a role="menuitem" tabindex="-1" href="#" class="add_row" data-type="golf" data-url="<?php echo e(route('add_row')); ?>">Golf</a></li>
                            </ul>
                          </div>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr></tr>
                    </tbody>
                
                  </table>
                  <div id="LoadingRow" style="display:none; position: absolute; margin:-4% 42% 17% 45%">
                    <center><span style="font-size: 38px;" id="placeholder" class="fa fa fa-spinner fa-spin"></span></center>
                  </div> 
                </div>
                <div class="col-md-12 text-right">
                  <div class="form-group">
                    <button type="submit" class="btn btn-success btn-flat btn-sm">Comfirm Booking</button>&nbsp;
                    <span class="btn btn-danger btn-sm reset_booking">Reset Booking</span>     
                  </div>
                </div>               
                <div class="col-md-12">
                  <table class='table'>
                    <thead>
                      <tr class="text-center">
                        <td style="width: 50%;"><strong>Service Included</strong></td>
                        <td style="width: 50%;"><strong>Service Excluded</strong></td>
                      </tr>
                    </thead>
                    <tbody>
                    <?php
                    $Included=App\Service::where(['service_cat'=>1,'service_status'=>1])->get();
                    $Excluded=App\Service::where(['service_cat'=>0,'service_status'=>1])->get();
                    ?>
                    <tr> 
                      <td style="vertical-align: top;">
                        <table class="table" style="width: 100%">
                          <?php $__currentLoopData = $Included->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <?php $__currentLoopData = $roomService; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <td style="width: 50%;">
                               <label style="margin-bottom: 0px; font-weight: 400; cursor: pointer;">
                                <span style="display: <?php echo e(in_array($room->id, explode(',', $service)) ? 'block':'none'); ?>" class="fa fa-check-square check"></span>
                                <span style="display: <?php echo e(in_array($room->id, explode(',', $service)) ? 'none':'block'); ?>;" class="fa fa-square-o nocheck"></span>
                                <input <?php echo e(in_array($room->id, explode(',', $service))? 'checked':''); ?> type="checkbox" class="checkRoom" name="service[]" value="<?php echo e($room->id); ?>"> 
                                <span style="position:relative;left:20px; top:1px;"><?php echo e($room->service_name); ?></span></label>
                              </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                      </td>

                      <td style="vertical-align: top;">
                        <table class="table" style="width: 100%">
                          <?php $__currentLoopData = $Excluded->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $svChunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <?php $__currentLoopData = $svChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td style="width: 50%;">
                              <label style="margin-bottom: 0px; font-weight: 400; cursor: pointer;">
                              <span style="display: <?php echo e(in_array($room->id, explode(',', $service)) ? 'block':'none'); ?>;" class="fa fa-check-square check"></span>
                              <span style="display: <?php echo e(in_array($room->id, explode(',', $service)) ? 'none':'block'); ?>;" class="fa fa-square-o nocheck"></span>
                              <input type="checkbox" class="checkRoom" name="service[]" value="<?php echo e($room->id); ?>" <?php echo e(in_array($room->id, explode(',', $service)) ? 'checked':''); ?>> 
                              <span style="position:relative;left:20px;top:1px;"><?php echo e($room->service_name); ?></span></label>
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </div>
                <div style="margin-bottom: 30px;"></div>
            </section>
          </form>
        </div>
      </section>
    </div>  
  </div>
  <?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>