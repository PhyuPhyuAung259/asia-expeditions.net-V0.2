<?php $__env->startSection('title', 'Banks'); ?>
<?php $active = 'setting-options';
$subactive ='bank'; 
use App\component\Content;
?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <form action="POST">
            <section class="col-lg-12 connectedSortable">
                <h3 class="border">Banks List <span style=" font-size: 22px;" class="fa fa-angle-double-right"></span> <a href="<?php echo e(route('getBankForm')); ?>" class="btn btn-primary btn-sm">Add New Bank Info</a></h3>
                <table class=" table table-hover table-striped">
                  <thead>
                    <tr>
                      <th>Title</th>                     
                      <th>Created at</th>
                      <th width="120px" class="text-center">Status</th>
                      <th width="100px" class="text-center">action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>                     
                      <td><a target="_blank" href="<?php echo e(route('getBankPreview', ['preview_bank' => $ab->id])); ?>"><?php echo e($ab->name); ?></a></td>
                      <td><?php echo e(Content::dateformat($ab->updated_at)); ?></td>
                      <td class="text-center"><?php echo $ab->status > 0 ? '<span class="badge">Enable</span>':'<span class="badge label-warning">Disabled</span>'; ?></td>
                      <td class="text-right">
                        <a href="<?php echo e(route('getBankForm', ['bank_id'=> $ab->id])); ?>"  title="Edit bank info">
                          <label style="cursor: pointer;" class="icon-list ic_edit"></label>
                        </a>         
                        <a href="javascript:void(0)" class="RemoveHotelRate" data-type="bank" data-id="<?php echo e($ab->id); ?>" title="Remove this user?">
                            <label style="cursor: pointer;" class="icon-list ic_remove"></label>
                        </a>
                      </td>                     
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>                
            </section>
          </form>
        </div>
    </section>
  </div>  
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>