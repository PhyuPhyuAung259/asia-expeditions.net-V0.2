<?php $__env->startSection('title', 'Create Tour'); ?>
<?php
  $active = 'tours'; 
  $subactive ='tour/create/new';
  use App\component\Content;
  $countryId = Auth::user()->country_id ? Auth::user()->country_id : 0;
?>
<?php $__env->startSection('content'); ?>
  <div class="wrapper">
    <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content"> 
        <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="col-lg-12"><h3 class="border">Tour Management</h3></div>
        <form method="POST" action="<?php echo e(route('tourCreate')); ?>">
            <?php echo e(csrf_field()); ?>

            <section class="col-lg-9 connectedSortable">
              <div class="card">                                
                <div class="row">
                  <div class="col-md-6 col-xs-12">
                    <div class="form-group">
                      <label>Tour name<span style="color:#b12f1f;">*</span></label> 
                      <input type="text" placeholder="Tour Name" class="form-control" name="title" required>
                    </div> 
                  </div>        
                  <div class="col-md-3 col-xs-6">
                    <div class="form-group">
                      <label>Country <span style="color:#b12f1f;">*</span></label> 
                      <select class="form-control country" data-locat="data" name="country" data-type="country"  data-locat="data"  data-method="tour_accommodation" required>
                        <?php $__currentLoopData = App\Country::where('country_status', 1)->whereHas('tour')->orderBy('country_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($con->id); ?>"><?php echo e($con->country_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div> 
                  </div>
                  <div class="col-md-3 col-xs-6">
                    <div class="form-group">
                      <label>City <span style="color:#b12f1f;">*</span></label> 
                      <select class="form-control" name="city" id="dropdown-country" required>
                        <?php $__currentLoopData = App\Province::where(['province_status'=> 1, 'country_id'=> $countryId ])->orderBy('province_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($pro->id); ?>"><?php echo e($pro->province_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div> 
                  </div>
                  <div class="col-md-3 col-xs-6">
                    <div class="form-group">
                      <label>Tour Type <span style="color:#b12f1f;">*</span></label>
                       <div class="btn-group" style="display: block;">
                          <button type="button" class="form-control " data-toggle="dropdown" aria-haspopup="false" aria-expanded="false" data-backdrop="static" data-keyboard="false" role="dialog" data-backdrop="static" data-keyboard="false">
                            <span class="pull-left">Tour Type </span><span class="pull-right"><i class="caret"></i></span>
                          </button>  
                          <?php $getTourType = App\TourType::where(['status'=>1,'company_id'=>Auth::user()->company_id])->orderBy('title')->get(); ?>
                          <div class="obs-wrapper-search">
                            <?php if($getTourType->count() > 0): ?>
                              <div>
                                <input type="text" id="search" onkeyup="myFunction()" class="form-control input-sm" >
                              </div>
                              <ul id="myUL" class="list-unstyled" style="width: 100%;">
                                <?php $__currentLoopData = $getTourType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li class="list" style="padding: 0px 0px;">
                                    <input id="checkid<?php echo e($key); ?>" type="checkbox" name="type[]" value="<?php echo e($cat->id); ?>">
                                    <label style="position: relative;top: -1px;" for="checkid<?php echo e($key); ?>"><?php echo e($cat->title); ?></label>
                                  </li>                           
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="clearfix"></div>
                              </ul>
                            <?php else: ?>
                              <div class="text-center"><span>Not Found tour Type ...!</span></div>
                            <?php endif; ?>
                          </div>
                        </div>
                    </div>
                  </div>               
                  <div class="col-md-3 col-xs-6">
                    <div class="form-group">
                      <label>Destination</label>
                       <input type="text" name="destination" class="form-control" placeholder="Destination" >
                    </div>
                  </div>
                  <div class="col-md-3 col-xs-6">
                    <div class="form-group">
                      <label>Days/Nights</label> 
                      <input type="text" name="daynight" class="form-control" placeholder="Days/Nights" >
                    </div>
                  </div>
                  <div class="col-md-3 col-xs-6">
                    <div class="form-group">
                      <label>Price <small>(<?php echo e(Content::currency()); ?>)</small></label> 
                      <input type="text" name="tour_price" class="form-control number_only" placeholder="00.00 <?php echo e(Content::currency()); ?>">
                    </div>
                  </div>
                </div>  
                <div class="form-group">
                  <label>Service Included/Exluded</label>
                  <script src="<?php echo e(asset('adminlte/editor/tinymce.min.js')); ?>"></script>
                  <textarea class="form-control my-editor" name="tour_remark" rows="6" placeholder="Enter ..."><?php echo old('tour_remark'); ?></textarea>             
                </div>
                <div class="form-group">
                  <label>Hightlights</label>
                  <textarea class="form-control my-editor" name="tour_hight" rows="6" placeholder="Enter ..."><?php echo old('tour_hight'); ?></textarea>      
                </div>
                <div class="form-group">
                  <label>Description</label>
                  <textarea class="form-control my-editor" name="tour_desc" rows="6" placeholder="Enter ..."><?php echo old('tour_desc'); ?></textarea>
                </div>
                <div class="form-group">
                  <div class="col-md-3 col-xs-6">
                    <div class="form-group">
                      <label>Status</label>&nbsp;
                      <label style="font-weight:400;"> <input type="radio" name="status" value="1" checked="">Publish</label>&nbsp;&nbsp;
                      <label style="font-weight: 400;"> <input type="radio" name="status" value="0">UnPublish</label>
                    </div> 
                  </div>
                </div>             
              </div>
            </section>
            <section class="col-lg-3 connectedSortable"><br>
              <div class="panel panel-default">
                <div class="panel-body">
                  <div id="wrap-feature-image" style="position:relative;">
                    <input type="hidden" name="image" id="data-img">
                    <img id="feature-img" src="#" style="width:100%;display:none;margin-bottom:12px;" class="btnUploadFiles" data-type="single-img" data-toggle="modal" data-target="#myUpload">
                    <i id="removeImage" class="fa fa-remove (alias)" title="Remove picture" style="display: none;"></i>
                  </div>
                  <a href="#uploadfile" class="btnUploadFiles" data-type="single-img" data-toggle="modal" data-target="#myUpload">Set Feature Image</a>
                </div>
                <div class="panel-footer">Supplier Logo</div>
              </div>
              <div class="form-group text-center"> 
                <button type="submit" class="btn btn-success btn-flat btn-sm">Submit</button>
              </div>
              <div class="panel panel-default">
                <div class="panel-body" style="padding: 8px;">
                  <div id="wrap-gallery-image" style="position:relative;">
                    <ul class="list-ustyled">
                    </ul>                    
                    <div class="clearfix"></div>
                    <i id="removeImage" class="fa fa-remove (alias)" title="Remove picture" style="display: none;"></i>
                  </div>
                  <a href="#uploadfile" class="btnUploadFiles" data-type="multi-img" data-toggle="modal" data-target="#myUpload">Set Gallery Image</a>
                </div>
                <div class="panel-footer">Gallery Image</div>
              </div>
              <?php $getService = \App\Service::where(['service_cat'=>0, 'company_id'=> Auth::user()->company_id])->orderBy('service_name', 'ASC')->get(); ?>
             <?php if($getService->count() > 0): ?>
              <div class="panel panel-default">
                <div class="panel-heading"><strong>Tours Facilities</strong></div>
                <div class="panel-body scrolTourFeasility" style="padding: 8px; max-height: 277px;">
                  <ul class="list-unstyled">
                    <?php $__currentLoopData = $getService; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li>
                        <div class="checkMebox">
                          <label>
                            <span style="position: relative;top: 4px;"> 
                              <i class="fa fa-square-o "></i>
                              <input type="checkbox" name="tour_feasilitiy[]" value="<?php echo e($sv->id); ?>">&nbsp;
                            </span>
                            <span><?php echo e($sv->service_name); ?></span>
                          </label>
                        </div>
                      </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div>
                <div class="panel-footer"></div>
              </div>
              <?php endif; ?>
              <?php 
                $getSupplier = \App\Supplier::where(['business_id'=>1,'supplier_status'=>1,'company_id'=> Auth::user()->company_id])->select('id', 'supplier_name')->orderBy('supplier_name')->get();
              ?>
              <?php if($getSupplier->count() > 0): ?>
                <div class="panel panel-default">
                  <div class="panel-heading"><strong>Accommodation</strong></div>
                  <div class="panel-body scrolTourAccommodation" style="padding:8px; max-height: 277px; overflow: auto;">
                    <ul class="list-unstyled">
                      <?php $__currentLoopData = $getSupplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                          <div class="checkMebox">
                            <label>
                              <span style="position: relative;top: 4px;"> 
                                <i class="fa fa-square-o"></i>
                                <input type="checkbox" name="tour_supplier[]" value="<?php echo e($sup->id); ?>">&nbsp;
                              </span>
                              <span><?php echo e($sup->supplier_name); ?></span>
                            </label>
                          </div>
                        </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                  </div>
                  <div class="panel-footer"></div>
                </div>
              <?php endif; ?>
            </section>
        </form>
        <div class="clearfix"></div>
      </section>
    </div>  
  </div>
  <?php echo $__env->make('admin.include.windowUpload', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.editor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script>
    function myFunction() {
      input = document.getElementById("search");
      filter = input.value.toUpperCase();
      ul = document.getElementById("myUL");
      li = ul.getElementsByTagName("li");
      for (i = 0; i < li.length; i++) {
        a = li[i];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
          li[i].style.display = "";
        } else {
          li[i].style.display = "none";
        }
      }
    }
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>