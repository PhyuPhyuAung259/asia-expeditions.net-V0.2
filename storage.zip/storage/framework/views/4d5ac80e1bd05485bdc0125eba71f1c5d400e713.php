<?php $__env->startSection('title', 'Booked Hotel List'); ?>
<?php $active = 'booked/project'; 
$subactive = 'booked/hotelrate';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <form method="POST" action="<?php echo e(route('searchProject', ['project'=> 'hotelrate'])); ?>">
             <?php echo e(csrf_field()); ?>

            <section class="col-lg-12 connectedSortable">
                <h3 class="border">Booked Hotel Rate List</h3>
                <div class="col-sm-8 pull-right">
                  <div class="col-md-3">
                    <input type="hidden" name="" value="<?php echo e(isset($projectNum) ? $projectNum : ''); ?>" id="projectNum">
                    <input class="form-control input-sm" type="text" id="from_date" name="start_date" placeholder="From Date" value="<?php echo e(isset($startDate) ? $startDate : ''); ?>"> 
                  </div>
                  <div class="col-md-3">
                    <input class="form-control input-sm" type="text" id="to_date" name="end_date" placeholder="To Date" value="<?php echo e(isset($endDate) ? $endDate : ''); ?>"> 
                  </div>
                   <div class="col-md-2" style="padding: 0px;">
                    <button class="btn btn-default btn-sm" type="submit">Search</button>
                  </div>
                </div>
                <table class="datatable table table-hover table-striped">
                  <thead>
                    <tr>                       
                      <th width="75">Project No.</th>
                      <th>Check-In</th>
                      <th>Check-Out</th>
                      <th>Hotel</th>
                      <th>Room Type</th>
                      <?php $__currentLoopData = App\RoomCategory::take(5)->orderBy('id', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e($cat->name); ?></th>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <th class="text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   
                    <tr> 
                      <td class="studentId" width="75">
                        <input type="checkbox" class="btnCheck"> &nbsp; 
                        <?php echo e($hotel->project_number); ?></td>
                      <td><?php echo e(Content::dateformat($hotel->checkin)); ?></td>
                      <td><?php echo e(Content::dateformat($hotel->checkout)); ?></td>
                      <td><?php echo e(isset($hotel->hotel->supplier_name) ? $hotel->hotel->supplier_name : ''); ?></td>
                      <td><?php echo e(isset($hotel->room->name) ? $hotel->room->name : ''); ?></td>
                      <td class="text-right"><?php echo e(number_format($hotel->ssingle, 2)); ?></td>
                      <td class="text-right"><?php echo e(number_format($hotel->stwin, 2)); ?></td>
                      <td class="text-right"><?php echo e(number_format($hotel->sdouble, 2)); ?></td>
                      <td class="text-right"><?php echo e(number_format($hotel->sextra, 2)); ?></td>
                      <td class="text-right"><?php echo e(number_format($hotel->schextra, 2)); ?></td>
                      <td class="text-right">
                        <?php if(isset($hotel->book->id)): ?>
                          <a  target="_blank" href="<?php echo e(route('hVoucher', ['project'=>$hotel->project_number, 'bhotel'=> $hotel->id, 'bookid'=>$hotel->book->id, 'type'=>'hotel-voucher'])); ?>" title="Hotel Voucher">
                        <?php else: ?>
                          <a href="javascript:void(0)" title="No Room Rate">
                        <?php endif; ?>
                          <label class="icon-list ic_inclusion"></label>
                        </a>
                        <a href="javascript:void(0)" class="RemoveHotelRate" data-type="book_hotelrate" data-id="<?php echo e($hotel->id); ?>" title="Delete this Hotel Rate">
                          <label class="icon-list ic_remove"></label>
                        </a>                     
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <!-- <div class="pull-left">Check All</div> -->
            </section>
          </form>
        </div>
    </section>
</div>
<script type="text/javascript">
  $(".datatable").DataTable({
      language: {
        searchPlaceholder: "File / Project No."
      }
  });
</script>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>