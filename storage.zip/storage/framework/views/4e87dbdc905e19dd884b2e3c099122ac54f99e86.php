<?php $__env->startSection('title', 'Flight Booking'); ?>
<?php $active = 'booked/project';
$subactive ='booked/flight';
  use App\component\Content;
  $countryId = $book->country_id != null ? $book->country_id : Auth::user()->country_id;
  $amount = number_format(($book->book_price * $book->book_pax), 2);
?>
<?php $__env->startSection('content'); ?>
  <div class="wrapper">
    <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content"> 
        <div class="row">
          <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="col-lg-12"><h3 class="border">Flight Booking</h3></div>
          <form method="POST" action="<?php echo e(route('updateBooked', 'flight')); ?>">
              <?php echo e(csrf_field()); ?>

              <input type="hidden" name="bookId" value="<?php echo e($book->id); ?>">
              <section class="col-lg-9">                              
                  <div class="row">
                    <div class="col-md-3 col-xs-12">
                      <div class="form-group">
                        <label>Flight Date <span style="color:#b12f1f;">*</span></label> 
                        <input type="text" class="form-control book_date" name="book_start" value="<?php echo e($book->book_checkin); ?>"  placeholder="Tour Date" required >
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Country <span style="color:#b12f1f;">*</span></label> 
                        <select class="form-control country" name="country" data-type="country_flight" required>
                          <?php $__currentLoopData = App\Country::where('country_status', 1)->orderBy('country_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($con->id); ?>" <?php echo e($book->country_id == $con->id ? 'selected':''); ?>><?php echo e($con->country_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>City <span style="color:#b12f1f;">*</span></label> 
                        <select class="form-control province" name="city" id="dropdown-data" data-type="pro_Book_flight">
                          <?php 
                            $cityFlight = \App\FlightSchedule::where(['flight_status'=>1, 'country_id'=> $countryId])->groupBy('province_id')->orderBy('flight_from', 'DESC')->get();
                          ?>
                          <?php if($cityFlight->count() > 0): ?>{
                            <option value="0">Choose City</option>
                            <?php $__currentLoopData = $cityFlight; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php 
                                $fl = \App\Province::find($pro->province_id);
                              ?>
                              <?php if($fl): ?>
                                <option value="<?php echo e($fl->id); ?>" <?php echo e($fl->id == $book->province_id ? 'selected':''); ?>><?php echo e($fl->province_name); ?></option>
                              <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                        </select>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Destination <span style="color:#b12f1f;">*</span></label> 
                       <select class="form-control city_destination"​​​ id="city_destination" name="city_destination" data-type="single_city_destination">
                          <option value="0">Destination</option>
                        <?php if($book->city_destination): ?>
                          <option value="<?php echo e($book->city_destination); ?>" selected><?php echo e($book->city_destination); ?></option>
                        <?php endif; ?>
                       </select>
                      </div> 
                    </div>        
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Flight Number<span style="color:#b12f1f;">*</span></label> 
                        <select class="form-control Book_FlightNo" data-type="flightno" name="flight_name" id="dropdown-FlightNo" style="font-size: 12px;">
                          <?php $__currentLoopData = App\FlightSchedule::where(['flight_status'=> 1, 'supplier_id'=>$book->supplier_id])->orderBy('flightno')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($fno->id); ?>" <?php echo e($fno->id == $book->flight_id ? 'selected':''); ?>><?php echo e($fno->flightno); ?> - D:<?php echo e($fno->dep_time); ?> -> A:<?php echo e($fno->arr_time); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Ticketing Agent <span style="color:#b12f1f;">*</span></label> 
                        <?php 
                        $gatFAgent = App\FlightSchedule::find($book->flight_id); 
                        ?>
                        <select class="form-control book_FlightAgent" name="ticketing" id="dropdown-TicketingAgent"  style="font-size: 12px;">
                          <?php if( isset($gatFAgent->flightagent) ): ?>
                              <option value="0" class="no_data">Select Flight Agent</option>
                            <?php $__currentLoopData = $gatFAgent->flightagent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($sch->id); ?>" data-oneway="<?php echo e($sch->pivot->oneway_price); ?>" 
                                      data-return="<?php echo e($sch->pivot->return_price); ?>" 
                                      data-noneway="<?php echo e($sch->pivot->oneway_nprice); ?>" 
                                      data-nreturn="<?php echo e($sch->pivot->return_nprice); ?>" 
                                      data-koneway="<?php echo e($sch->pivot->oneway_kprice); ?>" 
                                      data-kreturn="<?php echo e($sch->pivot->return_kprice); ?>" 
                                      <?php echo e($sch->id == $book->book_agent?'selected':''); ?>><?php echo e($sch->supplier_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php else: ?> 
                            <option value="">No Agent</option>
                          <?php endif; ?>
                        </select>
                      </div> 
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Pax No.</label> 
                        <select class="form-control book_FlightPax" name="book_pax">
                          <?php for($n=1; $n<=29; $n++): ?>
                            <option value="<?php echo e($n); ?>" <?php echo e($n==$book->book_pax?'selected':''); ?>><?php echo e($n); ?></option>
                          <?php endfor; ?>
                        </select>
                      </div>
                    </div>                    
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <div><label>Book Way</label></div>
                        <label style="font-weight:400;"> 
                          <input type="radio" class="bookway" name="book_way" value="Oneway" <?php echo e($book->book_way == 'Oneway'? 'checked':''); ?> /><span style="position: relative;top:-2px;">Oneway</span></label>&nbsp;&nbsp;
                        <label style="font-weight: 400;"> 
                          <input type="radio" class="bookway" name="book_way" value="Return" <?php echo e($book->book_way == 'Return'? 'checked':''); ?> /><span style="position: relative;top:-2px;">Return</span></label>
                      </div>
                    </div><div class="clearfix"></div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Price <?php echo e(Content::currency()); ?></label> 
                        <input type="text" name="book_price" id="book_price" class="form-control" value="<?php echo e($book->book_price); ?>" placeholder="00.0" readonly>
                        <input type="hidden" name="book_nprice" id="book_nprice" value="<?php echo e($book->book_nprice); ?>">
                        <input type="hidden" name="book_kprice" id="book_kprice" value="<?php echo e($book->book_kprice); ?>">
                      </div>
                    </div>
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Amount <?php echo e(Content::currency()); ?></label> 
                        <input type="text" name="book_amount" id="book_amount" class="form-control" value="<?php echo e($book->book_amount); ?>" placeholder="00.0" readonly>
                      </div>
                    </div>
                    
                </div>
              </section>
              <section class="col-lg-3 ">
                <div class="panel panel-default">
                  <div class="panel-body">
                    <div class="form-group">
                      <div><label>Status</label></div>
                      <label style="font-weight:400;"> <input type="radio" name="status" value="1" <?php echo e($book->book_status == 1? 'checked':''); ?>><span style="position: relative;top:-2px;">Publish</span></label>&nbsp;&nbsp;
                      <label style="font-weight: 400;"> <input type="radio" name="status" value="0" <?php echo e($book->book_status == 0? 'checked':''); ?>><span style="position: relative;top:-2px;">UnPublish</span></label>
                    </div> 
                  </div>
                  <div class="panel-footer text-center">
                    <button type="submit" class="btn btn-success btn-flat btn-sm">Submit</button> &nbsp;
                    <a href="<?php echo e(route('projectList', ['url'=> 'tour'])); ?>" class="btn btn-default btn-flat btn-sm">Go Bak</a>
                  </div>
                </div>
              </section>
          </form>
        </div>
      </section>
    </div>  
  </div>
  <?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>