<?php  use App\component\Content;?>
<table class="table" id="roomrate">
	<tr style="background-color: rgb(245, 245, 245);">
		<th style="padding: 2px;"><span>Service Name</span></td>
		<th style="padding: 2px;"><span>Selling Price</span></th>		
		<th style="padding: 2px;"><span>Net Price</span></th>		
		<th style="padding: 2px;"><span>Selling Kyat</span></th>		
		<th style="padding: 2px;"><span>Net Kyat</span></th>		
	</tr>		
	<?php $__currentLoopData = App\GolfMenu::where('supplier_id', $supplier->id)->orderBy('nprice')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $golf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
		<tr>
			<td style="width: 50%;"><?php echo e($golf->name); ?></td>
			<td><?php echo e($golf->price); ?> <span class="pcolor"><?php echo e(Content::currency()); ?></span></td>
			<td><?php echo e($golf->nprice); ?> <span class="pcolor"><?php echo e(Content::currency()); ?></span></td>
			<td><?php echo e($golf->kprice); ?> <span class="pcolor"><?php echo e(Content::currency(1)); ?></span></td>
			<td><?php echo e($golf->kprice); ?> <span class="pcolor"><?php echo e(Content::currency(1)); ?></span></td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php echo $__env->make('admin.report.supplier_info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</table>