
<!-- <?php $__currentLoopData = \App\Department::where(['status'=>1, 'type'=>3])->orderBy('order', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="col-sm-3 col-md-3 col-lg-1 col-xs-4 acc_no-padding">
    <a href="<?php echo e(route('getAccount')); ?>/<?php echo e($dep->slug); ?>">
      <div class="small-box btn btn-default <?php echo e($dep->slug==$active?'active':''); ?>" style="<?php echo e($dep->style); ?>">
        <div class="icon"><i class="<?php echo e($dep->icon); ?>"></i></div>
        <div><span><?php echo e($dep->name); ?></span></div>  
      </div>
    </a>
</div>     
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 -->