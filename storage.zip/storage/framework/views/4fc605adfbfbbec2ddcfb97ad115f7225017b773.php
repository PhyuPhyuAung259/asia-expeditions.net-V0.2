<?php $__env->startSection('title', 'Tours List'); ?>
<?php $active = 'setting-options'; 
  $subactive ='blog';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <section class="col-lg-12 connectedSortable">
            <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <h3 class="border">Blog Lists <span class="fa fa-angle-double-right"></span> <a href="<?php echo e(route('blogcreate')); ?>" class="btn btn-primary btn-sm">Add New Activity</a></h3>
            <form action="" method="">
              <div class="col-sm-2 col-xs-6 pull-right" style="text-align: right; position: relative; z-index: 2;">
                <label class="location">
                  <select class="form-control input-sm locationchange" name="location">
                    <?php $__currentLoopData = \App\Country::whereHas('tour', function($query) {$query->where('post_type', 1);})->where('country_status', 1)->orderBy('country_name', 'DESC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($loc->id); ?>" <?php echo e($locationid == $loc->id ? 'selected':''); ?>><?php echo e($loc->country_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </label>
              </div>
            </form>
            <table class="datatable table table-hover table-striped">
              <thead>
                <tr>
                  <th style="width: 12px;">Photo</th>
                  <th>Tittle</th>
                  <th>Published</th>
                  <th width="110" class="text-center">Options</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                 
                <tr>
                  <td><img src="<?php echo e(Content::urlthumbnail($tour->tour_photo, $tour->user_id)); ?>" style="width: 100%"></td>
                  <td><?php echo e($tour->tour_name); ?></td>
                  <td><?php echo e(Content::dateformat($tour->updated_at)); ?></td>
                  <td class="text-right">                      
                    <a href="<?php echo e(route('blogedit', ['url'=>$tour->id])); ?>" title="Edit Activity">
                      <label src="#" class="icon-list ic_edit_tour"></label>
                    </a>                   
                    <?php echo Content::DelUserRole("Delete this blog ?", "tour", $tour->id, $tour->user_id ); ?>    
                  </td>                     
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>                
          </section>
        </div>
    </section>
  </div>  
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>