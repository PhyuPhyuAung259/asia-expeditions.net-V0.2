<?php $__env->startSection('title', 'Room Type'); ?>
<?php $active = 'supplier/hotels'; 
  $subactive ='hotel/room';
  use App\component\Content;
?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <div class="row">
        <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <section class="col-lg-12">
          <h3 class="border">Room Type <span class="fa fa-angle-double-right"></span> <a href="#" class="btn btn-primary btn-sm btnEditRoom" data-toggle="modal" data-target="#myModal">New Room</a></h3>
          <table class="datatable table table-hover table-striped">
            <thead>
              <tr>                     
                <th>Name</th>
                <th>Description</th>
                <th width="100" class="text-center">Status</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($rom->name); ?></td>        	
                <td><?php echo e($rom->description); ?></td>				                  
    						<td class="text-center"> 
                    <a class="btnEditRoom" href="#" title="Edit Room Type" data-toggle="modal" data-id="<?php echo e($rom->id); ?>" data-name="<?php echo e($rom->name); ?>" data-room_desc="<?php echo e($rom->description); ?>" data-target="#myModal">
                      <!-- <label class="icon-list ic_edit"></label> -->
                      <i class="fa fa-edit btn btn-info btn-xs" ></i>
                    </a>	                        
                    &nbsp;&nbsp;
                    <a href="javascript:void(0)" class="RemoveHotelRate" data-type="room_type" data-id="<?php echo e($rom->id); ?>" title="Remove this?">
                      <i class="fa fa-minus btn btn-danger btn-xs"></i>
                    </a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>                
        </section>
      </div>
    </section>
  </div>
</div>

<div class="modal fade" id="myModal" role="dialog" data-backdrop="static" data-keyboard="true">
  <div class="modal-dialog modal-md">
    <form method="POST" action="<?php echo e(route('EditRoomType')); ?>">
      <div class="modal-content">       
        <input type="hidden" name="roomid" id="roomid"> 
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><strong> Room Type</strong></h4>
        </div>
        <div class="modal-body">
          <?php echo e(csrf_field()); ?> 
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label>Room Name</label>
                <input type="text" name="room_name" id="room_name" class="form-control" placeholder="Room Name">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label>Decription</label>
                <textarea class="form-control" rows="5" id="room_desc" name="description" placeholder="Type Decription...!"></textarea>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 col-xs-6">
              <div class="form-group">
                <label>Status</label>&nbsp;
                <label style="font-weight:400;"> <input type="radio" name="status" value="1" checked="">Publish</label>&nbsp;&nbsp;
                <label style="font-weight: 400;"> <input type="radio" name="status" value="0">UnPublish</label>
              </div>
            </div>
          </div>
          <div class="modal-footer" style="text-align: center;">
              <button type="submit" class="btn btn-success btn-flat btn-sm">Save</button>
          </div>
        </div>     
      </div>   
    </form>
  </div>
</div>
<script type="text/javascript">
  $(document).on("click", ".btnEditRoom", function(){
    $("#room_name").val($(this).data('name'));
    $("#room_desc").val($(this).data('room_desc'));
    $("#roomid").val($(this).data('id'));
  });
</script>
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>