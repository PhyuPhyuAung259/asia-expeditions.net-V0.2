<?php $__env->startSection('title', "Preview Post Account"); ?>
<?php 
	use App\component\Content;
	$user = App\User::find(isset($project->check_by) ? $project->check_by: 0);
?>
<?php $__env->startSection('content'); ?>
<style type="text/css">
	 
	.badge{
		line-height: 1.5 !important;
	}
</style>
	<div class="container">
		<div class="col-lg-12">
		    	<?php echo $__env->make('admin.report.project_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>	 
		    	<?php echo $__env->make("admin.include.message", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<div class="pull-left">
					<p><b>CRD:</b> <?php echo e(isset($project->project_date) ? Content::dateformat($project->project_date) :''); ?>, 
						<?php if( isset($project->project_check) ): ?>
						Project No. <b><?php echo e($project->project_number); ?></b> is Already checked by <b><?php echo e(isset($user->fullname) ? $user->fullname : ''); ?></b> at <?php echo e(Content::dateformat($project->project_check_date)); ?>,
						<?php endif; ?>
						<b>Revised Date</b> <?php echo e(isset($project->project_revise) ? $project->project_revise : ''); ?>

					</p> 
				</div>
				<div class="clearfix"></div>
				<!-- Hotel Start  -->
			<?php if(isset($project->project_number)): ?>
				<form method="GET" target="_blank" action="<?php echo e(route('requestReport', ['url'=> $project->project_number])); ?>">	
					<table class="table table-borderd" border="1">
						<?php 
							$totalCruise = 0;
							$totalHotel = 0;
						?>
						<?php 	
							$hotelBook  = App\HotelBooked::where('project_number', $project->project_number);
							$cruiseBook = App\CruiseBooked::where('project_number', $project->project_number);
							$tourBook   = App\Booking::tourBook($project->project_number);
							$flightBook = App\Booking::flightBook($project->project_number);
							$golfBook   = App\Booking::golfBook($project->project_number);
							$grandtotal = $cruiseBook->sum('sell_amount') + $golfBook->sum('book_amount') + $flightBook->sum('book_amount') + $hotelBook->sum('sell_amount') + $tourBook->sum('book_amount');
							if (empty((int)$project->project_selling_rate)) {
								$Project_total = $grandtotal;
							}else{
								$Project_total =  $project->project_selling_rate;
							} 
						?>
						<?php if(!empty($Project_total)): ?>
							<tr style="background-color:#f4f4f4;">
								<th style="border-top: none;" width="170px">Travelling Date</th>
								<th style="border-top: none;" colspan="9">Descriptions</th>
								<th style="border-top: none; width: 17%;" colspan="2" class="text-left">INV-Amount</th>
							</tr>
							<tr>
								<td><?php echo e(Content::dateformat($project->project_start)); ?> - <?php echo e(Content::dateformat($project->project_end)); ?></td>
								<td colspan="9"><?php echo $project->project_desc; ?></td>
								<td class="text-right" colspan="2">
									<?php
	              						$proJournal = \App\AccountJournal::where(['supplier_id'=> $project->supplier_id, 'business_id' => 9,'project_number' => $project->project_number, "book_id" => $project->id, 'status'=>1])->first();
	              						if ($proJournal) {
	              							$accTransaction = \App\AccountTransaction::where(['journal_id'=>$proJournal->id, 'account_type_id'=> 8, 'status'=>1]);
	              						}
	              					?>
	          						<?php if($proJournal): ?> 
	          							<span class="pull-left"><?php echo e(Content::money($Project_total - $accTransaction->sum('debit'))); ?></span>
	          						<?php else: ?>
										<span class="pull-left"><?php echo e(Content::money($Project_total)); ?> </span>
	          						<?php endif; ?>

									<?php if(!empty($Project_total)): ?>
	              						<?php if(isset($proJournal) && !empty($proJournal->supplier_id)): ?>
	              							<?php $accTransaction = \App\AccountTransaction::where(['journal_id'=>$proJournal->id, 'account_type_id'=> 8, 'status'=>1]); ?>
	              							<span class="btn btn-link btn-xs hidden-print">
	                  							<a target="_blank" href="<?php echo e(route('getJournalReport', ['journal_entry' => $project->project_number])); ?>">View/Edit</a>
	                  						</span>
	                  						<?php if($proJournal->credit > $accTransaction->sum('debit') || $proJournal->kcredit > $accTransaction->sum('kdebit')): ?>
	              								<a target="_blank" href="<?php echo e(route('getPayable', ['journal_id'=> $proJournal->id])); ?>" class="btn btn-info btn-acc btn-xs pull-right hidden-print"> <b>Receive Now</b></a>
	          								<?php else: ?>
	              								<span class="badge badge-light" style="line-height: none">Full Received</span>
	              							<?php endif; ?>
	                  					<?php else: ?>
	                  						<?php $supplier = \App\Supplier::find($project->supplier_id); ?>
											<span data-toggle="modal" data-target="#loadProjectConfirm" class="btn btn-success btn-xs AddToACcount text-right hidden-print pull-right"
	                  							data-type="9" data-kamount="" 
	                  							data-amount="<?php echo e($Project_total); ?>" 
	                  							data-process_type="receive" 
	                  							data-bus_type="agent"
	                  							data-title="<?php echo e(isset($supplier->supplier_name) ? $supplier->supplier_name : ''); ?>"
	                  							data-book_id="<?php echo e($project->id); ?>"
	                  							data-supplier="<?php echo e($project->supplier_id); ?>" 
	                  							data-country="<?php echo e($project->country_id); ?>">Post</span>
	                  					<?php endif; ?>
									<?php endif; ?>
								</td>
								
							</tr>
						<?php endif; ?>
						<?php 
							$hotelBook = \App\HotelBooked::where(['project_number'=> $project->project_number, 'status'=>1])
									->orderBy("checkin", "ASC"); 
						?>
						<?php if($hotelBook->get()->count() > 0): ?>
							<tr class="hotel">
								<th style="border-top: none;" colspan="11"`><strong style="text-transform: capitalize;"> hotel OverView</strong></th>
							</tr>
							<tr style="background-color:#f4f4f4;">
								<th width="200px">Checkin - Checkout</th>
								<th colspan="5" width="200px">Hotel</th>
								<th colspan="2" width="120px">Room</th>
								<th width="110px" style="font-size: 11px;">No. Room</th>
								<th class="text-center">Nights</th>
								<th class="text-left" width="290px">Amount</th>
							</tr>
							<?php $__currentLoopData = $hotelBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr class="container_hotel">
									<td>									
										<span><?php echo e(Content::dateformat($hotel->checkin)); ?> - <?php echo e(Content::dateformat($hotel->checkout)); ?></span>
									</td>
									<td colspan="5"><?php echo e(isset($hotel->hotel->supplier_name) ? $hotel->hotel->supplier_name : ''); ?> <small style="color: #9E9E9E;"><?php echo $hotel->remark > 0 ? "($hotel->remark)" :''; ?></small></td>
									<td colspan="2" ><?php echo e(isset($hotel->room->name) ? $hotel->room->name : ''); ?></td>
									<td class="text-center"><?php echo e($hotel->no_of_room); ?></td>
									<td class="text-center" ><?php echo e($hotel->book_day); ?></td>
									<td class="text-right" width="120px">
										<?php 
											$hotelAmount = $hotel->net_amount;
											$totalHotel = $totalHotel + $hotelAmount;
										?>
										<?php 
	                  						$HproJournal = \App\AccountJournal::where(['supplier_id'=> $hotel->hotel->id, 'business_id' => 1,'project_number' => $project->project_number, "book_id" => $hotel->id, 'status'=>1])->first();
	                  						if ($HproJournal) {
	                  							$accTransaction = \App\AccountTransaction::where(['journal_id'=>$HproJournal->id, 'status'=>1]); 
	                  						}
	                  					?>
	                  					<?php if($HproJournal): ?>
	                  					<?php 
	                  					echo $accTransaction->sum('credit');
	                  					$HotelDeposit = $hotelAmount - $accTransaction->sum('credit'); ?>
											<span class="pull-left">
												<?php echo $HotelDeposit > 0  ? Content::money($HotelDeposit) : "<a style='font-weight: 700;' href='javascript:void(0)'>".Content::money($hotelAmount). "</a>"; ?>

											</span>
										<?php else: ?>
											<span class="pull-left"><?php echo e(Content::money($hotelAmount)); ?></span>
										<?php endif; ?>
										<?php if($hotelAmount > 0): ?>
		              						<?php if(isset($HproJournal) && !empty($HproJournal->supplier_id)): ?>
		              							<span class=" btn btn-link btn-xs hidden-print">
		                  							<a target="_blank" href="<?php echo e(route('getJournalReport', ['journal_entry' => $project->project_number])); ?>">View/Edit</a>
		                  						</span>	
		                  						<?php if($HproJournal->debit > $accTransaction->sum('credit') || $HproJournal->kdebit > $accTransaction->sum('kcredit')): ?>
		              								<a target="_blank" href="<?php echo e(route('getPayable', ['journal_id'=> $HproJournal->id])); ?>" class="btn btn-info btn-acc btn-xs pull-right hidden-print"> <b>Pay Now</b></a>
		              							<?php else: ?>
		              								<span class="badge badge-light" style="line-height: none;">Full Paid</span>
		              							<?php endif; ?>
		                  					<?php else: ?>
												<span data-toggle="modal" data-target="#loadProjectConfirm" class="btn btn-success btn-xs AddToACcount text-right hidden-print pull-right" 
		                  							data-type="1" data-kamount="" 
		                  							data-amount="<?php echo e($hotelAmount); ?>" 
		                  							data-process_type="pay" 
		                  							data-bus_type="hotel"
		                  							data-title="<?php echo e(isset($hotel->hotel->supplier_name) ? $hotel->hotel->supplier_name : ''); ?>" 
		                  							data-book_id="<?php echo e($hotel->id); ?>"
		                  							data-supplier="<?php echo e(isset($hotel->hotel->id) ? $hotel->hotel->id : ''); ?>" 
		                  							data-country="<?php echo e(isset($hotel->hotel->country_id) ? $hotel->hotel->country_id : ''); ?>">Post
		                  						</span>
		                  					<?php endif; ?>
										<?php endif; ?>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td colspan="11" class="text-right"><h5><strong>Total: <?php echo e(Content::money($totalHotel)); ?> <?php echo e(Content::currency()); ?> </strong></h5></td>
							</tr>				
						<?php endif; ?>

						<?php 
							$flightBook = App\Booking::flightBook($project->project_number);
						?>
						<?php if($flightBook->count() > 0): ?>
							<tr class="flight">
								<td style="border-top: none;" colspan="11"><strong>Flight Expenses</strong></td>
							</tr>
							<tr style="background-color:#f4f4f4;">
								<th width="120px" style="width: 18%;">Date</th>
								<th colspan="3" width="119px">Supplier Name</th>
								<th colspan="2" class="text-center">From -> To</th>
								<th class="text-center">Seats</th>					
								<th class="text-right">Price<?php echo e(Content::currency()); ?></th>
								<th class="text-right">Amount</th>
								<th class="text-right">Price <?php echo e(Content::currency(1)); ?></th>
								<th class="text-left" style="width: 17%;">Amount</th>
							</tr>
							<?php $__currentLoopData = $flightBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php 
									$flprice = App\Supplier::find($fl->book_agent);
								?>			
								<tr class="container_flight">
									<td><?php echo e(Content::dateformat($fl->book_checkin)); ?></td>
									<?php if(!empty($fl->book_namount) || !empty($fl->book_kamount) ): ?>
										<?php if(isset($flprice->supplier_name)): ?>
											<?php
		                  						$FproJournal = \App\AccountJournal::where(['supplier_id'=> $flprice->id, 'business_id' => 4,'project_number' => $project->project_number, "book_id"=> $fl->id, 'type'=>1, 'status'=>1])->first();
		                  						if ($FproJournal) {
		                  							$accTransaction = \App\AccountTransaction::where(['journal_id'=>$FproJournal->id, 'status'=>1]);
		                  						}
		                  					?>
										<?php endif; ?>
									<?php endif; ?>
									<td colspan="3"><?php echo e(isset($flprice->supplier_name) ? $flprice->supplier_name : ''); ?></td>
									<td colspan="2" class="text-center"><?php echo e($fl->flight_from); ?> <i class="fa fa-arrow-right"></i> <?php echo e($fl->flight_to); ?></td>
									<td class="text-center"><?php echo e($fl->book_pax); ?></td>
									<td class="text-right"><?php echo e(Content::money($fl->book_nprice)); ?></td>
									<td class="text-right">
										<?php if(isset($FproJournal) && $accTransaction->get()->count() > 0): ?>
											<?php $FlightDeposit = $fl->book_namount - $accTransaction->sum('credit'); ?>
											<?php echo $FlightDeposit > 0  ? Content::money($FlightDeposit) : "<a style='font-weight: 700;' href='javascript:void(0)'>".Content::money($fl->book_namount). "</a>"; ?>

										<?php else: ?>
											<?php echo e(Content::money($fl->book_namount)); ?>

										<?php endif; ?>
									</td>
									<td class="text-right">
										<?php if(isset($FproJournal) && $accTransaction->get()->count() > 0): ?>
											<?php $KFlightDeposit = $fl->book_kprice - $accTransaction->sum('kcredit'); ?>
											<?php echo $KFlightDeposit > 0  ? Content::money($KFlightDeposit) : "<a style='font-weight: 700;' href='javascript:void(0)'>".Content::money($fl->book_kprice). "</a>"; ?>

										<?php else: ?>
											<?php echo e(Content::money($fl->book_kprice)); ?>

										<?php endif; ?>
										
									</td>
									<td class="text-right">
										<?php if($fl->book_namount > 0 || $fl->book_kamount > 0 ): ?>
											<?php if(isset($flprice->supplier_name)): ?>
			                  					<span class="pull-left"><?php echo e(Content::money($fl->book_kamount)); ?></span>
			              						<?php if(isset($FproJournal) && !empty($FproJournal->supplier_id)): ?>
			              							<span class=" btn btn-link btn-xs hidden-print">
			                  							<a  target="_blank" href="<?php echo e(route('getJournalReport', ['journal_entry' => $project->project_number])); ?>">View/Edit</a>
			                  						</span>
			              							<?php if($FproJournal->debit > $accTransaction->sum('credit') || $FproJournal->kdebit > $accTransaction->sum('kcredit')): ?>
			              								<a target="_blank" href="<?php echo e(route('getPayable', ['journal_id'=> $FproJournal->id])); ?>" class="btn btn-info btn-acc btn-xs pull-right hidden-print"> <b>Pay Now</b></a>
			              							<?php else: ?>
			              								<span class="badge badge-light" style="line-height: none;">Full Paid</span>
			              							<?php endif; ?>
			                  					<?php else: ?>
													<span data-toggle="modal" data-target="#loadProjectConfirm" class="btn btn-success btn-xs AddToACcount text-right hidden-print pull-right" 
			                  							data-type="4" data-kamount="<?php echo e($fl->book_kamount); ?>" 
			                  							data-amount="<?php echo e($fl->book_namount); ?>" 
			                  							data-process_type="pay" 
			                  							data-bus_type="flight"
			                  							data-title="<?php echo e(isset($flprice->supplier_name) ? $flprice->supplier_name : ''); ?>" 
			                  							data-book_id="<?php echo e($fl->id); ?>"
			                  							data-supplier="<?php echo e(isset($flprice->id) ? $flprice->id : ''); ?>" 
			                  							data-country="<?php echo e(isset($flprice->country_id) ? $flprice->country_id : ''); ?>">Post</span>
			                  					<?php endif; ?>
	                  						<?php endif; ?>
										<?php endif; ?>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
							<tr>
								<td colspan="11" class="text-right">
									<h5><strong>
										<?php if($flightBook->sum('book_namount') > 0): ?>
											Total <?php echo e(Content::currency()); ?>: <?php echo e(Content::money($flightBook->sum('book_namount'))); ?>

										<?php endif; ?>
										&nbsp;  
										<?php if($flightBook->sum('book_kamount') > 0): ?>
											, Total <?php echo e(Content::currency(1)); ?>: <?php echo e(Content::money($flightBook->sum('book_kamount'))); ?>

										<?php endif; ?>
										</strong>
									</h5>
								</td>
							</tr>
						<?php endif; ?>
						<!-- end flight  -->

						<?php 
							$golfBook = App\Booking::golfBook($project->project_number);
							$TotalGolf = 0;
							$TotalKGolf = 0;
						?>
						<?php if($golfBook->count() > 0): ?>
							<tr class="golf">
								<th style="border-top:none;" colspan="11">
									<strong style="text-transform:capitalize;">golf Courses Overview</strong>
								</th>
							</tr>
							<tr style="background-color:#f4f4f4;">
								<th width="100px">Date</th>
								<th>Golf</th>
								<th>Tee Time</th>
								<th colspan="3">Golf Service</th>
								<th class="text-center">Pax</th>
								<th class="text-right">Price <?php echo e(Content::currency()); ?></th>
								<th class="text-right">Amount </th>
								<th class="text-right">Price <?php echo e(Content::currency(1)); ?></th>
								<th class="text-left">Amount</th>
							</tr>
							<?php $__currentLoopData = $golfBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>			
								<?php 
									$gsv = App\GolfMenu::find($gf->program_id);
									$golfAmount = $gf->book_namount > 0 ? $gf->book_namount: $gf->book_nprice * $gf->book_pax;
									$golfKAmount = $gf->book_kamount > 0 ? $gf->book_kamount: $gf->book_kprice * $gf->book_pax;
									$TotalGolf = $TotalGolf + $golfAmount;
									$TotalKGolf = $TotalKGolf + $golfKAmount;
		                  			$GproJournal = \App\AccountJournal::where([ 'business_id' => 29,'project_number' => $project->project_number, "book_id" => $gf->id, 'type'=>1, 'status'=>1])->first();
		                  			if ( isset($GproJournal) ) {
		                  				$accTransaction = \App\AccountTransaction::where(['journal_id'=>$GproJournal->id, 'status'=>1]);
		                  			}
								?>
								<tr class="container_golf">
									<td><?php echo e(Content::dateformat($gf->book_checkin)); ?></td>
									<td><?php echo e($gf->supplier_name); ?></td>
									<td><?php echo e($gf->book_golf_time); ?></td>
									<td colspan="3"><?php echo e(isset($gsv->name) ? $gsv->name : ''); ?></td>
									<td class="text-center"><?php echo e($gf->book_pax); ?></td>			
									<td class="text-right"><?php echo e(Content::money($gf->book_nprice)); ?></td>
									<td class="text-right">
									<?php if(isset($GproJournal) && $accTransaction->sum('credit') > 0): ?>
										<?php $GDepositAmount =  $golfAmount - $accTransaction->sum('credit');?>
										
										<?php echo $GDepositAmount > 0  ? Content::money($GDepositAmount) : "<a style='font-weight: 700;' href='javascript:void(0)'>".Content::money($golfAmount). "</a>"; ?>

									<?php else: ?>
										<?php echo e(Content::money($golfAmount)); ?>

									<?php endif; ?>

									</td>
									<td class="text-right"><?php echo e(Content::money($gf->book_kprice)); ?></td>
									<td class="text-right" style="width: 17%;">
										<span class="pull-left">
											<?php if(isset($GproJournal) && $accTransaction->sum('kcredit') > 0): ?>
												<?php $KGDepositAmount = $golfKAmount - $accTransaction->sum('kcredit'); ?>
												<?php echo $KGDepositAmount > 0 ? Content::money($KGDepositAmount) : "<a style='font-weight: 700;' href='javascript:void(0)'>".Content::money($golfKAmount). "</a>"; ?>

											<?php else: ?>
												<?php echo e(Content::money($golfKAmount)); ?>

											<?php endif; ?>
										</span>
										<?php if($golfAmount > 0 || $golfKAmount > 0 ): ?>
		              						<?php if(isset($GproJournal) ): ?>
		              							<span class=" btn btn-link btn-xs hidden-print">
		                  							<a target="_blank" href="<?php echo e(route('getJournalReport', ['journal_entry' => $project->project_number])); ?>">View/Edit</a>
		                  						</span>
		              							<?php if($golfAmount > $accTransaction->sum('credit') || $golfKAmount > $accTransaction->sum('kcredit')): ?>
		              								<a target="_blank" href="<?php echo e(route('getPayable', ['journal_id'=> $GproJournal->id])); ?>" class="btn btn-info btn-acc btn-xs pull-right hidden-print"> <b>Pay Now</b></a>
		              							<?php else: ?>
		              								<span class="badge badge-light" style="line-height: 1.5;">Full Paid</span>
		              							<?php endif; ?>
		                  					<?php else: ?>
												<span data-toggle="modal" data-target="#loadProjectConfirm" class="btn btn-success btn-xs AddToACcount text-right hidden-print pull-right" 
		                  							data-type="29" data-kamount="<?php echo e($gf->book_kamount); ?>" 
		                  							data-amount="<?php echo e($gf->book_namount); ?>" 
		                  							data-process_type="pay" 
		                  							data-bus_type="golf"
		                  							data-title="<?php echo e($gf->supplier_name); ?>" 
		                  							data-book_id="<?php echo e($gf->id); ?>"
		                  							data-supplier="<?php echo e(isset($gf->golf_id) ? $gf->golf_id : ''); ?>" 
		                  							data-country="<?php echo e(isset($gf->country_id) ? $gf->country_id : ''); ?>">Post</span>
		                  					<?php endif; ?>
	                  					<?php endif; ?>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td colspan="11" class="text-right">
									<h5><strong>
										<?php if($TotalGolf > 0): ?>
											Total <?php echo e(Content::currency()); ?>: <?php echo e(Content::money($TotalGolf)); ?> &nbsp;
										<?php endif; ?>
										<?php if($TotalKGolf > 0): ?> 
											,Total <?php echo e(Content::currency(1)); ?>: <?php echo e(Content::money($TotalKGolf)); ?>

										<?php endif; ?>
										</strong>
									</h5>
								</td>
							</tr>
						<?php endif; ?>
						<!-- end golf -->

						<?php 
						$cruiseBook = App\CruiseBooked::where(['project_number'=> $project->project_number, 'status'=> 1])->orderBy("checkin");
						?>
						<?php if($cruiseBook->count() > 0): ?>
							<tr class="cruise">
								<th style="border-top: none;" colspan="11">
									<strong style="text-transform:capitalize;">River Cruise OverView</strong>
								</th>
							</tr>
							<tr style="background-color:#f4f4f4;">
								<th width="170px;">Date</th>
								<th colspan="3">River Cruise</th>
								<th colspan="4">Program</th>
								<th>Room</th>
								<th style="font-size: 11px;">Night/Cabin</th>
								<th class="text-left" style="width: 17%;" >Amount</th>
							</tr>
							<?php $__currentLoopData = $cruiseBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>			
							<?php 
								$pcr = App\CrProgram::find($crp->program_id);
								$rcr = App\RoomCategory::find($crp->room_id);
								
								
							?>	
							<tr class="container_river-cruise">
								<td><?php echo e(Content::dateformat($crp->checkin)); ?> - <?php echo e(Content::dateformat($crp->checkout)); ?> </td>
								<td colspan="3"><?php echo e(isset($crp->cruise->supplier_name) ? $crp->cruise->supplier_name : ''); ?></td>
								<td colspan="4"><?php echo e(isset($pcr->program_name) ? $pcr->program_name : ''); ?></td>
								<td><?php echo e(isset($crp->room->name) ? $crp->room->name : ''); ?></td>					
								<td class="text-center"><?php echo e($crp->book_day); ?> / <?php echo e($crp->cabin_pax); ?></td>
								<td class="text-right">
									<?php 
										$RiverProJournal = \App\AccountJournal::where(['book_id'=> $crp->id, 'business_id' => 3,'project_number' => $project->project_number, 'status'=> 1, 'type'=>1 ])->first();
										if ($RiverProJournal) {
											$RiveraccTransaction = \App\AccountTransaction::where(['journal_id'=>$RiverProJournal->id, 'status'=>1]); 
										}

										$cruiseAmount = $crp->net_amount;
										$totalCruise = $totalCruise + $cruiseAmount;
									?>
									<span class="pull-left">
									<?php if(isset($RiverProJournal) && $RiveraccTransaction->sum('credit') > 0): ?>
										<?php $GDepositAmount =  $cruiseAmount - $RiveraccTransaction->sum('credit');?>
										<?php echo $GDepositAmount > 0  ? Content::money($GDepositAmount) : "<a style='font-weight: 700;' href='javascript:void(0)'>".Content::money($cruiseAmount). "</a>"; ?>

									<?php else: ?>
										<?php echo e(Content::money($cruiseAmount)); ?>

									<?php endif; ?>
									</span>
									<?php if($cruiseAmount > 0): ?>
	                  					<?php if($RiverProJournal): ?>
	              							<span class=" btn btn-link btn-xs hidden-print">
	                  							<a  target="_blank" href="<?php echo e(route('getJournalReport', ['journal_entry' => $project->project_number])); ?>">View/Edit</a>
	                  						</span>
	              							<?php if($RiverProJournal->debit > $RiveraccTransaction->sum('credit') || $RiverProJournal->kdebit > $RiveraccTransaction->sum('kcredit')): ?>
	              								<a target="_blank" href="<?php echo e(route('getPayable', ['journal_id'=> $RiverProJournal->id])); ?>" class="btn btn-info btn-acc btn-xs pull-right hidden-print"> <b>Pay Now</b></a>
	              							<?php else: ?>
	              								<span class="badge badge-light" style="line-height: 1.5;">Full Paid</span>
	              							<?php endif; ?>
		                  				<?php else: ?>
											<span data-toggle="modal" data-target="#loadProjectConfirm" class="btn btn-success btn-xs AddToACcount text-right hidden-print pull-right" 
	                  							data-type="3" data-kamount="" 
	                  							data-amount="<?php echo e($cruiseAmount); ?>" 
	                  							data-process_type="pay" 
	                  							data-bus_type="cruise"
	                  							data-title="<?php echo e(isset($crp->cruise->supplier_name) ? $crp->cruise->supplier_name : ''); ?>" 
	                  							data-book_id="<?php echo e($crp->id); ?>"
	                  							data-supplier="<?php echo e($crp->cruise_id); ?>" 
	                  							data-country="<?php echo e($crp->cruise->country_id); ?>">Post</span>
	                  					<?php endif; ?>
									<?php endif; ?>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td colspan="11" class="text-right"><h5><strong>
									Total <?php echo e(Content::currency()); ?> : <?php echo e(Content::money($totalCruise)); ?></strong></h5>
								</td>
							</tr>
						<?php endif; ?>
						<!-- Transport Start-->
						<?php 
							$tranBook = \App\Booking::tourBook($project->project_number); 
							$transportTotal = 0;
							$transportkTotal = 0;
						?>
						<?php if( $tranBook->get()->count() != 0): ?>
							<tr class="transport">
								<th colspan="11" style="border-top:none;">
									<strong style="text-transform: capitalize;">transport expenses</strong></div>
								</th>
							</tr>
							<tr style="background-color:#f4f4f4;">
								<th width="110px">Date</th>
								<th>City</th>
								<th>SupplierName</th>
								<th colspan="3">Title</th>
								<th colspan="2">Service</th>
								<th >Vehicle</th>
								<th class="text-right" width="160px">Price <?php echo e(Content::currency()); ?></th>
								<th class="text-left" width="160px">Price <?php echo e(Content::currency(1)); ?></th>
							</tr>			
							<?php $__currentLoopData = $tranBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php 
								$pro   = App\Province::find($tran->province_id); 
								$btran = App\BookTransport::where(['project_number'=>$tran->book_project, 'book_id'=> $tran->id])->first();
								$price = isset($btran->price)? $btran->price:0; 
								$kprice = isset($btran->kprice)? $btran->kprice:0;
								$transportTotal = $transportTotal + $price;
								$transportkTotal = $transportkTotal + $kprice;
								if (isset($btran) ) {
									$TranproJournal = \App\AccountJournal::where(['supplier_id'=> $btran->transport_id, 'business_id' => 7,'project_number' => $project->project_number, 'book_id'=> $tran->id, 'type'=>1 ])->first();
									if ($TranproJournal) {
										$TAccTran = \App\AccountTransaction::where(['journal_id'=> $TranproJournal->id, 'status'=>1]);
									}
								}
							?>
							<tr class="container_transport">
								<td><?php echo e(Content::dateformat($tran->book_checkin)); ?></td>
								<td><?php echo e(isset($pro->province_name) ? $pro->province_name : ''); ?></td>
								<td><?php echo e(isset($btran->transport->supplier_name) ? $btran->transport->supplier_name : ''); ?></td>
								<td colspan="3"><?php echo e($tran->tour_name); ?></td>
								<td colspan="2"><?php echo e(isset($btran->service->title) ? $btran->service->title : ''); ?></td>
				                <td ><?php echo e(isset($btran->vehicle->name) ? $btran->vehicle->name : ''); ?></td>
				                <td class="text-right">
				                	<?php if(isset($TranproJournal) && $TAccTran->sum('credit') > 0): ?>
										<?php $TranDepositAmount = $price - $TAccTran->sum('credit');?>
										<?php echo $TranDepositAmount > 0 ? Content::money($TranDepositAmount) : "<a style='font-weight: 700;' href='javascript:void(0)'>".Content::money($price). "</a>"; ?>

									<?php else: ?>
										<?php echo e(Content::money($price)); ?>

									<?php endif; ?>
				                </td>
			                  	<td class="text-right" style="width: 17%;">
			                  		<span class="pull-left">
			                  			<?php if(isset($TranproJournal) && $TAccTran->sum('kcredit') > 0): ?>
											<?php $TranDepositAmount = $kprice - $TAccTran->sum('kcredit');?>
											<?php echo $TranDepositAmount > 0 ? Content::money($TranDepositAmount) : "<a style='font-weight: 700;' href='javascript:void(0)'>".Content::money($kprice). "</a>"; ?>

										<?php else: ?>
											<?php echo e(Content::money($kprice)); ?>

										<?php endif; ?>
			                  		</span>
			                  		<?php if( $kprice > 0 || $price > 0 ): ?>
	                  					<?php if(isset($TranproJournal)): ?>
	              							<span class="btn btn-link btn-xs hidden-print">
	                  							<a target="_blank" href="<?php echo e(route('getJournalReport', ['journal_entry'=> $project->project_number])); ?>">View/Edit</a>
	                  						</span>
	              							<?php if($TranproJournal->debit > $TAccTran->sum('credit') || $TranproJournal->kdebit > $TAccTran->sum('kcredit')): ?>
	              								<a target="_blank" href="<?php echo e(route('getPayable', ['journal_id'=> $TranproJournal->id])); ?>" class="btn btn-info btn-acc btn-xs pull-right hidden-print"> <b>Pay Now</b></a>
	              							<?php else: ?>
	              								<span class="badge badge-light" style="line-height:none;">Full Paid</span>
	              							<?php endif; ?>
		                  				<?php else: ?>
			                  				<span data-toggle="modal" data-target="#loadProjectConfirm" class="btn btn-success btn-xs AddToACcount text-right hidden-print pull-right" 
	                  							data-type="7" data-kamount="<?php echo e($kprice); ?>" 
	                  							data-amount="<?php echo e($price); ?>" 
	                  							data-process_type="pay" 
	                  							data-bus_type="transport"
	                  							data-title="<?php echo e(isset($btran->transport->supplier_name) ? $btran->transport->supplier_name : ''); ?>" 
	                  							data-book_id="<?php echo e($tran->id); ?>"
	                  							data-supplier="<?php echo e($btran->transport_id); ?>" 
	                  							data-country="<?php echo e($btran->country_id); ?>">Post</span>
	                  					<?php endif; ?>
			                  		<?php endif; ?>
			                  	</td>
							</tr>				
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td colspan="11" class="text-right">
									<h5>
										<strong>
											<?php if($transportTotal > 0): ?>
												Total <?php echo e(Content::currency()); ?>: <?php echo e(Content::money($transportTotal)); ?>

											<?php endif; ?>
											<?php if($transportkTotal): ?>
												,&nbsp; Total <?php echo e(Content::currency(1)); ?> : <?php echo e(Content::money($transportkTotal)); ?>

											<?php endif; ?>
										</strong>
									</h5>
								</td>
							</tr>
						<?php endif; ?>
						<!-- End Transport -->
						<!-- Guide Start-->
						<?php 
							$guideBook = \App\Booking::tourBook($project->project_number); 
							$guidTotal = 0;
							$guidkTotal = 0;
						?>
						<?php if($guideBook->count() > 0): ?>
							<tr class="guide">
								<th colspan="12" style="border-top:none;">
									<strong style="text-transform:capitalize;">guide expenses</strong>
								</th>
							</tr>
							<tr style="background-color:#f4f4f4;">
								<th width="100px">StartDate</th>
								<th>City</th>
								<th colspan="3">Tour</th>
								<th colspan="2">Service</th>
								<th width="150px">SupplierName</th>
								<th>Language</th>
								<th class="text-right"><?php echo e(Content::currency()); ?> Amount</th>
								<th class="text-left" style="width: 17%;"><?php echo e(Content::currency(1)); ?> Amount</th>
							</tr>			
							<?php $__currentLoopData = $guideBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php 
									$pro = \App\Province::find($tran->province_id);
									$bg  = App\BookGuide::where(['project_number'=>$tran->book_project,'book_id'=>$tran->id])->first(); 
									$price = isset($bg->price)?$bg->price :0;
									$guidTotal = $guidTotal + $price;
									$kprice = isset($bg->kprice)? $bg->kprice :0;
									$guidkTotal = $guidkTotal + $kprice;

									if (isset($bg)) {
										$GuideproJournal = \App\AccountJournal::where(['supplier_id'=> $bg->supplier_id, 'business_id' => 6,'project_number' => $project->project_number, 'book_id'=> $tran->id, 'type'=>1 ,'status'=>1])->first();
		              					if ($GuideproJournal) {
		              						$GAccTran = \App\AccountTransaction::where(['journal_id'=>$GuideproJournal->id, 'status'=>1]);
		              					}
									}	
								?>
								<tr class="container_guide">
									<td><span class="hidden-print" style="position: relative;top:2px;"></span><?php echo e(Content::dateformat($tran->book_checkin)); ?></td>
									<td><?php echo e($pro->province_name); ?></td>         
									<td colspan="3"><?php echo e($tran->tour_name); ?></td>     
									<td colspan="2"><?php echo e(isset($bg->service->title) ? $bg->service->title : ''); ?></td>
									<td><?php echo e(isset($bg->supplier->supplier_name) ? $bg->supplier->supplier_name : ''); ?> </td>
									<td><?php echo e(isset($bg->language->name) ? $bg->language->name : ''); ?></td>
									<td class="text-right">
									<?php if(isset($GuideproJournal) && $GAccTran->sum('credit') > 0): ?>
										<?php $GDPAmount = $price - $GAccTran->sum('credit'); ?>
										<?php echo $GDPAmount > 0 ? Content::money($GDPAmount):"<a style='font-weight:700;' href='javascript:void(0)'>".Content::money($price)."</a>"; ?>

									<?php else: ?>
										<?php echo e(Content::money($price)); ?>

									<?php endif; ?>
									</td>
									<td class="text-right" style="vertical-align: middle;">
										<span class="pull-left">
											<?php if(isset($GuideproJournal) && $GAccTran->sum('kcredit') > 0): ?>
												<?php $KGuideDepositAmount = $kprice - $GAccTran->sum('kcredit'); ?>
												<?php echo $KGuideDepositAmount > 0 ? Content::money($KGuideDepositAmount) : "<a style='font-weight: 700;' href='javascript:void(0)'>".Content::money($kprice). "</a>"; ?>

											<?php else: ?>
												<?php echo e(Content::money($kprice)); ?>

											<?php endif; ?>
										</span>
										<?php if($price > 0 || $kprice > 0): ?>
		                  					<?php if(isset($GuideproJournal)): ?>                  					
		              							<span class=" btn btn-link btn-xs hidden-print">
		                  							<a target="_blank" href="<?php echo e(route('getJournalReport', ['journal_entry'=> $project->project_number])); ?>">View/Edit</a>
		                  						</span>
		              							<?php if($price): ?>
		              								<?php if($price < 0 && $kprice < 0): ?>
		              									<a target="_blank" href="<?php echo e(route('getPayable', ['journal_id'=> $$GuideproJournal->id])); ?>" class="btn btn-info btn-acc btn-xs pull-right hidden-print"> <b>Pay Now</b></a>
		              								<?php endif; ?>
		              							<?php else: ?>
		              								<span class="badge badge-light" style="line-height: none;">Full Paid</span>
		              							<?php endif; ?>
			                  				<?php else: ?>
			                  					<?php if(isset($bg->supplier)): ?>
													<span data-toggle="modal" data-target="#loadProjectConfirm" class="btn btn-success btn-xs AddToACcount text-right hidden-print pull-right" 
		                  							data-type="6" data-kamount="<?php echo e($kprice); ?>" 
		                  							data-amount="<?php echo e($price); ?>" 
		                  							data-process_type="pay" 
		                  							data-bus_type="guide"
		                  							data-title="<?php echo e(isset($bg->supplier->supplier_name) ? $bg->supplier->supplier_name : ''); ?>" 
		                  							data-book_id="<?php echo e($tran->id); ?>"
		                  							data-supplier="<?php echo e($bg->supplier_id); ?>" 
		                  							data-country="<?php echo e($bg->country_id); ?>">Post</span>
		                  						<?php else: ?> 
			                  						<span class=" btn btn-link btn-sm hidden-print" style="padding-right: 0px;">
			                  							<a data-toggle="modal" data-target="#myAlert">Please Assign</a>
			                  						</span>
		                  						<?php endif; ?>
	                  						<?php endif; ?>
										<?php endif; ?>
									</td>
								</tr>				
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td colspan="11" class="text-right">
									<h5>
										<strong>
											<?php if($guidTotal > 0): ?>
												Total <?php echo e(Content::currency()); ?>: <?php echo e(Content::money($guidTotal)); ?>

											<?php endif; ?>
											<?php if($guidkTotal): ?>
												,Total <?php echo e(Content::currency(1)); ?>: <?php echo e(Content::money($guidkTotal)); ?>

											<?php endif; ?>
										</strong>
									</h5>
								</td>
							</tr>
						<?php endif; ?>
						<!-- End Guide -->

						<!-- Restaurant Start-->
						<?php
						$restBook = \App\BookRestaurant::where('project_number', $project->project_number)->orderBy('start_date', 'ASC');?>
							<?php if($restBook->count() > 0): ?>
								<tr class="restaurant">
									<th style="border-top: none;">
										<strong style="text-transform:capitalize;">restaurant expenses</strong>
									</th>
								</tr>
								<tr style="background-color:#f4f4f4;">
					                <th width="100px">Start Date</th>
					                <th colspan="2">SupplierName</th>
					                <th colspan="3">Menu</th>
					                <th class="text-center">Pax</th>
					                <th class="text-right">Price <?php echo e(Content::currency()); ?></th>
					                <th class="text-right">Amount</th>
					                <th class="text-right">Price <?php echo e(Content::currency(1)); ?></th>
					                <th class="text-left" style="widows: 17%;">Amount</th>
				                </tr>		
								<?php $__currentLoopData = $restBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php 
          								$RproJournal =\App\AccountJournal::where(['supplier_id'=> $rest->supplier_id, 'business_id'=> 2,'project_number' => $project->project_number, 'book_id'=> $rest->id, 'type'=>1, 'status'=>1 ])->first();
          								if ($RproJournal) {
          									$RestAccTran = \App\AccountTransaction::where(['journal_id'=>$RproJournal->id, 'status'=>1]);
          								}
              						?>
								<tr class="container_restaurant">
									<td><?php echo e(Content::dateformat($rest->start_date)); ?></td>
					                <td colspan="2"><?php echo e(isset($rest->supplier->supplier_name) ? $rest->supplier->supplier_name : ''); ?></td>         
					                <td colspan="3"><?php echo e(isset($rest->rest_menu->title) ? $rest->rest_menu->title : ''); ?></td>
					                <td class="text-center"><?php echo e($rest->book_pax); ?></td>
					                <td class="text-right"><?php echo e(Content::money($rest->price)); ?></td>
					                <td class="text-right">
					                	<?php if(isset($RproJournal) && $RestAccTran->sum('credit') > 0 ): ?>
					                		<?php $ResDeposit = $rest->amount - $RestAccTran->sum('credit'); ?>
					                		<?php echo $ResDeposit > 0 ? Content::money($ResDeposit) : "<a style='font-weight: 700;' href='javascript:void(0)'>".Content::money($rest->amount). "</a>"; ?>

					                	<?php else: ?>
					                		<?php echo e(Content::money($rest->amount)); ?>

					                	<?php endif; ?>
					                </td>
					                <td class="text-right"><?php echo e(Content::money($rest->kprice)); ?></td>
				                  	<td class="text-right">
				                  		<span class="pull-left">
				                  			<?php if(isset($RproJournal) && $RestAccTran->sum('kcredit') > 0 ): ?>
						                		<?php $KResDeposit = $rest->kamount - $RestAccTran->sum('kcredit'); ?>
						                		<?php echo $KResDeposit > 0 ? Content::money($KResDeposit) : "<a style='font-weight: 700;' href='javascript:void(0)'>".Content::money($rest->kamount). "</a>"; ?>

						                	<?php else: ?>
						                		<?php echo e(Content::money($rest->kamount)); ?>

						                	<?php endif; ?>
				                  		</span>
				                  		<?php if($rest->kamount > 0 || $rest->amount > 0): ?>
		                  					<?php if(isset($RproJournal)): ?>		                  						
		              							<span class="btn btn-link btn-xs hidden-print">
		                  							<a target="_blank" href="<?php echo e(route('getJournalReport', ['journal_entry'=> $project->project_number])); ?>">View/Edit</a>
		                  						</span>

		              							<?php if($RproJournal->debit > $RestAccTran->sum('credit') || $RproJournal->kdebit > $RestAccTran->sum('kcredit')): ?>
		              								<a target="_blank" href="<?php echo e(route('getPayable', ['journal_id'=> $RproJournal->id])); ?>" class="btn btn-info btn-acc btn-xs pull-right hidden-print"> <b>Pay Now</b></a>
		              							<?php else: ?>
		              								<span class="badge badge-light" style="line-height: none;">Full Paid</span>
		              							<?php endif; ?>
			                  				<?php else: ?>
				                  				<span data-toggle="modal" data-target="#loadProjectConfirm" class="btn btn-success btn-xs AddToACcount text-right hidden-print pull-right" 
		                  							data-type="2" data-kamount="<?php echo e($rest->kamount); ?>" 
		                  							data-amount="<?php echo e($rest->amount); ?>" 
		                  							data-process_type="pay" 
		                  							data-bus_type="restaurant"
		                  							data-title="<?php echo e(isset($rest->supplier->supplier_name) ? $rest->supplier->supplier_name : ''); ?>" 
		                  							data-book_id="<?php echo e($rest->id); ?>"
		                  							data-supplier="<?php echo e($rest->supplier_id); ?>" 
		                  							data-country="<?php echo e($rest->country_id); ?>">Post</span>
		                  					<?php endif; ?>
				                  		<?php endif; ?>
				                  	</td>
								</tr>				
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td colspan="11" class="text-right">
										<h5>
											<strong>
												<?php if($restBook->sum('amount') > 0): ?>
													Total <?php echo e(Content::currency()); ?>: <?php echo e(Content::money($restBook->sum('amount'))); ?>

												<?php endif; ?>
												<?php if($restBook->sum('kamount')): ?>
													,&nbsp;&nbsp;&nbsp;
													Total <?php echo e(Content::currency(1)); ?>: <?php echo e(Content::money($restBook->sum('kamount'))); ?> 
												<?php endif; ?>
											</strong>
										</h5>
									</td>
								</tr>
							<?php endif; ?>
						<!-- End Restaurant -->

						<!-- Entrance Fees Start-->
						<?php 
						$EntranceBook = \App\BookEntrance::where('project_number', $project->project_number)->orderBy('start_date', 'ASC'); ?>
							<?php 
								$entranAmount = 0; 
								$entranKAmount = 0;
							?>
							<?php if($EntranceBook->count() > 0): ?>
								<tr class="entran">
									<th colspan="11" style="border-top: none;">
										<strong style="text-transform: capitalize;">entrance fees expenses</strong>
									</th>
								</tr>
								<tr style="background-color:#f4f4f4;">
									<th width="100px">Start Date</th>
				                  	<th colspan="5">Entrance Fees</th>
				                  	<th class="text-center">Pax</th>
				                  	<th class="text-right">Price </th>
				                  	<th class="text-right"><?php echo e(Content::currency()); ?> Amount </th>
				                  	<th class="text-right">Price</th>
				                  	<th class="text-left"> <?php echo e(Content::currency(1)); ?> Amount</th>
								</tr>
								<?php $__currentLoopData = $EntranceBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php 
										$pro = \App\Province::find($ent->province_id); 
										$entKamount = $ent->kamount > 0 ? $ent->kamount : $ent->kprice * $ent->book_pax;
										$entAmount = $ent->amount > 0 ? $ent->amount : $ent->price * $ent->book_pax;
										$entranKAmount = $entranKAmount + $entKamount;
										$entranAmount = $entranAmount + $entAmount;
          								$EntproJournal = \App\AccountJournal::where(['business_id'=> 55,'project_number' => $project->project_number, 'book_id'=> $ent->id, 'type'=>1, 'status'=>1])->first();
          								if ($EntproJournal) {
          									$EntAccTran = \App\AccountTransaction::where(['journal_id'=>$EntproJournal->id, 'status'=>1]);
          								}
									?>
									<tr>
										<td><?php echo e(Content::dateformat($ent->start_date)); ?></td>
						                <td colspan="5"><?php echo e(isset($ent->entrance->name) ? $ent->entrance->name : ''); ?></td>
						                <td class="text-center"><?php echo e($ent->book_pax); ?></td>
						                <td class="text-right"><?php echo e(Content::money($ent->price)); ?></td>
						                <td class="text-right">
						                	<?php if(isset($EntproJournal) && $EntAccTran->sum('credit') > 0): ?>
				                  				<?php $EntDeposit =  $entAmount - $EntAccTran->sum('credit'); ?>
				                  				<?php echo $EntDeposit > 0 ? Content::money($EntDeposit) : "<a style='font-weight:700;' href='javascript:void(0)'>".Content::money($entAmount)."</a>"; ?>

				                  			<?php else: ?>
				                  				<?php echo e(Content::money($entAmount)); ?>

				                  			<?php endif; ?>
						                </td>
						                <td class="text-right"><?php echo e(Content::money($ent->kprice)); ?></td>
					                  	<td class="text-right">
					                  		<span class="pull-left">
					                  			<?php if(isset($EntproJournal) && $EntAccTran->sum('kcredit') > 0): ?>
					                  				<?php $EntDeposit =  $entKamount - $EntAccTran->sum('kcredit'); ?>
					                  				<?php echo $EntDeposit > 0 ? Content::money($EntDeposit) : "<a style='font-weight:700;' href='javascript:void(0)'>".Content::money($entKamount)."</a>"; ?>

					                  			<?php else: ?>
					                  				<?php echo e(Content::money($entKamount)); ?>

					                  			<?php endif; ?>

					                  		</span>
					                  		<?php if( $entAmount > 0 || $entKamount > 0): ?>
			                  					<?php if($EntproJournal): ?>
			              							<span class="btn btn-link btn-xs hidden-print">
			                  							<a  target="_blank" href="<?php echo e(route('getJournalReport', ['journal_entry' => $project->project_number])); ?>">View/Edit</a>
			                  						</span>
			              							<?php if($EntproJournal->debit > $EntAccTran->sum('credit') || $EntproJournal->kdebit > $EntAccTran->sum('kcredit')): ?>
			              								<a target="_blank" href="<?php echo e(route('getPayable', ['journal_id'=> $EntproJournal->id])); ?>" class="btn btn-info btn-acc btn-xs pull-right hidden-print"> <b>Pay Now</b></a>
			              							<?php else: ?>
			              								<span class="badge badge-light" style="line-height: none;">Full Paid</span>
			              							<?php endif; ?>
				                  				<?php else: ?>
					                  				<span data-toggle="modal" data-target="#loadProjectConfirm" class="btn btn-success btn-xs AddToACcount text-right hidden-print pull-right" 
			                  							data-type="55" data-kamount="<?php echo e($entKamount); ?>" 
			                  							data-amount="<?php echo e($entAmount); ?>" 
			                  							data-process_type="pay" 
			                  							data-title="<?php echo e(isset($ent->entrance->name) ? $ent->entrance->name : ''); ?>" 
			                  							data-book_id="<?php echo e($ent->id); ?>"
			                  							data-supplier="" 
			                  							data-country="<?php echo e($ent->country_id); ?>">Post
			                  						</span>
			                  					<?php endif; ?>
					                  		<?php endif; ?>
					                  	</td>
									</tr>				
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td colspan="11" class="text-right">
										<h5>
											<strong>
												<?php if($entranAmount > 0): ?>
													Total <?php echo e(Content::currency()); ?>: <?php echo e(Content::money($entranAmount)); ?>

												<?php endif; ?>
												<?php if($entranKAmount > 0): ?>
													&nbsp;&nbsp;,Total <?php echo e(Content::currency(1)); ?>: <?php echo e(Content::money($entranKAmount)); ?>

												<?php endif; ?>
											</strong>
										</h5>
									</td>
								</tr>
							<?php endif; ?>
						<!-- End Entrance Fees -->

						<!-- MISC Start-->
						<?php 
							$MiscBook = \App\Booking::tourBook($project->project_number); 
							$miscTotal = 0;
							$misckTotal = 0;
						?>
						<?php if($MiscBook->count() > 0): ?>
							<tr class="misc">
								<th colspan="11" style="border-top: none;">
									<strong style="text-transform: capitalize;">MISC expenses</strong>
								</th>
							</tr>
							<tr style="background-color:#f4f4f4;">
								<th width="100px">Date</th>
								<th width="120px">City</th>
								<th colspan="9">Title</th>						
							</tr>			
							<?php $__currentLoopData = $MiscBook->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php 
								$pro = \App\Province::find($tour->province_id); 
								$miscService = App\BookMisc::where(['project_number'=>$tour->book_project,'book_id'=>$tour->id])->orderBy("created_at", "DESC")->get();?>
								<tr class="container_misc">
					                <td><?php echo e(Content::dateformat($tour->book_checkin)); ?></td>
					                <td><?php echo e($pro->province_name); ?></td>         
					                <td colspan="9" style="padding-right: 0px;">
					                  	<div><strong><?php echo e($tour->tour_name); ?></strong></div>
							            <?php if($miscService->count() > 0): ?> 
							            	<hr style="border-top:none; border-bottom: 1px solid #ddd;padding: 5px 0px; margin-top:0px; margin-bottom: 0px;">
						                  	<div class="row "style="font-style: italic;">
							                  	<label class="col-md-5	 ">
							                  		<strong class="pcolor">Service Name</strong>
							                  	</label>
							                  	<label class="col-md-1 ">
							                  		<label class="row">
							                  			<strong class="pcolor">PaxNo.</strong>
							                  		</label>
							                  	</label>
							                  	<label class="col-md-1 ">
							                  		<label class="row">
								                  		<strong class="pcolor">Price<?php echo e(Content::currency()); ?></strong>
								                  	</label>
							                  	</label>
							                  	<label class="col-md-1 ">
							                  		<label class="row">
								                  		<strong class="pcolor">Amount</strong>
								                  	</label>
							                  	</label>
							                  	<label class="col-md-1 ">
							                  		<label class="row">
								                  		<strong class="pcolor">Price<?php echo e(Content::currency(1)); ?></strong>
								                  	</label>
							                  	</label>
							                  	<label class="col-md-3 pcolor text-left" style="padding-left: 0px;">
								                  	<strong class="pcolor">Amount</strong>
							                  	</label>
						                  	</div>		                
							            	<?php $__currentLoopData = $miscService; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $misc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								            	<?php 
								            		$miscAmount = $misc->amount > 0 ? $misc->amount : $misc->book_pax * $misc->price;
								            		$misckAmount = $misc->kamount > 0 ? $misc->kamount : $misc->book_pax * $misc->kprice;
									            	$miscTotal = $miscTotal + $miscAmount;
									            	$misckTotal = $misckTotal + $misckAmount;
		              								$MISCproJournal = \App\AccountJournal::where(['business_id' => 54,'project_number' => $project->project_number, 'book_id'=> $misc->id, 'type'=>1, 'status'=>1 ])->first();
		              								if ($MISCproJournal) {
		              									$MiscAccTran = \App\AccountTransaction::where(['journal_id'=>$MISCproJournal->id, 'status'=>1]);
		              								}
			              						?>
							                  	<div class="row col-md-12" style="padding-right: 0px;">
								                  	<label class="col-md-5" style="font-weight: 400;">
								                  		<p><?php echo e(isset($misc->servicetype->name) ? $misc->servicetype->name : ''); ?></p>
								                  	</label>
								                  	<label class="col-md-1" style="font-weight: 400;">
								                  		<p><?php echo e($misc->book_pax); ?></p>
								                  	</label>
								                  	<label class="col-md-1" style="font-weight: 400;">
								                  		<p><?php echo e(Content::money($misc->price)); ?></p>
								                  	</label>
								                  	<label class="col-md-1" style="font-weight: 400;">
								                  		<?php if(isset($MISCproJournal) && $MiscAccTran->sum('credit') > 0): ?>
							                  				<?php $MiscDeposit =  $miscAmount - $MiscAccTran->sum('credit'); ?>
							                  				<p><?php echo $MiscDeposit > 0 ? Content::money($MiscDeposit) : "<a style='font-weight:700;' href='javascript:void(0)'>".Content::money($miscAmount)."</a>"; ?></p>
							                  			<?php else: ?>
							                  				<p><?php echo e(Content::money($miscAmount)); ?></p>
							                  			<?php endif; ?>
								                  	</label>
								                  	<label class="col-md-1" style="font-weight: 400;">
								                  		<p><?php echo e(Content::money($misc->kprice)); ?></p>
								                  	</label>
								                  	<label class="col-md-3 text-right" style="font-weight: 400; padding-right: 0px;">
								                  		<span class="pull-left">
									                  		<?php if(isset($MISCproJournal) && $MiscAccTran->sum('kcredit') > 0): ?>
								                  				<?php $KMiscDeposit =  $misckAmount - $MiscAccTran->sum('kcredit'); ?>
								                  				<p><?php echo $KMiscDeposit > 0 ? Content::money($KMiscDeposit) : "<a style='font-weight:700;' href='javascript:void(0)'>".Content::money($misckAmount)."</a>"; ?></p>
								                  			<?php else: ?>
								                  				<p><?php echo e(Content::money($misckAmount)); ?></p>
								                  			<?php endif; ?>
							                  			</span> 
								                  		<?php if($miscAmount > 0 || $misckAmount > 0): ?>
						                  					<?php if($MISCproJournal): ?>
						              							<span class="btn btn-link btn-xs hidden-print">
						                  							<a  target="_blank" href="<?php echo e(route('getJournalReport', ['journal_entry' => $project->project_number])); ?>">View/Edit</a>
						                  						</span>
						              							<?php if($MISCproJournal->debit > $accTransaction->sum('credit') || $MISCproJournal->kdebit > $accTransaction->sum('kcredit')): ?>
						              								<a target="_blank" href="<?php echo e(route('getPayable', ['journal_id'=> $proJournal->id])); ?>" class="btn btn-info btn-acc btn-xs pull-right hidden-print"> <b>Pay Now</b></a>
						              							<?php else: ?>
						              								<span class="badge badge-light" style="line-height: none;">Full Paid</span>
						              							<?php endif; ?>
							                  				<?php else: ?>
								                  				<span data-toggle="modal" data-target="#loadProjectConfirm" class="btn btn-success btn-xs AddToACcount text-right hidden-print pull-right" 
						                  							data-type="54" data-kamount="<?php echo e($misckAmount); ?>" 
						                  							data-amount="<?php echo e($miscAmount); ?>" 
						                  							data-process_type="pay" 
						                  							data-title="<?php echo e(isset($misc->servicetype->name) ? $misc->servicetype->name : ''); ?>" 
						                  							data-book_id="<?php echo e($misc->id); ?>"
						                  							data-supplier="" 
						                  							data-country="<?php echo e($tour->country_id); ?>">Post
						                  						</span>
						                  					<?php endif; ?>
				                  						<?php endif; ?>
								                  	</label>
								                  	<div class="clearfix"></div>
							                  	</div>
						                  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						                <?php endif; ?>
				                  	</td>	                                     
				                </tr>			
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td colspan="11" class="text-right">
									<h5>
										<strong>
											<?php if(!empty($miscTotal)): ?>
												Total <?php echo e(Content::currency()); ?>: <?php echo e(Content::money($miscTotal)); ?>

											<?php endif; ?>
												
											<?php if(!empty($misckTotal)): ?>
												,&nbsp;	Total <?php echo e(Content::currency(1)); ?>: <?php echo e(Content::money($misckTotal)); ?> 
											<?php endif; ?>
										</strong>
									</h5>
								</td>
							</tr>
						<?php endif; ?>
						<!-- End MISC -->
							<?php 
								$grandtotal = $totalHotel + $flightBook->sum('book_namount') + $golfBook->sum('book_namount') + $cruiseBook->sum('net_amount') + $restBook->sum('amount') + $entranAmount + $transportTotal + $guidTotal + $miscTotal;
								// echo $transportTotal + $guidTotal + $miscTotal;
								$grandktotal = $flightBook->sum('book_kamount') + $golfBook->sum('book_kamount') + $restBook->sum('kamount') + $entranKAmount + $transportkTotal + $guidkTotal + $misckTotal;
							?>
							<tr>
								<th rowspan="2" colspan="5" style="border-top: none;" >
									<!-- <div class="hidden-print">
										<label class="label-control">Remark</label>
										<textarea class="form-control" rows="5" name="remark" placeholder="Type remark here..."></textarea>
									</div> -->
								</th>
								<th style="border-top: none;" colspan="6">
									<h4 class="text-right" style="font-size: 17px;">
										<strong>
											<?php if($grandtotal > 0): ?>
											Sub Total <?php echo e(Content::currency()); ?>: <?php echo e(Content::money($grandtotal)); ?>

											&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; 
											<?php endif; ?>
											<?php if($grandktotal): ?>
												Sub Total <?php echo e(Content::currency(1)); ?>: <?php echo e(Content::money($grandktotal)); ?>

											<?php endif; ?>
										</strong>
									</h4> 
								</th>
							</tr> 

							<tr>
								<th  colspan="11">
									<h4 class="text-right">
										<strong>
											<?php 
												$getExRate = $project->project_ex_rate>0?$grandktotal / $project->project_ex_rate:"0";
												$getGrandTotal = ($grandtotal + $getExRate);

											?>
											Ex-<?php echo e(Content::currency(1)); ?> To <?php echo e(Content::currency()); ?>: <?php echo e(Content::money($getExRate)); ?>

											&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; 
											GRAND TOTAL <?php echo e(Content::currency()); ?>: <?php echo e(Content::money($getGrandTotal)); ?>

										</strong>
									</h4> 
								</th>
							</tr>
							<tr>
								<td colspan="5"></td>
								<?php $TotalPNL = ($Project_total - $getGrandTotal);?>
								<td colspan="7" class="text-right"><strong style="font-size:21px;">Gross Profit & Loss:  <?php echo e(number_format($TotalPNL, 2)); ?> <?php echo e(Content::currency()); ?></strong></td>
							</tr>
					</table>
				</form>
			<?php endif; ?>
		</div>
	</div>
	<br><br>

<?php if(isset($project->project_number)): ?>
	<?php 
		$getGuideBooked = \App\Supplier::where(["supplier_status"=>1, 'country_id' => \Auth::user()->country_id])->whereIn("business_id", [6, 7])->get();
	?>
	<div class="modal" id="loadProjectConfirm" role="dialog"  data-backdrop="static" data-keyboard="true">
		<div class="modal-dialog modal-lg">    
		    <form method="POST" action="<?php echo e(route('makeToJournal')); ?>">
		    	<?php echo e(csrf_field()); ?> 
	        	<div class="hidden-group">
		          	<input type="hidden" name="project_number" id="project_number" value="<?php echo e(isset($project->project_number) ? $project->project_number : ''); ?>">
		          	<input type="hidden" name="project_id" id="project_id" value="<?php echo e(isset($project->id) ? $project->id : ''); ?>">
		          	<input type="hidden" name="project_fileno" id="project_fileno" value="<?php echo e(isset($project->project_fileno) ? $project->project_fileno : ''); ?>">
		          	<input type="hidden" name="business_id" id="business_id"> 
		          	<input type="hidden" name="supplier_id" id="supplier_name"> 
		          	
		          	<input type="hidden" name="bus_type" id="bus_type"> 
		          	<input type="hidden" name="process_type" id="process_type"> 
		          	<input type="hidden" name="book_id" id="book_id"> 
				</div>
		      	<div class="modal-content">        
			        <div class="modal-header">
			          	<button type="button" class="close" data-dismiss="modal">&times;</button>
			          	<h4 class="modal-title" id="modal-title"><strong>Make to Cash Transaction For Project No. <?php echo e(isset($project->project_number) ? $project->project_number : ''); ?></strong></h4>
			        </div>
			        <div class="modal-body">
			        	<div class="row">
			        		<?php if(Auth::user()->role_id == 2): ?>
			        		<div class="col-md-4 col-xs-12">
					        	<div class="form-group">
				                  	<label class="col-sm-3 text-right" style="padding-top: 7px;">Country</label>
				                  	<div class="col-sm-9">
				                    	<select class="form-control location" name="country" data-type="country">
				                          	<option>--choose--</option>
				                          	<?php $__currentLoopData = App\Country::countryByProject(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                          		<option value="<?php echo e($con->id); ?>"><?php echo e($con->country_name); ?></option>
				                          	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                        </select>
				                  	</div>
				                  	<div class="clearfix"></div>
					            </div>
					        </div>
					        <?php endif; ?>
					        <div class="col-md-5 col-xs-12">
					        	<div class="form-group">
				                  	<label class="col-sm-4 text-right" style="padding-top: 7px;">Record Date</label>
				                  	<div class="col-sm-5">
				                    	<input type="text" name="pay_date"  id="pay_date"  class="form-control book_date" readonly="" value="<?php echo e(date('Y-m-d')); ?>">
				                  	</div>
				                  	<div class="clearfix"></div>
					            </div>
					        </div>
			              	<table class="table">
				                <tr class="table-head-row">
					                <th width="150px">Account Type <span style="color: red">*</span></th>
					                <th >Account Name <span style="color: red">*</span></th>
					                <th width="120px">Debit</th>
					                <th width="120px">Credit</th>
					                <th width="120px"><?php echo e(Content::currency(1)); ?> Debit</th>
					                <th width="120px"><?php echo e(Content::currency(1)); ?> Credit</th>
				                </tr>
				                <tbody id="data_payment_option">
					                <tr>
										<?php $acc_type = App\AccountType::where(['status'=> 1])->orderBy('account_name', 'ASC')->get(); ?>
					                    <td class="container_account_type">
						                	<select class="form-control account_type input-sm" name="account_type" data-type="account_name" required="">
						                		<option>--choose--</option>
						                		<?php $__currentLoopData = $acc_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						                			<option class="value" value="<?php echo e($acc_type->id); ?>"><?php echo e($acc_type->account_name); ?></option>
						                		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                      	</select>
					                    </td>
					                    <td style="position: relative;">
				                    		<div class="btn-group" style='display: block;'>
				                    			<button type="button" class="form-control input-sm arrow-down" data-toggle="dropdown" aria-haspopup="false" aria-expanded='false' data-backdrop="static" data-keyboard="false" role="dialog" data-backdrop="static" data-keyboard="false">
					                    			<span class="pull-left"></span>
					                    			<span class="pull-right"></span>
					                    		</button> 
						                    	<div class="obs-wrapper-search" style="max-height:250px; overflow: auto; ">
						                    		<div>
						                    			<input type="text" data-url="<?php echo e(route('getFilter')); ?>" id="search_Account" onkeyup="filterAccountName()" class="form-control input-sm">
						                    		</div>
						                    		<ul id="myAccountName" class="list-unstyled dropdown_account_name">
						                    		</ul>
						                    	</div>
						                    </div>
					                    </td>
					                    <td>
					                      	<input type="text" class="debit form-control input-sm text-right" data-type="debit" name="debit" id="debit" placeholder="00.0" readonly="">
					                    </td>
					                    <td>
					                      	<input type="text" class="credit form-control input-sm text-right" data-type="credit" name="credit" id="credit" placeholder="00.0" readonly="">
					                    </td>
					                    <td>
					                      	<input type="text" class="kyat-debit form-control input-sm text-right" data-type="kyat-debit" name="kyatdebit" id="kyat-debit" placeholder="00.0" readonly="">
					                    </td>
					                    <td>
					                      	<input type="text" class="kyat-credit form-control input-sm text-right" data-type="kyat-credit" name="kyatcredit" id="kyat-credit" placeholder="00.0" readonly="">
					                    </td>
					                </tr>
					            
					                <tr>
					                	<td colspan="7" style="border-top: none;">
					                		<label>Descriptions</label>
					                		<textarea class="form-control" rows="4" name="payment_desc" placeholder="Type Descriptions here...!"></textarea>
					                	</td>
					                </tr>
				                </tbody>
				            </table>
				        </div>
			        </div>
			        <div class="modal-footer ">
			          	<div class="text-center">
			            	<button class="btn btn-info btn-sm" id="btnUpdateAccount">Save</button>
			            	<a href="#" class="btn btn-default btn-sm btn-acc" data-dismiss="modal">Cancel</a>
			          	</div>
			        </div>
		      	</div>      
		    </form>
		</div>
	</div>
	<div class="modal" id="myAlert" role="dialog" data-backdrop="static" data-keyboard="true">
	  <div class="modal-dialog modal-sm">    
	    <form method="POST" action="" id="add_new_account_form">
	      <div class="modal-content">        
	        <div class="modal-header">
	          <button type="button" class="close" data-dismiss="modal">&times;</button>
	          <h4 class="modal-title"><strong>Supplier Missing</strong></h4>
	        </div>
	        <div class="modal-body">
	          <strong id="message">Please update supplier name </strong>        
	        </div>
	        <div class="modal-footer">
	          <div class="text-center">
	            <a href="#" class="btn btn-info btn-xs" data-dismiss="modal">OK</a>
	          </div>
	        </div>    
	      </div>  
	    </form>
	  </div>
	</div>

	<div class="modal" id="LoadSupplier" role="dialog" data-backdrop="static" data-keyboard="true" >
		<div class="modal-dialog modal-lg">    
		    <form method="POST" action="<?php echo e(route('createSupplier')); ?>" id="Add_New_supplier">
		      <div class="modal-content">        
		        <div class="modal-header">
		          	<button type="button" class="close" data-dismiss="modal">&times;</button>
		          	<h4 class="modal-title"><strong>Add New Supplier</strong></h4>
		        </div>
		        <div class="notify-message"></div>
		        <div class="modal-body">
				   	<?php echo e(csrf_field()); ?>    
				    <input type="hidden" name="eid" id="eid">
			        <div class="row">
		                <div class="col-md-6 col-xs-12">
		                    <div class="form-group">
		                      	<label>Supplier name<span style="color:#b12f1f;">*</span></label> 
		                      	<input autofocus="" type="text" placeholder="Tour Name" class="form-control" name="title" required>
		                    </div> 
		                </div>        
		                <div class="col-md-3 col-xs-6">
		                    <div class="form-group">
		                      	<label>Country <span style="color:#b12f1f;">*</span></label> 
		                      	<select class="form-control country" name="country" data-type="country" required>
			                        <?php $__currentLoopData = App\Country::where('country_status', 1)->orderBy('country_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                          <option value="<?php echo e($con->id); ?>" ><?php echo e($con->country_name); ?></option>
			                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                      	</select>
		                    </div> 
		                </div>
		                <div class="col-md-3 col-xs-6">
		                    <div class="form-group">
		                      	<label>City <span style="color:#b12f1f;">*</span></label> 
		                      	<select class="form-control" name="city" id="dropdown-data" required>
			                        <?php $__currentLoopData = App\Province::where(['province_status'=> 1, 'country_id'=> Auth::user()->country_id ])->orderBy('province_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                          <option value="<?php echo e($pro->id); ?>"><?php echo e($pro->province_name); ?></option>
			                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                      	</select>
		                    </div> 
		                </div>
		                <div class="col-md-3 col-xs-6">
		                    <div class="form-group">
		                      	<label>Business Type <span style="color:#b12f1f;">*</span></label>
			                    <select class="form-control" name="business_type">
			                        <option value="0">--Select--</option>
			                        <?php $__currentLoopData = App\Business::where(['category_id'=>0, 'status'=>1])->orderBy('name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                            <option value="<?php echo e($cat->id); ?>" <?php echo e($type == $cat->slug ?'selected':''); ?>><?php echo e($cat->name); ?></option>
			                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                      	</select>
		                    </div>
		                </div> 
		                <div class="col-md-3 col-xs-6">
		                    <div class="form-group">
		                      	<label>Phone<span style="color:#b12f1f;">*</span></label>
			                    <input class="form-control" name="supplier_phone" placeholder="+855987 654 321">
		                    </div>
		                </div> 
		                <div class="col-md-3 col-xs-6">
		                    <div class="form-group">
		                      	<label>Email<span style="color:#b12f1f;">*</span></label>
			                    <input class="form-control" name="supplier_email" placeholder="virak@asia-expeditions.com">
		                    </div>
		                </div> 
	                	<div class="col-md-12 col-xs-12">
		                    <div class="form-group">
		                      	<label>Description <span style="color:#b12f1f;">*</span></label> 
		                      	<textarea class="form-control" rows="6" name="desc" placeholder="Description here...!"></textarea>
		                    </div> 
		                </div>		
		          	</div>
		        </div>
		        <div class="modal-footer">
		          <div class="text-center">
		            <button class="btn btn-info btn-sm" id="btnAddSupplier" type="submit">Save</button>
		            <a href="#" class="btn btn-default btn-sm btn-acc" data-dismiss="modal">Close</a>
		          </div>
		        </div>    
		      </div>  
		    </form>
		</div>
	</div>



	<script type="text/javascript" src="<?php echo e(asset('js/jquery.table2excel.min.js')); ?>"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$(document).on("click", ".AddToACcount", function(){
				var bustype = $(this).data("type"),
					supplier_id = $(this).data("supplier"),
					bus_type = $(this).data("bus_type"),
					kamount = $(this).data("kamount"),
					amount = $(this).data("amount"),
					bookkId = $(this).data("book_id"),
					process_type = $(this).data("process_type"),
					coun_id = $(this).data("country");
					
					$(".location option").each( function(i){
		                if($(this).val() == coun_id){
		                    $(this).attr("selected", true);
		                }else{
		                    $(this).removeAttr("selected", true);
		                }
		            });
					$("#business_id").val(bustype);
					$("#supplier_name").val(supplier_id);
					$("#country").val(coun_id);
					$("#credit").val("");
					$("#debit").val("");
					$("#kyat-debit").val("");
					$("#kyat-credit").val("");
					if (process_type == "pay") {
						$("#debit").val(amount);	
						$("#kyat-debit").val(kamount);
						$("#modal-title strong").text("Make Cash Transaction for [" + $(this).data('title')+ "]");
					}else{
						$("#modal-title strong").text("Receive Cash Transaction from [" + $(this).data('title')+ "]");
						$("#credit").val(amount);	
						$("#kyat-credit").val(kamount);
					}

					$("#process_type").val(process_type);
					$("#book_id").val(bookkId);
					$("#bus_type").val(bus_type);

				var data_row = "<tr class='supplier_row'><td colspan='12'><div class='form-group'><label>Supplier<span style='color:#b12f1f;'>*</span></label><div class='btn-group' style='display: block;'><button  type='button' class='form-control arrow-down' data-toggle='dropdown' aria-haspopup='false' aria-expanded='false' data-backdrop='static' data-keyboard='false' role='dialog' data-backdrop='static' data-keyboard='false'><span class='pull-left'></span><span class='pull-right'></span></button> <div class='obs-wrapper-search'><div><input type='text' data-url='<?php echo e(route('getFilter')); ?>' id='search' onkeyup='myFunction()' class='form-control' ></div><ul class='dropdown-data' id='myUL' style='width: 100%;' ><li  data-toggle='modal' data-target='#LoadSupplier'><a><i class='fa fa-plus'></i> Add Supplier</a> </li><?php $__currentLoopData = $getGuideBooked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $gb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(!empty($gb->id)): ?><li class='list' style=' padding: 4px 0px !important;'><label style='position: relative;top: 3px; font-weight: 400;'><input type='radio' name='supplier_name' value='<?php echo e($gb->id); ?>'><span style='position:relative; top:-2px;'>  <?php echo e(isset($gb->supplier_name) ? $gb->supplier_name : ''); ?></span></label></li>  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><div class='clearfix'></div></ul></div></div></div></td></tr>";
				
				$("tbody#data_payment_option tr.supplier_row").remove();
				if (bustype == 55 || bustype == 54 ) {
					$("tbody#data_payment_option tr:first-child").after(data_row);
				}

			});	

			$(".myConvert").click(function(){
				if(confirm('Do you to export in excel?')){
					$(".table").table2excel({
						exclude: ".noExl",
						name: "Operation Expenses <?php echo e($project->project_number); ?>",
						filename: "Operation Expenses <?php echo e($project->project_number); ?>",
						fileext: ".xls",
						exclude_img: true,
						exclude_links: true,
						exclude_inputs: true
					});
					return false;
				}else{
					return false;
				}
			});
		});      
	</script>
<?php endif; ?>	

<script>
	function myFunction() {
        input = document.getElementById("search");
        filter = input.value.toUpperCase();
        ul = document.getElementById("myUL");
        li = ul.getElementsByClassName ("list");
        for (i = 0; i < li.length; i++) {
            a = li[i];
            if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
              li[i].style.display = "";
            } else {
              li[i].style.display = "none";
            }
        }
    }

    function filterAccountName(){
        input = document.getElementById("search_Account");
        filter = input.value.toUpperCase();
        ul = document.getElementById("myAccountName");
        li = ul.getElementsByClassName ("list");
        for (i = 0; i < li.length; i++) {
            a = li[i];
            if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
              li[i].style.display = "";
            } else {
              li[i].style.display = "none";
            }
        }
    }
</script>
<?php echo $__env->make("admin.account.accountant", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make("admin.include.datepicker", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- <script type="text/javascript">
	
</script> -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>