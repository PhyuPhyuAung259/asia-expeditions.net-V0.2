<?php $__env->startSection('title', 'Tours List'); ?>
<?php $active = 'tours'; 
  $subactive ='tours';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <section class="col-lg-12 connectedSortable">
            <h3 class="border">Tours List <span class="fa fa-angle-double-right"></span> <a href="<?php echo e(route('tourForm')); ?>" class="btn btn-default btn-sm">New Tour</a></h3>
            <form action="" method="">
              <div class="col-sm-2 col-xs-6 pull-right" style="text-align: right; position: relative; z-index: 2;">
                <label class="location">
                  <span class="fa fa-map-marker hidden-xs" style="left: 35px;"></span>
                  <select class="form-control input-sm locationchange" name="location">
                    <?php $__currentLoopData = \App\Country::getCountryTour(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($loc->id); ?>" <?php echo e($locationid == $loc->id ? 'selected':''); ?>><?php echo e($loc->country_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </label>
              </div>
            </form>
            <table class="datatable table table-hover table-striped">
              <thead>
                <tr>
                  <th style="width: 12px;">Photo</th>
                  <th>TourName</th>
                  <th width="170">TourType</th>
                  <th>Country</th>
                  <th>City</th>
                  <th>Published</th>
                  <th>Pax&Price</th>
                  <th width="110" class="text-center">Options</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                 
                <tr>
                  <td><img src="<?php echo e(Content::urlthumbnail($tour->tour_photo, $tour->user_id)); ?>" style="width: 100%"></td>
                  <td><?php echo e($tour->tour_name); ?></td>
                  <td>
                    <?php $__currentLoopData = $tour->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $busin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <label class="label label-default label-xs"><?php echo e($busin->name); ?></label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </td>
                  <td><?php echo e(isset($tour->country->country_name) ? $tour->country->country_name : ''); ?></td>
                  <td><?php echo e(isset($tour->province->province_name) ? $tour->province->province_name : ''); ?></td>
                  <td><?php echo e(Content::dateformat($tour->updated_at)); ?></td>
                  <td class="text-center">
                    <span class="badge"><?php echo e($tour->pricetour->count()); ?></span>
                  </td>                  
                  <td class="text-right">                      
                    <a href="<?php echo e(route('getTourUpdate', ['url'=> $tour->id])); ?>" title="Edit Tour">
                      <label src="#" class="icon-list ic_edit_tour"></label>
                    </a>
                    <a href="<?php echo e(route('getTourPrice', ['url'=> $tour->id])); ?>" title="Add Tour Pax & Price">
                      <label src="#" class="icon-list ic_tour_addprice"></label>
                    </a>
                    <a href="<?php echo e(route('getTourPriceEdit', ['url' => $tour->id])); ?>" title="Edit Tour Pax & Price">
                      <label src="#" class="icon-list ic_tour_editprice"></label>
                    </a>
                    <a target="_blank" href="<?php echo e(route('getTourReport', ['url'=> $tour->id, 'type'=> 'selling'])); ?>" title="View Tour Report Selling Price">
                      <label src="#" class="icon-list ic_report_selling"></label>
                    </a>
                    <a target="_blank" href="<?php echo e(route('getTourReport', ['url'=> $tour->id, 'type'=> 'net'])); ?>" title="View Tour Report Net Price">
                      <label src="#" class="icon-list ic_report_net"></label>
                    </a>
                    <?php echo Content::DelUserRole("Delete this tour ?", "tour", $tour->id, $tour->user_id ); ?>    
                  </td>                     
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>                
          </section>
        </div>
    </section>
  </div>  
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>