<?php 
	$comId = Auth::user()->company_id ? Auth::user()->company_id: 1;
	$comadd = \App\Company::find($comId);
?>
<table class="table">
	<tr>
		<td style="border-top: none; border-bottom: 1px solid #f4f4f4;">
			<div><strong style="text-transform: capitalize;">Project <?php echo e($type); ?></strong></div>
			<div><b>File/ Project :</b> <?php echo e($project->project_prefix); ?>-<?php echo e($project->project_fileno ? $project->project_fileno: $project->project_number); ?></div>
			<div><b>Client Name/s :</b> <?php echo e($project->project_client); ?></div>
			<div><b>Travelling Date :</b> <?php echo e(date("d-M-Y", strtotime($project->project_start))); ?> - <?php echo e(date("d-M-Y", strtotime($project->project_end))); ?></div>
			<div>
				<span><b>Flight No./Arrival :</b> <?php echo e(isset($project->flightArr->flightno) ? $project->flightArr->flightno : ''); ?> - <?php echo e(isset($project->flightArr->arr_time) ? $project->flightArr->arr_time : ''); ?></span>, 
				<span><b>Flight No./Departure :</b> <?php echo e(isset($project->flightDep->flightno) ? $project->flightDep->flightno : ''); ?> - <?php echo e(isset($project->flightDep->dep_time) ? $project->flightDep->dep_time : ''); ?></span>
			</div>
			<div>
				<span><b>Travel Consultant :</b> <?php echo e($project->project_book_consultant); ?></span>, 
				<span><b>Reference No.: <?php echo e($project->project_book_ref); ?></b></span>
			</div>
		</td>
		<td class="text-right" width="200px" style="border-top: none; border-bottom: 1px solid #f4f4f4;">
			<img src="<?php echo e(Storage::url('avata/')); ?><?php echo e(isset($comadd->logo) ? $comadd->logo : ''); ?>" style="width: 100%;">
		</td>
	</tr>
</table> 