<?php $__env->startSection('title', 'Flight Schedule'); ?>
<?php $active = 'supplier/flights'; 
$subactive = 'cruise/applied/cabin';
  use App\component\Content;
?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <section class="col-lg-12 connectedSortable">
              <h3 class="border"> <i class="fa fa-plane"></i> Flight Schedule <span class="fa fa-angle-double-right"></span> <a href="<?php echo e(route('createFlightSchedule')); ?>" class="btn btn-default btn-sm">New Schedule </a></h3>
              <form action="" method="">
                <div class="col-sm-2 pull-right" style="text-align: right;">
                  <label class="location">
                    <span class="fa fa-map-marker hidden-xs"></span>
                    <select class="form-control input-sm locationchange" name="location">
                      <?php $__currentLoopData = \App\Country::where('web', 1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($loc->id); ?>" <?php echo e($locationid == $loc->id ? 'selected':''); ?>><?php echo e($loc->country_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </label>
                </div>
              </form>
              <table class="datatable table table-hover table-striped">
                <thead>
                  <tr>
                    <th width="20">Number</th>
                    <th width="190">Departure & Arrival Time</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Days</th>
                    <th>Country</th>
                    <th>Airline</th>
                    <th>Agents</th>              
                    <th class="text-center">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>                      
                    <td><?php echo e($schedule->flightno); ?></td>
                    <td><?php echo e($schedule->dep_time); ?>  <i class="fa fa-fighter-jet"></i> <?php echo e($schedule->arr_time); ?></td>
                    <td><?php echo e($schedule->flight_from); ?></td>
                    <td><?php echo e($schedule->flight_to); ?></td>
                    <td width="239px">             
                      <?php $__currentLoopData = $schedule->weekday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="label label-default"><?php echo e(substr($day->days_name,0,3)); ?></label>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </td>
                    <td><?php echo e(isset($schedule->country->country_name) ? $schedule->country->country_name : ''); ?></td>
                    <td><?php echo e(isset($schedule->supplier->supplier_name) ? $schedule->supplier->supplier_name : ''); ?></td>
                    <td class="text-right">
                      <?php $__currentLoopData = $schedule->flightagent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $flight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a title="View Flight Agency & Price" href="<?php echo e(route('getSchedulePrice', ['url'=> $flight->id])); ?>" class="label label-default"><?php echo e($flight->supplier_name); ?> <i class="fa fa-gg"></i></a>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td width="100" class="text-right">
                      <a href="<?php echo e(route('getEditSchedule', ['urid' => $schedule->id])); ?>" title="Edit flight Schedule">
                        <label src="#" class="icon-list ic_book_project"></label>
                      </a>
                      <?php echo Content::DelUserRole("Delete this flight No. ?", "flightNo", $schedule->id, $schedule->user_id ); ?>            
                    </td>                     
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>                
          </section>
        </div>
    </section>
  </div>  
</div>
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>