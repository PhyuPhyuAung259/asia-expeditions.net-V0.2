<?php $__env->startSection('title', 'Journal Entry'); ?>
<?php 
  $active = 'finance/accountPayable/project-booked'; 
  $subactive = 'finance/journal/create';
  use App\component\Content;
  $countryId = Auth::user()->country_id ? Auth::user()->country_id : 0;
?>
<?php $__env->startSection('content'); ?>
  
  <div class="wrapper">
    <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content">
        <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <h3 class="border text-center" style="color:black;text-transform: uppercase;font-weight:bold;">Journal Entry</h3>
          <form method="POST" action="<?php echo e(route('createJournal')); ?>" id="account_journal_entry_form">
            <?php echo e(csrf_field()); ?>

            <div class="row">
              <div class="col-md-12" style="margin-bottom: 20px">
                <div class="account-saction"><br>
                  <div class="col-md-12">
                    <div class="row">
                      <div class="col-md-2 col-xs-6">
                        <div class="form-group">
                          <label>Date<span style="color:#b12f1f;">*</span></label> 
                          <input type="text" name="entry_date" class="form-control book_date" value="<?php echo e(date('Y-m-d')); ?>" required="">
                        </div>
                      </div>
                      <div class="col-md-2 col-xs-6">
                        <div class="form-group">
                          <label>location</label>
                          <select class="form-control location" name="country" data-type="country">
                            <?php $__currentLoopData = App\Country::countryByProject(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($con->id); ?>"><?php echo e($con->country_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div class="clearfix"></div>
                  <div class="col-md-12">
                    <table class="">
                      <tr class="table-head-row">
                        <th>Business Type</th>
                        <th width="200px">Supplier</th>
                        <th width="190px">Account Type</th>
                        <th width="350px">Account Name</th>
                        <th width="120px">Debit</th>
                        <th width="120px">Credit</th>
                        <th width="120px"><?php echo e(Content::currency(1)); ?> Debit</th>
                        <th width="120px"><?php echo e(Content::currency(1)); ?> Credit</th>
                        <th></th>
                      </tr>
                      <tbody id="data_payment_option">
                        <tr class="clone-data">
                          <td>
                            <select class="form-control input-sm business" name="business[]" data-type="sup_by_bus" required="">
                              <option value="">--choose--</option>
                              <?php $__currentLoopData = App\Business::where(['category_id'=>0, 'status'=>1])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($bn->id); ?>"><?php echo e($bn->name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </td>
                          <td style="position: relative;">
                            <select class="form-control suppliers input-sm" name="supplier[]" id="dropdown_supplier" required=""></select>
                          </td>
                          <td>
                            <select class="form-control account_type input-sm" name="account_type[]" data-multiType="account_name_journal" data-type="account_name" required="">
                              <option value="0">Choose Account Types</option>
                              <?php $__currentLoopData = App\AccountType::where('status', 1)->orderBy('account_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($acc->id); ?>"><?php echo e($acc->account_name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </td>
                          <td style="position: relative;">
                            <div class="btn-group" style='display: block;'>
                                <button type="button" class="form-control input-sm arrow-down" data-toggle="dropdown" aria-haspopup="false" aria-expanded='false' data-backdrop="static" data-keyboard="false" role="dialog" data-backdrop="static" data-keyboard="false">
                                  <span class="pull-left">
                                    <?php if(isset($acc_tran->account_name)): ?>
                                      <?php echo e(isset($acc_tran->account_name->account_code) ? $acc_tran->account_name->account_code : ''); ?> - <?php echo e(isset($acc_tran->account_name->account_name) ? $acc_tran->account_name->account_name : ''); ?>

                                    <?php endif; ?>
                                  </span>
                                  <span class="pull-right"></span>
                                </button> 
                                <div class="obs-wrapper-search" style="max-height:250px; overflow: auto; ">
                                  <div>
                                    <input type="text" data-url="<?php echo e(route('getFilter')); ?>" id="search_Account" onkeyup="filterAccountName()" class="form-control input-sm">
                                  </div>
                                  <ul id="myAccountName" class="list-unstyled dropdown_account_name">
                                    <?php if(isset($_GET['eid']) && !empty(isset($_GET['eid']))): ?>
                                      <?php $__currentLoopData = \App\AccountName::where("account_type_id", $acc_tran->account_type_id)->orderBy('account_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class='list' style=' padding: 4px 0px !important;'>
                                          <label style='position: relative;font-weight: 400; line-height:12px;'>
                                            <input type='radio' name='account_name' value="<?php echo e($acc_name->id); ?>" <?php echo e($acc_name->id == $acc_tran->account_name_id ? 'checked' : ''); ?>> <span style='position:relative; top:-2px;'> <?php echo e($acc_name->account_code); ?> - <?php echo e($acc_name->account_name); ?></span></label></li>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                  </ul>
                                </div>
                            </div>
                          </td>
                          <td>
                            <input type="text" class="debit form-control input-sm text-right balance number_only" data-type="debit" name="debit[]" id="debit" placeholder="00.0">
                          </td>
                          <td>
                            <input type="text" class="credit form-control input-sm text-right balance number_only" data-type="credit" name="credit[]" id="credit" placeholder="00.0">
                          </td>
                          <td>
                            <input type="text" class="kyat-debit form-control input-sm text-right balance number_only" data-type="kyat-debit" name="kyatdebit[]" id="kyat-debit" placeholder="00.0">
                          </td>
                          <td>
                            <input type="text" class="kyat-credit form-control input-sm text-right balance number_only" data-type="kyat-credit" name="kyatcredit[]" id="kyat-credit" placeholder="00.0">
                          </td>
                          <td class="text-center">
                            <span class="btnRemoveEntry">
                              <i class="fa fa-times-circle btn-block" style="font-size: 19px; background: #ddd;padding: 6px;"></i></span>
                          </td>
                        </tr>
                      </tbody>
                    </table><br>
                    <div class="col-md-6">
                      <div class="row">
                        <span class="btn btn-flat btn-primary btn-xs btnAddLine" ><i class="fa fa-plus-square"></i> Add New Line</span>
                      </div>
                    </div>
                    <div class="col-md-6 text-right">
                      <div class="row">
                        <div style="padding: 4px 0px;">
                          <div class="col-md-6"> <span>Subtotal <?php echo e(Content::currency()); ?></span></div>
                          <div class="col-md-3"> 
                            <span class="sub_total_debit">0.00</span>
                          </div>
                          <div class="col-md-3"> <span class="sub_total_credit">00.00</span>
                            <input type="hidden" name="debit_amount" id="debit_amount">
                          </div>
                          <div class="clearfix"></div>
                        </div>
                      
                        <div style="padding: 7px 0px; border-top: solid 1px #999999b3;">
                          <div class="col-md-6"><strong>TOTAL</strong></div>
                          <div class="col-md-3"> 
                            <strong class="sub_total_debit">0.00</strong>
                          </div>
                          <div class="col-md-3"> 
                            <strong class="sub_total_credit">00.00</strong>
                            <input type="hidden" name="credit_amount" id="credit_amount">
                          </div>
                          <div class="clearfix"></div>
                        </div>
                        <div style="padding: 4px 0px;">
                          <div class="col-md-6"> <span>Subtotal <?php echo e(Content::currency(1)); ?></span></div>
                          <div class="col-md-3"> 
                            <span class="kyat_sub_total_debit">0.00</span>
                          </div>
                          <div class="col-md-3"> <span class="kyat_sub_total_credit">00.00</span>
                            <input type="hidden" name="kyat_debit_amount" id="kyat_debit_amount">
                          </div>
                          <div class="clearfix"></div>
                        </div>
                      
                        <div style="padding: 7px 0px; border-top: solid 1px #999999b3;">
                          <div class="col-md-6"> <strong>TOTAL</strong> </div>
                          <div class="col-md-3"> 
                            <strong class="kyat_sub_total_debit">0.00</strong>
                          </div>
                          <div class="col-md-3"> 
                              <strong class="kyat_sub_total_credit">00.00</strong>
                              <input type="hidden" name="kyat_credit_amount" id="kyat_credit_amount">
                          </div>                        
                        </div>
                        <div class="clearfix"></div>
                        <hr style="padding: 1px;border: solid 1px #999999b3;margin-top: 0px;border-right: none;border-left: none;">
                      </div>
                    </div>
                    <div class="clearfix"></div>
                    <br>
                    <div class="col-md-12 text-center">
                      <div class="form-group">
                        <button class="btn btn-info btn-sm btn-flat" id="btnSaveReceivable" style="width: 120px;">Save</button>
                      </div>
                    </div>
                  </div>
                <div class="clearfix"></div>
                </div>
              </div>
            </div>
          </form> 
        <br><br>
      </section>
    </div>
  </div>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="modal" id="myAlert" role="dialog" data-backdrop="static" data-keyboard="true">
  <div class="modal-dialog modal-sm">    
    <form method="POST" action="<?php echo e(route('addNewAccount')); ?>" id="add_new_account_form">
      <div class="modal-content">        
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><strong>Delete line item</strong></h4>
        </div>
        <div class="modal-body">
          <strong id="message">You must have at least 2 line items.</strong>        
        </div>
        <div class="modal-footer">
          <div class="text-center">
            <a href="#" class="btn btn-danger btn-xs" data-dismiss="modal">OK</a>
          </div>
        </div>    
      </div>  
    </form>
  </div>
</div>

<?php echo $__env->make("admin.account.accountant", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
<script type="text/javascript">
  // $(document).ready(function(){

     function filterAccountName(){
          input = document.getElementById("search_Account");
          // input = $(this).find("#search_Account");
          filter = input.value.toUpperCase();
          ul = document.getElementById("myAccountName");
          li = ul.getElementsByClassName ("list");
          for (i = 0; i < li.length; i++) {
              a = li[i];
              if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
                li[i].style.display = "";
              } else {
                li[i].style.display = "none";
              }
          }
      }
  // });
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>