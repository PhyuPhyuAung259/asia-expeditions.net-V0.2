<?php $__env->startSection('title', 'User List'); ?>
<?php $active = 'users';
  $subactive ='users'; 
  use App\component\Content;
?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <section class="col-lg-12 connectedSortable">
            <h3 class="border">Users List <span style=" font-size: 22px;" class="fa fa-angle-double-right"></span> <a href="<?php echo e(route('userForm')); ?>" class="btn btn-primary btn-sm">Add User</a></h3>
            <table class="datatable table table-hover table-striped">
              <thead>
                <tr>
                  <th width="30px">Photo</th>
                  <th>UserName</th>
                  <th>Country</th>
                 <!--  <?php if(Auth::user()->role_id == 2): ?>
                  <th>Company Name</th>
                  <?php endif; ?> -->
                  <th>Phone</th>
                  <th>Email</th>
                  <!-- <th>Password</th> -->
                  <th>Role</th>
                  <th>Joining on</th>
                  <th>Status</th>
                  <th width="120" class="text-center">action</th>
                </tr>
              </thead>
              <tbody>
              <?php if(isset($users) && $users->count() > 0): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td width="30px"><img src="<?php echo e($user->picture > 0 ? Storage::url($user->picture) : Storage::url('avata/user_icon.png')); ?>" style="border-radius: 50%;width: 36px;"></td>
                    <td><?php echo e($user->fullname); ?></td>
                    <td><?php echo e($user->country->country_name); ?></td>
                  <!--   <?php if(Auth::user()->role_id == 2): ?>
                      <td><b><?php echo e(isset($user->company->name) ? $user->company->name : ''); ?></b></td>
                    <?php endif; ?> -->
                    <td><?php echo e($user->phone); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <!-- <td><?php echo e($user->password_text); ?></td> -->
                    <td><?php echo e(isset($user->role->name) ? $user->role->name : ''); ?></td> 
                    <td><?php echo e(Content::dateformat($user->created_at)); ?></td>   
                    <td><?php echo $user->banned==1? "<label class='label label-default'>Deactive<label>": "<label class='label label-success'>Active</label>"; ?></td>      
                    <td class="text-right">    
                      <?php if(Auth::user()->role_id == 2 && !empty($user->company_id && $user->banned === 0) ): ?>
                        <form method="POST" target="_blank" action="<?php echo e(route('guardLogin')); ?>" class="pull-left">
                          <?php echo e(csrf_field()); ?>

                          <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                          <input type="hidden" name="email" value="<?php echo e($user->email); ?>">
                          <input type="hidden" name="password" value="<?php echo e($user->password_text); ?>">
                          <button type="submit" class="btn btn-info btn-xs"><i class="fa fa-user-plus"></i></button>
                        </form>
                      <?php endif; ?>
                      <a target="_blank" href="<?php echo e(route('userStore', ['id'=>$user->id])); ?>" class="btn btn-info btn-xs" title="Change User Info">
                        <i class="fa fa-edit"></i>
                      </a>
                      <a target="_blank" href="<?php echo e(route('editpermission', ['url'=> $user->id])); ?>" class="btn btn-primary btn-xs" title="Change Password & User Permission">
                        <i class="fa fa-gear (alias)"></i>
                      </a>            
                      <a href="javascript:void(0)" data-type="user" class="RemoveHotelRate btn btn-danger btn-xs" data-id="<?php echo e($user->id); ?>" title="Remove this user?">
                        <i class="fa fa-minus-circle"></i>
                      </a>
                    </td>                     
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
              </tbody>
            </table>                
        </section>
        <div class="clearfix"></div>
    </section>
  </div>  
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>