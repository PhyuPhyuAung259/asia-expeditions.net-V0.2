<?php $__env->startSection('title', 'Payment Link'); ?>
<?php
  $active = 'finance'; 
  $subactive = 'finance/payment_getway';
  use App\component\Content;
?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <div class="row">
        <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <section class="col-lg-12 connectedSortable">
            <h3 class="border">Payment Link <span class="fa fa-angle-double-right"></span> <a href="<?php echo e(route('createPaymentLink')); ?>" class="btn btn-default btn-sm">Add New Payment</a></h3>
            <form action="" method="">
              <div class="col-sm-2 col-xs-6 pull-right" style="text-align: right; position: relative; z-index: 2;">
                <label class="sort">
                  <select class="form-control input-sm locationchange" name="sort">
                    <option value="">Sort</option>
                    <option value="paid" <?php echo e(isset($_GET['sort']) && $_GET['sort'] == 'paid' ? 'selected':''); ?>>Paid</option>
                    <option value="unpaid" <?php echo e(isset($_GET['sort']) && $_GET['sort'] == 'unpaid' ? 'selected':''); ?>>UnPaid</option>
                  </select>
                </label>
              </div>
            </form>
            <table class="datatable table table-hover table-striped">
              <thead>
                <tr>     
                  <th width="90px">Invoice #</th>                
                  <th>Client Name</th>
                  <th>Customer Name</th>
                  <th>User Created</th>
                  <th>Email</th>
                  <th>Invoice Date</th>
                  <th>Pay Date</th>
                  <th class="text-right">Amount <?php echo e(Content::currency()); ?></th>
                  <th width="100" class="text-center">Status</th>
                  <th class="text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $paymentlink; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $plk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><a target="_blank" href="<?php echo e(route('getPaymentView', ['preview_inv'=> $plk->invoice_number])); ?>">#<?php echo e($plk->invoice_number); ?></a></td>
                    <td><?php echo e(isset($plk->project->project_prefix) ? $plk->project->project_prefix : ''); ?>-<?php echo e(isset($plk->project->project_fileno) ? $plk->project->project_fileno : ''); ?> - <?php echo e(isset($plk->project->project_client) ? $plk->project->project_client : ''); ?></td>
                    <td><?php echo e($plk->fullname); ?></td>
                    <td><?php echo e(isset($plk->user->fullname) ? $plk->user->fullname : ''); ?></td>
                    <td><?php echo e($plk->email); ?></td>
                    <td class="text-right"><?php echo e(date("d M Y, H:s A", strtotime($plk->created_at))); ?></td>
                    <td class="text-right"><?php echo e(date("d M Y, H:s A", strtotime($plk->updated_at))); ?></td>
                    <td class="text-right"><?php echo e(Content::money($plk->amount)); ?></td>                    
                    <td class="text-center">
                      <?php if($plk->payment_confirm == "paid"): ?>
                        <span class="label label-success block">Paid</span>
                      <?php else: ?>
                        <span class="label label-warning block">UnPaid</span>
                      <?php endif; ?>                     
                    </td>
                    <td class="text-right">
                      <?php if($plk->payment_confirm == "unpaid"): ?>
                        <a href="<?php echo e(route('createPaymentLink', ['action'=> 'edit', 'eid'=>$plk->id ])); ?>">
                          <label class="icon-list ic_edit"></label>
                        </a>
                        <span class="btnRemoveOption" data-type="payment_link" data-id="<?php echo e($plk->id); ?>" title="Remove this ?">
                          <label class="icon-list ic_remove"></label>
                        </span>
                      <?php else: ?>
                        <i class="fa fa-check-circle " style="color: #b8cac2;font-size: 25px;"></i>
                      <?php endif; ?>                     
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>                
        </section>
      </div>
    </section>
  </div>
</div> 
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php echo $__env->make("admin.account.accountant", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>