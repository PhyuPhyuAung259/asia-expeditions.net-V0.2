<?php $__env->startSection('title', 'INVOICE'); ?>
<?php 
	use App\component\Content;
	$comadd = \App\Company::find(1);
?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php echo $__env->make('admin.report.headerReport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>		
		<h3 class="text-center"><strong class="btborder" style="text-transform:uppercase;">Invoice</strong></h3>
		<table style="width: 100%;">
			<td style="width: 80%;">				
				<div class="well">
					<div><b>Invoice To:</b> <?php echo e($project->supplier_id == 502 ? $project->project_client :  $project->supplier->supplier_name); ?></div>
					<div><b>Address:</b> <?php echo e(isset($project->supplier->supplier_address) ? $project->supplier->supplier_address : ''); ?></div>
					<div><b>Phone:</b> <?php echo e(isset($project->supplier->supplier_phone) ? $project->supplier->supplier_phone : ''); ?> / <?php echo e(isset($project->supplier->supplier_phone2) ? $project->supplier->supplier_phone2 : ''); ?></div>
				</div>
			</td>
			<td class="text-center" valign="top">
				<h4><?php echo e($project->project_prefix); ?>-<?php echo e($project->project_fileno != null ? $project->project_fileno: $project->project_number); ?></h4>
				<?php echo e(date('d-M-Y')); ?>

			</td>
		</table>
		<div class="clearfix"></div>
		<div><b>Client Name: </b><?php echo e($project->project_client); ?>, <b>Reference: </b><?php echo e($project->project_book_ref); ?>, <b>Travel Consultant :</b><?php echo e($project->project_book_consultant); ?></div>
	<?php 	
		$hotelBook  = App\HotelBooked::where('project_number', $project->project_number);
		$cruiseBook = App\CruiseBooked::where('project_number', $project->project_number);
		$tourBook   = App\Booking::tourBook($project->project_number);
		$flightBook = App\Booking::flightBook($project->project_number);
		$golfBook   = App\Booking::golfBook($project->project_number);
		$grandtotal = $cruiseBook->sum('sell_amount') + $golfBook->sum('book_amount') + $flightBook->sum('book_amount') + $hotelBook->sum('sell_amount') + $tourBook->sum('book_amount');

		if (empty((int)$project->project_selling_rate)) {
			$Project_total = $grandtotal;
		}else{
			$Project_total =  $project->project_selling_rate;
		}
	 ?>
	<table class="table table-striped" style="border: solid 1px #c4c2c2;">
		<tr>
			<th width="10px">No.</th>
			<th style="width: 80%;" class="text-left">Descriptions</th>
			<th class="text-right">Amount</th>
		</tr>
		<tr>
			<td valign="top">1</td>
			<td><?php echo $project->project_desc; ?></td>
			<td class="text-right"><b><?php echo e(Content::money($Project_total)); ?> <?php echo e(Content::currency()); ?></b></td>
		</tr>
		<tr style="background: white;">			
			<td class="text-right" colspan="3"><strong style="text-transform:uppercase;">Grand Total:</strong>
				<b><?php echo e(Content::money($Project_total)); ?> <?php echo e(Content::currency()); ?></b>
			</td>
		</tr>
	</table>
	<table cellpadding="12" cellspacing="5" style="width: 100%;">
		<tbody>
			<td style="width: 80;">
				<?php 
					$bankId = isset($project->project_bank)? $project->project_bank:3;
					$badd = App\Bank::find($project->project_bank);
				?>
				<p><b>Your payment with:</b></p>
				
				<?php echo isset($badd['details']) ? $badd['details'] : ''; ?>

				<br>
				<p><b>Note:</b><br>
					Please note that all bank charges must be paid by sender. Thank you.
				</p>
			</td>
			<td class="text-center" valign="middle">
				<p>
					x x x x x <br>
					Win Zaw<br>
					Managing Director<br>
					Asia Expeditions Co.,Ltd.<br>
				</p>
			</td>
		</tbody>
	</table>
</div><br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>