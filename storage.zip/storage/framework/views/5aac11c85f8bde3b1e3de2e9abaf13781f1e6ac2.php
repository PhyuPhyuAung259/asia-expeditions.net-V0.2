<?php $__env->startSection('title', $supplier->supplier_name); ?>
<?php  use App\component\Content;
	if ($type == 'hotels') {
		$title = 'hotels';
	}elseif ($type == 'golf') {
		$title = 'Golf';
	}elseif ($type == 'flights') {
		$title = 'flights';
	}elseif ($type == 'cruises') {
		$title = 'Cruises';
	}else{
		$title = '';
	} 

	if ($priceType == "contract") {
		$reportType = "Information";
	}else {
		$reportType = "Tariff";
	}
?>
<?php $__env->startSection('content'); ?>
	<div class="col-lg-12">
    <?php echo $__env->make('admin.report.headerReport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>		
		<h3 class="text-center"><strong class="btborder" style="text-transform: uppercase;"><?php echo e($title); ?> <?php echo e($reportType); ?></strong></h3>
		<div class="col-md-12">
			<div class="pull-left">
				<h4 style="text-transform: capitalize;"><strong><?php echo e(isset($supplier->country->country_name) ? $supplier->country->country_name : ''); ?> <i class="fa fa fa-angle-double-right"></i> <?php echo e(isset($supplier->province->province_name) ? $supplier->province->province_name : ''); ?> <i class="fa fa fa-angle-double-right"></i>  <?php echo e($supplier->supplier_name); ?> </strong></h4>
			</div>
			<?php if($priceType != "contract" ): ?>
				<?php if($type == "hotels" ): ?>
				<div class="col-md-7 pull-center hidden-print">
					<form action="/<?php echo e($currentAction); ?>?type=<?php echo e(isset($priceType) ? $priceType : ''); ?>" method="POST">
						<?php echo e(csrf_field()); ?>

						<div class="col-md-12" style="padding-right: 0px;">
							<div class="col-md-6">
								<div class="pull-left"><label style="position:relative;top:8px;">Month</label></div>
								<div class="input-group">
									<select class="form-control input-sm" name="fmonth">
								  		<option value="">--Date--</option>
								  		<?php 
								  			$months = ["January","February","March", "April","May","June","July","August", "September","October","November", "December"];
								  		?>
								  		<?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								  			<option value="<?php echo e($key+1); ?>" <?php echo e((isset($fmonth)?$fmonth:'') == $key+1 ?'selected':''); ?>><?php echo e($m); ?></option>
								  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								  	</select>
								    <span class="input-group-addon">From & To</span>
								    <select class="form-control input-sm" name="tmonth">
								  		<option value="">--Date--</option>
								  		<?php 
								  			$months = ["January","February","March", "April","May","June","July","August", "September","October","November", "December"];
								  		?>
								  		<?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								  			<option value="<?php echo e($key+1); ?>" <?php echo e((isset($tmonth)?$tmonth:'') == $key+1 ?'selected':''); ?>><?php echo e($m); ?></option>
								  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								  	</select>
								</div>
							</div>
						  	<div class="col-md-3">
							  	<div class="pull-left"><label style="position:relative;top:8px;">Year</label></div>
							  	<div class="pull-right">
								  	<select class="form-control input-sm" name="year">
								  		<?php $plusYear = date('Y', strtotime('+10 years'));  ?>
								  		<option value="">---Years---</option>
								  		<?php for($y = 2015; $y <= $plusYear; $y++): ?>
								  			<option value="<?php echo e($y); ?>" <?php echo e((isset($year)?$year == $y:'') ? 'selected':''); ?>><?php echo e($y); ?></option>
								  		<?php endfor; ?>
								  	</select>
								</div>
								<div class="clearfix"></div>
							</div>	
							<div class="col-md-2" style="padding-left: 0px;">
								<label><br></label>
								<button class=" btn btn-default btn-sm active">Query</button>
							</div>						
						</div>
						
					</form>
				</div>
				<?php endif; ?>		
			<?php endif; ?>	
			<div class="pull-right hidden-print">
				<!-- <h3>/ -->
					<a href="javascript:void(0)" onclick="window.print();"><span class="fa fa-print btn btn-primary"> Print</span></a>&nbsp;&nbsp;&nbsp;&nbsp;
				<!-- 	<a class="hidden-print" href="<?php echo e(route('getDownload',['id'=> $supplier->id])); ?>"><span class="fa fa-cloud-download"></span></a> -->
				<!-- </h3> -->
			</div>
		</div>
		<?php if($type == "hotels"): ?>
			<?php echo $__env->make('admin.report.hotel_report', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php elseif( $type == "golf"): ?>
			<?php echo $__env->make('admin.report.golf_report', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php elseif($type == "flights"): ?>
			<?php echo $__env->make('admin.report.flight_report', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php endif; ?>



  	</div>
  	<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>