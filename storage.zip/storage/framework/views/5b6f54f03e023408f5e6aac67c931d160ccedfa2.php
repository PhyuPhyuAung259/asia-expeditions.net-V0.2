<?php $__env->startSection('title', 'Booked Tour List'); ?>
<?php $active = 'booked/project'; 
  $subactive ='booked/tour';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
        <div class="row">
          <form method="POST" action="<?php echo e(route('searchProject', ['project'=> 'tour'])); ?>">
             <?php echo e(csrf_field()); ?>

            <section class="col-lg-12 connectedSortable">
                <h3 class="border">Booked Tours List</h3>
                <div class="col-sm-8 col-xs-12 pull-right">
                  <div class="col-md-3">
                    <input type="hidden" svalue="<?php echo e(isset($projectNum) ? $projectNum : ''); ?>" id="projectNum">
                    <input class="form-control input-sm" type="text" id="from_date" name="start_date" placeholder="From Date" value="<?php echo e(isset($startDate) ? $startDate : ''); ?>"> 
                  </div>
                  <div class="col-md-3">
                    <input class="form-control input-sm" type="text" id="to_date" name="end_date" placeholder="To Date" value="<?php echo e(isset($endDate) ? $endDate : ''); ?>"> 
                  </div>
                   <div class="col-md-2" style="padding: 0px;">
                    <button class="btn btn-default btn-sm" type="submit">Search</button>
                  </div>
                </div>
                <table class="datatable table table-hover table-striped">
                  <thead>
                    <tr>                       
                      <th width="67">Project No.</th>
                      <th>Date</th>
                      <th>Country</th>
                      <th>City</th>
                      <th>Tour</th>
                      <th>User</th>
                      <th>Pax</th>
                      <th>Price</th>
                      <th>Amount</th>
                      <th class="text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php 
                        $tourb = \App\Tour::find($tour->tour_id);
                        $conb = \App\Country::find($tour->country_id);
                        $prob = \App\Province::find($tour->province_id);
                        $user =  \App\User::find($tour->book_userId);
                      ?>
                    <tr>
                      <td class="studentId" width="75">
                        <input type="checkbox" class="btnCheck"> &nbsp; 
                        <?php echo e($tour->book_project); ?></td>
                      <td><?php echo e(Content::dateformat($tour->book_checkin)); ?></td>
                      <td><?php echo e(isset($conb->country_name) ? $conb->country_name : ''); ?></td>
                      <td><?php echo e(isset($prob->province_name) ? $prob->province_name : ''); ?></td>
                      <td><?php echo e(isset($tourb->tour_name) ? $tourb->tour_name : ''); ?></td>
                      <td><?php echo e(isset($user->fullname) ? $user->fullname : ''); ?></td>
                      <td><?php echo e($tour->book_pax); ?></td>
                      <td><?php echo e(Content::money($tour->book_price)); ?></td>
                      <td><?php echo e(Content::money($tour->book_amount)); ?></td>
                      <td class="text-right">
                        <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$tour->book_project, 'type'=>'details'])); ?>" title="Program Details">
                          <label class="icon-list ic_ops_program"></label>
                        </a>
                        <a target="_blank" href="<?php echo e(route('bookingEdit', ['type'=>'tour', 'bookid'=>$tour->book_id])); ?>" title="Edit booked tour">
                          <label class="icon-list ic_edit"></label>
                        </a> 
                        &nbsp;           
                      <!--   <a href="javascript:void(0)" class="RemoveHotelRate" data-type="book_tour" data-id="<?php echo e($tour->book_id); ?>" title="Delete this booking">
                          <label class="icon-list ic_remove"></label>
                        </a>         -->
                       <?php echo Content::DelUserRole("Delete this Tour Booked ?", "book_tour", $tour->book_id, $tour->user_id ); ?>              
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <!-- <div class="pull-left">Check All</div> -->
            </section>
          </form>
        </div>
    </section>
  </div>
<script type="text/javascript">
  $(document).ready(function(){
    $(".datatable").DataTable({
      language: {
        searchPlaceholder: "File / Project No."
      }
    });
  });
</script>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>