<!DOCTYPE html>
<?php 
  $comadd = App\Company::find(1);
?>
<html>

  <head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e($comadd->title); ?></title>    
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(url('storage/avata')); ?>/<?php echo e($comadd->logo); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('adminlte/css/all.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('adminlte/css/style.css')); ?>">
    <!-- <link rel="stylesheet" type="text/css" href="<?php echo e(asset('adminlte/css/style.css')); ?>"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('adminlte/table/datatables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('adminlte/table/datepicker.css')); ?>">

    <script type="text/javascript" src="<?php echo e(asset('adminlte/js/all.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('adminlte/table/datatables.min.js')); ?>"></script>

    <!-- <script type="text/javascript" src="/adminlte/bower_components/fastclick/lib/fastclick.js"></script> -->

    <script type="text/javascript" src="<?php echo e(asset('adminlte/js/script.js')); ?>"></script>


<!-- minify file script -->
    <!-- <script type="text/javascript" src="<?php echo e(asset('adminlte/js/script.min.js')); ?>"></script> -->

    <script type="text/javascript" src="<?php echo e(asset('adminlte/js/booking.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(asset('adminlte/js/apply_room.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(asset('adminlte/js/uploadfile.js')); ?>"></script>

  </head>

  <body class=" skin-green sidebar-mini sidebar-collapse">

      <?php echo $__env->yieldContent('content'); ?>

      <script type="text/javascript" src="<?php echo e(asset('adminlte/table/bootstrap-datepicker.js')); ?>"></script>

      <script type="text/javascript" src="<?php echo e(asset('adminlte/table/datepicker.js')); ?>"></script>

      <script type="text/javascript">

        $(document).ready(function(){
          $(".text-search").attr('name','textSearch');

          $(".text-search").val($("#projectNum").val());

          $("#goTotop").click(function (){
              $('html, body').animate({
                  scrollTop: $(".skin-green").offset().top
              }, 300);
          });
          $(window).scroll(function(){
            if($(window).scrollTop() > 250 ){
              $("#goTotop").css('display','block');
            }else{
              $("#goTotop").css('display','none');
            }
          });
        });
      </script>

    </div>
    <a id="goTotop" class="hidden-print" style="position: fixed; right: 19px; display: none; bottom: 25px; font-size: 35px; z-index: 999999999;" href="javascript:void(0)"><span class="fa fa-chevron-circle-up"></span></a>

  </body>

</html>

