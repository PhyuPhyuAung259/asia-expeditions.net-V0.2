<?php $__env->startSection('title', 'Hotel Voucher'); ?>
<?php 
	use App\component\Content;
	$comId = Auth::user()->company_id ? Auth::user()->company_id: 1;
	$comadd = \App\Company::find($comId);
?>
<?php $__env->startSection('content'); ?>
<style type="text/css">
	@media  print {
	  .no_of_room {
	    width: 120px !important;
	  }
	}
</style>
	<div class="container">
    <?php echo $__env->make('admin.report.headerReport', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>		
		<h3 class="text-center"><strong class="btborder" style="text-transform:uppercase;">service voucher</strong></h3>
		<div class="col-md-10 col-md-offset-2">
			<div class="row">
				<div class="pull-left hotel_voucher_title" style="position: relative;bottom:-12px;left:55px">
					<strong style="font-size:16px;">File / Project No. <?php echo e($project->project_fileno ? $project['project_prefix'].'-'.$project['project_fileno'] : $project->project_number); ?></strong>
				</div>
				<div class="pull-right hidden-print">
					<a href="javascript:void(0)" onclick="window.print();"><span class="fa fa-print btn btn-primary"></span></a>&nbsp;&nbsp;&nbsp;&nbsp;
				</div>
			</div> 
		</div>
		<table class="table" style="width: 100%;" >
			<tr>
				<td style="border-top: none" class="text-right hotel_voucher" width="205px">
					<address style="margin-bottom: 0px;">
						Name:<br>
						Address:<br>
						Phone:<br>
						Email:
					</address>
				</td>
				<td style="border-top: none" colspan="3" >
					<div class="well" style="padding: 4px;margin-bottom: 0px; background-color: #ddd0;">
						<address style="margin-bottom: 0px;">
							<?php echo e(isset($bhotel->hotel->supplier_name) ? $bhotel->hotel->supplier_name : ''); ?><br>
							<?php echo e(isset($bhotel->hotel->supplier_address) ? $bhotel->hotel->supplier_address : ''); ?><br>
							<?php echo e(isset($bhotel->hotel->supplier_phone) ? $bhotel->hotel->supplier_phone : ''); ?> / <?php echo e(isset($bhotel->hotel->supplier_phone2) ? $bhotel->hotel->supplier_phone2 : ''); ?><br>
							<?php echo e(isset($bhotel->hotel->supplier_email) ? $bhotel->hotel->supplier_email : ''); ?><br>
						</address>
					</div>
				</td>
			</tr>
			<tr>
				<td style="border-top: none; padding:2px;" class="text-right" >
					<label style="font-weight:400;margin-top: 8px;">Client Name:</label>
				</td>
				<td style="border-top: none; width: 34%; padding:2px;">
					<div style="padding: 1px;margin-bottom: 0px; background-color: #ddd0; border:none;">
						<div style="margin: 0px 0px 4px 0px;" class="form-control input-sm"><?php echo e($project['project_client']); ?></div>
					</div>
				</td>
				<td style="border-top: none; width: 12%; vertical-align: top; text-align: right; padding:2px;">
					<label style="font-weight: 400; margin-top: 10px">No. of Pax:</label>
				</td>
				<td style="border-top: none; width: 34%; vertical-align: top; padding:2px;">
					<div  style="padding: 1px;margin-bottom: 0px; background-color: #ddd0; border:none;">
						<div style="margin: 0px 0px 4px 0px;" class="form-control input-sm"><?php echo e($booking['book_pax']); ?></div>
					</div>
				</td>
			</tr>
			<tr>
				<td style="border-top: none; padding:2px;" class="text-right" >
					<label style="font-weight:400;margin-top: 11px;">Check-In:</label><br>
				</td>
				<td style="border-top: none; width: 34%; padding:2px;">
					<div style="padding: 1px;margin-bottom: 0px; background-color: #ddd0; border:none;">
						<div style="margin: 0px 0px 4px 0px;" class="form-control input-sm"><?php echo e(Content::dateformat($bhotel['checkin'])); ?></div>
					</div>
				</td>
				<td style="border-top: none; width: 12%; vertical-align: top; text-align: right; padding:2px;">
					<label style="font-weight: 400; margin-top: 12px;">Check-Out:</label><br>
				</td>
				<td style="border-top: none; width: 34%; vertical-align: top; padding:2px;">
					<div  style="padding: 1px;margin-bottom: 0px; background-color: #ddd0; border:none;">
						<div style="margin: 0px 0px 4px 0px;" class="form-control input-sm"><?php echo e(Content::dateformat($bhotel['checkout'])); ?></div>
					</div>
				</td>
			</tr>
			<?php if($hotel): ?>
				<?php $__currentLoopData = $hotel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $bh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>							
					<tr>
						<td style="border-top: none; padding: 2px;" class="text-right">Room Type:</td>
						<td style="border-top: none; padding: 2px;"><div style="margin: 0px 0px 4px 0px;" class="form-control input-sm"><?php echo e($bh->room->name); ?></div></td>
						<td style="border-top:none; padding:2px;" class="text-right no_of_room">No. of <?php echo e(isset($bh->category->name) ? $bh->category->name : ''); ?>:</td>
						<td style="border-top:none; padding:2px;"><div class="form-control input-sm"><?php echo e($bh->no_of_room); ?></div></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
			<tr>				
				
				<td colspan="5" style="border-top: none; vertical-align: top;">
					<?php $getClientProject = \App\Admin\ProjectClientName::where('project_number', $project->project_number)->orderBy('client_name')->get(); ?>
					<?php if($getClientProject->count() > 0): ?>
					<br><br>
					<table class="table">
							<tr>
								<th colspan="10" style="text-transform: capitalize; border: none; background: #dddddd78">Passenger Manifest</th>
							</tr>
							<tr>
								<th>No.</th>
								<th>Client Name/s</th>
								<th>Nationality</th>
								<th>Passport No.</th>
								<th>Date of Expiry</th>
								<th>Date Of Birth</th>
								<th>Shared With</th>
								<th>Dietary</th>
								<th>Allergies</th>
								<th>Mobile Phone</th>
							</tr>
							<?php $n=1; ?>
							<?php $__currentLoopData = $getClientProject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr><td><?php echo e($n++); ?></td>
									<td><?php echo e($cl->client_name); ?></td>
									<td><?php echo e(isset($cl->country->nationality) ? $cl->country->nationality : ''); ?></td>
									<td><?php echo e($cl->passport); ?></td>
									<td><?php echo e(Content::dateformat($cl->expired_date)); ?></td>
									<td><?php echo e(Content::dateformat($cl->date_of_birth)); ?></td>
									<td><?php echo e($cl->share_with); ?></td>
									<td><?php echo e($cl->dietary); ?></td>
									<td><?php echo e($cl->allergies); ?></td>
									<td><?php echo e($cl->phone); ?></td>
								</tr>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<td style="border-top: none" colspan="4">
					<strong>Remark</strong>
					<div class="form-control input-sm"><?php echo e($bhotel->remark); ?></div></td>
			</tr>
			<tr><td style="border-top: none"></td></tr>			
			<tr>
				<td style="border-top: none">
					<?php echo e($comadd->title); ?>

				</td>
			</tr>
			<tr>
				<td style="border-top: none" colspan="2" class="text-left">Signed By: ........................................</td>
			</tr>
		</table>		
  	</div>
  	<br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>