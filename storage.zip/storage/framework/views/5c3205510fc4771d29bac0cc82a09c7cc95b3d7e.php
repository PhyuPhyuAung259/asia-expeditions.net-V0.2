<?php $__env->startSection('title', 'Cruise Program'); ?>
<?php $active = 'supplier/cruises'; 
  $subactive ='cruise/program';
  use App\component\Content;
  $countryId = Auth::user()->country_id ? Auth::user()->country_id : 0;
?>
<?php $__env->startSection('content'); ?>
  <div class="wrapper">
    <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content"> 
        <div class="row">
          <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="col-lg-12"><h3 class="border">River Cruise Program Management</h3></div>
          <form method="POST" action="<?php echo e(route('updateCrprogram')); ?>">
              <?php echo e(csrf_field()); ?>

              <input type="hidden" name="eid" value="<?php echo e($crpro->id); ?>">
              <section class="col-lg-9 connectedSortable">
                <div class="card">                                
                  <div class="row">
                    <div class="col-md-6 col-xs-12">
                      <div class="form-group">
                        <label>Cruise name<span style="color:#b12f1f;">*</span></label> 
                        <select class="form-control" name="cruis_name" required>
                          <?php $__currentLoopData = App\Supplier::where('business_id', 3)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cruis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($cruis->id); ?>" <?php echo e($cruis->id == $supplier->id? 'selected':''); ?>><?php echo e($cruis->supplier_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div> 
                    </div>
                    <div class="col-md-6 col-xs-12">
                      <div class="form-group">
                        <label>Program Name <span style="color:#b12f1f;">*</span></label> 
                        <input type="text" name="program_name" class="form-control" value="<?php echo e($crpro->program_name); ?>" required>
                      </div> 
                    </div>
                  </div>  
                  <div class="form-group">
                    <label>Hightlights</label>                    
                    <textarea class="form-control" name="program_hight" rows="6"><?php echo $crpro->program_highlight; ?></textarea>
                  </div>
                  <div class="form-group">
                    <label>Remarks</label>
                    <textarea class="form-control" name="program_remark" rows="6"><?php echo $crpro->program_remark; ?></textarea>             
                  </div>
                  <div class="form-group">
                    <label>Description</label>
                    <script src="<?php echo e(asset('adminlte/editor/tinymce.min.js')); ?>"></script>
                    <textarea class="form-control my-editor" name="program_desc" rows="6"><?php echo $crpro->program_intro; ?></textarea>             
                  </div>
                  <div class="form-group">
                    <div class="col-md-3 col-xs-6">
                      <div class="form-group">
                        <label>Status</label>&nbsp;
                        <label style="font-weight:400;"> <input type="radio" name="status" value="1" checked="">Publish</label>&nbsp;&nbsp;
                        <label style="font-weight: 400;"> <input type="radio" name="status" value="0">UnPublish</label>
                      </div> 
                    </div>
                  </div>             
                </div>
              </section>
              <section class="col-lg-3 connectedSortable">
                <div class="panel panel-default">
                  <div class="panel-heading">Applied Type of Cabin</div>
                  <div class="panel-body addscrolling">
                    <?php $__currentLoopData = App\CrCabin::where('status', 1)->orderBy('name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cabin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div>                        
                        <span style="position:relative;top:3px;padding-right:3px;">
                          <i data-id="<?php echo e($key); ?>" class="fa <?php echo e(in_array($cabin->id, explode(',', $dataid)) ? 'fa-check-square' :'fa-square-o'); ?> nocheck"></i>
                          <input style="opacity: 0;" class="choose-option" type="checkbox" name="crcabin[]" value="<?php echo e($cabin->id); ?>" id="<?php echo e($key); ?>" <?php echo e(in_array($cabin->id, explode(',', $dataid)) ? 'checked':''); ?>>
                        </span>
                        <label style="font-weight: 400;" for="<?php echo e($key); ?>"><?php echo e($cabin->name); ?></label>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>                  
                </div>
                <div class="panel panel-default">
                  <div class="panel-heading">Destination City Name</div>
                  <div class="panel-body">               
                    <select class="form-control" name="program_dest">
                      <?php $__currentLoopData = App\Province::where(['country_id'=>$supplier->country_id, 'province_status'=> 1])->orderBy('province_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($pro->id); ?>" <?php echo e($pro->id == $crpro->province_id ? 'selected':''); ?>><?php echo e($pro->province_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>                  
                </div>
                <div class="form-group"> 
                  <button type="submit" class="btn btn-success btn-flat btn-sm">Submit</button>&nbsp;&nbsp;
                  <a href="<?php echo e(route('tourList')); ?>" class="btn btn-danger btn-flat btn-sm">Cancel</a>               
                </div>
              </section>
          </form>
        </div>
      </section>
    </div>  
  </div>
  <?php echo $__env->make('admin.include.windowUpload', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.editor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>