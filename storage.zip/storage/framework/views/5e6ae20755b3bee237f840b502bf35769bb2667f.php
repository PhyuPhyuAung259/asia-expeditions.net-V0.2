<?php $__env->startSection('title', 'Restaurant Menu'); ?>
<?php 
  $active = 'restaurant/menu';
  $subactive ='restaurant/menu';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
  <div class="wrapper">
    <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="content-wrapper">
      <section class="content"> 
        <div class="row">
          <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <form method="POST" action="<?php echo e(route('AddRestMenu')); ?>">
            <?php echo e(csrf_field()); ?>

              <div class="col-lg-12"> 
                <div class="border form-group">
                  <div class="col-md-2">
                    <div class="row">
                      <strong style="font-size: 23px;">Restaurant Name</strong>
                    </div>
                  </div>  
                  <div class="col-md-2 col-xs-6">                  
                    <select class="form-control country" name="country" data-type="restaurant_supplier" data-selectetype="restaurrant_supplier" data-locat="data">
                      <?php $getLocation = App\Country::countryBySupplier([2]); ?>
                      <option>--Choose--</option>
                      <?php $__currentLoopData = $getLocation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($con->id); ?>"><?php echo e($con->country_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>                      
                  <div class="col-md-5 col-xs-6">                  
                    <select class="form-control" name="rest_name" id="dropdown-restaurant_supplier"> </select>
                  </div><div class="clearfix"></div>
                </div>
              </div>
              <section class="col-lg-9">                              
                <table class="table table-hover table-striped" id="restaurant">
                  <thead>
                    <tr>                     
                      <th>Menu Name</th>
                      <th class="text-center">Price <?php echo e(Content::currency()); ?></th>
                      <th class="text-center">Price <?php echo e(Content::currency(1 )); ?></th>
                      <th class="text-center">action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td style="width: 60%;">
                        <input type="text" name="menu_name[]" class="form-control input-sm" placeholder="Menu Name" required="">
                      </td> 
                      <td>
                        <input type="text" name="price[]" class="number_only form-control text-center input-sm" placeholder="00.0" required="">
                      </td> 
                      <td>
                        <input type="text" name="kprice[]" class="number_only form-control text-center input-sm" placeholder="00.0" required="">
                      </td> 
                      <td class="text-center"><span class="btn btn-info btn-xs addMenu"><i class="fa fa-plus-circle"></i> Add new</span></td>
                    </tr>               
                  </tbody>
                </table>  
              </section>
              <section class="col-lg-3 ">
                <div class="panel panel-default">
                  <div class="panel-body">
                    <button type="submit" class="btn btn-success btn-flat btn-sm">Confirm</button>
                  </div>
                </div>
              </section>
          </form>
        </div>
      </section>
    </div>  
  </div>
  <script type="text/javascript">
    $(".addMenu").on("click", function(){
        $("table#restaurant tbody tr:last").after('<tr><td style="width: 60%;"><input type="text" name="menu_name[]" class="form-control input-sm" placeholder="Menu Name" required></td> <td><input type="text" name="price[]" class="number_only form-control text-center input-sm" placeholder="00.0" required> </td> <td><input type="text" name="kprice[]" class="number_only form-control text-center input-sm" placeholder="00.0" required=""></td><td class="text-center"><span class="btn btn-danger btn-xs RemoveRest" data-type="hotelrate"><i class="fa fa-minus-circle"></i> Remove</span></td></tr>');
    });
    $(document).on('click','.RemoveRest', function(){
      $(this).closest("tr").remove();
    });
    
  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>