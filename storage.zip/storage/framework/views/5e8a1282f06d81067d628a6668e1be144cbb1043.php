<?php $__env->startSection('title', 'Client Arrival Report'); ?>
<?php
  $active = 'reports'; 
  $subactive = 'arrival_report';
  use App\component\Content;
  $agent_id = isset($agentid) ?  $agentid:0;
  $locat = isset($location) ? $location:0;
  $main = isset($sort_main) ? $sort_main:0;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <div class="row">
        <section class="col-lg-12 connectedSortable">
          <h3 class="border">Client Arrival Report</h3>
          <form method="POST" action="<?php echo e(route('searchArrival')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="col-sm-8 pull-right">
              <div class="col-md-2">
                <input type="hidden" name="" value="<?php echo e(isset($projectNo) ? $projectNo : ''); ?>" id="projectNum">
                <input class="form-control input-sm" type="text" id="from_date" name="start_date" placeholder="From Date" value="<?php echo e(isset($startDate) ? $startDate : ''); ?>"> 
              </div>
              <div class="col-md-2" style="padding-right: 0px;">
                <input class="form-control input-sm" type="text" id="to_date" name="end_date" placeholder="To Date" value="<?php echo e(isset($endDate) ? $endDate : ''); ?>"> 
              </div>
              <div class="col-md-2" style="padding-right: 0px;">
                <select class="form-control input-sm" name="agent">
                  <option value="">Agent</option>
                  <?php $__currentLoopData = App\Supplier::where(['business_id'=>9, 'supplier_status'=>1])->orderBy('supplier_name', 'ASC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($agent->id); ?>" <?php echo e($agent->id == $agent_id ? 'selected':''); ?>> <?php echo e($agent->supplier_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="col-md-2">
                <select class="form-control input-sm" name="sort_main">
                  <option value="Main" <?php echo e($main == 'Main' ? 'selected':''); ?>>Main</option>
                  <option value="Sub" <?php echo e($main == 'Sub' ? 'selected':''); ?>>Sub</option>
                </select>
              </div>
              <div class="col-md-2">
                <select class="form-control input-sm" name="sort_location">
                  <option value="AE" <?php echo e($locat == 'AE' ? 'selected':''); ?>>AE</option>
                  <option value="AM" <?php echo e($locat == 'AM' ? 'selected':''); ?>>AM</option>
                </select>
              </div>
              <div class="col-md-2" style="padding: 0px;">
                <button class="btn btn-default btn-sm" type="submit">Search</button>
              </div>          
            </div>
        
            <table class="datatable table table-hover table-striped">
              <thead>
                <tr>
                  <th width="48px">File No.</th>
                  <th>Client Name</th>
                  <th>Agent</th>
                  <th class="text-center">PaxNo</th>
                  <th>Flight Arrival</th>
                  <th width="123px">Flight Departure</th>
                  <th width="131px">Start Date-End Date</th>
                  <th>User</th>
                  <th class="text-center">Preview</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($pro->project_prefix); ?>-<?php echo e($pro->project_fileno); ?></td>
                  <td><?php echo e($pro->project_client); ?></td>         
                  <td><?php echo e(isset($pro->supplier->supplier_name) ? $pro->supplier->supplier_name : ''); ?></td>     
                  <td class="text-center"><?php echo e($pro->project_pax); ?></td> 
                  <td>
                    <?php if(isset($pro->flightArr->flightno)): ?>
                      <?php echo e(isset($pro->flightArr->flightno) ? $pro->flightArr->flightno : ''); ?>-D:<?php echo e(isset($pro->flightArr->dep_time) ? $pro->flightArr->dep_time : ''); ?>->A:<?php echo e(isset($pro->flightArr->arr_time) ? $pro->flightArr->arr_time : ''); ?>

                    <?php endif; ?>
                  </td>   
                  <td>
                    <?php if(isset($pro->flightDep->flightno)): ?>
                      <?php echo e(isset($pro->flightDep->flightno) ? $pro->flightDep->flightno : ''); ?>-D:<?php echo e(isset($pro->flightDep->dep_time) ? $pro->flightDep->dep_time : ''); ?>->A:<?php echo e(isset($pro->flightDep->arr_time) ? $pro->flightDep->arr_time : ''); ?>

                    <?php endif; ?>
                  </td>          
                  <td>
                    <?php echo e(Content::dateformat($pro->project_start)); ?> - <?php echo e(Content::dateformat($pro->project_end)); ?>

                  </td>
                  <td><span style="text-transform: capitalize;"><?php echo e(isset($pro->user->fullname) ? $pro->user->fullname : ''); ?></span></td>
                  <td class="text-right">                      
                    <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$pro->project_number, 'type'=>'operation'])); ?>" title="Operation Program">
                      <label style="cursor: pointer;" class="icon-list ic_ops_program"></label>
                    </a>
                    <a target="_blank" href="<?php echo e(route('previewProject', ['project'=>$pro->project_number, 'type'=>'sales'])); ?>" title="Prview Details">
                      <label style="cursor: pointer;" class="icon-list ic_del_drop"></label>
                    </a>     
                    <a target="_blank" href="<?php echo e(route('getInvoice', ['prject'=>$pro->project_number, 'type'=> 'invoice'])); ?>" title="View Invoice">
                      <label style="cursor: pointer;" class="icon-list ic_invoice_drop"></label>
                    </a>                 
                  </td>                     
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </form>
        </section>
      </div>
    </section>
  </div>
</div>
<script type="text/javascript">
  $(document).ready(function(){
    $(".datatable").DataTable({
      language: {
        searchPlaceholder: "Number No., File No.",
      }
    });
  });
</script>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>