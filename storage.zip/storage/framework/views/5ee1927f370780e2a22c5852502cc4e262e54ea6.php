<?php $__env->startSection('title', 'Restaurant Menu'); ?>
<?php
  $active = 'restaurant/menu'; 
  $subactive ='restaurant/menu';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
  <div class="content-wrapper">
    <section class="content"> 
      <div class="row">
        <section class="col-lg-12 connectedSortable">
          <h3 class="border">Resturants List <span class="fa fa-angle-double-right"></span> <a href="<?php echo e(route('createrestMenu', ['rest' =>'restaurants'])); ?>" class="btn btn-default btn-sm">Add New Menu</a></h3>
          <?php if(Auth::user()->role_id == 2): ?>
            <form action="" method="">
                <div class="col-sm-2 col-xs-6 pull-right" style="text-align: right; position: relative; z-index: 2;">
                  <label class="location">
                    <select class="form-control input-sm locationchange" name="loc">
                      <?php $__currentLoopData = \App\Country::getCountryTour(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($loc->id); ?>" <?php echo e($locationid == $loc->id ? 'selected':''); ?>><?php echo e($loc->country_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </label>
                </div>
            </form>
          <?php endif; ?>
          <table class="datatable table table-hover table-striped">
            <thead>
              <tr>
                <th>Restaurant</th>
                <th>Menu</th>
                <th class="text-center">Price <?php echo e(Content::currency()); ?></th>
                <th class="text-center">Price <?php echo e(Content::currency(1)); ?></th>
                <th class="text-center">Status</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $restaurant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e(isset($rest->supplier->supplier_name) ? $rest->supplier->supplier_name : ''); ?></td>
                <td><?php echo e($rest->title); ?></td>
                <td class="text-right"><?php echo e(number_format($rest->price,2)); ?></td>
                <td class="text-right"><?php echo e(number_format($rest->kprice,2)); ?></td>
                <td class="text-right">                      
                  <button class="restEditMenu" data-id="<?php echo e($rest->id); ?>" style="padding:0px; border:none;" data-country_id="<?php echo e($rest->country_id); ?>" data-type="country_rest" data-menu="<?php echo e($rest->title); ?>" data-price="<?php echo e($rest->price); ?>" data-rest_name="<?php echo e(isset($rest->supplier->id) ? $rest->supplier->id : ''); ?>" data-kprice="<?php echo e($rest->kprice); ?>" data-toggle="modal" data-target="#myModal">
                    <i style="padding:1px 2px;" class="btn btn-info btn-xs fa fa-pencil-square-o"></i>
                  </button>
                  <a href="javascript:void(0)" class="RemoveHotelRate" data-type="restMenu" data-id="<?php echo e($rest->id); ?>" title="Remove this menu ?">
                    <label class="icon-list ic-trash"></label>
                  </a>
                </td>                     
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </section>
      </div>
    </section>
  </div>
</div> 

<div class="modal fade" id="myModal" role="dialog" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog modal-lg">    
    <form id="form_submitRestMenu" method="POST" action="<?php echo e(route('EditRestMenu')); ?>">
      <div class="modal-content">        
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><strong>Update Restaurant Menu</strong></h4>
        </div>
        <div class="modal-body">
          <?php echo e(csrf_field()); ?>    
          <input type="hidden" name="eid" id="restid">
          <div class="row">
            <div class="col-md-6 col-xs-6">    
              <div class="form-group">
                <input type="hidden" name="country">
                <label>Country <span style="color:#b12f1f;">*</span></label> 
                <select class="form-control country" id="country" name="country" data-type="country" data-locat="apply_guide" data-pro_of_bus_id="2" required>
                  <option value="">--choose--</option>
                  <?php $__currentLoopData = App\Country::getCountry(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($con->id); ?>"><?php echo e($con->country_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <div class="col-md-6 col-xs-6">
              <div class="form-group">
                <label>City Name <span style="color:#b12f1f;">*</span></label> 
                <select class="form-control province" name="city" data-type="rest_name" id="dropdown-apply_guide" required>
                  <option value="">--choose--</option>                  
                </select>
              </div> 
            </div>
            <div class="col-md-6 col-xs-6">    
              <div class="form-group">
                <label>Restaurant Name <span style="color:#b12f1f;">*</span></label> 
                 <select class="form-control" name="rest_name" id="dropdown-transervice">
                      <?php $__currentLoopData = App\Supplier::where(['supplier_status'=>1, 'business_id'=>2, 'country_id'=> Auth::user()->country_id])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($rest->id); ?>"><?php echo e($rest->supplier_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>
            </div>
            <div class="col-md-6 col-xs-6">
              <div class="form-group">
                <label>Menu Name<span style="color:#b12f1f;">*</span></label> 
                <input type="text" placeholder="Title" class="form-control" name="menu_name" id="menu_name" required autofocus>
              </div> 
            </div>       
            <div class="col-md-6">
              <div class="form-group">
                <label>Price <?php echo e(Content::currency()); ?> </label>
                <input type="text" class="form-control" name="price" id="price">
              </div>
            </div>     
            <div class="col-md-6">
              <div class="form-group">
                <label>Price <?php echo e(Content::currency(1)); ?> </label>
                <input type="text" class="form-control" name="kprice" id="kprice">
              </div>
            </div>         
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-success btn-flat btn-sm" >Publish</button>
            <a href="#" class="btn btn-danger btn-flat btn-sm" data-dismiss="modal">Cancel</a>
          </div>
        </div>  
      </div>  
    </form>
  </div>
</div>
<script type="text/javascript">
  $(document).ready(function(){
     $(".datatable").DataTable();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>