<?php $__env->startSection('title', isset($business) ? $business->name: 'Suppliers'); ?>
<?php 
  $active = isset($business) ? 'supplier/'.$business->slug: 'suppliers'; 
  $supply = isset($business) ? $business->slug: 'supplier'; 
  $subactive = isset($business) ? 'supplier/'.$business->slug: 'suppliers';
  use App\component\Content;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <div class="row">
        <section class="col-lg-12 connectedSortable">
          <h3 class="border">Suppliers <?php echo e(isset($business->name) ? $business->name : ''); ?> List <span class="fa fa-angle-double-right"></span> <a href="<?php echo e(route('getSupplierForm', ['type'=> $supply] )); ?>" class="btn btn-default btn-sm">New <?php echo e(isset($business->name) ? $business->name : 'Supplier'); ?></a></h3>     
          <?php if(Auth::user()->role_id == 2 || Auth::user()->role_id == 4): ?>
          <form action="" method="" style="position: relative; z-index: 2;">
            <div class="col-sm-2 col-xs-6 pull-right" style="text-align: right; margin-right: -15px;">
              <label class="location">
                <select class="form-control input-sm locationchange" name="location">
                  <option value="">--Choose--</option>
                  	<?php 
                    	if (isset($business)) {
                    		$getCountry = \App\Country::countryBySupplier($business['id']);
                    	}else{
                    		$getCountry = \App\Country::where('country_status', 1)->orderBy('country_name', 'ASC')->get();
                    	}
                  	?>
	                <?php $__currentLoopData = $getCountry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                    <option value="<?php echo e($loc->id); ?>" <?php echo e($locationid == $loc->id ? 'selected':''); ?>><?php echo e($loc->country_name); ?></option>
	                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </label>
            </div>
          </form>
         
          <?php endif; ?>
          <?php if(isset($supplierName) && $supplierName == 'hotels'): ?>
            <?php  $route = route('getHotelinfo'); ?>
          <?php elseif(isset($supplierName) && $supplierName == 'restaurants'): ?>
            <?php  $route = route('getRestautantinfo'); ?>  
          <?php else: ?>
            <?php  $route = route('getRestautantinfo'); ?>
          <?php endif; ?>
          <form target="_blank" action="<?php echo e($route); ?>" method="GET">
              <div class="col-sm-1 pull-right">
                <button style="border-radius: 50px;" class="btn btn-sm btn-default ok_download" data-type="excel">Download Excel  &nbsp;<i class="fa fa-download"></i></button>
              </div>
              <div class="col-sm-1 pull-right checkingAction" style="display: none;">
                <button class="btn btn-sm btn-primary btn_acc">Preview Info</button>
              </div>
              <table class="datatable table table-hover table-striped excel-sheed">
                <thead>
                  <tr>
                    <?php if(isset($supplierName) && $supplierName == 'hotels'): ?>
                    <th style="vertical-align: middle;">
                      <label class="container-CheckBox">
                        <input type="checkbox" id="check_all" >
                        <span class="checkmark hidden-print" ></span>
                      </label>
                    </th>
                    <?php endif; ?>
                    <?php if(isset($supplierName) && $supplierName == 'restaurants'): ?>
                    <th style="vertical-align: middle;">
                      <label class="container-CheckBox">
                        <input type="checkbox" id="check_all" >
                        <span class="checkmark hidden-print" ></span>
                      </label>
                    </th>
                    <?php endif; ?>
                    <th class="hidden-xs" width="20px">Logo</th>
                    <th>Name</th>
                    <th class="hidden-xs" width="135px">Location</th>
                    <?php if(!isset($supplierName)): ?>
                    <th>Type</th>
                    <?php endif; ?>
                    <th>Phone</th>
                    <th>Email</th>
                    <th class="hidden-xs" width="75">Added By</th>
                    <?php if(isset($supplierName)): ?>
                      <?php if($supplierName == 'restaurants'): ?>
                        <th>Restaurant</th>
                      <?php endif; ?>
                    <?php endif; ?>

                    <?php if(isset($supplierName)): ?>
                      <?php if($supplierName == 'hotels'): ?>
                      <th class="text-center">Room</th>
                      <?php endif; ?>
                    <?php endif; ?>
                    <th class="text-center hidden-xs">Status</th>
                    <?php if(isset($supplierName)): ?>
                      <?php if($supplierName == 'cruises'): ?>
                      <th class="text-center">Program</th>
                      <?php endif; ?>
                    <?php endif; ?>
                    <th width="150" class="text-center">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    	<?php if(isset($supplierName) && $supplierName == 'hotels'): ?>
                        <td style="vertical-align: middle;">
                          <label class="container-CheckBox">
                              <input type="checkbox" class="checkall" name="hotel_checked[]" value="<?php echo e($sup->id); ?>">
                              <span class="checkmark hidden-print"></span>
                          </label>
                        </td>
                      <?php endif; ?> 
                      <?php if(isset($supplierName) && $supplierName == 'restaurants'): ?>
                        <td style="vertical-align: middle;">
                          <label class="container-CheckBox">
                              <input type="checkbox" class="checkall" name="hotel_checked[]" value="<?php echo e($sup->id); ?>">
                              <span class="checkmark hidden-print"></span>
                          </label>
                        </td>
                      <?php endif; ?>                
                      <td class="hidden-xs" width="20px">
                        <img src="<?php echo e(Content::urlthumbnail($sup->supplier_photo, $sup->user_id)); ?>" style="width: 100%"></td>
                      <td><?php echo e($sup->supplier_name); ?></td>
                      <td class="hidden-xs" style="color: #605ca8;"><?php echo e(isset($sup->country->country_name) ? $sup->country->country_name : ''); ?>,  <?php echo e(isset($sup->province->province_name) ? $sup->province->province_name : ''); ?></td>
                      <?php if(!isset($supplierName)): ?>
                        <td><?php echo e(isset($sup->business->name) ? $sup->business->name : ''); ?></td>
                      <?php endif; ?>
                      <td><?php echo e($sup->supplier_phone); ?></td>
                      <td><?php echo e($sup->supplier_email); ?></td>

                      <td class="hidden-xs"><?php echo e($sup->user['fullname']); ?></td> 
                      <?php if(isset($supplierName)): ?>
                        <?php if($supplierName == "hotels"): ?>
                        <td class="text-center"><label title="Number of Room" class="badge"><?php echo e($sup->room->count()); ?></label></td>
                        <?php endif; ?>
                      <?php endif; ?>  
                      <?php if(isset($supplierName)): ?>
                        <?php if($supplierName == 'restaurants'): ?>
                          <td class="text-center"><label class="badge"><?php echo e($sup->res_menu()->where('status',1)->count()); ?></label> <a target="_blank" href="<?php echo e(route('restMenu')); ?>?rest=<?php echo e($sup->id); ?>">View Menu</a></td>
                        <?php endif; ?>
                      <?php endif; ?> 
                      <td class="text-center hidden-xs">
                        <?php if($sup->supplier_status == 1): ?>
                          <label class="icon-list ic_active"></label>
                        <?php else: ?>
                          <label class="icon-list ic_inactive"></label>
                        <?php endif; ?>
                      </td>
                      <?php if(isset($supplierName)): ?>
                        <?php if($supplierName == "cruises"): ?>
                        <td class="text-center"><label class="badge"><?php echo e($sup->crprogram->count()); ?></label></td>
                        <?php endif; ?>
                      <?php endif; ?>                                   
                      <td class="text-right">
                        <?php if(isset($supplierName)): ?>
                          <?php if($supplierName == "transport"): ?>
                            <a target="_blank" href="<?php echo e(route('getDriver', ['id'=> $sup->id])); ?>" title="Preview Driver">
                              <i style="padding:1px 2px; position: relative;top:-5px;" class="btn btn-primary btn-xs a fa fa-list-alt"></i>
                            </a>
                          <?php endif; ?>
                        <?php endif; ?>
                        <a href="<?php echo e(route('getEditSupplier', ['url'=> $sup->id])); ?>" title="Edit Supplier">
                          <label  class="icon-list ic_book_project"></label>
                        </a>
                        <?php if(isset($supplierName)): ?>
                          <?php if($supplierName == "cruises"): ?>
                            <a href="<?php echo e(route('getCruiseProgram',['uri' => $sup->id])); ?>" title="Create River Cruises Program">
                              <label  class="icon-list ic_book_add"></label>
                            </a>
                          <?php endif; ?>
                        <?php endif; ?>                  

                        <?php if(isset($supplierName)): ?>
                          <?php if($supplierName == "hotels"): ?>
                            <a href="<?php echo e(route('getRoomApply',['hotelId' => $sup->id])); ?>" title="Apply Room">
                              <label class="icon-list ic_roomApply"></label>
                            </a>              
                            <a target="_blank" href="<?php echo e(route('supplierReport' ,['reportId' => $sup->id,'type'=> isset($sup->business->slug)? $sup->business->slug :''])); ?>?type=selling" title="View report hotel selling price">
                              <label class="icon-list ic_report"></label>
                            </a> 
                            <a href="<?php echo e(route('getEditHotelInfo', ['url'=> $sup->id])); ?>" title="Edit hotel Infor">
                              <label  class="icon-list ic_book_project"></label>
                            </a>
                            <a target="_blank" href="<?php echo e(route('supplierReport' ,['reportId' => $sup->id,'type'=> isset($sup->business->slug)? $sup->business->slug :''])); ?>?type=contract" title="View report hotel contract">
                              <label  class="icon-list ic_invoice_drop"></label>
                            </a>
                          <?php endif; ?>
                        <?php endif; ?> 
                        <a target="_blank" href="<?php echo e(route('supplierReport' ,['reportId' => $sup->id,'type'=> isset($sup->business->slug)? $sup->business->slug :''])); ?>" title="View <?php echo e(isset($business->name) ? $business->name : 'supplier'); ?> Report">
                          <label class="icon-list ic_report"></label>
                        </a> 
                                      
                        <a href="javascript:void(0)" class="RemoveHotelRate" data-type="supplier" data-id="<?php echo e($sup->id); ?>" title="Remove this Flight Number ?">
                          <label class="icon-list ic_remove"></label>
                        </a>                   
                      </td>                     
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table> 
          </form>               
        </section>
      </div>
    </section>
  </div>  
</div>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.table2excel.min.js')); ?>"></script>
<script type="text/javascript">
  $(".ok_download").click(function(){
    console.log(1)
    var type = $(this).data('type');
    if (type == 'excel') {
      $(".excel-sheed").table2excel({
        exclude: ".noExl",
        name: "Supplier booked report by",
        filename: "Supplier booked report by",
        fileext: ".xls",
        exclude_img: true,
        exclude_links: true,
        exclude_inputs: true            
      });
      return false;
    }
  });
</script>
<script type="text/javascript">
  $(document).ready(function(){
      $(".datatable").DataTable();
    // $(".checkingAction").css({"display": "none"});
      $('input[type="checkbox"]').change(function(){
          var checkBotton = false;
          $(".checkall").each(function(i, v){
            if($(v).prop("checked") == true){
              checkBotton = true;
            }
          });

          if(checkBotton){
            $(".checkingAction").fadeIn();
          }else{
            $(".checkingAction").fadeOut();
          }
      });
  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>