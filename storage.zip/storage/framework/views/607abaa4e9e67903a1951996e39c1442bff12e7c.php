<?php $__env->startSection('title', 'Receivable Form'); ?>
<?php $__env->startSection('active', 'active'); ?>
<?php 
  $active = 'general_ledger'; 
  $subactive = 'account';
  use App\component\Content;
  $countryId = Auth::user()->country_id ? Auth::user()->country_id : 0;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <h3 class="border text-center" style="color:black;text-transform:uppercase;font-weight:bold;">General Ledger</h3>
      <table class=" table table-hover table-striped">
        <tr>
          <th>No</th>
          <th>Item No</th>
          <th>Description</th>
          <th>Qty Ordered</th>
          <th>Qty Received</th>
          <th>Unit Cost</th>
          <th>Account</th>
          <th>Amount</th>
          <th class="text-center">Options</th>
        </tr>           
        <tbody>
          <?php $__currentLoopData = $ledgers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($lg->project_number); ?></td>
            <td></td>                      
            <td></td>
            <td></td> 
            <td></td>                      
            <td></td>
            <td></td>
            <td></td>
            <td class="text-right">            
              <a href="#" title="Edit County">
                <label class="icon-list ic_book_project"></label>
              </a>
              <a href="javascript:void(0)">
                <label class="icon-list ic-trash"></label>
              </a>
            </td>                     
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </section>
  </div>
</div>
<?php echo $__env->make('admin.include.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>