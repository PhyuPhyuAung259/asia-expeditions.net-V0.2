<?php $__env->startSection('title', 'Update User'); ?>
<?php 
  $active = 'users'; 
  $subactive ='user/register';
  use App\component\Content;
  $countryId = Auth::user()->country_id ? Auth::user()->country_id : 0;
?>
<?php $__env->startSection('content'); ?>
<div class="wrapper">
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content"> 
      <div class="row">
        <?php echo $__env->make('admin.include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="col-lg-12"><h3 class="border text-center">User Management</h3></div>
        <form method="POST" action="<?php echo e(route('updateUser')); ?>" enctype="multipart/form-data"> 
          <?php echo e(csrf_field()); ?>

          <section class="col-lg-8 col-lg-offset-2">
            <div class="card"> 
              <div class="row">
                <div class="col-md-6 col-xs-6 col-md-offset-3 text-center">
                    <a id="choosImg" href="javascript:void(0)">Choose Image</a>
                    <input name="image" type='file' id="imgInp" style="opacity: 0;" />
                    <center>
                      <img class="img-responsive" id="blah" src="/storage/avata/<?php echo e($user->picture); ?>" style="display: <?php echo e($user->picture? 'block':'none'); ?>; box-shadow: 0px 1px 0px 8px #ddd; border-radius:5px;"/>
                    </center>   
                    <input type="hidden" name="oldFile" value="<?php echo e($user->picture); ?>">
                </div>
                <input type="hidden" name="eid" value="<?php echo e($user->id); ?>">
                <div class="col-md-6 col-xs-6">
                  <div class="form-group <?php echo e($errors->has('fullname')?'has-error has-feedback':''); ?>">
                    <label>Full Name <span style="color:#b12f1f;">*</span></label> 
                    <input type="text" class="form-control" name="fullname" placeholder="Full Name" value="<?php echo e(old('fullname', $user->fullname)); ?>"> 
                  </div> 
                </div>
                <div class="col-md-6 col-xs-6">
                  <div class="form-group <?php echo e($errors->has('username')?'has-error has-feedback':''); ?>">
                    <label>Username <span style="color:#b12f1f;">*</span></label> 
                    <input type="text" class="form-control" name="username" placeholder="User Name" value="<?php echo e(old('username', $user->name)); ?>" readonly>
                  </div> 
                </div>
                <div class="col-md-3 col-xs-6">
                  <div class="form-group <?php echo e($errors->has('email')?'has-error has-feedback':''); ?>">
                    <label>Email Address <span style="color:#b12f1f;">*</span></label> 
                    <input type="email" class="form-control" name="email" placeholder="virak@asia-expeditions.com" value="<?php echo e(old('email', $user->email)); ?>">
                  </div> 
                </div>
                <div class="col-md-3 col-xs-6">
                  <div class="form-group <?php echo e($errors->has('phone')?'has-error has-feedback':''); ?>">
                    <label>Phone <span style="color:#b12f1f;">*</span></label>
                    <input type="text" class="form-control" name="phone" placeholder="(+855) 1234 567 890" value="<?php echo e(old('phone', $user->phone)); ?>" required>
                  </div>
                </div>
                <div class="col-md-3 col-xs-6">
                  <div class="form-group <?php echo e($errors->has('phone')?'has-error has-feedback':''); ?>">
                    <label>Company Name <span style="color:#b12f1f;">*</span></label>
                      <select class="form-control" name="company" required>
                      <?php $__currentLoopData = App\Company::orderBy('name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($con->id); ?>" <?php echo e($user->company_id == $con->id ? 'selected':''); ?>><?php echo e($con->title); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-3 col-xs-6">
                  <div class="form-group <?php echo e($errors->has('password')?'has-error has-feedback':''); ?>">
                    <label>Position</label> 
                    <input type="text" class="form-control" name="position" placeholder="Position" value="<?php echo e(old('position', $user->position)); ?>" required>
                  </div> 
                </div>
                <div class="col-md-6 col-xs-6">
                  <div class="form-group <?php echo e($errors->has('zipcode')?'has-error has-feedback':''); ?>">
                    <label>Zip/Code</label> 
                    <input type="text" class="form-control" name="zipcode" value="<?php echo e(old('zipcode', $user->postal)); ?>" required>
                  </div> 
                </div>
                <div class="col-md-3 col-xs-6">
                  <div class="form-group">
                    <label>Country <span style="color:#b12f1f;">*</span></label> 
                    <select class="form-control country" name="country" data-type="country" required>
                      <?php $__currentLoopData = App\Country::where('country_status', 1)->orderBy('country_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($con->id); ?>" <?php echo e($user->country_id == $con->id ? 'selected':''); ?>><?php echo e($con->country_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div> 
                </div>
                <div class="col-md-3 col-xs-6">
                  <div class="form-group">
                    <label>City <span style="color:#b12f1f;">*</span></label> 
                    <select class="form-control" name="city" id="dropdown-data" required>
                      <?php $__currentLoopData = App\Province::where(['province_status'=> 1])->orderBy('province_name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($pro->id); ?>" <?php echo e($user->province_id == $pro->id ? 'selected':''); ?>><?php echo e($pro->province_name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div> 
                </div>                  
                <div class="col-md-6 col-xs-6">
                  <div class="form-group <?php echo e($errors->has('password')?'has-error has-feedback':''); ?>">
                    <label>Address</label>
                    <textarea class="form-control" name="address" rows="8" placeholder="Enter ..."><?php echo e(old('address', $user->address)); ?></textarea>
                  </div> 
                </div>
                <div class="col-md-6 col-xs-6">
                  <div class="form-group <?php echo e($errors->has('desc')?'has-error has-feedback':''); ?>">
                    <label>Description</label> 
                    <!-- <textarea class="form-control my-editor" name="desc" rows="8" placeholder="Enter ..."><?php echo e(old('desc', $user->descs)); ?></textarea> -->
                    <div id="container" >
                      <div class="row">
                        <?php echo $__env->make('include.editor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                      </div>
                        <div class="editor1" style="resize:both; overflow:auto;max-width:100%;min-width: 100%;" class="titletou" contenteditable="true"  data-text="Enter comment...."><?php echo old('desc', $user->descs); ?>

                        </div>
                        <textarea class="form-control my-editor" name="desc" id="_desc" rows="7" placeholder="Description..." style="display: none ;"><?php echo old('desc', $user->descs); ?></textarea>
                    </div> 
                  </div> 
                </div>
                <div class="col-md-6 col-xs-6">
                  <div class="form-group">
                    <label>Website</label>&nbsp;
                    <label style="font-weight:400;"> <input type="radio" name="web" value="1" <?php echo e($user->web==1? 'checked':''); ?>>Yes</label>&nbsp;&nbsp;
                    <label style="font-weight:400;"> <input type="radio" name="web" value="0" <?php echo e($user->web==0? 'checked':''); ?>>No</label>
                  </div> 
                </div>
              </div>
            </div>   
            <div class="modal-footer" style="padding: 5px 13px;">
                <button type="submit" class="btn btn-success btn-flat btn-sm">Update Now</button>
                <a href="<?php echo e(route('userList')); ?>" class="btn btn-primary btn-flat btn-sm" data-dismiss="modal">Cancel</a>
            </div>           
          </section>
        </form>
      </div>
    </section>
  </div>  
</div>
<script type="text/javascript">
  $(document).ready(function(){
  $('.editor1').bind('change keyup input',function(){
      var gettext = $(document).find('.editor1').html();
      $('#_desc').val(gettext);
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>