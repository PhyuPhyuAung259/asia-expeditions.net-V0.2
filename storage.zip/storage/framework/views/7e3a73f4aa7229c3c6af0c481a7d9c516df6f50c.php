<?php $__env->startSection('title', 'System'); ?>
<?php $__env->startSection('active', 'active'); ?>
<?php $active = 'active'; 
  $subactive ='users';?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('admin.include.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('admin.include.menuleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="content-wrapper">
    <section class="content">        
        <?php if(Auth::check()): ?>   
          <?php 
              $depart_id  = [];
              $roleDepart = \App\Role::find(\Auth::user()->role_id);
              if (!empty($roleDepart->department )) {
                foreach ($roleDepart->department as $key => $dep) {
                    $depart_id[] = $dep->pivot->department_id;
                }
              }
              $getDepart =\App\Department::where(['status'=>1, 'type'=>2])->whereIn("id", $depart_id)->orderBy('order')->get();
            ?>   
          <?php $__currentLoopData = $getDepart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
              $getSubDepartment = \App\DepartmentMenu::getDepartment_menu($dep->id);
              ?>
              <?php if($getSubDepartment->count() > 0): ?>
                <div class="col-sm-2 col-md-2 col-lg-1 col-xs-4 no-padding ">
                    <a href="<?php echo e(route('adminhome')); ?>/<?php echo e($dep->slug); ?>">
                      <div class="small-box btn btn-default" style="<?php echo e($dep->style); ?>">
                          <div class="icon">
                            <i class="<?php echo e($dep->icon); ?>"></i>
                          </div>
                          <div>
                          <span class="text-shadow"><?php echo e($dep->name); ?></span>
                        </div>  
                      </div>
                    </a>
                </div>     
              <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </section>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>