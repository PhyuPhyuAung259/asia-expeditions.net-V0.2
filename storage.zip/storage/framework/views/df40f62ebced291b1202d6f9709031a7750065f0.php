<?php $__env->startSection('title', config('app.title')); ?>
<?php
  use App\component\Content;
?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">    
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
<?php $__env->startSection('content'); ?>
<div class="wrapper-login">
  <div class="col-md-4 offset-md-4">
    <center>
      <img src="<?php echo e(url(config('app.logo'))); ?>" style="width: 30%;">
      <p><strong style="text-shadow: 0px 1px 3px #f8f9fa;font-weight: 700;">COMPLETE TOUR BOOKING SYSTEM</strong></p>
    </center>
      <?php echo $__env->make('include.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="card" style="padding:12px;">  
      <form action="<?php echo e(route('doLogin')); ?>" method="POST">     
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
          <label for="phone">Email Address</label>
          <input type="email" name="email" id="email" class="form-control" placeholder="Email" required="required" value="<?php echo e(old('email')); ?>">
        </div>
        <div class="form-group">
          <label for="phone">Password</label>            
          <input type="password" name="password" id="password" class="form-control" placeholder="Password" required="required" value="<?php echo e(old('password')); ?>">
        </div>
        <div class="form-group">
          <label><input type="checkbox" name="remember">Remember me ?</label>
        </div>
        <div class="form-group">
          <input type="submit" name="btnLogin" class="btn btn-info">
        </div>
      </form>   
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>